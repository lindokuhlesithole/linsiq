# Plan — SWEALTH OS v2: Flock-Safety-class AI Security Platform

## Goal
1. **Improve** the user's master prompt → deliver "SWEALTH OS — Master Prompt v2" (expanded with Flock Safety-grade capabilities: ALPR/hotlists, camera network onboarding, gunshot/audio detection, vehicle search, evidence sharing, real-time crime center).
2. **Build the most functional app** from that improved prompt — a working, dense, tactical React webapp with simulated real-time data layer (swappable for Supabase later).

## Stage 1 — Skill loading & prompt improvement
- Load `vibecoding-webapp-swarm` SKILL.md (orchestration guidance for the build).
- Orchestrator writes the improved Master Prompt v2 (`/mnt/agents/output/SWEALTH-OS-Master-Prompt-v2.md`), informed by the original spec + Flock Safety platform capabilities (ALPR, hotlists, vehicle search, Raven-style audio detection, camera network, evidence/case sharing, real-time crime center).

## Stage 2 — App build (swarm)
- Load `webapp-building-swarm` SKILL.md + `swarm-workspace` at this stage.
- Set up shared coordination repo + worktrees per the swarm-workspace contract.
- Delegate to build agents (parallel by module where independent):
  - App shell: routing, Sidebar, TopBar, theme tokens (Tactical SOC: navy #0A192F, cyan #00D4AA, amber #FF9F1C, red #E71D36, Inter + JetBrains Mono)
  - Simulated data layer: types, seed data (3 tenants), realtime simulator engine (cameras, drones, guards, alerts, plates, gunshot events)
  - Routes: / (Fleet Command), /cameras (network + onboarding wizard), /alpr (plate feed, hotlists, vehicle search), /alerts (AI Alert Center), /operations (PTZ, drones, guards), /incidents (cases + evidence export), /analytics, /map, /settings, /login
- Reviewer subagent validates against prompt v2 checklist.

## Stage 3 — Validate, build, deliver
- Fix issues from review, production build.
- Call `mshtools-website_version_manager` build_version (type: static).
- Final deliverables: improved prompt file + built webapp version URL.
