# SWEALTH OS — Master Development Prompt v2 (Improved)

> **What changed vs v1:** repositioned from "generic SOC dashboard" to a **Flock Safety-class community safety platform**: camera network + license plate recognition (ALPR) + hotlists + audio/gunshot detection + vehicle search + case/evidence management + real-time crime center. Also added: explicit acceptance criteria per feature, state machines, realistic seed data rules, role-based UI permissions, error/empty/loading state requirements, performance budgets, non-goals, and phase gates. Every section is written so an AI builder can execute it without ambiguity.

---

## 0. Product Definition (read first — every decision flows from this)

**SWEALTH OS** is a multi-tenant, AI-powered **community safety platform** for a South African security technology company. Like Flock Safety, it turns a distributed network of cameras into an intelligent crime-fighting system:

1. **Capture** — fixed ALPR cameras read every plate; live-view cameras stream video; acoustic sensors detect gunshots; drones patrol autonomously; guards carry the mobile link.
2. **Detect** — AI pipelines turn raw feeds into structured events: plate reads, hotlist hits, person/vehicle detections, perimeter breaches, gunshot triangulations, device health failures.
3. **Decide** — a real-time Alert Center triages events by severity with AI summaries, confidence scores, and evidence attached.
4. **Act** — dispatch guards/drones, control PTZ cameras, escalate per routing rules, and open case files.
5. **Solve** — vehicle/plate search, case management, evidence export, and audit trails help close cases and prove compliance.

**Phase 1 target:** a single demo tenant, **"Silver Lakes Estate, Pretoria"**, running on a fully client-side **simulated real-time data layer** that implements the exact contracts of the production Supabase backend, so the backend can be grafted later without touching the UI. Two additional demo tenants exist to prove tenant switching and data isolation: "Waterfall Heights Estate, Midrand" and "Camps Bay Marina, Cape Town".

**Success looks like:** an operator can open the app and, within 60 seconds, see the estate's live camera wall, spot a hotlisted vehicle entering a gate, watch the alert route to a supervisor, acknowledge it, dispatch the nearest guard, pull up the plate's full sighting history, and export an evidence pack — all in one continuous, believable, real-time session.

---

## 1. Tech Stack

| Layer | Phase 1 (this build) | Production target (Phase 2+) |
|---|---|---|
| Framework | React 19 + TypeScript + Vite 7 (SPA, react-router) | TanStack Start or Next.js — same component tree |
| Styling | Tailwind CSS + shadcn/ui primitives | Same |
| Icons | Lucide React | Same |
| Charts | Recharts | Same |
| Data layer | **Simulated realtime engine** (`src/lib/simulator.ts` + `src/lib/store.ts`) exposing typed hooks identical in signature to the future Supabase hooks; persisted to localStorage so state survives reloads | Supabase Postgres + Realtime + Storage |
| Auth | Guest/demo session + mode toggle (localStorage `swealth.auth_mode`) | Supabase Auth + RLS |
| Maps | Inline SVG tactical map with estate street geometry (no external tiles) | MapLibre + satellite tiles |
| PDF export | jspdf + jspdf-autotable (evidence packs, QA reports) | Same |

**Non-negotiable:** all UI code reads data ONLY through the hooks in `src/hooks/` — never directly from the simulator. This is the seam that lets the backend be swapped in later.

---

## 2. Visual Identity — "Tactical SOC"

The interface must feel like a professional real-time crime center, not a SaaS dashboard. Dense, dark, precise.

- Background: deep navy `#0A192F`; surface panels: translucent navy with 1px `rgba(100,255,218,0.08)` borders
- Primary / operational green-cyan: `#00D4AA` (live, OK, selected)
- Warning amber: `#FF9F1C` · Danger red: `#E71D36` · Info blue: `#4CC9F0` (used sparingly)
- Typography: **JetBrains Mono** for all data (timestamps, plates, IDs, telemetry, coordinates, tabular numbers); **Inter** for UI text. Weights 400/500/600 only.
- Aesthetic: sharp edges (`rounded-sm` max), dense data, monospace timestamps everywhere, animated "LIVE" dots, scan-line/grid textures on camera tiles, status pills with colored dot + uppercase 10px labels.
- Semantic tokens only (e.g. `bg-surface`, `text-primary`, `border-line`). No hardcoded `text-white`/`bg-black`. No purple/indigo, no gradients, no rounded-3xl.

---

## 3. Data Model (Phase 1 simulated; mirrors production schema)

All entities carry `org_id` for tenant scoping. Core types live in `src/lib/types.ts`.

**organizations** — id, name, slug, location, center_lat/lng, threat_level (derived), created_at.

**cameras** — id, org_id, name, zone, kind (`fixed_alpr | ptz | bullet | doorbell | drone_mount`), rtsp_url, resolution, fps, status (`online | offline | recording | motion | degraded`), ptz_enabled, storage_used_pct, lat/lng, heading_deg (field-of-view direction for map), last_heartbeat, firmware, install_date.

**plate_reads** — id, org_id, camera_id, plate (SA format, e.g. `GP 482-913`, `CA 552-210`), province, vehicle_color, vehicle_make, vehicle_type (`sedan | hatch | suv | bakkie | truck | motorcycle | taxi`), direction (`inbound | outbound`), confidence, snapshot_id, hotlist_hit (bool), captured_at. **This is the Flock-core table.** Volume: a busy gate camera generates ~40–120 reads/hour in the simulator.

**hotlists** — id, org_id, name, kind (`stolen_vehicle | wanted_person_vehicle | custom | national_sync`), source, enabled, entries: plate, reason, priority (`critical | high | medium`), added_by, added_at, notes. Seed examples: "SAPS Stolen Vehicles — Gauteng Sync", "Estate Watchlist — Repeat Offenders", "Contractor Blacklist".

**audio_events** — id, org_id, sensor_id, kind (`gunshot | glass_break | scream | explosion`), confidence, lat/lng (triangulated), triangulation_radius_m, sensors_confirmed (int), status, captured_at. (Flock "Raven"-equivalent.)

**drones** — id, org_id, callsign, model, status (`idle | patrolling | returning | charging | responding`), battery_pct, altitude_m, speed_mps, signal_pct, lat/lng, base_lat/lng, waypoints jsonb, current_waypoint, last_heartbeat.

**guards** — id, org_id, full_name, badge_no, shift (`day | night | swing`), status (`on_duty | off_duty | responding | on_break`), lat/lng, alerts_resolved, avg_response_sec, phone.

**alerts** — id, org_id, type (`hotlist_hit | perimeter_breach | unidentified_person | gunshot | drone_anomaly | offline_device | fire_smoke | loitering | tailgating`), severity (`critical | high | medium | low`), source_kind (`camera | alpr | audio | drone | guard | system`), source_id, source_name, title, ai_summary, ai_confidence, status (`new | acknowledged | responding | resolved | false_alarm`), assigned_guard_id, lat/lng, plate_read_id (nullable), created_at, updated_at, acknowledged_by, acknowledged_at, resolved_at.

**alert_evidence** — id, org_id, alert_id, kind (`snapshot | plate_crop | video_clip | audio_clip | thermal`), storage_path (Phase 1: generated canvas/data-URL or procedural SVG), captured_at.

**incidents** (case files) — id, org_id, case_no (`SL-2026-0042`), title, status (`open | investigating | closed | escalated_saps`), priority, linked_alert_ids, linked_plate_reads, assigned_investigator, summary, created_at, closed_at, disposition.

**alert_routing_rules** — id, org_id, severity, role (`supervisor | operator | manager | guard`), channel (`push | sms | email | radio`), escalate_after_sec, enabled. Unique (org_id, severity).

**ptz_commands** — id, org_id, camera_id, action (`pan_left | pan_right | tilt_up | tilt_down | zoom_in | zoom_out | preset_recall | preset_save`), payload, status (`dispatched | acknowledged | completed | failed`), timestamps, created_by.

**audit_log** — id, org_id, actor, action, entity_kind, entity_id, detail, created_at. **Every** acknowledge/resolve/dispatch/export/hotlist-edit writes here. (CJIS-style accountability.)

---

## 4. The Simulated Real-Time Engine (`src/lib/simulator.ts`)

Phase 1's heart. Requirements:

- **Deterministic-ish realism:** seeded RNG per tenant so reloads show a consistent world (persist state in localStorage; reseed only via Settings → "Reset demo data").
- **Tick loop:** drones advance along waypoints (great-circle interpolation, altitude/speed/battery drift); camera heartbeats update; guards on patrol routes move slowly; storage_used_pct creeps.
- **Event generator:** weighted random events per camera/sensor — plate reads stream continuously (gates busiest at 07:00–09:00 / 16:30–18:30 simulation time); hotlist hits are rare (~1 per 400 reads); a gunshot event may trigger every few hours; perimeter breaches at night; devices occasionally go offline and recover.
- **Causal chains (critical for believability):** a hotlist plate read → creates a `hotlist_hit` alert with the plate crop attached → if unacknowledged past `escalate_after_sec`, severity bumps and a second routing fires. A gunshot → nearest drone auto-changes to `responding` and flies to the triangulation point → drone arrival generates a follow-up evidence event.
- **Live clock:** TopBar clock is real wall-clock; simulated timestamps stay within the last 48h window.
- **Seed data:** 3 tenants × (8–14 cameras incl. ≥3 ALPR gate cameras, 2–3 drones, 5–8 guards, 3 hotlists with 15–40 entries, 48h of plate reads (~3–6k rows for the demo tenant — paginate/virtualize accordingly), 60–120 historical alerts, 4–8 incidents, full audit trail).
- **South African realism:** SA plate formats (`GP`, `CA`, `NW`, `ZN` etc.), SA names (e.g. Thandi Mokoena, Pieter van der Merwe, Sipho Ndlovu), real Pretoria/Cape Town geography for coordinates, vehicles common in SA (Toyota Hilux, VW Polo, Ford Ranger, Isuzu D-Max, Toyota Quantum taxis).

---

## 5. Routes & Features (with acceptance criteria)

### `/` — Fleet Command (default)
- KPI strip: cameras online, ALPR reads (24h), hotlist hits (24h), open alerts, avg response time, estate threat level (LOW/GUARDED/ELEVATED/HIGH, derived from open critical/high alerts).
- Live camera wall (`CameraTile`): procedural live-feed simulation (canvas or animated SVG scene — moving vehicle dots at gates, scan noise, timestamp burn-in, REC dot), status, zone, resolution/FPS/storage.
- Tactical SVG map (`TacticalMap`): estate streets, camera cones (heading + FOV), drone positions with trails, guard markers, pulsing alert markers. Click a marker → popover with entity details + "View" deep-link.
- Right rail: live alert ticker + plate-read ticker (latest 10, hotlist rows highlighted red).
- **Acceptance:** page renders ≤150ms after data load; tickers update live without full re-render (memoized rows).

### `/cameras` — Camera Network
- Camera inventory table: status, kind, zone, health (heartbeat age, storage, firmware), Uptime 24h sparkline.
- **Add Camera wizard** (the Flock "connect any camera" flow): step 1 type (ALPR fixed / PTZ / bullet / doorbell), step 2 connection (RTSP/ONVIF URL + credentials), step 3 placement (click on mini-map to set lat/lng + heading), step 4 AI detection toggles (plates, persons, loitering, fire/smoke), review → camera appears in inventory with status `online` and joins the simulator.
- Camera detail drawer: live procedural feed, PTZ controls (if enabled) with the 3-stage command lifecycle (Dispatched → ACK → Done, 180–400ms ACK, 600–2500ms mechanical, ~4% failure), AI detection toggles, health tab, recent plate reads from this camera.
- **Acceptance:** wizard creates a fully functional camera that shows on map, wall, and generates events within 5s.

### `/alpr` — Plate Intelligence (the Flock core)
- **Live plate feed:** virtualized table of plate reads (plate in large mono, province, vehicle fingerprint: color/make/type, camera, direction, confidence, HOT badge on hits). Filters: camera, direction, time range, hotlist-only toggle. Search: partial plate (`482` matches `GP 482-913`).
- **Vehicle search** (Flock "Vehicle Fingerprint"): filter by any combination of plate fragment, color, make, body type, camera/zone, date range → results grid with snapshots; click → **vehicle profile**: full sighting timeline, mini-map of sightings, cameras seen on, associated alerts, "Add to hotlist" action.
- **Hotlist manager:** list hotlists (kind, entries count, enabled toggle, source); entries table with add/remove/import (paste CSV); each entry: plate, reason, priority, notes. Editing writes to audit_log.
- **Acceptance:** searching `CA 5` returns matching reads instantly; adding a plate to a hotlist causes that plate's next simulated read to fire a critical alert within 30s.

### `/alerts` — AI Alert Center
- KPI tiles by severity; filter chips; full-text search across titles + AI summaries; grouped/deduplicated feed (`GroupedAlertRow`) collapsing repeats from same source+type until resolved.
- Alert detail drawer: AI summary, confidence meter, evidence grid (snapshots/plate crops/audio clips), linked plate read (if hotlist hit → jump to vehicle profile), timeline, acknowledge (records operator name + timestamp), assign guard, resolve / false-alarm with reason.
- Audible ping + toast on new high/critical alerts with mute toggle (WebAudio, no asset files).
- Routing badges on rows (e.g. `→ SUPERVISOR · SMS`, escalates visibly when timer overruns).
- **Acceptance:** acknowledging an alert updates everywhere (feed, KPIs, map, audit log) within one frame.

### `/operations` — Live Operations
- Large camera grid with PTZ detail panels; drone patrol controls (start/pause/return-to-base, waypoint editor on SVG map — add/drag/remove); guard roster with live positions and one-click dispatch to an alert location (guard status → `responding`, ETA computed from distance, position interpolates on map).

### `/incidents` — Case Management
- Case list (case_no, title, status, priority, linked alerts count, investigator). Case detail: linked alerts + plate reads, evidence gallery, investigator notes (append-only), status workflow (open → investigating → escalated_saps/closed).
- **Evidence pack export:** one click generates a PDF (jspdf) — case summary, timeline table, plate sighting table, evidence thumbnails, chain-of-custody audit excerpt. Writes to audit_log.
- **Acceptance:** PDF downloads and opens; contains ≥ the timeline + plate tables.

### `/analytics` — Intelligence
- Charts (Recharts): alerts over time (stacked by severity), plate-read volume by hour (gate heat curve), response-time distribution, device uptime, hotlist hit outcomes (resolved vs false alarm), guard performance leaderboard. All derived live from the data layer — no hardcoded chart data.

### `/map` — Full-screen Tactical Map
- Full-viewport SVG map with layer toggles (cameras + FOV cones, ALPR gates, drones, guards, audio sensor radii, alert heat). Time scrubber replays the last 2h of alert markers.

### `/settings` — Settings
- Auth mode toggle (guest ↔ production-auth placeholder), tenant/org switcher (proves data isolation — every number on every page changes), alert routing rules editor, hotlist sync status, demo data reset, audit log viewer, RLS/data-isolation indicator.
- Typography/contrast QA block (from v1) kept as a collapsible diagnostic section.

### `/login` — Secure Terminal
- Themed login. Guest mode auto-redirects to `/`. Session restore from localStorage.

---

## 6. Shared Components (`src/components/soc/`)

`AppShell` (Sidebar + TopBar), `TopBar` (live clock, stream count, threat level, tenant switcher, realtime status dot, user badge), `StatusPill`, `SeverityBadge`, `ThreatLevelGauge`, `CameraTile` (procedural live feed), `CameraDetailPanel`, `PtzPad` + `PtzLifecycleTracker`, `TacticalMap` (+ `MapMarker`, `FovCone`, `DroneTrail`), `PlateReadRow`, `PlateCard`, `HotlistEditor`, `VehicleSearchPanel`, `AlertRow`, `GroupedAlertRow`, `AlertDetailDrawer`, `EvidenceGrid`, `IncidentTimeline`, `GuardRoster`, `WaypointEditor`, `KpiTile`, `EmptyState`, `SkeletonRow`, `ErrorBoundary` (per-route).

**Every list must have:** loading skeleton, empty state with actionable copy, and error state. No blank screens, ever.

---

## 7. Hooks Contract (`src/hooks/useData.ts`)

`useOrg()`, `useOrgSwitch()`, `useCameras()`, `usePlateReads(filters)`, `useHotlists()`, `useAudioEvents()`, `useDrones()`, `useGuards()`, `useAlerts(filter)`, `useIncidents()`, `useAuditLog()`, `useRealtimeStatus()`, `useClock()`, plus mutations: `acknowledgeAlert()`, `resolveAlert()`, `dispatchGuard()`, `sendPtzCommand()`, `addCamera()`, `addHotlistEntry()`, `exportEvidencePack()`, `createIncident()`.

All hooks scope to active org (`localStorage swealth.active_org_id`). Mutations write audit_log entries. Hooks emit fine-grained updates (subscribers only re-render on their slice).

---

## 8. Security & Permissions (Phase 1 simulated, production-shaped)

- Roles: `admin | supervisor | operator | manager | guard`. Phase 1 guest = `Estate Manager` (full demo access); Settings lets you preview the UI as `operator` (read-only hotlists, no PTZ) and `guard` (mobile-ish view) to prove role-based UI.
- PTZ + hotlist edits + evidence export require operator+ — buttons disable with tooltip otherwise.
- Production section (kept from v1, applies when Supabase lands): tenant-scoped RLS via `has_org_role`, no `USING(true)`, private evidence bucket with org-prefixed paths, roles in `user_organizations` only.

---

## 9. Engineering Rules

1. No lorem ipsum, no dead buttons — every control does something visible.
2. Components small/focused; prefer search-replace edits over rewrites.
3. Performance: virtualize any list >100 rows; keep the 1s simulator tick from re-rendering the whole tree (React.memo + selector hooks).
4. Every route: unique `<title>` + meta description; per-route error boundary with retry.
5. Realistic data only — plates, names, places, and timestamps must all be internally consistent (an alert's `source_id` must resolve; a plate read's camera must exist).
6. Accessibility: keyboard-navigable drawers/menus, visible focus rings, WCAG AA contrast on text (check the cyan-on-navy ratios).
7. Build must pass with zero TypeScript errors. Verify with production build + screenshots of every route.

## 10. Non-Goals (Phase 1)

- Real video streaming (procedural feeds instead), real Supabase (simulated layer), mobile apps, multi-language, billing. Do NOT stub these with broken UI — omit them.

## 11. Definition of Done (gate before delivery)

- [ ] All 9 routes render with live simulated data, zero console errors
- [ ] Hotlist workflow end-to-end: add plate → hit → alert → acknowledge → dispatch → resolve → incident → PDF export
- [ ] Camera onboarding wizard end-to-end
- [ ] Tenant switch proves isolation (all numbers change)
- [ ] Role preview proves permissions
- [ ] Production build passes; every route screenshot-reviewed
