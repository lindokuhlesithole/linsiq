/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        /* SWEALTH OS — Tactical SOC semantic tokens (design.md §2) */
        canvas: '#060D1A',
        base: '#0A192F',
        surface: 'rgba(17,34,64,0.72)',
        'surface-solid': '#112240',
        raised: '#16294A',
        inset: '#081226',
        line: 'rgba(100,255,218,0.08)',
        'line-strong': 'rgba(100,255,218,0.18)',
        'danger-line': 'rgba(231,29,54,0.35)',

        primary: '#E6F1FF',
        secondary: '#A8B2D1',
        muted: '#5C6B8A',
        'on-accent': '#04101F',

        accent: '#00D4AA',
        'accent-dim': 'rgba(0,212,170,0.12)',
        warning: '#FF9F1C',
        'warning-dim': 'rgba(255,159,28,0.12)',
        danger: '#E71D36',
        'danger-dim': 'rgba(231,29,54,0.14)',
        info: '#4CC9F0',
        'info-dim': 'rgba(76,201,240,0.12)',
        'severity-low': '#5C6B8A',

        /* shadcn/ui compatibility (mapped onto the same palette) */
        border: 'rgba(100,255,218,0.08)',
        input: 'rgba(100,255,218,0.08)',
        ring: '#00D4AA',
        background: '#0A192F',
        foreground: '#E6F1FF',
        destructive: { DEFAULT: '#E71D36', foreground: '#E6F1FF' },
        popover: { DEFAULT: '#112240', foreground: '#E6F1FF' },
        card: { DEFAULT: '#112240', foreground: '#E6F1FF' },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      borderRadius: {
        sm: '2px',
        DEFAULT: '2px',
        md: '2px',
        lg: '2px',
        xl: '2px',
      },
      boxShadow: {
        drawer: '0 8px 24px rgba(2,6,17,0.55)',
      },
      keyframes: {
        'live-pulse': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.35' },
        },
        'rec-blink': {
          '0%, 60%': { opacity: '1' },
          '61%, 100%': { opacity: '0.15' },
        },
        shimmer: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' },
        },
        'scan-band': {
          '0%': { transform: 'translateY(-40px)' },
          '100%': { transform: 'translateY(400px)' },
        },
        shake: {
          '0%, 100%': { transform: 'translateX(0)' },
          '20%': { transform: 'translateX(-3px)' },
          '40%': { transform: 'translateX(3px)' },
          '60%': { transform: 'translateX(-2px)' },
          '80%': { transform: 'translateX(2px)' },
        },
        'alert-ring': {
          '0%': { transform: 'scale(0.4)', opacity: '0.9' },
          '100%': { transform: 'scale(2.2)', opacity: '0' },
        },
      },
      animation: {
        'live-pulse': 'live-pulse 1.6s ease-in-out infinite',
        'rec-blink': 'rec-blink 1.2s steps(1) infinite',
        shimmer: 'shimmer 1.4s linear infinite',
        'scan-band': 'scan-band 6s linear infinite',
        shake: 'shake 300ms ease-in-out 2',
        'alert-ring': 'alert-ring 1.6s ease-out infinite',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
};
