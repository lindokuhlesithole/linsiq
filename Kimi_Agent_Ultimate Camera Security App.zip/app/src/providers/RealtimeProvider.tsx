/**
 * RealtimeProvider — starts/stops the simulator singleton with the app shell
 * and mounts the toast host. Drawers opened from toasts are handled by the
 * Layout via the `swealth:open-alert` window event.
 */
import { useEffect } from 'react';
import type { ReactNode } from 'react';
import { startSimulator, stopSimulator } from '@/lib/simulator';
import { ToastHost } from '@/components/soc/Toast';

export function RealtimeProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    startSimulator();
    return () => stopSimulator();
  }, []);

  return (
    <>
      {children}
      <ToastHost
        onToastClick={(alertId) => window.dispatchEvent(new CustomEvent('swealth:open-alert', { detail: { alertId } }))}
      />
    </>
  );
}
