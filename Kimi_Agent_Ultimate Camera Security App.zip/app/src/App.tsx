import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { RealtimeProvider } from '@/providers/RealtimeProvider';
import Layout from '@/components/Layout';
import FleetCommand from '@/pages/FleetCommand';
import Cameras from '@/pages/Cameras';
import Alpr from '@/pages/Alpr';
import Alerts from '@/pages/Alerts';
import Operations from '@/pages/Operations';
import Incidents from '@/pages/Incidents';
import Analytics from '@/pages/Analytics';
import TacticalMapPage from '@/pages/TacticalMapPage';
import Settings from '@/pages/Settings';
import Login from '@/pages/Login';
import Stub from '@/pages/Stub';

export default function App() {
  return (
    <BrowserRouter>
      <RealtimeProvider>
        <Routes>
          <Route path="login" element={<Login />} />
          <Route element={<Layout />}>
            <Route index element={<FleetCommand />} />
            <Route path="cameras" element={<Cameras />} />
            <Route path="alpr" element={<Alpr />} />
            <Route path="alerts" element={<Alerts />} />
            <Route path="operations" element={<Operations />} />
            <Route path="incidents" element={<Incidents />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="map" element={<TacticalMapPage />} />
            <Route path="settings" element={<Settings />} />
            <Route path="*" element={<Stub name="Not Found" route="404" />} />
          </Route>
        </Routes>
      </RealtimeProvider>
    </BrowserRouter>
  );
}
