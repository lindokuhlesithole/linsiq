/**
 * WaypointEditor — SVG mini-map route editor for the selected drone
 * (operations.md §2 EDIT WAYPOINTS). Click empty map to append a waypoint,
 * drag dots to move, right-click a dot (or its × chip) to remove, click the
 * midpoint + handles to insert. Estate geometry comes from the shared
 * procedural tenant geometry; live fleet/guard/alert positions render as
 * context so the operator edits against reality.
 */
import { memo, useCallback, useMemo, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent, MouseEvent as ReactMouseEvent } from 'react';
import { Home, Plus, X } from 'lucide-react';
import type { Alert, Drone, Guard, Waypoint } from '@/lib/types';
import { useActiveOrgId } from '@/hooks/useData';
import { getTenantGeometry } from '@/lib/procedural';
import { fmtCoord } from '@/lib/format';
import { SocButton, GhostButton } from '@/components/soc';
import { SEVERITY_HEX } from '@/components/soc';
import { routeLengthM } from './droneOverrides';
import { cn } from '@/lib/utils';

const INFO = '#4CC9F0';
const ACCENT = '#00D4AA';
const WARNING = '#FF9F1C';

export const WaypointEditor = memo(function WaypointEditor({
  drone,
  fleet,
  guards,
  alerts,
  draft,
  onDraftChange,
  onSave,
  onDiscard,
}: {
  drone: Drone;
  fleet: Drone[];
  guards: Guard[];
  alerts: Alert[];
  draft: Waypoint[];
  onDraftChange: (wpts: Waypoint[]) => void;
  onSave: () => void;
  onDiscard: () => void;
}) {
  const orgId = useActiveOrgId();
  const geo = useMemo(() => getTenantGeometry(orgId), [orgId]);
  const svgRef = useRef<SVGSVGElement>(null);
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [selIdx, setSelIdx] = useState<number | null>(null);
  const dragMoved = useRef(false);

  const toSvg = useCallback((clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const ctm = svg.getScreenCTM();
    if (!ctm) return { x: 0, y: 0 };
    const pt = new DOMPoint(clientX, clientY).matrixTransform(ctm.inverse());
    return { x: pt.x, y: pt.y };
  }, []);

  const pts = useMemo(() => draft.map((w) => geo.project(w.lat, w.lng)), [draft, geo]);
  const dronePos = geo.project(drone.lat, drone.lng);
  const basePos = geo.project(drone.base_lat, drone.base_lng);

  const pathD = useMemo(() => {
    if (pts.length === 0) return '';
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) d += ` L ${pts[i].x} ${pts[i].y}`;
    if (pts.length > 2) d += ' Z';
    return d;
  }, [pts]);

  const midpoints = useMemo(() => {
    if (pts.length < 2) return [] as { x: number; y: number; insertAt: number }[];
    const out: { x: number; y: number; insertAt: number }[] = [];
    const segs = pts.length > 2 ? pts.length : pts.length - 1;
    for (let i = 0; i < segs; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      out.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, insertAt: i + 1 });
    }
    return out;
  }, [pts]);

  const lengthM = routeLengthM(draft);
  const loopMin = lengthM / 8.5 / 60;

  const onBackgroundClick = (e: ReactMouseEvent) => {
    if (dragMoved.current) return; // that was a drag release, not a click
    const p = toSvg(e.clientX, e.clientY);
    const ll = geo.unproject(p.x, p.y);
    const next = [...draft, { lat: ll.lat, lng: ll.lng, label: `WP-${draft.length + 1}` }];
    onDraftChange(next);
    setSelIdx(next.length - 1);
  };

  const onWaypointPointerDown = (i: number) => (e: ReactPointerEvent) => {
    e.stopPropagation();
    if (e.button !== 0) return;
    (e.target as Element).setPointerCapture(e.pointerId);
    dragMoved.current = false;
    setDragIdx(i);
    setSelIdx(i);
  };

  const onPointerMove = (e: ReactPointerEvent) => {
    if (dragIdx === null) return;
    dragMoved.current = true;
    const p = toSvg(e.clientX, e.clientY);
    const ll = geo.unproject(
      Math.min(geo.width, Math.max(0, p.x)),
      Math.min(geo.height, Math.max(0, p.y)),
    );
    onDraftChange(draft.map((w, i) => (i === dragIdx ? { ...w, lat: ll.lat, lng: ll.lng } : w)));
  };

  const endDrag = () => {
    setDragIdx(null);
    /* clear the moved flag after the click event has had a chance to read it */
    setTimeout(() => {
      dragMoved.current = false;
    }, 0);
  };

  const removeWaypoint = (i: number) => {
    const next = draft.filter((_, idx) => idx !== i).map((w, idx) => ({ ...w, label: `WP-${idx + 1}` }));
    onDraftChange(next);
    setSelIdx(null);
  };

  const insertAt = (insertIdx: number) => {
    const a = draft[insertIdx - 1];
    const b = draft[insertIdx % draft.length];
    if (!a || !b) return;
    const mid: Waypoint = { lat: (a.lat + b.lat) / 2, lng: (a.lng + b.lng) / 2, label: `WP-${insertIdx + 1}` };
    const next = [...draft.slice(0, insertIdx), mid, ...draft.slice(insertIdx)].map((w, idx) => ({
      ...w,
      label: `WP-${idx + 1}`,
    }));
    onDraftChange(next);
    setSelIdx(insertIdx);
  };

  const selPt = selIdx !== null ? pts[selIdx] : null;

  return (
    <div className="relative flex h-full min-h-0 flex-col">
      <div className="scan-grid relative min-h-0 flex-1 overflow-hidden bg-inset">
        <svg
          ref={svgRef}
          viewBox={geo.viewBox}
          className="h-full w-full cursor-crosshair"
          preserveAspectRatio="xMidYMid meet"
          onClick={onBackgroundClick}
          onPointerMove={onPointerMove}
          onPointerUp={endDrag}
          onPointerLeave={endDrag}
        >
          {/* estate geometry */}
          {geo.water && <path d={geo.water} fill="rgba(76,201,240,0.07)" stroke="rgba(76,201,240,0.18)" strokeWidth="1" />}
          {geo.streets.map((d, i) => (
            <path key={i} d={d} fill="none" stroke="#1B2F52" strokeWidth={i === 0 ? 10 : 6} strokeLinecap="round" />
          ))}
          <path d={geo.boundary} fill="none" stroke="rgba(100,255,218,0.25)" strokeWidth="1.4" strokeDasharray="7 5" />
          {geo.zones.map((z) => (
            <text key={z.label} x={z.x} y={z.y} fontFamily='"JetBrains Mono", monospace' fontSize="11" fill="#5C6B8A" letterSpacing="1.5">
              {z.label}
            </text>
          ))}

          {/* context: other drones */}
          {fleet
            .filter((d) => d.id !== drone.id)
            .map((d) => {
              const p = geo.project(d.lat, d.lng);
              const color = d.status === 'responding' ? '#E71D36' : INFO;
              return (
                <polygon
                  key={d.id}
                  points={`${p.x},${p.y - 6} ${p.x + 5.5},${p.y + 4.5} ${p.x - 5.5},${p.y + 4.5}`}
                  fill={color}
                  opacity="0.45"
                  stroke="#060D1A"
                  strokeWidth="1.2"
                />
              );
            })}

          {/* context: guards */}
          {guards.map((g) => {
            const p = geo.project(g.lat, g.lng);
            const color = g.status === 'responding' ? WARNING : g.status === 'off_duty' ? '#5C6B8A' : ACCENT;
            return <circle key={g.id} cx={p.x} cy={p.y} r="4" fill="none" stroke={color} strokeWidth="1.4" opacity="0.55" />;
          })}

          {/* context: open alerts */}
          {alerts.map((a) => {
            const p = geo.project(a.lat, a.lng);
            return (
              <g key={a.id}>
                <circle cx={p.x} cy={p.y} r="5" fill="none" stroke={SEVERITY_HEX[a.severity]} strokeWidth="1.2" opacity="0.8">
                  <animate attributeName="r" values="4;14" dur="1.6s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.8;0" dur="1.6s" repeatCount="indefinite" />
                </circle>
                <circle cx={p.x} cy={p.y} r="3" fill={SEVERITY_HEX[a.severity]} />
              </g>
            );
          })}

          {/* base station */}
          <g transform={`translate(${basePos.x} ${basePos.y})`}>
            <rect x="-5" y="-5" width="10" height="10" fill="none" stroke={INFO} strokeWidth="1.4" />
            <text x="8" y="4" fontFamily='"JetBrains Mono", monospace' fontSize="9" fill={INFO} opacity="0.8">
              BASE
            </text>
          </g>

          {/* draft route */}
          {pathD && (
            <path d={pathD} fill="rgba(76,201,240,0.05)" stroke={INFO} strokeWidth="1.6" strokeDasharray="6 4" />
          )}

          {/* leader line from drone to first waypoint */}
          {pts.length > 0 && (
            <line x1={dronePos.x} y1={dronePos.y} x2={pts[0].x} y2={pts[0].y} stroke={INFO} strokeWidth="1" strokeDasharray="3 4" opacity="0.5" />
          )}

          {/* midpoint insert handles */}
          {midpoints.map((m, i) => (
            <g
              key={`mid-${i}-${m.insertAt}`}
              transform={`translate(${m.x} ${m.y})`}
              className="cursor-pointer"
              onClick={(e) => {
                e.stopPropagation();
                insertAt(m.insertAt);
              }}
            >
              <circle r="7" fill="#0A192F" stroke={INFO} strokeWidth="1" opacity="0.9" />
              <path d="M -3 0 H 3 M 0 -3 V 3" stroke={INFO} strokeWidth="1.4" />
            </g>
          ))}

          {/* waypoint dots */}
          {pts.map((p, i) => (
            <g key={`wp-${i}`} transform={`translate(${p.x} ${p.y})`}>
              <circle
                r={dragIdx === i ? 11 : 9}
                fill={selIdx === i ? ACCENT : '#0A192F'}
                stroke={selIdx === i ? ACCENT : INFO}
                strokeWidth="1.6"
                className="cursor-grab"
                onPointerDown={onWaypointPointerDown(i)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  removeWaypoint(i);
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelIdx(i);
                }}
              />
              <text
                y="3"
                textAnchor="middle"
                fontFamily='"JetBrains Mono", monospace'
                fontSize="8"
                fill={selIdx === i ? '#04101F' : INFO}
                pointerEvents="none"
              >
                {i + 1}
              </text>
            </g>
          ))}

          {/* drone itself */}
          <g transform={`translate(${dronePos.x} ${dronePos.y})`}>
            <polygon points="0,-8 7,6 -7,6" fill={drone.status === 'responding' ? '#E71D36' : INFO} stroke="#060D1A" strokeWidth="1.4" />
            <text y="18" textAnchor="middle" fontFamily='"JetBrains Mono", monospace' fontSize="9" fill={INFO}>
              {drone.callsign}
            </text>
          </g>
        </svg>

        {/* editor hint + selected waypoint chip */}
        <div className="absolute left-2 top-2 z-10 rounded-sm border border-line bg-surface-solid/85 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.08em] text-muted backdrop-blur-sm">
          Click map = add · drag = move · right-click = remove
        </div>
        {selIdx !== null && draft[selIdx] && selPt && (
          <div className="absolute right-2 top-2 z-10 flex items-center gap-2 rounded-sm border border-line-strong bg-surface-solid px-2 py-1 shadow-drawer">
            <span className="font-mono text-[9px] text-accent">{draft[selIdx].label ?? `WP-${selIdx + 1}`}</span>
            <span className="font-mono text-[9px] text-muted">{fmtCoord(draft[selIdx].lat, draft[selIdx].lng)}</span>
            <button
              onClick={() => removeWaypoint(selIdx)}
              className="flex h-4 w-4 items-center justify-center rounded-sm text-muted transition-colors hover:bg-danger-dim hover:text-danger"
              title="Remove waypoint"
            >
              <X size={11} />
            </button>
          </div>
        )}
      </div>

      {/* footer bar */}
      <div className="flex h-11 shrink-0 items-center gap-2 border-t border-line-strong bg-surface-solid px-3">
        <SocButton onClick={onSave} disabled={draft.length < 2} tooltip={draft.length < 2 ? 'Route needs at least 2 waypoints' : 'Save route'}>
          Save route
        </SocButton>
        <GhostButton onClick={onDiscard}>Discard</GhostButton>
        <span className="ml-auto font-mono text-[10px] text-muted">
          {draft.length} WPTS · {(lengthM / 1000).toFixed(1)}km · ~{Math.max(1, Math.round(loopMin))} MIN LOOP
        </span>
        <span className="flex items-center gap-1 font-mono text-[9px] text-info">
          <Home size={10} /> {drone.callsign}
        </span>
        <span className={cn('hidden font-mono text-[9px] text-muted xl:inline')}>
          <Plus size={9} className="mr-0.5 inline" /> midpoint handles insert
        </span>
      </div>
    </div>
  );
});
