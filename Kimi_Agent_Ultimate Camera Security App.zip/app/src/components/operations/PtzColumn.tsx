/**
 * Operations left column — active camera control surface.
 * Large live feed + PTZ pad (or fixed-camera note) + camera select strip.
 */
import { memo, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { VideoOff } from 'lucide-react';
import type { Camera } from '@/lib/types';
import { useCanOperate } from '@/hooks/useData';
import { CameraScene } from '@/lib/procedural';
import { CameraTile, CameraDetailPanel, PtzPad, StatusPill, EmptyState } from '@/components/soc';
import { Panel, PanelHeader } from '@/components/soc';
import { cn } from '@/lib/utils';

/* 64×36 strip thumbnail with status dot + PTZ corner tag */
const StripThumb = memo(function StripThumb({
  camera,
  active,
  onSelect,
}: {
  camera: Camera;
  active: boolean;
  onSelect: (c: Camera) => void;
}) {
  const offline = camera.status === 'offline';
  const dot =
    camera.status === 'offline'
      ? 'bg-danger'
      : camera.status === 'degraded'
        ? 'bg-warning'
        : camera.status === 'motion'
          ? 'bg-info'
          : 'bg-accent';
  return (
    <button
      disabled={offline}
      onClick={() => onSelect(camera)}
      title={offline ? `${camera.name} — offline` : `Take control — ${camera.name}`}
      className={cn(
        'group relative h-9 w-16 shrink-0 overflow-hidden rounded-sm border transition-all duration-150',
        active ? 'border-accent' : 'border-line hover:border-accent/40',
        offline && 'cursor-not-allowed opacity-40',
      )}
    >
      <span className="absolute inset-0 [&>svg]:h-full [&>svg]:w-full">
        <CameraScene seed={camera.id} kind={camera.kind} noisy={camera.status === 'degraded'} />
      </span>
      <span className={cn('absolute left-0.5 top-0.5 h-1.5 w-1.5 rounded-full', dot, !offline && 'animate-live-pulse')} />
      {camera.ptz_enabled && (
        <span className="absolute bottom-0.5 right-0.5 rounded-sm bg-info-dim px-0.5 font-mono text-[7px] font-semibold text-info">
          PTZ
        </span>
      )}
      {active && <span className="absolute inset-x-0 bottom-0 h-0.5 bg-accent" />}
    </button>
  );
});

export const PtzColumn = memo(function PtzColumn({
  cameras,
  selectedId,
  onSelect,
}: {
  cameras: Camera[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  const canOperate = useCanOperate();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const camera = useMemo(() => cameras.find((c) => c.id === selectedId) ?? null, [cameras, selectedId]);

  if (cameras.length === 0) {
    return (
      <Panel className="flex h-full flex-col">
        <PanelHeader label="Active control" />
        <EmptyState
          icon={VideoOff}
          heading="No controllable cameras online"
          copy="All cameras in this tenant are offline. Last-seen telemetry is retained in the camera network inventory."
        />
      </Panel>
    );
  }

  return (
    <Panel className="flex h-full min-h-0 flex-col">
      <PanelHeader
        label="Active control"
        right={camera ? <StatusPill status={camera.status} /> : undefined}
      />
      <div className="flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto p-3">
        {camera && (
          <>
            <div className="flex items-center justify-between gap-2">
              <span className="truncate font-sans text-[13px] font-semibold text-primary">{camera.name}</span>
              <span className="shrink-0 font-mono text-[10px] uppercase tracking-[0.08em] text-muted">
                {camera.zone} · {camera.kind}
              </span>
            </div>

            {/* main feed with crossfade on swap */}
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={camera.id}
                initial={{ opacity: 0, x: 12, scale: 0.99 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: -12 }}
                transition={{ duration: 0.25, ease: [0.2, 0.8, 0.2, 1] }}
              >
                <CameraTile camera={camera} onClick={() => setDrawerOpen(true)} />
              </motion.div>
            </AnimatePresence>

            {/* PTZ block / fixed-camera fallback */}
            {camera.ptz_enabled ? (
              <div
                className={cn('rounded-sm border border-line bg-inset p-3', !canOperate && 'opacity-100')}
                title={canOperate ? undefined : 'Requires OPERATOR role'}
              >
                <div className="mb-2 flex items-center justify-between">
                  <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                    PTZ control
                  </span>
                  {!canOperate && (
                    <span className="font-mono text-[9px] uppercase tracking-[0.08em] text-warning">
                      Requires OPERATOR role
                    </span>
                  )}
                </div>
                <PtzPad cameraId={camera.id} />
              </div>
            ) : (
              <div className="rounded-sm border border-line bg-inset p-3">
                <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
                  Fixed camera — no PTZ head installed
                </span>
              </div>
            )}
          </>
        )}

        {/* camera strip */}
        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
              Camera strip
            </span>
            <span className="font-mono text-[9px] text-muted">
              {cameras.filter((c) => c.status !== 'offline').length}/{cameras.length} LIVE
            </span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {cameras.map((c) => (
              <StripThumb key={c.id} camera={c} active={c.id === selectedId} onSelect={(cam) => onSelect(cam.id)} />
            ))}
          </div>
        </div>
      </div>

      <CameraDetailPanel camera={camera} open={drawerOpen} onClose={() => setDrawerOpen(false)} />
    </Panel>
  );
});
