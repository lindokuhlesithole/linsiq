/**
 * Drone control overlay (operations page).
 *
 * The hooks layer (`@/hooks/useData`) exposes drone *reads* but no drone
 * mutations (no start/pause, no return-to-base, no waypoint save). Per the
 * page contract we must not touch the store/simulator directly, so this
 * module provides the patrol control plane as a local override layer that
 * merges over `useDrones()` output and persists to localStorage per tenant.
 * Waypoint routes saved here are also merged in, so the shared TacticalMap
 * (fed the merged fleet via its `drones` prop) renders the edited route.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { Drone, DroneStatus, Waypoint } from '@/lib/types';
import { useActiveOrgId, useDrones } from '@/hooks/useData';

export interface DroneOverride {
  status?: DroneStatus; // locally-driven state (idle=paused, patrolling, returning, charging)
  lat?: number;
  lng?: number;
  altitude_m?: number;
  speed_mps?: number;
  battery_pct?: number;
  wp_index?: number;
  waypoints?: Waypoint[]; // saved route from the waypoint editor
  auto_rtb?: boolean; // battery-driven RTB (banner + locked controls)
}

const M_PER_DEG_LAT = 111320;
const PATROL_MPS = 8.5;
const RTB_MPS = 13;
const LOW_BATT = 22;

function lsKey(orgId: string): string {
  return `swealth.drone_overrides.${orgId}`;
}

function loadOverrides(orgId: string): Record<string, DroneOverride> {
  try {
    const raw = localStorage.getItem(lsKey(orgId));
    const parsed = raw ? (JSON.parse(raw) as Record<string, DroneOverride>) : {};
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function persistOverrides(orgId: string, o: Record<string, DroneOverride>): void {
  try {
    localStorage.setItem(lsKey(orgId), JSON.stringify(o));
  } catch {
    /* storage full/blocked — overrides stay session-local */
  }
}

/** planar step toward a target, good enough at estate scale */
function stepToward(
  lat: number,
  lng: number,
  tLat: number,
  tLng: number,
  meters: number,
): { lat: number; lng: number; arrived: boolean } {
  const dLat = (tLat - lat) * M_PER_DEG_LAT;
  const dLng = (tLng - lng) * M_PER_DEG_LAT * Math.cos((lat * Math.PI) / 180);
  const dist = Math.hypot(dLat, dLng);
  if (dist <= Math.max(2, meters)) return { lat: tLat, lng: tLng, arrived: true };
  const f = meters / dist;
  return { lat: lat + (tLat - lat) * f, lng: lng + (tLng - lng) * f, arrived: false };
}

export function haversineM(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const dLat = (b.lat - a.lat) * M_PER_DEG_LAT;
  const dLng = (b.lng - a.lng) * M_PER_DEG_LAT * Math.cos((a.lat * Math.PI) / 180);
  return Math.hypot(dLat, dLng);
}

export function routeLengthM(wpts: Waypoint[], closeLoop = true): number {
  if (wpts.length < 2) return 0;
  let sum = 0;
  for (let i = 0; i < wpts.length - 1; i++) sum += haversineM(wpts[i], wpts[i + 1]);
  if (closeLoop && wpts.length > 2) sum += haversineM(wpts[wpts.length - 1], wpts[0]);
  return sum;
}

export interface DroneFleet {
  /** live drones with local control overrides merged in */
  drones: Drone[];
  /** true when the drone is driven by the local override layer, not the sim */
  isOverridden: (id: string) => boolean;
  /** true when the drone is in a battery-driven auto-RTB (controls locked) */
  isAutoRtb: (id: string) => boolean;
  /** start patrol (from idle/paused/charging) or pause an active patrol */
  startPausePatrol: (drone: Drone) => void;
  /** commit return-to-base from any airborne state */
  returnToBase: (drone: Drone) => void;
  /** persist an edited route; the drone flies it from waypoint 1 */
  saveWaypoints: (droneId: string, wpts: Waypoint[]) => void;
}

export function useDroneFleet(): DroneFleet {
  const orgId = useActiveOrgId();
  const live = useDrones();
  const [overrides, setOverrides] = useState<Record<string, DroneOverride>>(() => loadOverrides(orgId));

  const liveRef = useRef(live);
  liveRef.current = live;

  /* tenant switch → reload that tenant's overrides */
  useEffect(() => {
    setOverrides(loadOverrides(orgId));
  }, [orgId]);

  /* persist on change */
  useEffect(() => {
    persistOverrides(orgId, overrides);
  }, [orgId, overrides]);

  /* 1s local flight model for override-driven drones */
  useEffect(() => {
    const t = setInterval(() => {
      setOverrides((prev) => {
        let changed = false;
        const next: Record<string, DroneOverride> = { ...prev };
        for (const [id, ov] of Object.entries(prev)) {
          if (!ov.status) continue; // route-only override — sim still flies it
          const d = liveRef.current.find((x) => x.id === id);
          if (!d) continue;
          /* simulator auto-dispatch (gunshot) always wins — hand control back */
          if (d.status === 'responding') {
            next[id] = { waypoints: ov.waypoints };
            changed = true;
            continue;
          }
          const cur: DroneOverride = { ...ov };
          if (cur.status === 'patrolling') {
            const wpts = cur.waypoints ?? d.waypoints;
            const idx = (cur.wp_index ?? d.current_waypoint) % Math.max(1, wpts.length);
            const tgt = wpts[idx] ?? { lat: d.base_lat, lng: d.base_lng };
            const step = stepToward(cur.lat ?? d.lat, cur.lng ?? d.lng, tgt.lat, tgt.lng, PATROL_MPS);
            cur.lat = step.lat;
            cur.lng = step.lng;
            cur.speed_mps = PATROL_MPS;
            cur.altitude_m = Math.min(90, Math.max(40, (cur.altitude_m ?? 55) + (Math.random() - 0.5) * 2));
            cur.battery_pct = Math.max(0, (cur.battery_pct ?? d.battery_pct) - 0.05);
            if (step.arrived) cur.wp_index = (idx + 1) % Math.max(1, wpts.length);
            if ((cur.battery_pct ?? 100) < LOW_BATT) {
              cur.status = 'returning';
              cur.auto_rtb = true;
            }
          } else if (cur.status === 'returning') {
            const step = stepToward(cur.lat ?? d.lat, cur.lng ?? d.lng, d.base_lat, d.base_lng, RTB_MPS);
            cur.lat = step.lat;
            cur.lng = step.lng;
            cur.speed_mps = RTB_MPS;
            cur.battery_pct = Math.max(0, (cur.battery_pct ?? d.battery_pct) - 0.04);
            if (step.arrived) {
              cur.status = 'charging';
              cur.altitude_m = 0;
              cur.speed_mps = 0;
            }
          } else if (cur.status === 'charging') {
            cur.lat = d.base_lat;
            cur.lng = d.base_lng;
            cur.altitude_m = 0;
            cur.speed_mps = 0;
            cur.battery_pct = Math.min(100, (cur.battery_pct ?? d.battery_pct) + 1.2);
            if ((cur.battery_pct ?? 0) >= 99) {
              /* mirror simulator behavior: full battery → resume patrol */
              cur.status = 'patrolling';
              cur.auto_rtb = false;
              cur.altitude_m = 55;
              cur.wp_index = 0;
            }
          } else {
            continue; // idle (paused) — frozen, nothing to tick
          }
          next[id] = cur;
          changed = true;
        }
        return changed ? next : prev;
      });
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const isOverridden = useCallback((id: string) => Boolean(overrides[id]?.status), [overrides]);
  const isAutoRtb = useCallback((id: string) => Boolean(overrides[id]?.auto_rtb), [overrides]);

  const drones = useMemo(
    () =>
      live.map((d) => {
        const ov = overrides[d.id];
        if (!ov) return d;
        const waypoints = ov.waypoints ?? d.waypoints;
        /* store-side responding (gunshot auto-dispatch) always wins */
        if (d.status === 'responding') return { ...d, waypoints };
        if (!ov.status) {
          return {
            ...d,
            waypoints,
            current_waypoint: d.current_waypoint % Math.max(1, waypoints.length),
          };
        }
        return {
          ...d,
          status: ov.status,
          lat: ov.lat ?? d.lat,
          lng: ov.lng ?? d.lng,
          altitude_m: ov.altitude_m ?? 0,
          speed_mps: ov.speed_mps ?? 0,
          battery_pct: ov.battery_pct ?? d.battery_pct,
          waypoints,
          current_waypoint: (ov.wp_index ?? d.current_waypoint) % Math.max(1, waypoints.length),
          respond_target: null,
          /* sim trail tracks the store position — suppress while locally flown */
          trail: [],
        };
      }),
    [live, overrides],
  );

  const startPausePatrol = useCallback((drone: Drone) => {
    setOverrides((prev) => {
      const ov = prev[drone.id] ?? {};
      const next = { ...prev };
      if (drone.status === 'patrolling') {
        /* pause: freeze airframe in place, landed standby */
        next[drone.id] = {
          ...ov,
          status: 'idle',
          lat: drone.lat,
          lng: drone.lng,
          altitude_m: 0,
          speed_mps: 0,
          battery_pct: drone.battery_pct,
          wp_index: drone.current_waypoint,
        };
      } else if (drone.status === 'idle' || drone.status === 'charging') {
        /* launch / resume local patrol along the (possibly edited) route */
        next[drone.id] = {
          ...ov,
          status: 'patrolling',
          lat: drone.lat,
          lng: drone.lng,
          altitude_m: 55,
          speed_mps: PATROL_MPS,
          battery_pct: drone.battery_pct,
          wp_index: drone.current_waypoint,
          auto_rtb: false,
        };
      } else {
        return prev; // returning / responding — controls locked
      }
      return next;
    });
  }, []);

  const returnToBase = useCallback((drone: Drone) => {
    setOverrides((prev) => {
      if (drone.status !== 'patrolling' && drone.status !== 'idle') return prev;
      const ov = prev[drone.id] ?? {};
      return {
        ...prev,
        [drone.id]: {
          ...ov,
          status: 'returning',
          lat: drone.lat,
          lng: drone.lng,
          altitude_m: drone.altitude_m,
          speed_mps: RTB_MPS,
          battery_pct: drone.battery_pct,
          wp_index: drone.current_waypoint,
          auto_rtb: false,
        },
      };
    });
  }, []);

  const saveWaypoints = useCallback((droneId: string, wpts: Waypoint[]) => {
    setOverrides((prev) => ({
      ...prev,
      [droneId]: { ...(prev[droneId] ?? {}), waypoints: wpts, wp_index: 0 },
    }));
  }, []);

  return { drones, isOverridden, isAutoRtb, startPausePatrol, returnToBase, saveWaypoints };
}
