/**
 * DroneCard — callsign, live telemetry, patrol controls, waypoint list
 * (operations.md §3 DRONES tab).
 */
import { memo } from 'react';
import { ArrowDown, ArrowUp, Crosshair, Home, Pause, Play, Route, X } from 'lucide-react';
import type { Waypoint } from '@/lib/types';
import type { Drone } from '@/lib/types';
import { StatusPill } from '@/components/soc';
import { fmtCoord } from '@/lib/format';
import { haversineM } from './droneOverrides';
import { cn } from '@/lib/utils';

const RTB_MPS = 13;

function TelemetryCell({ label, value, tone }: { label: string; value: string; tone?: 'ok' | 'warn' | 'bad' }) {
  return (
    <div className="rounded-sm bg-inset px-1.5 py-1">
      <div className="font-sans text-[8px] font-semibold uppercase tracking-[0.12em] text-muted">{label}</div>
      <div
        className={cn(
          'font-mono text-[11px] leading-4',
          tone === 'bad' ? 'text-danger' : tone === 'warn' ? 'text-warning' : 'text-primary',
        )}
      >
        {value}
      </div>
    </div>
  );
}

export const DroneCard = memo(function DroneCard({
  drone,
  canOperate,
  autoRtb,
  editing,
  draftWpts,
  onStartPause,
  onRtb,
  onEditRoute,
  onView,
  onDraftChange,
}: {
  drone: Drone;
  canOperate: boolean;
  autoRtb: boolean;
  editing: boolean;
  draftWpts?: Waypoint[];
  onStartPause: () => void;
  onRtb: () => void;
  onEditRoute: () => void;
  onView: () => void;
  onDraftChange?: (wpts: Waypoint[]) => void;
}) {
  const responding = drone.status === 'responding';
  const returning = drone.status === 'returning';
  const charging = drone.status === 'charging';
  const controlsLocked = responding || returning;
  const battTone = drone.battery_pct < 15 ? 'bad' : drone.battery_pct < 30 ? 'warn' : 'ok';
  const distHome = haversineM({ lat: drone.lat, lng: drone.lng }, { lat: drone.base_lat, lng: drone.base_lng });
  const etaHomeSec =
    distHome < 15 ? 0 : distHome / (returning ? RTB_MPS : Math.max(drone.speed_mps, 8));
  const etaHome =
    distHome < 15 ? 'BASE' : etaHomeSec >= 90 ? `~${Math.round(etaHomeSec / 60)}m` : `~${Math.round(etaHomeSec)}s`;

  const gate = (fn: () => void) => (canOperate ? fn : undefined);
  const gateTip = canOperate ? undefined : 'Requires OPERATOR role';

  return (
    <div
      className={cn(
        'rounded-sm border bg-surface p-3 transition-colors duration-300',
        responding ? 'border-danger/30' : returning ? 'border-warning/30' : editing ? 'border-info/40' : 'border-line',
      )}
    >
      {/* header */}
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <span className="font-sans text-[12px] font-semibold text-primary">{drone.callsign}</span>
          <span className="ml-2 font-mono text-[10px] text-muted">{drone.model}</span>
        </div>
        <StatusPill status={drone.status} />
      </div>

      {/* auto-RTB banner */}
      {autoRtb && (
        <div className="mt-2 rounded-sm bg-warning-dim px-2 py-1 font-mono text-[9px] uppercase tracking-[0.08em] text-warning">
          Auto-RTB — battery {Math.round(drone.battery_pct)}% · controls locked
        </div>
      )}

      {/* responding destination line */}
      {responding && drone.respond_target && (
        <div className="mt-2 font-mono text-[9px] uppercase tracking-[0.06em] text-danger">
          → Gunshot triangulation · ETA {etaHome === 'BASE' ? '—' : etaHome}
        </div>
      )}

      {/* telemetry grid */}
      <div className="mt-2 grid grid-cols-3 gap-1">
        <div className="rounded-sm bg-inset px-1.5 py-1">
          <div className="font-sans text-[8px] font-semibold uppercase tracking-[0.12em] text-muted">Batt</div>
          <div
            className={cn(
              'font-mono text-[11px] leading-4',
              battTone === 'bad' ? 'text-danger' : battTone === 'warn' ? 'text-warning' : 'text-primary',
            )}
          >
            {Math.round(drone.battery_pct)}%
          </div>
          <div className="mt-0.5 h-1 overflow-hidden rounded-full bg-raised">
            <div
              className={cn(
                'h-full rounded-full transition-all duration-500',
                battTone === 'bad' ? 'bg-danger' : battTone === 'warn' ? 'bg-warning' : 'bg-accent',
                charging && 'animate-pulse',
              )}
              style={{ width: `${Math.min(100, drone.battery_pct)}%` }}
            />
          </div>
        </div>
        <TelemetryCell label="Alt" value={`${Math.round(drone.altitude_m)}m`} />
        <TelemetryCell label="Spd" value={`${drone.speed_mps.toFixed(1)} m/s`} />
        <TelemetryCell label="Sig" value={`${Math.round(drone.signal_pct)}%`} tone={drone.signal_pct < 70 ? 'warn' : 'ok'} />
        <TelemetryCell label="Wpt" value={`${Math.min(drone.current_waypoint + 1, drone.waypoints.length)}/${drone.waypoints.length}`} />
        <TelemetryCell label="ETA home" value={charging ? 'DOCKED' : etaHome} tone={returning ? 'warn' : 'ok'} />
      </div>

      {/* controls */}
      <div className="mt-2 flex items-center gap-1">
        <button
          disabled={!canOperate || controlsLocked}
          onClick={gate(onStartPause)}
          title={gateTip ?? (drone.status === 'patrolling' ? 'Pause patrol' : 'Start patrol')}
          className={cn(
            'flex h-6 flex-1 items-center justify-center gap-1 rounded-sm border font-sans text-[10px] font-semibold uppercase tracking-[0.08em] transition-colors',
            drone.status === 'patrolling'
              ? 'border-line-strong text-secondary hover:border-warning hover:text-warning'
              : 'border-line-strong text-secondary hover:border-accent hover:text-accent',
            'disabled:cursor-not-allowed disabled:opacity-40',
          )}
        >
          {drone.status === 'patrolling' ? <Pause size={11} /> : <Play size={11} />}
          {drone.status === 'patrolling' ? 'Pause' : 'Start'}
        </button>
        <button
          disabled={!canOperate || controlsLocked}
          onClick={gate(onRtb)}
          title={gateTip ?? 'Return to base'}
          className="flex h-6 flex-1 items-center justify-center gap-1 rounded-sm border border-warning/40 font-sans text-[10px] font-semibold uppercase tracking-[0.08em] text-warning transition-colors hover:bg-warning-dim disabled:cursor-not-allowed disabled:opacity-40"
        >
          <Home size={11} /> RTB
        </button>
        <button
          disabled={!canOperate || responding}
          onClick={gate(onEditRoute)}
          title={gateTip ?? 'Edit route in waypoint editor'}
          className={cn(
            'flex h-6 flex-1 items-center justify-center gap-1 rounded-sm border font-sans text-[10px] font-semibold uppercase tracking-[0.08em] transition-colors disabled:cursor-not-allowed disabled:opacity-40',
            editing ? 'border-info/50 bg-info-dim text-info' : 'border-line-strong text-secondary hover:border-info hover:text-info',
          )}
        >
          <Route size={11} /> {editing ? 'Editing' : 'Route'}
        </button>
        <button
          onClick={onView}
          title="Locate on operations map"
          className="flex h-6 w-7 items-center justify-center rounded-sm border border-line-strong text-secondary transition-colors hover:border-accent hover:text-accent"
        >
          <Crosshair size={11} />
        </button>
      </div>

      {/* waypoint list (live draft while editing) */}
      {editing && draftWpts && onDraftChange && (
        <div className="mt-2 rounded-sm border border-info/25 bg-inset">
          <div className="border-b border-line px-2 py-1 font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-info">
            Route draft — {draftWpts.length} waypoints
          </div>
          <div className="max-h-36 overflow-y-auto">
            {draftWpts.map((w, i) => (
              <div key={`${i}-${w.lat.toFixed(4)}`} className="flex items-center gap-1 border-b border-line/50 px-2 py-1 last:border-0">
                <span className="w-9 shrink-0 font-mono text-[9px] text-info">{w.label ?? `WP-${i + 1}`}</span>
                <span className="min-w-0 flex-1 truncate font-mono text-[9px] text-muted">{fmtCoord(w.lat, w.lng)}</span>
                <button
                  disabled={i === 0}
                  onClick={() => {
                    const next = [...draftWpts];
                    [next[i - 1], next[i]] = [next[i], next[i - 1]];
                    onDraftChange(next.map((x, idx) => ({ ...x, label: `WP-${idx + 1}` })));
                  }}
                  className="text-muted transition-colors hover:text-accent disabled:opacity-25"
                  title="Move up"
                >
                  <ArrowUp size={11} />
                </button>
                <button
                  disabled={i === draftWpts.length - 1}
                  onClick={() => {
                    const next = [...draftWpts];
                    [next[i], next[i + 1]] = [next[i + 1], next[i]];
                    onDraftChange(next.map((x, idx) => ({ ...x, label: `WP-${idx + 1}` })));
                  }}
                  className="text-muted transition-colors hover:text-accent disabled:opacity-25"
                  title="Move down"
                >
                  <ArrowDown size={11} />
                </button>
                <button
                  disabled={draftWpts.length <= 2}
                  onClick={() => onDraftChange(draftWpts.filter((_, idx) => idx !== i).map((x, idx) => ({ ...x, label: `WP-${idx + 1}` })))}
                  className="text-muted transition-colors hover:text-danger disabled:opacity-25"
                  title="Remove waypoint"
                >
                  <X size={11} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
});
