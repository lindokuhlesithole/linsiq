/**
 * UnitsRail — operations right rail: DRONES | GUARDS tabs with live cards
 * (operations.md §3).
 */
import { memo, useState } from 'react';
import { motion } from 'framer-motion';
import { Users } from 'lucide-react';
import type { Alert, Drone, Guard, Waypoint } from '@/lib/types';
import { SocTabs, EmptyState, showToast } from '@/components/soc';
import { fmtCoord } from '@/lib/format';
import { DroneCard } from './DroneCard';
import { GuardCard } from './GuardCard';
import type { DroneFleet } from './droneOverrides';

export type UnitsTab = 'drones' | 'guards';

export const UnitsRail = memo(function UnitsRail({
  tab,
  onTab,
  fleet,
  guards,
  openAlerts,
  canOperate,
  editDroneId,
  draftWpts,
  onEditRoute,
  onDraftChange,
  onDispatch,
  onSelectDrone,
}: {
  tab: UnitsTab;
  onTab: (t: UnitsTab) => void;
  fleet: DroneFleet;
  guards: Guard[];
  openAlerts: Alert[];
  canOperate: boolean;
  editDroneId: string | null;
  draftWpts: Waypoint[];
  onEditRoute: (d: Drone) => void;
  onDraftChange: (wpts: Waypoint[]) => void;
  onDispatch: (guardId: string, alertId: string) => void;
  onSelectDrone: (id: string) => void;
}) {
  const [rosterOpen, setRosterOpen] = useState(false);
  const activeGuards = guards.filter((g) => g.status !== 'off_duty');
  const offDuty = guards.filter((g) => g.status === 'off_duty');
  const patrollingN = fleet.drones.filter((d) => d.status === 'patrolling').length;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <SocTabs
        idScope="ops-units"
        tabs={[
          { id: 'drones' as UnitsTab, label: `Drones`, count: fleet.drones.length },
          { id: 'guards' as UnitsTab, label: `Guards`, count: activeGuards.length },
        ]}
        active={tab}
        onChange={(t) => onTab(t as UnitsTab)}
      />

      <div className="mt-2 min-h-0 flex-1 space-y-2 overflow-y-auto pr-0.5">
        {tab === 'drones' && (
          <>
            <div className="font-mono text-[9px] uppercase tracking-[0.1em] text-muted">
              {patrollingN} AIRBORNE · {fleet.drones.length - patrollingN} GROUND/OTHER
            </div>
            {fleet.drones.map((d, i) => (
              <motion.div
                key={d.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03, duration: 0.2 }}
              >
                <DroneCard
                  drone={d}
                  canOperate={canOperate}
                  autoRtb={fleet.isAutoRtb(d.id)}
                  editing={editDroneId === d.id}
                  draftWpts={editDroneId === d.id ? draftWpts : undefined}
                  onStartPause={() => {
                    const was = d.status;
                    fleet.startPausePatrol(d);
                    showToast({
                      severity: 'low',
                      title: was === 'patrolling' ? `${d.callsign} — patrol paused` : `${d.callsign} — patrol started`,
                      body: was === 'patrolling' ? 'Holding position, standby mode.' : 'Route resumed from current waypoint.',
                    });
                  }}
                  onRtb={() => {
                    fleet.returnToBase(d);
                    showToast({ severity: 'medium', title: `${d.callsign} — RTB committed`, body: 'Returning to base station.' });
                  }}
                  onEditRoute={() => {
                    onSelectDrone(d.id);
                    onEditRoute(d);
                  }}
                  onView={() => {
                    onSelectDrone(d.id);
                    showToast({
                      severity: 'low',
                      title: `${d.callsign} — position`,
                      body: `${fmtCoord(d.lat, d.lng)} · ALT ${Math.round(d.altitude_m)}m · ${d.status.toUpperCase()}`,
                    });
                  }}
                  onDraftChange={onDraftChange}
                />
              </motion.div>
            ))}
          </>
        )}

        {tab === 'guards' && (
          <>
            {activeGuards.length === 0 ? (
              <EmptyState
                icon={Users}
                heading="Shift change — no guards on duty"
                copy="The roster below lists off-duty units read-only until the next shift starts."
                actionLabel="View roster"
                onAction={() => setRosterOpen(true)}
              />
            ) : (
              activeGuards.map((g, i) => (
                <motion.div
                  key={g.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03, duration: 0.2 }}
                >
                  <GuardCard
                    guard={g}
                    openAlerts={openAlerts}
                    canOperate={canOperate}
                    onDispatch={onDispatch}
                    onLocate={(guard) =>
                      showToast({
                        severity: 'low',
                        title: `${guard.badge_no} — location`,
                        body: `${fmtCoord(guard.lat, guard.lng)} · ${guard.status.replace('_', ' ').toUpperCase()}`,
                      })
                    }
                  />
                </motion.div>
              ))
            )}
            {offDuty.length > 0 && (
              <div className="rounded-sm border border-line">
                <button
                  onClick={() => setRosterOpen((v) => !v)}
                  className="flex w-full items-center justify-between px-2.5 py-1.5 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted transition-colors hover:text-secondary"
                >
                  Off-duty roster ({offDuty.length})
                  <span className="font-mono text-[9px]">{rosterOpen ? 'HIDE' : 'VIEW'}</span>
                </button>
                {rosterOpen && (
                  <div className="border-t border-line">
                    {offDuty.map((g) => (
                      <div key={g.id} className="flex items-center justify-between px-2.5 py-1.5 opacity-60">
                        <span className="font-sans text-[11px] text-secondary">{g.full_name}</span>
                        <span className="font-mono text-[9px] text-muted">
                          {g.badge_no} · {g.shift.toUpperCase()}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
});
