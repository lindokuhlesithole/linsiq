/**
 * GuardCard — roster unit with one-click dispatch to a selected open alert
 * (operations.md §3 GUARDS tab). Dispatch → dispatchGuard() in the hooks
 * layer: guard flips to `responding`, the simulator interpolates position
 * toward the alert, and the ETA here counts down from live distance.
 */
import { memo, useMemo, useState } from 'react';
import { Crosshair, Eye, EyeOff, Radio, Send } from 'lucide-react';
import type { Alert, Guard } from '@/lib/types';
import { useClock } from '@/hooks/useData';
import { StatusPill, SEVERITY_HEX, showToast } from '@/components/soc';
import { fmtCoord, fmtCountdown, fmtDurationSec } from '@/lib/format';
import { haversineM } from './droneOverrides';
import { cn } from '@/lib/utils';

const GUARD_SPEED_MPS = 26; // matches simulator response interpolation band (22–30)

const SHIFT_TOKENS: Record<string, string> = {
  day: 'bg-info-dim text-info',
  night: 'bg-raised text-secondary',
  swing: 'bg-warning-dim text-warning',
};

export const GuardCard = memo(function GuardCard({
  guard,
  openAlerts,
  canOperate,
  onDispatch,
  onLocate,
}: {
  guard: Guard;
  openAlerts: Alert[];
  canOperate: boolean;
  onDispatch: (guardId: string, alertId: string) => void;
  onLocate: (g: Guard) => void;
}) {
  const now = useClock(1000);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [phoneShown, setPhoneShown] = useState(false);
  const responding = guard.status === 'responding' && guard.dispatch_target;
  void now; // re-render each second for the ETA countdown

  const etaSec = useMemo(() => {
    if (!responding || !guard.dispatch_target) return null;
    return haversineM({ lat: guard.lat, lng: guard.lng }, guard.dispatch_target) / GUARD_SPEED_MPS;
  }, [responding, guard]);

  const maskedPhone = guard.phone.length > 3 ? `••• ••• ${guard.phone.slice(-3)}` : '••• ••• •••';

  const call = () => {
    showToast({ severity: 'medium', title: `Radio check — ${guard.badge_no}`, body: `${guard.full_name} · transmitting…` });
    setTimeout(() => {
      showToast({ severity: 'low', title: `Radio check — ${guard.badge_no} · ACK`, body: `${guard.full_name} copies, all quiet on post.` });
    }, 1000);
  };

  return (
    <div
      className={cn(
        'relative rounded-sm border bg-surface p-3 transition-all duration-200',
        responding ? 'border-warning/30' : 'border-line',
      )}
    >
      {/* header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <span className="truncate font-sans text-[12px] font-semibold text-primary">{guard.full_name}</span>
          <span className="shrink-0 font-mono text-[10px] text-muted">{guard.badge_no}</span>
          <span className={cn('shrink-0 rounded-sm px-1 py-px font-mono text-[8px] font-semibold uppercase', SHIFT_TOKENS[guard.shift])}>
            {guard.shift}
          </span>
        </div>
        <StatusPill status={guard.status} />
      </div>

      {/* stats row */}
      <div className="mt-1.5 flex items-center gap-2 font-mono text-[10px] text-muted">
        <span>RESOLVED {guard.alerts_resolved}</span>
        <span>· AVG RESP {fmtDurationSec(guard.avg_response_sec)}</span>
        <button
          onClick={() => canOperate && setPhoneShown((v) => !v)}
          title={canOperate ? (phoneShown ? 'Hide number' : 'Reveal number') : 'Requires OPERATOR role'}
          className={cn(
            'ml-auto flex items-center gap-1 rounded-sm px-1 py-px transition-colors',
            canOperate ? 'hover:bg-raised hover:text-secondary' : 'cursor-not-allowed opacity-50',
          )}
        >
          {phoneShown ? <EyeOff size={10} /> : <Eye size={10} />}
          {phoneShown ? guard.phone : maskedPhone}
        </button>
      </div>

      {/* responding destination + ticking ETA */}
      {responding && guard.dispatch_target && (
        <div className="mt-2 flex items-center justify-between rounded-sm bg-warning-dim px-2 py-1">
          <span className="font-mono text-[9px] uppercase tracking-[0.06em] text-warning">
            → En route · {fmtCoord(guard.dispatch_target.lat, guard.dispatch_target.lng)}
          </span>
          <span className="font-mono text-[10px] font-semibold text-warning">
            ETA {etaSec !== null ? fmtCountdown(etaSec) : '—'}
          </span>
        </div>
      )}

      {/* actions */}
      <div className="mt-2 flex items-center gap-1">
        <button
          disabled={!canOperate || guard.status !== 'on_duty' || openAlerts.length === 0}
          onClick={() => setPickerOpen((v) => !v)}
          title={
            !canOperate
              ? 'Requires OPERATOR role'
              : guard.status !== 'on_duty'
                ? `Cannot dispatch — ${guard.status.replace('_', ' ')}`
                : openAlerts.length === 0
                  ? 'No open alerts to dispatch to'
                  : 'Dispatch to an open alert'
          }
          className="flex h-6 flex-1 items-center justify-center gap-1 rounded-sm bg-accent font-sans text-[10px] font-semibold uppercase tracking-[0.08em] text-on-accent transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:bg-raised disabled:text-muted"
        >
          <Send size={11} /> Dispatch
        </button>
        <button
          onClick={() => onLocate(guard)}
          title="Locate on operations map"
          className="flex h-6 flex-1 items-center justify-center gap-1 rounded-sm border border-line-strong font-sans text-[10px] font-semibold uppercase tracking-[0.08em] text-secondary transition-colors hover:border-accent hover:text-accent"
        >
          <Crosshair size={11} /> Locate
        </button>
        <button
          onClick={call}
          title="Radio check (simulated)"
          className="flex h-6 w-7 items-center justify-center rounded-sm border border-line-strong text-secondary transition-colors hover:border-accent hover:text-accent"
        >
          <Radio size={11} />
        </button>
      </div>

      {/* dispatch alert picker */}
      {pickerOpen && canOperate && (
        <div className="absolute inset-x-3 top-[104px] z-20 rounded-sm border border-line-strong bg-surface-solid shadow-drawer">
          <div className="flex items-center justify-between border-b border-line px-2 py-1">
            <span className="font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">
              Dispatch {guard.badge_no} to…
            </span>
            <button onClick={() => setPickerOpen(false)} className="font-mono text-[9px] text-muted hover:text-primary">
              ESC
            </button>
          </div>
          <div className="max-h-44 overflow-y-auto">
            {openAlerts.map((a) => {
              const distKm = haversineM({ lat: guard.lat, lng: guard.lng }, { lat: a.lat, lng: a.lng }) / 1000;
              return (
                <button
                  key={a.id}
                  onClick={() => {
                    onDispatch(guard.id, a.id);
                    setPickerOpen(false);
                  }}
                  className="relative flex w-full items-center gap-2 border-b border-line/50 py-1.5 pl-3 pr-2 text-left transition-colors last:border-0 hover:bg-raised"
                >
                  <span
                    className="absolute left-0 top-0 bottom-0 w-0.5"
                    style={{ background: SEVERITY_HEX[a.severity] }}
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-sans text-[11px] text-primary">{a.title}</span>
                    <span className="block font-mono text-[9px] text-muted">
                      {a.source_name} · {distKm.toFixed(1)}km · ETA {fmtCountdown((distKm * 1000) / GUARD_SPEED_MPS)}
                    </span>
                  </span>
                  <span className="shrink-0 font-mono text-[9px] uppercase" style={{ color: SEVERITY_HEX[a.severity] }}>
                    {a.severity}
                  </span>
                </button>
              );
            })}
            {openAlerts.length === 0 && (
              <div className="px-3 py-3 font-mono text-[10px] text-muted">No open alerts — board is clear.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
});
