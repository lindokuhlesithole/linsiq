/** Feedback states: EmptyState, SkeletonRow, RouteErrorBoundary (design.md §6.13). */
import { Component, memo } from 'react';
import type { ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { GhostButton, SocButton } from './primitives';
import { cn } from '@/lib/utils';

/* ── EmptyState ──────────────────────────────────────────────────────────── */

export const EmptyState = memo(function EmptyState({
  icon: Icon,
  heading,
  copy,
  actionLabel,
  onAction,
  className,
}: {
  icon: LucideIcon;
  heading: string;
  copy: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}) {
  return (
    <div className={cn('flex h-full min-h-[120px] flex-col items-center justify-center gap-2 p-6 text-center', className)}>
      <Icon size={32} className="text-muted" strokeWidth={1.5} />
      <div className="font-sans text-[13px] font-medium text-primary">{heading}</div>
      <p className="max-w-[40ch] font-sans text-[12px] text-muted">{copy}</p>
      {actionLabel && onAction && (
        <GhostButton className="mt-1" onClick={onAction}>
          {actionLabel}
        </GhostButton>
      )}
    </div>
  );
});

/* ── SkeletonRow (shimmer sweep, design.md §6.13) ────────────────────────── */

export const SkeletonRow = memo(function SkeletonRow({ variant = 'text', className }: { variant?: 'text' | 'plate' | 'kpi' | 'feed'; className?: string }) {
  const bar = 'relative overflow-hidden rounded-sm bg-raised';
  const sheen = (
    <span className="pointer-events-none absolute inset-0 -translate-x-full animate-shimmer bg-[linear-gradient(90deg,transparent,rgba(0,212,170,0.06),transparent)]" />
  );
  if (variant === 'feed') {
    return (
      <div className={cn(bar, 'aspect-video w-full', className)}>
        {sheen}
      </div>
    );
  }
  if (variant === 'kpi') {
    return (
      <div className={cn('flex h-[88px] flex-col justify-between rounded-sm border border-line bg-surface p-3', className)}>
        <div className={cn(bar, 'h-2.5 w-20')}>{sheen}</div>
        <div className="flex items-end justify-between">
          <div className={cn(bar, 'h-7 w-24')}>{sheen}</div>
          <div className={cn(bar, 'h-6 w-14')}>{sheen}</div>
        </div>
      </div>
    );
  }
  if (variant === 'plate') {
    return (
      <div className={cn('flex h-10 items-center gap-2 px-3', className)}>
        <div className={cn(bar, 'h-5 w-20')}>{sheen}</div>
        <div className={cn(bar, 'h-3 w-28')}>{sheen}</div>
        <div className="ml-auto flex items-center gap-2">
          <div className={cn(bar, 'h-3 w-10')}>{sheen}</div>
          <div className={cn(bar, 'h-3 w-12')}>{sheen}</div>
        </div>
      </div>
    );
  }
  return (
    <div className={cn('flex h-12 items-center gap-2 px-3', className)}>
      <div className={cn(bar, 'h-8 w-0.5')}>{sheen}</div>
      <div className={cn(bar, 'h-4 w-4')}>{sheen}</div>
      <div className="flex-1 space-y-1.5">
        <div className={cn(bar, 'h-3 w-3/5')}>{sheen}</div>
        <div className={cn(bar, 'h-2.5 w-4/5')}>{sheen}</div>
      </div>
      <div className={cn(bar, 'h-3 w-12')}>{sheen}</div>
    </div>
  );
});

/* ── RouteErrorBoundary ──────────────────────────────────────────────────── */

interface EBState {
  error: Error | null;
  errorId: string;
}

export class RouteErrorBoundary extends Component<{ children: ReactNode }, EBState> {
  state: EBState = { error: null, errorId: '' };

  static getDerivedStateFromError(error: Error): EBState {
    return { error, errorId: `ERR-${Date.now().toString(36).toUpperCase()}` };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('[RouteErrorBoundary]', error, info);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="flex h-full min-h-[300px] items-center justify-center p-8">
        <div className="w-full max-w-md rounded-sm border border-danger-line bg-danger-dim p-6">
          <div className="flex items-center gap-2">
            <AlertTriangle size={18} className="text-danger" />
            <h2 className="font-mono text-[14px] font-semibold uppercase tracking-[0.08em] text-danger">
              Signal interrupted
            </h2>
          </div>
          <p className="mt-3 font-sans text-[12px] text-secondary">
            This panel lost its feed and was isolated before it could corrupt the rest of the console.
          </p>
          <p className="mt-2 break-all font-mono text-[10px] text-muted">
            {this.state.errorId} · {this.state.error.message}
          </p>
          <div className="mt-4 flex items-center gap-2">
            <SocButton onClick={() => this.setState({ error: null, errorId: '' })}>
              <span className="inline-flex items-center gap-1.5">
                <RotateCcw size={13} /> Retry
              </span>
            </SocButton>
            <span className="font-mono text-[9px] text-muted">report ref: {this.state.errorId}</span>
          </div>
        </div>
      </div>
    );
  }
}
