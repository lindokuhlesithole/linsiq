/** CameraTile — procedural live feed (design.md §6.4). */
import { memo } from 'react';
import { Expand, Move3d } from 'lucide-react';
import type { Camera } from '@/lib/types';
import { CameraScene } from '@/lib/procedural';
import { useClock } from '@/hooks/useData';
import { fmtTime } from '@/lib/format';
import { StatusPill } from './StatusPill';
import { cn } from '@/lib/utils';

/* Burn-in clock isolated so the 1s tick only re-renders this tiny node */
const BurnInClock = memo(function BurnInClock() {
  const now = useClock(1000);
  return <span className="hud-text font-mono text-[10px]">{fmtTime(now)}</span>;
});

export interface CameraTileProps {
  camera: Camera;
  onClick?: (camera: Camera) => void;
  /** force danger border + ALERT SOURCE corner tag */
  alertActive?: boolean;
  /** bump to flash the border accent once (new plate read on this camera) */
  readFlashKey?: number;
  className?: string;
}

export const CameraTile = memo(
  function CameraTile({ camera, onClick, alertActive = false, className }: CameraTileProps) {
    const offline = camera.status === 'offline';
    const degraded = camera.status === 'degraded';
    return (
      <div
        role="button"
        tabIndex={0}
        onClick={() => onClick?.(camera)}
        onKeyDown={(e) => e.key === 'Enter' && onClick?.(camera)}
        className={cn(
          'group relative overflow-hidden rounded-sm border bg-inset transition-colors duration-100',
          alertActive ? 'border-danger-line' : 'border-line hover:border-accent/40',
          onClick && 'cursor-pointer',
          className,
        )}
      >
        {/* feed area */}
        <div className="relative aspect-video w-full overflow-hidden">
          {offline ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 bg-canvas">
              <svg className="absolute inset-0 h-full w-full opacity-30" aria-hidden>
                <filter id={`sl-${camera.id}`}>
                  <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" />
                  <feColorMatrix type="matrix" values="0 0 0 0 0.9 0 0 0 0 0.2 0 0 0 0 0.25 0 0 0 0.4 0" />
                </filter>
                <rect width="100%" height="100%" filter={`url(#sl-${camera.id})`} />
              </svg>
              <span className="relative font-mono text-[12px] font-semibold uppercase tracking-[0.2em] text-danger">
                Signal lost
              </span>
              <span className="relative font-mono text-[9px] text-muted">
                last seen {fmtTime(camera.last_heartbeat)}
              </span>
            </div>
          ) : (
            <>
              <CameraScene seed={camera.id} kind={camera.kind} noisy={degraded} className="absolute inset-0 h-full w-full" />
              <div className="scanlines absolute inset-0" />
              <div className="scan-band absolute inset-0 overflow-hidden" />
              {degraded && (
                <span className="absolute right-1.5 top-6 z-10 rounded-sm bg-warning-dim px-1.5 py-0.5 font-mono text-[8px] font-semibold uppercase tracking-[0.1em] text-warning">
                  Degraded
                </span>
              )}
            </>
          )}

          {/* burn-in HUD */}
          <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-1.5">
            <div className="flex items-start justify-between">
              <span className="hud-text font-mono text-[10px] uppercase">
                {camera.name} · {camera.zone}
              </span>
              {!offline && (
                <span className="flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-danger animate-rec-blink" />
                  <span className="hud-text font-mono text-[9px] font-semibold">REC</span>
                </span>
              )}
            </div>
            <div className="flex items-end justify-between">
              <BurnInClock />
              <span className="hud-text font-mono text-[9px]">
                {camera.resolution} · {camera.fps}FPS
              </span>
            </div>
          </div>

          {alertActive && (
            <span className="absolute left-1.5 top-6 z-10 flex items-center gap-1 rounded-sm bg-danger-dim px-1.5 py-0.5 font-mono text-[8px] font-semibold uppercase tracking-[0.1em] text-danger animate-live-pulse">
              Alert source
            </span>
          )}

          {/* hover expand affordance */}
          <span className="absolute right-1.5 top-1/2 z-10 -translate-y-1/2 rounded-sm bg-surface-solid/80 p-1 text-accent opacity-0 transition-opacity duration-100 group-hover:opacity-100">
            <Expand size={13} />
          </span>
        </div>

        {/* footer strip */}
        <div className="flex h-7 items-center gap-2 border-t border-line bg-surface px-2">
          <StatusPill status={camera.status} />
          <span className="ml-auto flex items-center gap-1.5">
            <span className="h-1 w-14 overflow-hidden rounded-full bg-raised">
              <span
                className={cn('block h-full rounded-full', camera.storage_used_pct > 85 ? 'bg-warning' : 'bg-accent')}
                style={{ width: `${Math.min(100, camera.storage_used_pct)}%` }}
              />
            </span>
            <span className="font-mono text-[9px] text-muted">{Math.round(camera.storage_used_pct)}%</span>
          </span>
          {camera.ptz_enabled && (
            <span className="flex items-center gap-0.5 rounded-sm bg-info-dim px-1 py-px font-mono text-[8px] font-semibold text-info">
              <Move3d size={9} /> PTZ
            </span>
          )}
        </div>
      </div>
    );
  },
  (prev, next) =>
    prev.camera.id === next.camera.id &&
    prev.camera.status === next.camera.status &&
    prev.camera.name === next.camera.name &&
    prev.camera.zone === next.camera.zone &&
    Math.round(prev.camera.storage_used_pct) === Math.round(next.camera.storage_used_pct) &&
    prev.alertActive === next.alertActive &&
    prev.readFlashKey === next.readFlashKey,
);
