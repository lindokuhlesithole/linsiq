/** KpiTile (design.md §6.3) — mono value, sparkline or delta, value flash on change. */
import { memo, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export const Sparkline = memo(function Sparkline({ data, stroke = '#00D4AA', w = 56, hgt = 24 }: { data: number[]; stroke?: string; w?: number; hgt?: number }) {
  if (data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${hgt - 2 - ((v - min) / range) * (hgt - 4)}`).join(' ');
  return (
    <svg width={w} height={hgt} className="shrink-0" aria-hidden>
      <polyline points={pts} fill="none" stroke={stroke} strokeWidth="1.4" strokeLinejoin="round" strokeLinecap="round" />
      <polygon points={`${pts} ${w},${hgt} 0,${hgt}`} fill={stroke} opacity="0.08" />
    </svg>
  );
});

export interface KpiTileProps {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  spark?: number[];
  sparkStroke?: string;
  delta?: { dir: 'up' | 'down'; text: string; good: boolean };
  topBorder?: 'danger' | 'warning' | null;
  onClick?: () => void;
}

export const KpiTile = memo(function KpiTile({ label, value, sub, spark, sparkStroke, delta, topBorder, onClick }: KpiTileProps) {
  const [flash, setFlash] = useState(false);
  const prevRef = useRef<string>('');
  const valKey = typeof value === 'string' || typeof value === 'number' ? String(value) : '';
  useEffect(() => {
    if (prevRef.current && valKey && prevRef.current !== valKey) {
      setFlash(true);
      const t = setTimeout(() => setFlash(false), 400);
      return () => clearTimeout(t);
    }
    prevRef.current = valKey;
  }, [valKey]);

  return (
    <motion.button
      type="button"
      onClick={onClick}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className={cn(
        'relative h-[88px] w-full rounded-sm border border-line bg-surface p-3 text-left backdrop-blur-sm',
        'transition-colors duration-150 hover:border-line-strong',
        onClick && 'cursor-pointer',
      )}
    >
      {topBorder && (
        <span className={cn('absolute left-0 right-0 top-0 h-0.5 rounded-t-sm', topBorder === 'danger' ? 'bg-danger' : 'bg-warning')} />
      )}
      <div className="flex h-full flex-col justify-between">
        <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">{label}</span>
        <div className="flex items-end justify-between gap-2">
          <motion.span
            key={valKey || 'static'}
            initial={valKey ? { scale: 1.06 } : false}
            animate={{ scale: 1 }}
            transition={{ duration: 0.18 }}
            className={cn('font-mono text-[26px] font-semibold leading-[30px] tracking-[-0.02em] text-primary rounded-sm px-1 -ml-1', flash && 'bg-accent-dim')}
          >
            {value}
          </motion.span>
          {spark && <Sparkline data={spark} stroke={sparkStroke} />}
          {delta && (
            <span className={cn('font-mono text-[11px] leading-[14px]', delta.good ? 'text-accent' : 'text-danger')}>
              {delta.dir === 'up' ? '▲' : '▼'} {delta.text}
            </span>
          )}
        </div>
        {sub && <div className="truncate font-mono text-[10px] leading-[14px] text-muted">{sub}</div>}
      </div>
    </motion.button>
  );
});
