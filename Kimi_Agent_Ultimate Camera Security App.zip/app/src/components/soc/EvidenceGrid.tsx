/** EvidenceGrid + lightbox (design.md §6.11) with WebAudio synth playback. */
import { memo, useState } from 'react';
import { Camera, FileVideo, Flame, ScanLine, Volume2, Play } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { AlertEvidence } from '@/lib/types';
import { fmtDateTime } from '@/lib/format';
import { evidenceThumbSvg } from '@/lib/procedural';
import { SocModal } from './primitives';
import { cn } from '@/lib/utils';

const KIND_ICONS: Record<string, LucideIcon> = {
  snapshot: Camera,
  plate_crop: ScanLine,
  video_clip: FileVideo,
  audio_clip: Volume2,
  thermal: Flame,
};

/** WebAudio synth "playback" for audio-clip thumbs (no asset files). */
function playSynthClip(): void {
  try {
    const ctx = new AudioContext();
    const t0 = ctx.currentTime;
    for (let i = 0; i < 14; i++) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.value = 120 + Math.random() * 480;
      const start = t0 + i * 0.07;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(i % 5 === 0 ? 0.06 : 0.015, start + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.06);
      osc.connect(gain).connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.07);
    }
    setTimeout(() => void ctx.close(), 1400);
  } catch {
    /* audio unavailable */
  }
}

const EvidenceThumb = memo(function EvidenceThumb({ item, onOpen }: { item: AlertEvidence; onOpen: (e: AlertEvidence) => void }) {
  const Icon = KIND_ICONS[item.kind] ?? Camera;
  const seed = item.storage_path.replace(/^proc:\/\/[^/]+\//, '');
  return (
    <button
      onClick={() => onOpen(item)}
      className="group relative aspect-video overflow-hidden rounded-sm border border-line bg-inset transition-colors duration-100 hover:border-accent"
    >
      <span className="absolute inset-0 [&>svg]:h-full [&>svg]:w-full">{evidenceThumbSvg(item.kind, seed || item.id, 160, 90)}</span>
      <span className="absolute inset-0 flex items-center justify-center bg-canvas/0 opacity-0 transition-opacity duration-100 group-hover:bg-canvas/40 group-hover:opacity-100">
        <Icon size={18} className="text-accent" />
      </span>
      <span className="absolute bottom-1 left-1 rounded-sm bg-surface-solid/85 px-1 font-mono text-[8px] uppercase text-muted">
        {item.kind.replace('_', ' ')}
      </span>
    </button>
  );
});

export const EvidenceGrid = memo(function EvidenceGrid({ evidence }: { evidence: AlertEvidence[] }) {
  const [lightbox, setLightbox] = useState<AlertEvidence | null>(null);
  if (evidence.length === 0) {
    return <div className="p-3 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">No evidence attached</div>;
  }
  const seedOf = (e: AlertEvidence) => e.storage_path.replace(/^proc:\/\/[^/]+\//, '') || e.id;
  return (
    <>
      <div className="grid grid-cols-3 gap-2 p-3">
        {evidence.map((e) => (
          <EvidenceThumb key={e.id} item={e} onOpen={setLightbox} />
        ))}
      </div>
      <SocModal open={!!lightbox} onClose={() => setLightbox(null)} title={lightbox ? `Evidence — ${lightbox.kind.replace('_', ' ').toUpperCase()}` : undefined} maxWidth={720}>
        {lightbox && (
          <div className="p-4">
            <div className="relative aspect-video w-full overflow-hidden rounded-sm border border-line bg-inset [&>svg]:h-full [&>svg]:w-full">
              {evidenceThumbSvg(lightbox.kind, seedOf(lightbox), 640, 360)}
              {lightbox.kind === 'audio_clip' && (
                <button
                  onClick={playSynthClip}
                  className="absolute bottom-3 right-3 flex h-8 w-8 items-center justify-center rounded-full bg-accent text-on-accent transition-transform hover:scale-105"
                  title="Play (synthesized)"
                >
                  <Play size={14} />
                </button>
              )}
            </div>
            <div className="mt-3 grid grid-cols-2 gap-x-6 gap-y-1.5 font-mono text-[10px]">
              <div className="flex justify-between"><span className="text-muted">CAPTURED</span><span className="text-secondary">{fmtDateTime(lightbox.captured_at)}</span></div>
              <div className="flex justify-between"><span className="text-muted">ALERT</span><span className="text-secondary">{lightbox.alert_id}</span></div>
              <div className="col-span-2 flex justify-between gap-4">
                <span className="text-muted">STORAGE</span>
                <span className="truncate text-secondary" title={lightbox.storage_path}>
                  {lightbox.storage_path.length > 48 ? `${lightbox.storage_path.slice(0, 45)}…` : lightbox.storage_path}
                </span>
              </div>
            </div>
          </div>
        )}
      </SocModal>
    </>
  );
});

export { cn as _cnEvidence };
