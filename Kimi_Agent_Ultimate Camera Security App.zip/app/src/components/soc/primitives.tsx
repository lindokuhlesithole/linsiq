/**
 * SWEALTH OS — shared primitives (design.md §6.12 / §5.4).
 * Buttons, inputs, chips, tabs, toggles, drawers, modals.
 */
import { memo, useEffect, useRef } from 'react';
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { tooltip?: string };

export const SocButton = memo(function SocButton({ className, tooltip, children, ...rest }: BtnProps) {
  return (
    <button
      title={tooltip}
      className={cn(
        'h-8 px-3 rounded-sm bg-accent text-on-accent font-sans text-[12px] font-semibold uppercase tracking-[0.02em]',
        'transition-all duration-100 hover:brightness-110 hover:-translate-y-px active:scale-[0.97]',
        'disabled:bg-raised disabled:text-muted disabled:cursor-not-allowed',
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
});

export const GhostButton = memo(function GhostButton({ className, tooltip, children, ...rest }: BtnProps) {
  return (
    <button
      title={tooltip}
      className={cn(
        'h-8 px-3 rounded-sm border border-line-strong bg-transparent text-secondary font-sans text-[12px] font-semibold uppercase tracking-[0.02em]',
        'transition-colors duration-100 hover:border-accent hover:text-accent',
        'disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:border-line-strong disabled:hover:text-secondary',
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
});

export const DangerButton = memo(function DangerButton({ className, tooltip, children, ...rest }: BtnProps) {
  return (
    <button
      title={tooltip}
      className={cn(
        'h-8 px-3 rounded-sm border border-danger bg-transparent text-danger font-sans text-[12px] font-semibold uppercase tracking-[0.02em]',
        'transition-colors duration-100 hover:bg-danger-dim',
        'disabled:opacity-40 disabled:cursor-not-allowed',
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
});

export const IconButton = memo(function IconButton({ className, tooltip, children, ...rest }: BtnProps) {
  return (
    <button
      title={tooltip}
      className={cn(
        'h-7 w-7 inline-flex items-center justify-center rounded-sm border border-transparent text-secondary',
        'transition-colors duration-100 hover:border-line-strong hover:text-accent hover:bg-raised',
        'disabled:opacity-40 disabled:cursor-not-allowed',
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
});

export const SocInput = memo(function SocInput({ className, mono, ...rest }: InputHTMLAttributes<HTMLInputElement> & { mono?: boolean }) {
  return (
    <input
      className={cn(
        'h-8 w-full rounded-sm border border-line bg-inset px-2.5 text-[12px] text-primary placeholder:text-muted',
        mono ? 'font-mono' : 'font-sans',
        'focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent-dim',
        className,
      )}
      {...rest}
    />
  );
});

export const FilterChip = memo(function FilterChip({ active, onClick, children, className }: { active?: boolean; onClick?: () => void; children: ReactNode; className?: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'h-6 px-2.5 rounded-full font-sans text-[10px] font-semibold uppercase tracking-[0.10em] transition-colors duration-150 border',
        active
          ? 'bg-accent-dim text-accent border-accent/30'
          : 'bg-raised text-secondary border-transparent hover:text-primary',
        className,
      )}
    >
      {children}
    </button>
  );
});

export const ToggleSwitch = memo(function ToggleSwitch({ on, onChange, disabled, tooltip }: { on: boolean; onChange?: (v: boolean) => void; disabled?: boolean; tooltip?: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      title={tooltip ?? (disabled ? 'Requires OPERATOR role' : undefined)}
      disabled={disabled}
      onClick={() => onChange?.(!on)}
      className={cn(
        'h-4 w-7 rounded-full border transition-colors duration-150 relative shrink-0',
        on ? 'bg-accent-dim border-accent' : 'bg-raised border-line',
        disabled && 'opacity-40 cursor-not-allowed',
      )}
    >
      <span
        className={cn(
          'absolute top-1/2 -translate-y-1/2 h-3 w-3 rounded-full transition-all duration-150',
          on ? 'left-[14px] bg-accent' : 'left-[2px] bg-muted',
        )}
      />
    </button>
  );
});

export const SocTabs = memo(function SocTabs<T extends string>({ tabs, active, onChange, idScope = 'tabs' }: { tabs: readonly { id: T; label: string; count?: number }[]; active: T; onChange: (t: T) => void; idScope?: string }) {
  return (
    <div className="flex items-center gap-4 border-b border-line">
      {tabs.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={cn(
            'relative h-8 font-sans text-[11px] font-semibold uppercase tracking-[0.06em] transition-colors duration-150',
            active === t.id ? 'text-accent' : 'text-muted hover:text-secondary',
          )}
        >
          {t.label}
          {typeof t.count === 'number' && <span className="ml-1.5 font-mono text-[10px] text-muted">{t.count}</span>}
          {active === t.id && (
            <motion.span
              layoutId={`${idScope}-underline`}
              className="absolute -bottom-px left-0 right-0 h-0.5 bg-accent"
              transition={{ type: 'spring', stiffness: 500, damping: 40 }}
            />
          )}
        </button>
      ))}
    </div>
  );
});

export const SocDrawer = memo(function SocDrawer({
  open,
  onClose,
  title,
  headerRight,
  width = 480,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  headerRight?: ReactNode;
  width?: 480 | 560;
  children: ReactNode;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    const node = panelRef.current;
    node?.querySelector<HTMLElement>('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')?.focus();
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-40 bg-[rgba(2,6,17,0.6)] backdrop-blur-[2px]"
            onClick={onClose}
          />
          <motion.div
            key="panel"
            ref={panelRef}
            role="dialog"
            aria-modal="true"
            initial={{ x: width }}
            animate={{ x: 0 }}
            exit={{ x: width }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className={cn(
              'fixed right-0 top-14 bottom-0 z-50 bg-surface-solid border-l border-line-strong shadow-drawer flex flex-col',
              width === 560 ? 'w-[560px]' : 'w-[480px]',
            )}
          >
            <div className="flex items-center justify-between gap-3 border-b border-line-strong px-5 h-14 shrink-0">
              <div className="min-w-0 flex-1">{title}</div>
              <div className="flex items-center gap-2 shrink-0">
                {headerRight}
                <IconButton onClick={onClose} tooltip="Close (Esc)">
                  <X size={15} />
                </IconButton>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">{children}</div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
});

export const SocModal = memo(function SocModal({
  open,
  onClose,
  title,
  children,
  maxWidth = 640,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  children: ReactNode;
  maxWidth?: number;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            key="bd"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-40 bg-[rgba(2,6,17,0.6)] backdrop-blur-[2px]"
            onClick={onClose}
          />
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 pointer-events-none">
            <motion.div
              key="md"
              role="dialog"
              aria-modal="true"
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              transition={{ duration: 0.2, ease: [0.2, 0.8, 0.2, 1] }}
              className="pointer-events-auto w-full rounded-sm border border-line-strong bg-surface-solid shadow-drawer"
              style={{ maxWidth }}
            >
              {title !== undefined && (
                <div className="flex items-center justify-between border-b border-line-strong px-5 h-12">
                  <div className="font-sans text-[13px] font-semibold text-primary">{title}</div>
                  <IconButton onClick={onClose} tooltip="Close (Esc)">
                    <X size={15} />
                  </IconButton>
                </div>
              )}
              {children}
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
});

export const Panel = memo(function Panel({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <section className={cn('rounded-sm border border-line bg-surface backdrop-blur-sm', className)}>
      {children}
    </section>
  );
});

export const PanelHeader = memo(function PanelHeader({ label, right, className }: { label: ReactNode; right?: ReactNode; className?: string }) {
  return (
    <header className={cn('flex items-center justify-between gap-2 border-b border-line px-3 h-9 shrink-0', className)}>
      <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">{label}</span>
      <div className="flex items-center gap-2">{right}</div>
    </header>
  );
});
