/** CameraDetailPanel — live feed, PTZ, health, recent reads (design.md §6.8). */
import { memo, useMemo, useState } from 'react';
import type { Camera } from '@/lib/types';
import { useClock, usePlateReads } from '@/hooks/useData';
import { fmtDateTime, fmtHeartbeat, relTime } from '@/lib/format';
import { CameraScene } from '@/lib/procedural';
import { StatusPill } from './StatusPill';
import { PtzPad } from './PtzPad';
import { PlateReadRow } from './PlateReadRow';
import { EmptyState } from './feedback';
import { SocDrawer, SocTabs } from './primitives';
import { ScanLine } from 'lucide-react';
import { cn } from '@/lib/utils';

type Tab = 'feed' | 'health' | 'reads';

const BurnIn = memo(function BurnIn() {
  const now = useClock(1000);
  return <span className="hud-text font-mono text-[11px]">{fmtDateTime(now)}</span>;
});

export const CameraDetailPanel = memo(function CameraDetailPanel({
  camera,
  open,
  onClose,
}: {
  camera: Camera | null;
  open: boolean;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<Tab>('feed');
  const reads = usePlateReads(camera ? { cameraId: camera.id, limit: 12 } : undefined);
  const cameras = useMemo(() => (camera ? [camera] : []), [camera]);

  return (
    <SocDrawer
      open={open}
      onClose={onClose}
      title={
        <div className="flex min-w-0 items-center gap-2">
          <span className="truncate font-sans text-[14px] font-semibold text-primary">{camera?.name ?? 'Camera'}</span>
        </div>
      }
      headerRight={camera ? <StatusPill status={camera.status} /> : undefined}
    >
      {!camera ? (
        <div className="p-5 font-mono text-[11px] text-muted">Camera not found in current tenant scope.</div>
      ) : (
        <div className="flex h-full flex-col">
          {/* large live feed */}
          <div className="relative aspect-video w-full shrink-0 overflow-hidden border-b border-line bg-inset">
            {camera.status === 'offline' ? (
              <div className="flex h-full flex-col items-center justify-center gap-1.5">
                <span className="font-mono text-[13px] font-semibold uppercase tracking-[0.2em] text-danger">Signal lost</span>
                <span className="font-mono text-[10px] text-muted">last seen {fmtDateTime(camera.last_heartbeat)}</span>
              </div>
            ) : (
              <>
                <CameraScene seed={camera.id} kind={camera.kind} noisy={camera.status === 'degraded'} className="absolute inset-0 h-full w-full" />
                <div className="scanlines absolute inset-0" />
                <div className="scan-band absolute inset-0 overflow-hidden" />
                <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-2">
                  <div className="flex items-start justify-between">
                    <span className="hud-text font-mono text-[11px] uppercase">{camera.name} · {camera.zone}</span>
                    <span className="flex items-center gap-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-danger animate-rec-blink" />
                      <span className="hud-text font-mono text-[10px] font-semibold">REC</span>
                    </span>
                  </div>
                  <div className="flex items-end justify-between">
                    <BurnIn />
                    <span className="hud-text font-mono text-[10px]">{camera.resolution} · {camera.fps}FPS</span>
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="px-5 pt-3">
            <SocTabs
              idScope="camera-detail"
              tabs={[
                { id: 'feed' as Tab, label: camera.ptz_enabled ? 'PTZ Control' : 'Feed' },
                { id: 'health' as Tab, label: 'Health' },
                { id: 'reads' as Tab, label: 'Plate Reads', count: reads.length },
              ]}
              active={tab}
              onChange={(t) => setTab(t as Tab)}
            />
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
            {tab === 'feed' && (
              <div className="space-y-4">
                {camera.ptz_enabled ? (
                  <PtzPad cameraId={camera.id} />
                ) : (
                  <div className="rounded-sm border border-line bg-inset p-3 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
                    Fixed camera — no PTZ head installed
                  </div>
                )}
                <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 font-mono text-[10px]">
                  <div className="flex justify-between"><span className="text-muted">KIND</span><span className="text-secondary">{camera.kind}</span></div>
                  <div className="flex justify-between"><span className="text-muted">ZONE</span><span className="text-secondary">{camera.zone}</span></div>
                  <div className="flex justify-between"><span className="text-muted">HEADING</span><span className="text-secondary">{camera.heading_deg}°</span></div>
                  <div className="col-span-2 flex justify-between gap-4"><span className="text-muted">RTSP</span><span className="truncate text-secondary">{camera.rtsp_url}</span></div>
                </div>
              </div>
            )}

            {tab === 'health' && (
              <div className="space-y-3">
                <HealthRow label="HEARTBEAT" value={fmtHeartbeat(camera.last_heartbeat)} tone={Date.now() - new Date(camera.last_heartbeat).getTime() > 30_000 ? 'warn' : 'ok'} />
                <HealthRow label="STATUS" value={camera.status.toUpperCase()} tone={camera.status === 'offline' ? 'bad' : camera.status === 'degraded' ? 'warn' : 'ok'} />
                <div>
                  <div className="flex justify-between font-mono text-[10px]">
                    <span className="text-muted">STORAGE</span>
                    <span className="text-secondary">{Math.round(camera.storage_used_pct)}%</span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-raised">
                    <div className={cn('h-full rounded-full', camera.storage_used_pct > 85 ? 'bg-warning' : 'bg-accent')} style={{ width: `${camera.storage_used_pct}%` }} />
                  </div>
                </div>
                <HealthRow label="FIRMWARE" value={camera.firmware} />
                <HealthRow label="INSTALLED" value={fmtDateTime(camera.install_date).slice(0, 10)} />
                <HealthRow label="LAST EVENT" value={relTime(camera.last_heartbeat)} />
              </div>
            )}

            {tab === 'reads' && (
              <div className="-mx-5">
                {reads.length === 0 ? (
                  <EmptyState icon={ScanLine} heading="No plate reads" copy="This camera has not captured any plates in the current window." />
                ) : (
                  reads.map((r) => <PlateReadRow key={r.id} read={r} camera={cameras[0]} />)
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </SocDrawer>
  );
});

function HealthRow({ label, value, tone }: { label: string; value: string; tone?: 'ok' | 'warn' | 'bad' }) {
  return (
    <div className="flex justify-between font-mono text-[10px]">
      <span className="text-muted">{label}</span>
      <span className={cn(tone === 'ok' && 'text-accent', tone === 'warn' && 'text-warning', tone === 'bad' && 'text-danger', !tone && 'text-secondary')}>
        {value}
      </span>
    </div>
  );
}
