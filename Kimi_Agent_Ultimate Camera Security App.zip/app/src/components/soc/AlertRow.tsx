/** AlertRow + GroupedAlertRow (design.md §6.7) + shared alert type icon map. */
import { memo, useMemo, useState } from 'react';
import {
  Car, ChevronDown, Cctv, Crosshair, Flame, Hourglass, PersonStanding, ScanLine,
  Siren, Volume2, WifiOff,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import type { Alert, AlertRoutingRule, AlertType } from '@/lib/types';
import { fmtCountdown, relTime } from '@/lib/format';
import { useClock } from '@/hooks/useData';
import { SeverityBadge, StatusPill } from './StatusPill';
import { cn } from '@/lib/utils';

export const ALERT_TYPE_ICONS: Record<AlertType, LucideIcon> = {
  hotlist_hit: Flame,
  perimeter_breach: Crosshair,
  unidentified_person: PersonStanding,
  gunshot: Volume2,
  drone_anomaly: Siren,
  offline_device: WifiOff,
  fire_smoke: Flame,
  loitering: Hourglass,
  tailgating: Car,
};

export function alertTypeIcon(type: AlertType): LucideIcon {
  return ALERT_TYPE_ICONS[type] ?? ScanLine;
}

/* Routing badge with escalation countdown */
const RoutingBadge = memo(function RoutingBadge({ alert, rule }: { alert: Alert; rule?: AlertRoutingRule }) {
  const now = useClock(1000);
  if (!rule) return null;
  if (alert.status !== 'new') {
    return (
      <span className="rounded-sm bg-info-dim px-1 py-px font-mono text-[9px] text-info">
        → {rule.role.toUpperCase()} · {rule.channel.toUpperCase()}
      </span>
    );
  }
  const ageSec = (now.getTime() - new Date(alert.created_at).getTime()) / 1000;
  const remain = rule.escalate_after_sec - ageSec;
  if (remain > 0 && remain < rule.escalate_after_sec * 0.5) {
    return (
      <span className="rounded-sm bg-warning-dim px-1 py-px font-mono text-[9px] text-warning">
        ESC {fmtCountdown(remain)}
      </span>
    );
  }
  return (
    <span className="rounded-sm bg-info-dim px-1 py-px font-mono text-[9px] text-info">
      → {rule.role.toUpperCase()} · {rule.channel.toUpperCase()}
    </span>
  );
});

const RAIL: Record<string, string> = {
  critical: 'bg-danger',
  high: 'bg-warning',
  medium: 'bg-info',
  low: 'bg-severity-low',
};

export interface AlertRowProps {
  alert: Alert;
  rule?: AlertRoutingRule;
  onClick?: (a: Alert) => void;
  /** render entrance flash for freshly-arrived rows */
  fresh?: boolean;
  dense?: boolean;
}

export const AlertRow = memo(function AlertRow({ alert, rule, onClick, fresh = false, dense = false }: AlertRowProps) {
  const Icon = alertTypeIcon(alert.type);
  return (
    <motion.button
      layout="position"
      initial={fresh ? { backgroundColor: alert.severity === 'critical' ? 'rgba(231,29,54,0.14)' : 'rgba(255,159,28,0.12)' } : false}
      animate={{ backgroundColor: 'rgba(0,0,0,0)' }}
      transition={{ duration: 1.2 }}
      onClick={() => onClick?.(alert)}
      className={cn(
        'relative flex w-full items-center gap-2.5 border-b border-line px-3 pl-3.5 text-left transition-colors hover:bg-raised/60',
        dense ? 'h-10' : 'h-12',
      )}
    >
      <span className={cn('absolute left-0 top-0 bottom-0 w-0.5', RAIL[alert.severity])} />
      <Icon size={16} className="shrink-0 text-secondary" />
      <div className="min-w-0 flex-1">
        <div className="truncate font-sans text-[12px] font-medium text-primary">{alert.title}</div>
        {!dense && <div className="truncate font-sans text-[11px] text-muted">{alert.ai_summary}</div>}
      </div>
      <span className="hidden shrink-0 font-mono text-[10px] text-muted md:block">{alert.source_name}</span>
      <span className="hidden shrink-0 lg:block">
        <RoutingBadge alert={alert} rule={rule} />
      </span>
      <SeverityBadge severity={alert.severity} className="shrink-0" />
      <StatusPill status={alert.status} className="hidden shrink-0 sm:inline-flex" />
      <span className="w-14 shrink-0 text-right font-mono text-[10px] text-muted" title={alert.created_at}>
        {relTime(alert.created_at)}
      </span>
    </motion.button>
  );
});

/* ── Grouped variant: collapses repeats from same source+type ────────────── */

export function groupAlerts(alerts: Alert[]): { key: string; head: Alert; children: Alert[] }[] {
  const groups = new Map<string, { key: string; head: Alert; children: Alert[] }>();
  for (const a of alerts) {
    const key = `${a.source_id}:${a.type}`;
    const g = groups.get(key);
    if (!g) {
      groups.set(key, { key, head: a, children: [a] });
    } else {
      g.children.push(a);
      if (a.created_at > g.head.created_at) g.head = a;
    }
  }
  return [...groups.values()].sort((x, y) => y.head.created_at.localeCompare(x.head.created_at));
}

export const GroupedAlertRow = memo(function GroupedAlertRow({
  group,
  rules,
  onAlertClick,
}: {
  group: { key: string; head: Alert; children: Alert[] };
  rules: AlertRoutingRule[];
  onAlertClick?: (a: Alert) => void;
}) {
  const [open, setOpen] = useState(false);
  const rule = useMemo(() => rules.find((r) => r.severity === group.head.severity), [rules, group.head.severity]);
  const single = group.children.length <= 1;
  return (
    <div className="border-b border-line">
      <div className="relative">
        {!single && (
          <span className="absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-sm bg-accent-dim px-1 font-mono text-[9px] font-semibold text-accent">
            ×{group.children.length}
          </span>
        )}
        <div className={cn(!single && 'pl-8')}>
          <AlertRow alert={group.head} rule={rule} onClick={single ? onAlertClick : undefined} />
        </div>
        {!single && (
          <button
            onClick={() => setOpen((o) => !o)}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted transition-transform hover:text-accent"
            aria-label={open ? 'Collapse group' : 'Expand group'}
          >
            <ChevronDown size={14} className={cn('transition-transform duration-200', open && 'rotate-180')} />
          </button>
        )}
      </div>
      <AnimatePresence initial={false}>
        {open && !single && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden bg-inset/60"
          >
            {group.children.map((c, i) => (
              <motion.div
                key={c.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04 }}
              >
                <AlertRow alert={c} rule={rule} onClick={onAlertClick} dense />
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
});

export { Cctv as _cctvIcon };
