/** AlertDetailDrawer — full triage workflow (design.md §6.8, alerts.md contract). */
import { memo, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCheck, ShieldQuestion, Siren, UserPlus } from 'lucide-react';
import {
  acknowledgeAlert, assignGuard, dispatchGuard, resolveAlert,
  useAlert, useAuditLog, useCanOperate, useEvidence, useGuards, useRoutingRules,
} from '@/hooks/useData';
import { fmtDateTime, relTime } from '@/lib/format';
import { SeverityBadge, StatusPill } from './StatusPill';
import { EvidenceGrid } from './EvidenceGrid';
import { DangerButton, GhostButton, SocButton, SocDrawer, SocTabs } from './primitives';
import { alertTypeIcon } from './AlertRow';
import { cn } from '@/lib/utils';

type Tab = 'overview' | 'evidence' | 'timeline';

export const AlertDetailDrawer = memo(function AlertDetailDrawer({
  alertId,
  open,
  onClose,
}: {
  alertId: string | null;
  open: boolean;
  onClose: () => void;
}) {
  const alert = useAlert(alertId);
  const guards = useGuards();
  const rules = useRoutingRules();
  const allEvidence = useEvidence();
  const audit = useAuditLog();
  const canOperate = useCanOperate();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('overview');
  const [assignee, setAssignee] = useState('');

  const evidence = useMemo(() => allEvidence.filter((e) => e.alert_id === alertId), [allEvidence, alertId]);
  const trail = useMemo(() => audit.filter((a) => a.entity_id === alertId).slice(0, 20), [audit, alertId]);
  const rule = alert ? rules.find((r) => r.severity === alert.severity) : undefined;
  const isOpen = alert && (alert.status === 'new' || alert.status === 'acknowledged' || alert.status === 'responding');

  const headerTitle = alert ? (
    <div className="flex min-w-0 items-center gap-2">
      <span className="truncate font-sans text-[14px] font-semibold text-primary">{alert.title}</span>
    </div>
  ) : (
    <span className="font-sans text-[14px] text-muted">Alert</span>
  );

  return (
    <SocDrawer
      open={open}
      onClose={onClose}
      title={headerTitle}
      headerRight={alert ? (
        <>
          <SeverityBadge severity={alert.severity} />
          <StatusPill status={alert.status} />
        </>
      ) : undefined}
    >
      {!alert ? (
        <div className="p-5 font-mono text-[11px] text-muted">Alert not found in current tenant scope.</div>
      ) : (
        <div className="flex h-full flex-col">
          {/* summary strip */}
          <div className="border-b border-line px-5 py-3">
            <div className="flex items-center justify-between font-mono text-[10px] text-muted">
              <span>{alert.source_name} · {alert.source_kind.toUpperCase()}</span>
              <span title={alert.created_at}>{relTime(alert.created_at)}</span>
            </div>
            <div className="mt-2 flex items-center gap-2">
              <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-muted">AI confidence</span>
              <span className="h-1 flex-1 overflow-hidden rounded-full bg-raised">
                <span
                  className={cn('block h-full rounded-full', alert.ai_confidence > 0.85 ? 'bg-accent' : alert.ai_confidence > 0.65 ? 'bg-warning' : 'bg-danger')}
                  style={{ width: `${alert.ai_confidence * 100}%` }}
                />
              </span>
              <span className="font-mono text-[10px] text-secondary">{Math.round(alert.ai_confidence * 100)}%</span>
            </div>
            {rule && (
              <div className="mt-2 font-mono text-[9px] text-info">
                ROUTING → {rule.role.toUpperCase()} · {rule.channel.toUpperCase()} · ESC AFTER {rule.escalate_after_sec}S
                {alert.escalated && <span className="ml-2 text-warning">— ESCALATED</span>}
              </div>
            )}
          </div>

          <div className="px-5 pt-3">
            <SocTabs
              idScope="alert-detail"
              tabs={[
                { id: 'overview' as Tab, label: 'Overview' },
                { id: 'evidence' as Tab, label: 'Evidence', count: evidence.length },
                { id: 'timeline' as Tab, label: 'Timeline' },
              ]}
              active={tab}
              onChange={(t) => setTab(t as Tab)}
            />
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto">
            {tab === 'overview' && (
              <div className="space-y-4 px-5 py-4">
                <p className="max-w-[72ch] font-sans text-[13px] leading-5 text-secondary">{alert.ai_summary}</p>
                <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 font-mono text-[10px]">
                  <div className="flex justify-between"><span className="text-muted">TYPE</span><span className="text-secondary">{alert.type.replace(/_/g, ' ')}</span></div>
                  <div className="flex justify-between"><span className="text-muted">SOURCE</span><span className="text-secondary">{alert.source_name}</span></div>
                  <div className="flex justify-between"><span className="text-muted">CREATED</span><span className="text-secondary">{fmtDateTime(alert.created_at)}</span></div>
                  <div className="flex justify-between"><span className="text-muted">UPDATED</span><span className="text-secondary">{relTime(alert.updated_at)}</span></div>
                  {alert.acknowledged_by && (
                    <div className="flex justify-between"><span className="text-muted">ACK BY</span><span className="text-secondary">{alert.acknowledged_by}</span></div>
                  )}
                  {alert.plate_read_id && (
                    <div className="flex justify-between">
                      <span className="text-muted">PLATE READ</span>
                      <button className="text-info hover:underline" onClick={() => navigate('/alpr')}>
                        open in ALPR →
                      </button>
                    </div>
                  )}
                </div>

                {/* triage actions */}
                <div className="space-y-2 border-t border-line pt-4">
                  <div className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">Triage</div>
                  <div className="flex flex-wrap gap-2">
                    <SocButton disabled={!isOpen || alert.status !== 'new'} onClick={() => acknowledgeAlert(alert.id)} tooltip={alert.status !== 'new' ? 'Already acknowledged' : undefined}>
                      <span className="inline-flex items-center gap-1.5"><CheckCheck size={13} /> Acknowledge</span>
                    </SocButton>
                    <GhostButton disabled={!isOpen} onClick={() => resolveAlert(alert.id, 'resolved')}>
                      Resolve
                    </GhostButton>
                    <DangerButton disabled={!isOpen} onClick={() => resolveAlert(alert.id, 'false_alarm', 'Operator marked false alarm from triage drawer')}>
                      <span className="inline-flex items-center gap-1.5"><ShieldQuestion size={13} /> False alarm</span>
                    </DangerButton>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <select
                      value={assignee}
                      onChange={(e) => setAssignee(e.target.value)}
                      className="h-8 flex-1 rounded-sm border border-line bg-inset px-2 font-sans text-[12px] text-primary focus:border-accent focus:outline-none"
                    >
                      <option value="">Select guard…</option>
                      {guards.filter((g) => g.status !== 'off_duty').map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.full_name} ({g.badge_no}) — {g.status.replace('_', ' ')}
                        </option>
                      ))}
                    </select>
                    <GhostButton
                      disabled={!assignee || !isOpen || !canOperate}
                      tooltip={!canOperate ? 'Requires OPERATOR role' : undefined}
                      onClick={() => assignee && assignGuard(alert.id, assignee)}
                    >
                      <span className="inline-flex items-center gap-1.5"><UserPlus size={13} /> Assign</span>
                    </GhostButton>
                    <SocButton
                      disabled={!assignee || !isOpen || !canOperate}
                      tooltip={!canOperate ? 'Requires OPERATOR role' : undefined}
                      onClick={() => assignee && dispatchGuard(assignee, alert.id)}
                    >
                      <span className="inline-flex items-center gap-1.5"><Siren size={13} /> Dispatch</span>
                    </SocButton>
                  </div>
                </div>
              </div>
            )}

            {tab === 'evidence' && <EvidenceGrid evidence={evidence} />}

            {tab === 'timeline' && (
              <div className="space-y-0 px-5 py-4">
                <TimelineRow when={alert.created_at} label={`Alert created — ${alert.type.replace(/_/g, ' ')} (${alert.severity})`} />
                {alert.escalated_at && <TimelineRow when={alert.escalated_at} label="Escalated — routing timer overran, severity bumped" warn />}
                {alert.acknowledged_at && <TimelineRow when={alert.acknowledged_at} label={`Acknowledged by ${alert.acknowledged_by ?? 'operator'}`} />}
                {alert.resolved_at && <TimelineRow when={alert.resolved_at} label={`Closed as ${alert.status.replace('_', ' ')}`} />}
                {trail.map((t) => (
                  <TimelineRow key={t.id} when={t.created_at} label={`${t.action} — ${t.detail}`} muted />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </SocDrawer>
  );
});

function TimelineRow({ when, label, warn = false, muted = false }: { when: string; label: string; warn?: boolean; muted?: boolean }) {
  return (
    <div className="flex gap-3 border-l border-line-strong py-1.5 pl-3">
      <span className="w-16 shrink-0 font-mono text-[10px] text-muted">{fmtDateTime(when).slice(11)}</span>
      <span className={cn('font-sans text-[11px]', warn ? 'text-warning' : muted ? 'text-muted' : 'text-secondary')}>{label}</span>
    </div>
  );
}

export { alertTypeIcon as _ati };
