/** AlertTicker + PlateTicker (design.md §6.6) — memoized rows, pause-on-hover. */
import { memo, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowDownLeft, ArrowUpRight, Flame } from 'lucide-react';
import type { Alert, Camera, PlateRead } from '@/lib/types';
import { relTime } from '@/lib/format';
import { useClock } from '@/hooks/useData';
import { ALERT_TYPE_ICONS } from './AlertRow';
import { PlateChip } from './PlateReadRow';
import { cn } from '@/lib/utils';

/* Shared pause wrapper — stops row insertion visually while hovered */
function TickerShell({ children, className }: { children: ReactNode; className?: string }) {
  const [paused, setPaused] = useState(false);
  return (
    <div
      className={cn('ticker-mask relative min-h-0 flex-1 overflow-hidden', className)}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <AnimatePresence>
        {paused && (
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.12 }}
            className="absolute left-1/2 top-1.5 z-10 -translate-x-1/2 rounded-full bg-surface-solid px-2 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-[0.1em] text-warning border border-line-strong"
          >
            ⏸ Paused
          </motion.span>
        )}
      </AnimatePresence>
      <div className="flex h-full flex-col">{children}</div>
    </div>
  );
}

/* ── Alert ticker row ────────────────────────────────────────────────────── */

const AlertTickerRow = memo(function AlertTickerRow({ alert, onClick }: { alert: Alert; onClick?: (a: Alert) => void }) {
  const Icon = ALERT_TYPE_ICONS[alert.type] ?? ALERT_TYPE_ICONS.loitering;
  const rail = alert.severity === 'critical' ? 'bg-danger' : alert.severity === 'high' ? 'bg-warning' : alert.severity === 'medium' ? 'bg-info' : 'bg-severity-low';
  return (
    <motion.button
      layout
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.25 }}
      onClick={() => onClick?.(alert)}
      className={cn(
        'relative flex h-10 w-full shrink-0 items-center gap-2 border-b border-line px-2.5 pl-3 text-left transition-colors hover:bg-raised/60',
        alert.status === 'new' && alert.severity === 'critical' && 'bg-danger-dim',
      )}
    >
      <span className={cn('absolute left-0 top-0 bottom-0 w-0.5', rail)} />
      <Icon size={14} className="shrink-0 text-secondary" />
      <span className="min-w-0 flex-1 truncate font-sans text-[11px] text-primary">{alert.title}</span>
      {alert.escalated && (
        <span className="shrink-0 rounded-sm bg-warning-dim px-1 font-mono text-[8px] font-semibold text-warning">ESC</span>
      )}
      <span className="shrink-0 font-mono text-[10px] text-muted" title={alert.created_at}>
        {relTime(alert.created_at)}
      </span>
    </motion.button>
  );
});

export const AlertTicker = memo(function AlertTicker({ alerts, onAlertClick }: { alerts: Alert[]; onAlertClick?: (a: Alert) => void }) {
  // 30s heartbeat keeps relative timestamps fresh without re-rendering per second
  const minuteBucket = Math.floor(useClock(30_000).getTime() / 15_000);
  const { pinned, stream } = useMemo(() => {
    const pinned = alerts.filter((a) => a.severity === 'critical' && a.status === 'new').slice(0, 3);
    const pinnedIds = new Set(pinned.map((a) => a.id));
    return { pinned, stream: alerts.filter((a) => !pinnedIds.has(a.id)).slice(0, 10) };
  }, [alerts]);
  return (
    <TickerShell>
      {pinned.map((a) => (
        <AlertTickerRow key={`${a.id}-${minuteBucket}`} alert={a} onClick={onAlertClick} />
      ))}
      {stream.map((a) => (
        <AlertTickerRow key={`${a.id}-${minuteBucket}`} alert={a} onClick={onAlertClick} />
      ))}
      {alerts.length === 0 && (
        <div className="flex flex-1 items-center justify-center p-4 font-mono text-[10px] uppercase tracking-[0.12em] text-accent">
          All clear — no active alerts
        </div>
      )}
    </TickerShell>
  );
});

/* ── Plate ticker row ────────────────────────────────────────────────────── */

const PlateTickerRow = memo(function PlateTickerRow({ read, cameraCode, onClick }: { read: PlateRead; cameraCode: string; onClick?: (r: PlateRead) => void }) {
  return (
    <motion.button
      layout
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.25 }}
      onClick={() => onClick?.(read)}
      className={cn(
        'relative flex h-10 w-full shrink-0 items-center gap-2 border-b border-line px-2.5 text-left transition-colors hover:bg-raised/60',
        read.hotlist_hit && 'bg-danger-dim pl-3',
      )}
    >
      {read.hotlist_hit && <span className="absolute left-0 top-0 bottom-0 w-0.5 bg-danger" />}
      <PlateChip plate={read.plate} hot={read.hotlist_hit} small />
      <span className="min-w-0 flex-1 truncate font-sans text-[10px] text-secondary">
        {read.vehicle_color} {read.vehicle_make}
      </span>
      {read.hotlist_hit && (
        <span className="flex shrink-0 items-center gap-0.5 rounded-sm bg-danger px-1 py-px font-mono text-[8px] font-semibold text-primary">
          <Flame size={8} /> HOT
        </span>
      )}
      <span className="shrink-0 font-mono text-[9px] text-muted">{cameraCode}</span>
      {read.direction === 'inbound' ? (
        <ArrowDownLeft size={12} className="shrink-0 text-accent" />
      ) : (
        <ArrowUpRight size={12} className="shrink-0 text-muted" />
      )}
      <span className="shrink-0 font-mono text-[10px] text-muted" title={read.captured_at}>
        {relTime(read.captured_at)}
      </span>
    </motion.button>
  );
});

export const PlateTicker = memo(function PlateTicker({ reads, cameras, onReadClick }: { reads: PlateRead[]; cameras: Camera[]; onReadClick?: (r: PlateRead) => void }) {
  const camNames = useMemo(() => {
    const m = new Map<string, string>();
    cameras.forEach((c) => m.set(c.id, c.name.replace(' ALPR', '').toUpperCase()));
    return m;
  }, [cameras]);
  const minuteBucket = Math.floor(useClock(30_000).getTime() / 15_000);
  const top = reads.slice(0, 10);
  return (
    <TickerShell>
      {top.map((r) => (
        <PlateTickerRow key={`${r.id}-${minuteBucket}`} read={r} cameraCode={camNames.get(r.camera_id) ?? '—'} onClick={onReadClick} />
      ))}
      {reads.length === 0 && (
        <div className="flex flex-1 items-center justify-center p-4 font-mono text-[10px] uppercase tracking-[0.12em] text-muted">
          No reads in window
        </div>
      )}
    </TickerShell>
  );
});
