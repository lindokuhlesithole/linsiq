/** StatusPill + SeverityBadge + ThreatLevelGauge (design.md §6.1/§6.2, §2.4). */
import { memo } from 'react';
import type { Severity, ThreatLevel } from '@/lib/types';
import { cn } from '@/lib/utils';

/* Status → token mapping (single source of truth, design.md §2.4) */
const STATUS_TOKENS: Record<string, { dot: string; bg: string; text: string; pulse?: boolean }> = {
  online: { dot: 'bg-accent', bg: 'bg-accent-dim', text: 'text-accent', pulse: true },
  recording: { dot: 'bg-accent', bg: 'bg-accent-dim', text: 'text-accent', pulse: true },
  motion: { dot: 'bg-info', bg: 'bg-info-dim', text: 'text-info' },
  degraded: { dot: 'bg-warning', bg: 'bg-warning-dim', text: 'text-warning' },
  offline: { dot: 'bg-danger', bg: 'bg-danger-dim', text: 'text-danger' },
  critical: { dot: 'bg-danger', bg: 'bg-danger-dim', text: 'text-danger', pulse: true },
  high: { dot: 'bg-warning', bg: 'bg-warning-dim', text: 'text-warning' },
  medium: { dot: 'bg-info', bg: 'bg-info-dim', text: 'text-info' },
  low: { dot: 'bg-severity-low', bg: 'bg-raised', text: 'text-muted' },
  idle: { dot: 'bg-muted', bg: 'bg-raised', text: 'text-muted' },
  patrolling: { dot: 'bg-accent', bg: 'bg-accent-dim', text: 'text-accent', pulse: true },
  responding: { dot: 'bg-warning', bg: 'bg-warning-dim', text: 'text-warning', pulse: true },
  charging: { dot: 'bg-info', bg: 'bg-info-dim', text: 'text-info' },
  returning: { dot: 'bg-warning', bg: 'bg-warning-dim', text: 'text-warning' },
  on_duty: { dot: 'bg-accent', bg: 'bg-accent-dim', text: 'text-accent' },
  on_break: { dot: 'bg-info', bg: 'bg-info-dim', text: 'text-info' },
  off_duty: { dot: 'bg-muted', bg: 'bg-raised', text: 'text-muted' },
  new: { dot: 'bg-danger', bg: 'bg-danger-dim', text: 'text-danger', pulse: true },
  acknowledged: { dot: 'bg-info', bg: 'bg-info-dim', text: 'text-info' },
  resolved: { dot: 'bg-accent', bg: 'bg-accent-dim', text: 'text-accent' },
  false_alarm: { dot: 'bg-muted', bg: 'bg-raised', text: 'text-muted' },
  confirmed: { dot: 'bg-accent', bg: 'bg-accent-dim', text: 'text-accent' },
  dismissed: { dot: 'bg-muted', bg: 'bg-raised', text: 'text-muted' },
  open: { dot: 'bg-danger', bg: 'bg-danger-dim', text: 'text-danger' },
  investigating: { dot: 'bg-warning', bg: 'bg-warning-dim', text: 'text-warning' },
  closed: { dot: 'bg-accent', bg: 'bg-accent-dim', text: 'text-accent' },
  escalated_saps: { dot: 'bg-info', bg: 'bg-info-dim', text: 'text-info' },
};

export const StatusPill = memo(function StatusPill({ status, label, className }: { status: string; label?: string; className?: string }) {
  const t = STATUS_TOKENS[status] ?? STATUS_TOKENS.idle;
  return (
    <span className={cn('inline-flex h-[18px] items-center gap-1.5 rounded-full px-2', t.bg, className)}>
      <span className={cn('h-1.5 w-1.5 rounded-full', t.dot, t.pulse && 'animate-live-pulse')} />
      <span className={cn('font-sans text-[10px] font-semibold uppercase tracking-[0.10em] leading-3', t.text)}>
        {(label ?? status).replace(/_/g, ' ')}
      </span>
    </span>
  );
});

const SEV_TOKENS: Record<Severity, { bar: string; bg: string; text: string }> = {
  critical: { bar: 'bg-danger', bg: 'bg-danger-dim', text: 'text-danger' },
  high: { bar: 'bg-warning', bg: 'bg-warning-dim', text: 'text-warning' },
  medium: { bar: 'bg-info', bg: 'bg-info-dim', text: 'text-info' },
  low: { bar: 'bg-severity-low', bg: 'bg-raised', text: 'text-muted' },
};

export const SeverityBadge = memo(function SeverityBadge({ severity, className }: { severity: Severity; className?: string }) {
  const t = SEV_TOKENS[severity];
  return (
    <span className={cn('relative inline-flex h-[18px] items-center rounded-sm pl-2.5 pr-1.5', t.bg, className)}>
      <span className={cn('absolute left-0 top-0 bottom-0 w-0.5 rounded-l-sm', t.bar)} />
      <span className={cn('font-sans text-[10px] font-semibold uppercase tracking-[0.10em] leading-3', t.text)}>{severity}</span>
    </span>
  );
});

/** severity → accent token hex (SVG attribute space) */
export const SEVERITY_HEX: Record<Severity, string> = {
  critical: '#E71D36',
  high: '#FF9F1C',
  medium: '#4CC9F0',
  low: '#5C6B8A',
};

const THREAT_TOKENS: Record<ThreatLevel, { text: string; dot: string }> = {
  LOW: { text: 'text-accent', dot: '#00D4AA' },
  GUARDED: { text: 'text-info', dot: '#4CC9F0' },
  ELEVATED: { text: 'text-warning', dot: '#FF9F1C' },
  HIGH: { text: 'text-danger', dot: '#E71D36' },
};
const THREAT_ORDER: ThreatLevel[] = ['LOW', 'GUARDED', 'ELEVATED', 'HIGH'];

export const ThreatLevelGauge = memo(function ThreatLevelGauge({ level, compact = false }: { level: ThreatLevel; compact?: boolean }) {
  const idx = THREAT_ORDER.indexOf(level);
  const t = THREAT_TOKENS[level];
  return (
    <span className={cn('inline-flex items-center gap-1.5', level === 'HIGH' && 'animate-live-pulse')}>
      {!compact && <span className="h-1.5 w-1.5 rounded-full" style={{ background: t.dot }} />}
      <span className={cn('font-sans text-[10px] font-semibold uppercase tracking-[0.10em]', t.text)}>
        {compact ? level : `THREAT: ${level}`}
      </span>
      <span className="inline-flex items-center gap-[3px]">
        {THREAT_ORDER.map((_, i) => (
          <span
            key={i}
            className="h-[5px] w-[9px] rounded-[1px]"
            style={{ background: i <= idx ? t.dot : 'rgba(92,107,138,0.35)' }}
          />
        ))}
      </span>
    </span>
  );
});
