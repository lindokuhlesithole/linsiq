/** PtzPad + PtzLifecycleTracker (design.md §6.9). */
import { memo, useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Crosshair, Minus, Plus } from 'lucide-react';
import type { PtzAction, PtzCommand } from '@/lib/types';
import { sendPtzCommand, usePtzCommands, useCanOperate } from '@/hooks/useData';
import { cn } from '@/lib/utils';

const HOLD_TO_SAVE_MS = 1200;

export const PtzLifecycleTracker = memo(function PtzLifecycleTracker({ command }: { command: PtzCommand | null }) {
  if (!command) {
    return (
      <div className="flex items-center gap-2 font-mono text-[9px] text-muted">
        <span className="h-1.5 w-1.5 rounded-full bg-muted" /> NO ACTIVE COMMAND
      </div>
    );
  }
  const steps: { id: string; label: string; state: 'done' | 'active' | 'pending' | 'failed' }[] = [];
  const s = command.status;
  steps.push({ id: 'd', label: 'DISPATCHED', state: s === 'dispatched' ? 'active' : 'done' });
  steps.push({
    id: 'a', label: 'ACK',
    state: s === 'dispatched' ? 'pending' : s === 'acknowledged' ? 'active' : s === 'failed' ? 'failed' : 'done',
  });
  steps.push({
    id: 'c', label: s === 'failed' ? 'FAILED' : 'DONE',
    state: s === 'completed' ? 'done' : s === 'failed' ? 'failed' : 'pending',
  });
  return (
    <div className="flex items-center gap-1.5">
      {steps.map((st, i) => (
        <div key={st.id} className="flex items-center gap-1.5">
          {i > 0 && <span className="h-px w-4 bg-line-strong" />}
          <span
            className={cn(
              'h-1.5 w-1.5 rounded-full',
              st.state === 'done' && 'bg-accent',
              st.state === 'active' && 'bg-warning animate-live-pulse',
              st.state === 'pending' && 'bg-muted',
              st.state === 'failed' && 'bg-danger',
            )}
          />
          <span
            className={cn(
              'font-mono text-[9px] tracking-[0.06em]',
              st.state === 'done' && 'text-accent',
              st.state === 'active' && 'text-warning',
              st.state === 'pending' && 'text-muted',
              st.state === 'failed' && 'text-danger',
            )}
          >
            {st.label}
          </span>
        </div>
      ))}
      {command.status === 'failed' && (
        <span className="ml-1 font-mono text-[9px] text-danger">— RETRY via pad</span>
      )}
    </div>
  );
});

export const PtzPad = memo(function PtzPad({ cameraId, compact = false }: { cameraId: string; compact?: boolean }) {
  const canOperate = useCanOperate();
  const commands = usePtzCommands();
  const latest = commands.find((c) => c.camera_id === cameraId) ?? null;
  const [savingPreset, setSavingPreset] = useState<number | null>(null);
  const holdTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    if (holdTimer.current) clearTimeout(holdTimer.current);
  }, []);

  const fire = (action: PtzAction, payload: Record<string, string | number> = {}) => {
    if (!canOperate) return;
    sendPtzCommand(cameraId, action, payload);
  };

  const btn = (action: PtzAction, label: React.ReactNode, tooltip: string) => (
    <button
      key={action}
      title={canOperate ? tooltip : 'Requires OPERATOR role'}
      disabled={!canOperate}
      onClick={() => fire(action)}
      className={cn(
        'flex h-9 w-9 items-center justify-center rounded-sm bg-raised text-secondary transition-all duration-100',
        'hover:text-accent active:scale-95 active:bg-accent-dim',
        'disabled:opacity-40 disabled:cursor-not-allowed',
      )}
    >
      {label}
    </button>
  );

  const startHold = (preset: number) => {
    if (!canOperate) return;
    setSavingPreset(preset);
    holdTimer.current = setTimeout(() => {
      fire('preset_save', { preset });
      setSavingPreset(null);
    }, HOLD_TO_SAVE_MS);
  };
  const endHold = (preset: number) => {
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
      if (savingPreset === preset) {
        setSavingPreset(null);
        fire('preset_recall', { preset });
      }
    }
  };

  return (
    <div className={cn('flex flex-col gap-2', compact && 'gap-1.5')}>
      <div className="flex items-start gap-3">
        <div className="grid grid-cols-3 gap-1">
          <span />
          {btn('tilt_up', <ChevronUp size={15} />, 'Tilt up')}
          <span />
          {btn('pan_left', <ChevronLeft size={15} />, 'Pan left')}
          <button
            title={canOperate ? 'Preset recall (center)' : 'Requires OPERATOR role'}
            disabled={!canOperate}
            onClick={() => fire('preset_recall', { preset: 1 })}
            className="flex h-9 w-9 items-center justify-center rounded-sm border border-line-strong text-muted transition-colors hover:text-accent disabled:opacity-40"
          >
            <Crosshair size={13} />
          </button>
          {btn('pan_right', <ChevronRight size={15} />, 'Pan right')}
          <span />
          {btn('tilt_down', <ChevronDown size={15} />, 'Tilt down')}
          <span />
        </div>
        <div className="flex flex-col gap-1">
          {btn('zoom_in', <Plus size={15} />, 'Zoom in')}
          {btn('zoom_out', <Minus size={15} />, 'Zoom out')}
        </div>
      </div>
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4].map((p) => (
          <button
            key={p}
            disabled={!canOperate}
            title={canOperate ? 'Click: recall · hold: save preset' : 'Requires OPERATOR role'}
            onMouseDown={() => startHold(p)}
            onMouseUp={() => endHold(p)}
            onMouseLeave={() => savingPreset === p && endHold(p)}
            className={cn(
              'h-5 w-7 rounded-sm font-mono text-[9px] transition-colors',
              savingPreset === p ? 'bg-warning-dim text-warning' : 'bg-raised text-muted hover:text-accent',
              'disabled:opacity-40 disabled:cursor-not-allowed',
            )}
          >
            P{p}
          </button>
        ))}
        <span className="ml-1 font-mono text-[8px] text-muted">HOLD = SAVE</span>
      </div>
      <PtzLifecycleTracker command={latest} />
    </div>
  );
});
