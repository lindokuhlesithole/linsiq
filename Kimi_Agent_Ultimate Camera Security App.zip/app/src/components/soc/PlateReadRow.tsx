/** PlateChip + PlateReadRow + PlateCard (design.md §6.10). */
import { memo } from 'react';
import { ArrowDownLeft, ArrowUpRight, Flame } from 'lucide-react';
import type { Camera, PlateRead } from '@/lib/types';
import { relTime } from '@/lib/format';
import { evidenceThumbSvg } from '@/lib/procedural';
import { cn } from '@/lib/utils';

/* Mini SA plate chip: province band left, mono plate right */
export const PlateChip = memo(function PlateChip({ plate, hot = false, small = false }: { plate: string; hot?: boolean; small?: boolean }) {
  const province = plate.slice(0, 2);
  const rest = plate.slice(2).trim();
  return (
    <span
      className={cn(
        'inline-flex items-stretch overflow-hidden rounded-sm border bg-raised',
        hot ? 'border-danger' : 'border-line-strong',
      )}
    >
      <span className={cn('flex items-center bg-info-dim px-1 font-mono font-semibold text-info', small ? 'text-[8px]' : 'text-[9px]')}>
        {province}
      </span>
      <span className={cn('px-1.5 font-mono font-semibold uppercase tracking-[0.06em] text-primary', small ? 'text-[11px] leading-5' : 'text-[12px] leading-6')}>
        {rest}
      </span>
    </span>
  );
});

const COLOR_HEX: Record<string, string> = {
  White: '#E6F1FF', Silver: '#A8B2D1', Grey: '#5C6B8A', Black: '#1a2333',
  Blue: '#4CC9F0', Red: '#E71D36', Beige: '#c8bfa4', Green: '#00D4AA',
};

export const VehicleDot = memo(function VehicleDot({ color }: { color: string }) {
  return (
    <span
      className="inline-block h-2 w-2 shrink-0 rounded-full border border-line-strong"
      style={{ background: COLOR_HEX[color] ?? '#5C6B8A' }}
      title={color}
    />
  );
});

export interface PlateReadRowProps {
  read: PlateRead;
  camera?: Camera;
  onClick?: (r: PlateRead) => void;
}

export const PlateReadRow = memo(function PlateReadRow({ read, camera, onClick }: PlateReadRowProps) {
  return (
    <button
      onClick={() => onClick?.(read)}
      className={cn(
        'relative flex h-9 w-full items-center gap-2.5 border-b border-line px-3 text-left transition-colors hover:bg-raised/60',
        read.hotlist_hit && 'bg-danger-dim pl-3.5',
      )}
    >
      {read.hotlist_hit && <span className="absolute left-0 top-0 bottom-0 w-0.5 bg-danger" />}
      <PlateChip plate={read.plate} hot={read.hotlist_hit} />
      <span className="flex min-w-0 flex-1 items-center gap-1.5 font-sans text-[11px] text-secondary">
        <VehicleDot color={read.vehicle_color} />
        <span className="truncate">
          {read.vehicle_make} · {read.vehicle_type}
        </span>
      </span>
      {read.hotlist_hit && (
        <span className="flex shrink-0 items-center gap-0.5 rounded-sm bg-danger px-1 py-px font-mono text-[8px] font-semibold text-primary">
          <Flame size={8} /> HOT
        </span>
      )}
      <span className="hidden shrink-0 font-mono text-[10px] text-muted md:block">{camera?.name ?? read.camera_id}</span>
      {read.direction === 'inbound' ? (
        <ArrowDownLeft size={13} className="shrink-0 text-accent" />
      ) : (
        <ArrowUpRight size={13} className="shrink-0 text-muted" />
      )}
      <span className="w-9 shrink-0 text-right font-mono text-[10px] text-secondary">{Math.round(read.confidence * 100)}%</span>
      <span className="w-14 shrink-0 text-right font-mono text-[10px] text-muted" title={read.captured_at}>
        {relTime(read.captured_at)}
      </span>
    </button>
  );
});

/* PlateCard — 44px row with procedural snapshot thumb (design.md §6.10) */
export const PlateCard = memo(function PlateCard({ read, camera, onClick }: PlateReadRowProps) {
  return (
    <button
      onClick={() => onClick?.(read)}
      className={cn(
        'relative flex h-11 w-full items-center gap-2.5 border-b border-line px-2.5 text-left transition-colors hover:bg-raised/60',
        read.hotlist_hit && 'bg-danger-dim',
      )}
    >
      {read.hotlist_hit && <span className="absolute left-0 top-0 bottom-0 w-0.5 bg-danger" />}
      <span className="h-9 w-16 shrink-0 overflow-hidden rounded-sm border border-line">
        {evidenceThumbSvg('snapshot', read.snapshot_id, 64, 36)}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <PlateChip plate={read.plate} hot={read.hotlist_hit} small />
          {read.hotlist_hit && (
            <span className="rounded-sm bg-danger px-1 font-mono text-[8px] font-semibold text-primary">HOT</span>
          )}
        </div>
        <div className="mt-0.5 flex items-center gap-1.5 font-sans text-[10px] text-muted">
          <VehicleDot color={read.vehicle_color} />
          <span className="truncate">
            {read.vehicle_color} {read.vehicle_make} · {camera?.name ?? read.camera_id}
          </span>
        </div>
      </div>
      <span className="shrink-0 font-mono text-[10px] text-muted" title={read.captured_at}>
        {relTime(read.captured_at)}
      </span>
    </button>
  );
});
