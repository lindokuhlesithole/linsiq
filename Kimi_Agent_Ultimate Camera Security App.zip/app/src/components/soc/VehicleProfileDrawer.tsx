/** VehicleProfileDrawer — full sighting history + hotlist action (design.md §6.8, alpr.md). */
import { memo, useMemo, useState } from 'react';
import { ListPlus } from 'lucide-react';
import {
  addHotlistEntry, useAlerts, useCameras, useCanOperate, useHotlists, usePlateReads,
} from '@/hooks/useData';
import { fmtDateTime, relTime } from '@/lib/format';
import { SocButton, SocDrawer } from './primitives';
import { PlateChip, VehicleDot } from './PlateReadRow';
import { StatusPill } from './StatusPill';
import { showToast } from './Toast';
import { cn } from '@/lib/utils';

export const VehicleProfileDrawer = memo(function VehicleProfileDrawer({
  plate,
  open,
  onClose,
}: {
  plate: string | null;
  open: boolean;
  onClose: () => void;
}) {
  const allReads = usePlateReads();
  const cameras = useCameras();
  const alerts = useAlerts();
  const hotlists = useHotlists();
  const canOperate = useCanOperate();
  const [targetList, setTargetList] = useState('');

  const sightings = useMemo(
    () => (plate ? allReads.filter((r) => r.plate === plate).slice(0, 30) : []),
    [allReads, plate],
  );
  const sightingIds = useMemo(() => new Set(sightings.map((s) => s.id)), [sightings]);
  const relatedAlerts = useMemo(
    () => alerts.filter((a) => a.plate_read_id && sightingIds.has(a.plate_read_id)).slice(0, 8),
    [alerts, sightingIds],
  );
  const camName = useMemo(() => {
    const m = new Map(cameras.map((c) => [c.id, c.name] as const));
    return (id: string) => m.get(id) ?? id;
  }, [cameras]);
  const first = sightings[0];
  const isHotlisted = useMemo(
    () => hotlists.some((h) => h.entries.some((e) => e.plate === plate)),
    [hotlists, plate],
  );

  return (
    <SocDrawer
      open={open}
      onClose={onClose}
      width={560}
      title={
        <div className="flex items-center gap-3">
          {plate && <PlateChip plate={plate} hot={isHotlisted} />}
          <span className="font-sans text-[12px] text-muted">VEHICLE PROFILE</span>
        </div>
      }
      headerRight={isHotlisted ? <StatusPill status="critical" label="Hotlisted" /> : undefined}
    >
      {!plate ? (
        <div className="p-5 font-mono text-[11px] text-muted">No plate selected.</div>
      ) : (
        <div className="space-y-5 px-5 py-4">
          {/* fingerprint */}
          <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 font-mono text-[10px]">
            <div className="flex justify-between"><span className="text-muted">SIGHTINGS</span><span className="text-secondary">{sightings.length}</span></div>
            <div className="flex justify-between"><span className="text-muted">ALERTS</span><span className="text-secondary">{relatedAlerts.length}</span></div>
            {first && (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-muted">VEHICLE</span>
                  <span className="flex items-center gap-1.5 text-secondary">
                    <VehicleDot color={first.vehicle_color} /> {first.vehicle_color} {first.vehicle_make}
                  </span>
                </div>
                <div className="flex justify-between"><span className="text-muted">TYPE</span><span className="text-secondary">{first.vehicle_type}</span></div>
              </>
            )}
          </div>

          {/* add to hotlist */}
          <div className="flex items-center gap-2 rounded-sm border border-line bg-inset p-2.5">
            <select
              value={targetList}
              onChange={(e) => setTargetList(e.target.value)}
              className="h-8 flex-1 rounded-sm border border-line bg-inset px-2 font-sans text-[12px] text-primary focus:border-accent focus:outline-none"
            >
              <option value="">Select hotlist…</option>
              {hotlists.map((h) => (
                <option key={h.id} value={h.id}>{h.name}</option>
              ))}
            </select>
            <SocButton
              disabled={!targetList || !canOperate || isHotlisted}
              tooltip={!canOperate ? 'Requires OPERATOR role' : isHotlisted ? 'Already hotlisted' : undefined}
              onClick={() => {
                if (!targetList || !plate) return;
                addHotlistEntry(targetList, { plate, reason: 'Added from vehicle profile', priority: 'high' });
                showToast({ severity: 'high', title: `${plate} added to hotlist`, body: 'Next sighting fires a critical alert within 30s' });
              }}
            >
              <span className="inline-flex items-center gap-1.5"><ListPlus size={13} /> Add to hotlist</span>
            </SocButton>
          </div>

          {/* associated alerts */}
          {relatedAlerts.length > 0 && (
            <div>
              <div className="mb-1.5 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">Associated alerts</div>
              <div className="space-y-1">
                {relatedAlerts.map((a) => (
                  <div key={a.id} className="flex items-center gap-2 rounded-sm border border-line bg-inset px-2.5 py-1.5">
                    <span className={cn('h-1.5 w-1.5 rounded-full', a.severity === 'critical' ? 'bg-danger' : a.severity === 'high' ? 'bg-warning' : 'bg-info')} />
                    <span className="min-w-0 flex-1 truncate font-sans text-[11px] text-primary">{a.title}</span>
                    <StatusPill status={a.status} />
                    <span className="font-mono text-[10px] text-muted">{relTime(a.created_at)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* sighting timeline */}
          <div>
            <div className="mb-1.5 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">Sighting timeline</div>
            <div className="space-y-0">
              {sightings.map((s) => (
                <div key={s.id} className="flex items-center gap-3 border-l border-line-strong py-1.5 pl-3">
                  <span className="w-[130px] shrink-0 font-mono text-[10px] text-muted">{fmtDateTime(s.captured_at)}</span>
                  <span className="min-w-0 flex-1 truncate font-sans text-[11px] text-secondary">{camName(s.camera_id)}</span>
                  <span className="font-mono text-[10px] uppercase text-muted">{s.direction}</span>
                  {s.hotlist_hit && <span className="rounded-sm bg-danger px-1 font-mono text-[8px] font-semibold text-primary">HOT</span>}
                </div>
              ))}
              {sightings.length === 0 && (
                <div className="py-4 text-center font-mono text-[10px] uppercase tracking-[0.1em] text-muted">No sightings in window</div>
              )}
            </div>
          </div>
        </div>
      )}
    </SocDrawer>
  );
});
