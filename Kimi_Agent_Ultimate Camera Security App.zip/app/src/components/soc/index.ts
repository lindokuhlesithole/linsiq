/** SWEALTH OS — shared component library barrel (src/components/soc/). */
export { StatusPill, SeverityBadge, ThreatLevelGauge, SEVERITY_HEX } from './StatusPill';
export { KpiTile, Sparkline } from './KpiTile';
export type { KpiTileProps } from './KpiTile';
export { CameraTile } from './CameraTile';
export type { CameraTileProps } from './CameraTile';
export { TacticalMap, FovCone, DroneTrail, DEFAULT_LAYERS } from './TacticalMap';
export type { TacticalMapProps, MapLayers, MapMarkerInfo } from './TacticalMap';
export { AlertTicker, PlateTicker } from './Tickers';
export { AlertRow, GroupedAlertRow, groupAlerts, ALERT_TYPE_ICONS, alertTypeIcon } from './AlertRow';
export { AlertDetailDrawer } from './AlertDetailDrawer';
export { CameraDetailPanel } from './CameraDetailPanel';
export { PtzPad, PtzLifecycleTracker } from './PtzPad';
export { PlateReadRow, PlateCard, PlateChip, VehicleDot } from './PlateReadRow';
export { EvidenceGrid } from './EvidenceGrid';
export { VehicleProfileDrawer } from './VehicleProfileDrawer';
export { EmptyState, SkeletonRow, RouteErrorBoundary } from './feedback';
export { ToastHost, showToast, playAlertPing } from './Toast';
export {
  SocButton, GhostButton, DangerButton, IconButton, SocInput, FilterChip,
  ToggleSwitch, SocTabs, SocDrawer, SocModal, Panel, PanelHeader,
} from './primitives';
