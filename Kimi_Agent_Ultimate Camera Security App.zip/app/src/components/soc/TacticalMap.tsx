/**
 * TacticalMap (+ MapMarker, FovCone, DroneTrail) — design.md §6.5.
 * Inline SVG, pan (drag) + zoom (wheel 0.6×–2.5×), layer toggles,
 * popover on marker click, coordinate readout.
 */
import { memo, useCallback, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Alert, AudioSensor, Camera, Drone, Guard } from '@/lib/types';
import { getTenantGeometry } from '@/lib/procedural';
import { useActiveOrgId, useAlerts, useAudioSensors, useCameras, useDrones, useGuards } from '@/hooks/useData';
import { OPEN_STATUSES } from '@/lib/store';
import { fmtCoord } from '@/lib/format';
import { SEVERITY_HEX, StatusPill } from './StatusPill';
import { GhostButton } from './primitives';
import { cn } from '@/lib/utils';

const CAM_HEX: Record<string, string> = {
  online: '#00D4AA', recording: '#00D4AA', motion: '#4CC9F0', degraded: '#FF9F1C', offline: '#E71D36',
};

export interface MapLayers {
  cameras: boolean;
  drones: boolean;
  guards: boolean;
  alerts: boolean;
  audio: boolean;
}
export const DEFAULT_LAYERS: MapLayers = { cameras: true, drones: true, guards: true, alerts: true, audio: true };

export interface MapMarkerInfo {
  kind: 'camera' | 'drone' | 'guard' | 'alert' | 'sensor';
  id: string;
  title: string;
  status: string;
  rows: [string, string][];
  viewTo: string;
  x: number;
  y: number;
}

/* ── FovCone: 60° wedge oriented by heading_deg ──────────────────────────── */
const FovCone = memo(function FovCone({ x, y, heading, len, alertTint }: { x: number; y: number; heading: number; len: number; alertTint?: boolean }) {
  const half = 30;
  const rad = (d: number) => ((d - 90) * Math.PI) / 180;
  const x1 = x + Math.cos(rad(heading - half)) * len;
  const y1 = y + Math.sin(rad(heading - half)) * len;
  const x2 = x + Math.cos(rad(heading + half)) * len;
  const y2 = y + Math.sin(rad(heading + half)) * len;
  const fill = alertTint ? 'rgba(231,29,54,0.10)' : 'rgba(0,212,170,0.08)';
  const stroke = alertTint ? 'rgba(231,29,54,0.30)' : 'rgba(0,212,170,0.20)';
  return <path d={`M ${x} ${y} L ${x1} ${y1} A ${len} ${len} 0 0 1 ${x2} ${y2} Z`} fill={fill} stroke={stroke} strokeWidth="1" />;
});

/* ── DroneTrail: last ~20 positions, fading polyline ─────────────────────── */
const DroneTrail = memo(function DroneTrail({ points, color }: { points: { x: number; y: number }[]; color: string }) {
  if (points.length < 2) return null;
  const n = points.length;
  return (
    <g>
      {points.slice(0, -1).map((p, i) => {
        const q = points[i + 1];
        return <line key={i} x1={p.x} y1={p.y} x2={q.x} y2={q.y} stroke={color} strokeWidth="1.4" opacity={(i / n) * 0.55} />;
      })}
    </g>
  );
});

/* ── Popover ─────────────────────────────────────────────────────────────── */
const MapPopover = memo(function MapPopover({ marker, onClose }: { marker: MapMarkerInfo; onClose: () => void }) {
  const navigate = useNavigate();
  return (
    <div
      className="absolute z-20 w-[240px] rounded-sm border border-line-strong bg-surface-solid p-3 shadow-drawer"
      style={{
        left: `min(max(8px, ${marker.x}px), calc(100% - 248px))`,
        top: `min(max(8px, ${marker.y}px), calc(100% - 190px))`,
        animation: 'popover-in 120ms ease-out',
      }}
    >
      <style>{`@keyframes popover-in { from { opacity: 0; transform: scale(0.95);} to { opacity: 1; transform: scale(1);} }`}</style>
      <div className="flex items-start justify-between gap-2">
        <span className="font-sans text-[12px] font-semibold text-primary">{marker.title}</span>
        <StatusPill status={marker.status} />
      </div>
      <div className="mt-2 space-y-1">
        {marker.rows.map(([k, v]) => (
          <div key={k} className="flex justify-between font-mono text-[10px]">
            <span className="text-muted">{k}</span>
            <span className="text-secondary">{v}</span>
          </div>
        ))}
      </div>
      <div className="mt-2.5 flex items-center gap-2">
        <GhostButton className="h-6 px-2 text-[10px]" onClick={() => navigate(marker.viewTo)}>
          View →
        </GhostButton>
        <GhostButton className="h-6 px-2 text-[10px]" onClick={onClose}>
          Close
        </GhostButton>
      </div>
    </div>
  );
});

/* ── Main component ──────────────────────────────────────────────────────── */

export interface TacticalMapProps {
  orgId?: string;
  cameras?: Camera[];
  drones?: Drone[];
  guards?: Guard[];
  alerts?: Alert[];
  audioSensors?: AudioSensor[];
  layers?: MapLayers;
  onLayersChange?: (l: MapLayers) => void;
  onMarkerClick?: (m: MapMarkerInfo) => void;
  /** compact mode: hides layer toggles + coordinate readout */
  compact?: boolean;
  /** camera ids with an active hotlist hit (red-tinted FOV cones) */
  hotCameraIds?: ReadonlySet<string>;
  className?: string;
}

export const TacticalMap = memo(function TacticalMap({
  orgId: orgIdProp,
  cameras: camsProp,
  drones: dronesProp,
  guards: guardsProp,
  alerts: alertsProp,
  audioSensors: sensorsProp,
  layers: layersProp,
  onLayersChange,
  onMarkerClick,
  compact = false,
  hotCameraIds,
  className,
}: TacticalMapProps) {
  const activeOrgId = useActiveOrgId();
  const orgId = orgIdProp ?? activeOrgId;
  const hookCams = useCameras();
  const hookDrones = useDrones();
  const hookGuards = useGuards();
  const hookAlerts = useAlerts();
  const hookSensors = useAudioSensors();
  const cameras = camsProp ?? hookCams;
  const drones = dronesProp ?? hookDrones;
  const guards = guardsProp ?? hookGuards;
  const alerts = alertsProp ?? hookAlerts;
  const sensors = sensorsProp ?? hookSensors;

  const [internalLayers, setInternalLayers] = useState<MapLayers>(DEFAULT_LAYERS);
  const layers = layersProp ?? internalLayers;
  const setLayers = useCallback(
    (l: MapLayers) => {
      if (onLayersChange) onLayersChange(l);
      else setInternalLayers(l);
    },
    [onLayersChange],
  );

  const geo = useMemo(() => getTenantGeometry(orgId), [orgId]);
  const [view, setView] = useState({ k: 1, px: 0, py: 0 });
  const [cursor, setCursor] = useState<{ lat: number; lng: number } | null>(null);
  const [selected, setSelected] = useState<MapMarkerInfo | null>(null);
  const dragRef = useRef<{ startX: number; startY: number; px: number; py: number } | null>(null);
  const svgWrapRef = useRef<HTMLDivElement>(null);

  const openAlerts = useMemo(() => alerts.filter((a) => OPEN_STATUSES.has(a.status)), [alerts]);

  const toLocal = useCallback((clientX: number, clientY: number) => {
    const rect = svgWrapRef.current?.getBoundingClientRect();
    if (!rect) return { x: 0, y: 0 };
    return { x: clientX - rect.left, y: clientY - rect.top };
  }, []);

  const onWheel = useCallback(
    (e: React.WheelEvent) => {
      const factor = e.deltaY < 0 ? 1.15 : 1 / 1.15;
      setView((v) => ({ ...v, k: Math.min(2.5, Math.max(0.6, v.k * factor)) }));
    },
    [],
  );

  const onMouseDown = useCallback(
    (e: React.MouseEvent) => {
      dragRef.current = { startX: e.clientX, startY: e.clientY, px: view.px, py: view.py };
    },
    [view],
  );
  const onMouseMove = useCallback(
    (e: React.MouseEvent) => {
      const local = toLocal(e.clientX, e.clientY);
      const rect = svgWrapRef.current?.getBoundingClientRect();
      if (rect) {
        const sx = ((local.x - view.px) / view.k / rect.width) * geo.width;
        const sy = ((local.y - view.py) / view.k / rect.height) * geo.height;
        setCursor(geo.unproject(sx, sy));
      }
      const d = dragRef.current;
      if (d) {
        setView((v) => ({ ...v, px: d.px + (e.clientX - d.startX), py: d.py + (e.clientY - d.startY) }));
      }
    },
    [geo, toLocal, view.k, view.px, view.py],
  );
  const endDrag = useCallback(() => {
    dragRef.current = null;
  }, []);

  const clickMarker = useCallback(
    (m: Omit<MapMarkerInfo, 'x' | 'y'>, clientX: number, clientY: number) => {
      const local = toLocal(clientX, clientY);
      const full: MapMarkerInfo = { ...m, x: local.x + 10, y: local.y + 10 };
      setSelected(full);
      onMarkerClick?.(full);
    },
    [onMarkerClick, toLocal],
  );

  const layerChip = (key: keyof MapLayers, label: string) => (
    <button
      key={key}
      onClick={(e) => {
        e.stopPropagation();
        setLayers({ ...layers, [key]: !layers[key] });
      }}
      className={cn(
        'h-5 rounded-full px-2 font-sans text-[9px] font-semibold uppercase tracking-[0.08em] transition-colors border',
        layers[key] ? 'bg-accent-dim text-accent border-accent/30' : 'bg-raised text-muted border-transparent',
      )}
    >
      {label}
    </button>
  );

  const smooth = { transition: 'transform 900ms linear' };

  return (
    <div
      ref={svgWrapRef}
      className={cn('scan-grid relative h-full w-full select-none overflow-hidden bg-inset', className)}
      onWheel={onWheel}
      onMouseDown={onMouseDown}
      onMouseMove={onMouseMove}
      onMouseUp={endDrag}
      onMouseLeave={() => {
        endDrag();
        setCursor(null);
      }}
      onDoubleClick={() => setView((v) => ({ ...v, k: Math.min(2.5, v.k * 1.4) }))}
      role="application"
      aria-label="Tactical map"
    >
      <svg
        viewBox={geo.viewBox}
        className="h-full w-full"
        preserveAspectRatio="xMidYMid meet"
        style={{ cursor: dragRef.current ? 'grabbing' : 'grab' }}
      >
        <g
          style={{
            transform: `translate(${view.px}px, ${view.py}px) scale(${view.k})`,
            transformOrigin: '0 0',
            transition: dragRef.current ? 'none' : 'transform 120ms ease-out',
          }}
        >
          {/* estate geometry */}
          {geo.water && <path d={geo.water} fill="rgba(76,201,240,0.07)" stroke="rgba(76,201,240,0.18)" strokeWidth="1" />}
          {geo.streets.map((d, i) => (
            <path key={i} d={d} fill="none" stroke="#1B2F52" strokeWidth={i === 0 ? 10 : 6} strokeLinecap="round" />
          ))}
          <path d={geo.boundary} fill="none" stroke="rgba(100,255,218,0.25)" strokeWidth="1.4" strokeDasharray="7 5" />
          {geo.zones.map((z) => (
            <text key={z.label} x={z.x} y={z.y} fontFamily='"JetBrains Mono", monospace' fontSize="11" fill="#5C6B8A" letterSpacing="1.5">
              {z.label}
            </text>
          ))}
          {geo.waterLabel && (
            <text x={geo.waterLabel.x} y={geo.waterLabel.y} fontFamily='"JetBrains Mono", monospace' fontSize="10" fill="rgba(76,201,240,0.5)" letterSpacing="2">
              {geo.waterLabel.label}
            </text>
          )}

          {/* audio sensors */}
          {layers.audio &&
            sensors.map((s) => {
              const p = geo.project(s.lat, s.lng);
              const r = (s.triangulation_radius_m / 111320 / (geo.bbox.maxLat - geo.bbox.minLat)) * geo.height;
              return (
                <g key={s.id} style={smooth}>
                  <circle cx={p.x} cy={p.y} r={r} fill="none" stroke="rgba(76,201,240,0.22)" strokeWidth="1" strokeDasharray="4 4" />
                  <circle cx={p.x} cy={p.y} r={r * 0.5} fill="none" stroke="rgba(76,201,240,0.14)" strokeWidth="1" strokeDasharray="3 4" />
                  <circle
                    cx={p.x} cy={p.y} r={3.2} fill="#4CC9F0" opacity="0.85"
                    className="cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      clickMarker(
                        { kind: 'sensor', id: s.id, title: s.name, status: s.status, rows: [['ZONE', s.zone], ['RADIUS', `${s.triangulation_radius_m}m`], ['POS', fmtCoord(s.lat, s.lng)]], viewTo: '/operations' },
                        e.clientX, e.clientY,
                      );
                    }}
                  />
                </g>
              );
            })}

          {/* cameras + FOV cones */}
          {layers.cameras &&
            cameras.map((c) => {
              const p = geo.project(c.lat, c.lng);
              const hot = hotCameraIds?.has(c.id);
              const len = c.kind === 'fixed_alpr' ? 78 : 52;
              return (
                <g key={c.id} style={smooth}>
                  <FovCone x={p.x} y={p.y} heading={c.heading_deg} len={len} alertTint={hot} />
                  <rect
                    x={p.x - 5} y={p.y - 5} width={10} height={10}
                    transform={`rotate(45 ${p.x} ${p.y})`}
                    fill={CAM_HEX[c.status] ?? '#5C6B8A'}
                    stroke="#060D1A" strokeWidth="1.4"
                    className="cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      clickMarker(
                        {
                          kind: 'camera', id: c.id, title: c.name, status: c.status,
                          rows: [['ZONE', c.zone], ['KIND', c.kind], ['RES', `${c.resolution}@${c.fps}`], ['POS', fmtCoord(c.lat, c.lng)]],
                          viewTo: '/cameras',
                        },
                        e.clientX, e.clientY,
                      );
                    }}
                  />
                </g>
              );
            })}

          {/* drones */}
          {layers.drones &&
            drones.map((d) => {
              const p = geo.project(d.lat, d.lng);
              const trail = d.trail.map((t) => geo.project(t.lat, t.lng));
              const color = d.status === 'responding' ? '#E71D36' : '#4CC9F0';
              const tgt = d.status === 'responding' && d.respond_target ? d.respond_target : d.status === 'returning' ? { lat: d.base_lat, lng: d.base_lng } : d.waypoints[d.current_waypoint];
              const tp = tgt ? geo.project(tgt.lat, tgt.lng) : null;
              return (
                <g key={d.id}>
                  <DroneTrail points={trail} color={color} />
                  {tp && <line x1={p.x} y1={p.y} x2={tp.x} y2={tp.y} stroke={color} strokeWidth="1" strokeDasharray="3 4" opacity="0.5" />}
                  <g style={smooth}>
                    <polygon
                      points={`${p.x},${p.y - 6} ${p.x + 5.5},${p.y + 4.5} ${p.x - 5.5},${p.y + 4.5}`}
                      fill={color} stroke="#060D1A" strokeWidth="1.2"
                      className="cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        clickMarker(
                          {
                            kind: 'drone', id: d.id, title: d.callsign, status: d.status,
                            rows: [['MODEL', d.model], ['BATT', `${Math.round(d.battery_pct)}%`], ['ALT', `${Math.round(d.altitude_m)}m`], ['SPD', `${d.speed_mps.toFixed(1)} m/s`]],
                            viewTo: '/operations',
                          },
                          e.clientX, e.clientY,
                        );
                      }}
                    />
                  </g>
                </g>
              );
            })}

          {/* guards */}
          {layers.guards &&
            guards.map((g) => {
              const p = geo.project(g.lat, g.lng);
              const color = g.status === 'responding' ? '#FF9F1C' : g.status === 'off_duty' ? '#5C6B8A' : g.status === 'on_break' ? '#4CC9F0' : '#00D4AA';
              const dest = g.dispatch_target ? geo.project(g.dispatch_target.lat, g.dispatch_target.lng) : null;
              return (
                <g key={g.id}>
                  {dest && <line x1={p.x} y1={p.y} x2={dest.x} y2={dest.y} stroke="#FF9F1C" strokeWidth="1.2" strokeDasharray="5 4" opacity="0.7" />}
                  <g style={smooth}>
                    <circle cx={p.x} cy={p.y} r={5.5} fill="none" stroke={color} strokeWidth="1.6" />
                    <circle
                      cx={p.x} cy={p.y} r={2.2} fill={color}
                      className="cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        clickMarker(
                          {
                            kind: 'guard', id: g.id, title: g.full_name, status: g.status,
                            rows: [['BADGE', g.badge_no], ['SHIFT', g.shift], ['RESOLVED', String(g.alerts_resolved)], ['POS', fmtCoord(g.lat, g.lng)]],
                            viewTo: '/operations',
                          },
                          e.clientX, e.clientY,
                        );
                      }}
                    />
                  </g>
                </g>
              );
            })}

          {/* alert markers: pulsing rings */}
          {layers.alerts &&
            openAlerts.map((a) => {
              const p = geo.project(a.lat, a.lng);
              const color = SEVERITY_HEX[a.severity];
              return (
                <g key={a.id}>
                  <circle cx={p.x} cy={p.y} r={5} fill="none" stroke={color} strokeWidth="1.4">
                    <animate attributeName="r" values="4;16" dur="1.6s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.9;0" dur="1.6s" repeatCount="indefinite" />
                  </circle>
                  <circle
                    cx={p.x} cy={p.y} r={3.4} fill={color}
                    className="cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      clickMarker(
                        {
                          kind: 'alert', id: a.id, title: a.title, status: a.status,
                          rows: [['SEVERITY', a.severity.toUpperCase()], ['SOURCE', a.source_name], ['CONF', `${Math.round(a.ai_confidence * 100)}%`]],
                          viewTo: '/alerts',
                        },
                        e.clientX, e.clientY,
                      );
                    }}
                  />
                </g>
              );
            })}
        </g>
      </svg>

      {/* layer toggles */}
      {!compact && (
        <div className="absolute left-2 top-2 z-10 flex flex-wrap gap-1 rounded-sm border border-line bg-surface-solid/85 p-1 backdrop-blur-sm">
          {layerChip('cameras', 'Cameras')}
          {layerChip('drones', 'Drones')}
          {layerChip('guards', 'Guards')}
          {layerChip('alerts', 'Alerts')}
          {layerChip('audio', 'Audio')}
        </div>
      )}

      {/* coordinates readout */}
      {!compact && (
        <div className="absolute bottom-2 right-2 z-10 rounded-sm border border-line bg-surface-solid/85 px-2 py-1 font-mono text-[9px] text-muted backdrop-blur-sm">
          {cursor ? fmtCoord(cursor.lat, cursor.lng) : '— —'} · ZOOM {(view.k * 100).toFixed(0)}%
        </div>
      )}

      {/* popover */}
      {selected && <MapPopover marker={selected} onClose={() => setSelected(null)} />}
    </div>
  );
});

export { FovCone, DroneTrail };
export type { ReactNode as _RN };
