/**
 * Toast system + WebAudio two-tone ping (design.md §6.13).
 * New high/critical alerts fire the toast+ping hook via emitAppEvent;
 * the ping respects the global mute toggle.
 */
import { memo, useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';
import { onAppEvent, store } from '@/lib/store';
import type { Alert, Severity } from '@/lib/types';
import { fmtTime } from '@/lib/format';
import { SEVERITY_HEX } from './StatusPill';
import { cn } from '@/lib/utils';

/* ── WebAudio two-tone ping (880/1320Hz, 120ms, synthesized) ─────────────── */

let audioCtx: AudioContext | null = null;

export function playAlertPing(severity: Severity): void {
  if (store.getState().muted) return;
  try {
    audioCtx ??= new (window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const ctx = audioCtx;
    if (ctx.state === 'suspended') void ctx.resume();
    const t0 = ctx.currentTime;
    const freqs = severity === 'critical' ? [880, 1320] : [880, 1108];
    freqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const start = t0 + i * 0.14;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(severity === 'critical' ? 0.08 : 0.05, start + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.12);
      osc.connect(gain).connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.14);
    });
  } catch {
    /* audio unavailable — visual toast still fires */
  }
}

/* ── Toast stack ─────────────────────────────────────────────────────────── */

interface ToastItem {
  id: string;
  severity: Severity;
  title: string;
  body: string;
  at: string;
  alertId?: string;
  sticky: boolean;
}

let toastSeq = 0;

/** Imperative toast API (any module can fire UI feedback). */
export function showToast(input: { severity?: Severity; title: string; body?: string; alertId?: string }): void {
  window.dispatchEvent(new CustomEvent('swealth:toast', { detail: input }));
}

export const ToastHost = memo(function ToastHost({ onToastClick }: { onToastClick?: (alertId: string) => void }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const timers = useRef(new Map<string, ReturnType<typeof setTimeout>>());

  const dismiss = useCallback((id: string) => {
    setToasts((t) => t.filter((x) => x.id !== id));
    const timer = timers.current.get(id);
    if (timer) clearTimeout(timer);
    timers.current.delete(id);
  }, []);

  const push = useCallback(
    (item: Omit<ToastItem, 'id' | 'at'>) => {
      const id = `toast-${++toastSeq}`;
      setToasts((t) => [{ ...item, id, at: new Date().toISOString() }, ...t].slice(0, 5));
      if (!item.sticky) {
        timers.current.set(id, setTimeout(() => dismiss(id), 5000));
      }
    },
    [dismiss],
  );

  useEffect(() => {
    const off = onAppEvent((e) => {
      if (e.kind === 'alert' && e.alert) {
        const a: Alert = e.alert;
        playAlertPing(a.severity);
        push({
          severity: a.severity,
          title: a.title,
          body: a.source_name,
          alertId: a.id,
          sticky: a.severity === 'critical',
        });
      } else if (e.kind === 'info' && e.message) {
        push({ severity: e.severity ?? 'medium', title: e.message, body: '', sticky: false });
      }
    });
    const onCustom = (ev: Event) => {
      const d = (ev as CustomEvent).detail as { severity?: Severity; title: string; body?: string; alertId?: string };
      push({ severity: d.severity ?? 'medium', title: d.title, body: d.body ?? '', alertId: d.alertId, sticky: false });
    };
    window.addEventListener('swealth:toast', onCustom);
    return () => {
      off();
      window.removeEventListener('swealth:toast', onCustom);
    };
  }, [push]);

  useEffect(() => () => timers.current.forEach((t) => clearTimeout(t)), []);

  return (
    <div className="pointer-events-none fixed right-3 top-16 z-[70] flex w-[340px] flex-col gap-2">
      <AnimatePresence initial={false}>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ x: 340, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 340, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 400, damping: 32 }}
            className={cn(
              'pointer-events-auto relative overflow-hidden rounded-sm border border-line-strong bg-surface-solid shadow-drawer',
              t.alertId && 'cursor-pointer',
            )}
            onClick={() => {
              if (t.alertId) {
                onToastClick?.(t.alertId);
                dismiss(t.id);
              }
            }}
          >
            <span className="absolute left-0 top-0 bottom-0 w-0.5" style={{ background: SEVERITY_HEX[t.severity] }} />
            <div className="flex items-start gap-2 px-3 py-2.5 pl-4">
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate font-sans text-[12px] font-semibold text-primary">{t.title}</span>
                  <span className="shrink-0 font-mono text-[10px] text-muted">{fmtTime(t.at)}</span>
                </div>
                {t.body && <div className="mt-0.5 truncate font-mono text-[10px] text-muted">{t.body}</div>}
                <div className="mt-0.5 font-sans text-[10px] uppercase tracking-[0.08em]" style={{ color: SEVERITY_HEX[t.severity] }}>
                  {t.severity} alert{t.sticky ? ' — requires acknowledgement' : ''}
                </div>
              </div>
              <button
                className="mt-0.5 text-muted transition-colors hover:text-primary"
                onClick={(e) => {
                  e.stopPropagation();
                  dismiss(t.id);
                }}
                aria-label="Dismiss"
              >
                <X size={13} />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
});
