/**
 * Navbar.tsx — the TOPBAR component (design.md §5.2).
 * Named Navbar for contract compatibility with the swarm scaffold.
 */
import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Bell, Building2, Check, ChevronDown, LogOut, Volume2, VolumeX } from 'lucide-react';
import { deriveThreat, getSidebarCollapsed, OPEN_STATUSES, onAppEvent, useStoreSelector } from '@/lib/store';
import {
  setRolePreview, toggleMute, useCameras, useClock, useMuted, useOrg, useOrgs, useOrgSwitch, useRole,
} from '@/hooks/useData';
import { fmtTime, relTime } from '@/lib/format';
import type { RolePreview } from '@/lib/types';
import { SeverityBadge, ThreatLevelGauge } from './soc/StatusPill';
import { cn } from '@/lib/utils';

const PAGE_META: Record<string, string> = {
  '/': 'Fleet Command',
  '/map': 'Tactical Map',
  '/operations': 'Live Operations',
  '/cameras': 'Camera Network',
  '/alpr': 'Plate Intelligence',
  '/alerts': 'AI Alert Center',
  '/incidents': 'Case Management',
  '/analytics': 'Analytics',
  '/settings': 'Settings',
  '/login': 'Secure Terminal',
};

/* ticking SAST clock — isolated 1s re-render */
const TopClock = memo(function TopClock() {
  const now = useClock(1000);
  return (
    <span className="font-mono text-[13px] font-medium tracking-[0.05em] text-primary">
      {fmtTime(now)} <span className="text-muted">SAST</span>
    </span>
  );
});

function useDropdown(): [boolean, () => void, () => void, React.RefObject<HTMLDivElement | null>] {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);
  return [open, () => setOpen((o) => !o), () => setOpen(false), ref];
}

const ddPanel =
  'absolute right-0 top-full z-50 mt-1 min-w-[220px] origin-top rounded-sm border border-line-strong bg-surface-solid shadow-drawer animate-in fade-in zoom-in-95 duration-100';
const ddItem = 'flex h-[30px] w-full items-center gap-2 px-2.5 text-left font-sans text-[12px] text-secondary transition-colors hover:bg-raised hover:text-primary';

export const TopBar = memo(function TopBar() {
  const location = useLocation();
  const navigate = useNavigate();
  const org = useOrg();
  const orgs = useOrgs();
  const switchOrg = useOrgSwitch();
  const role = useRole();
  const muted = useMuted();
  const cameras = useCameras();
  const alerts = useStoreSelector((s) => s.byOrg[s.activeOrgId]?.alerts ?? []);

  const [bellOpen, toggleBell, closeBell, bellRef] = useDropdown();
  const [orgOpen, toggleOrg, closeOrg, orgRef] = useDropdown();
  const [userOpen, toggleUser, closeUser, userRef] = useDropdown();
  const [shaking, setShaking] = useState(false);
  const [crossfade, setCrossfade] = useState(false);
  const [collapsed, setCollapsed] = useState(getSidebarCollapsed);
  useEffect(() => {
    const on = () => setCollapsed(getSidebarCollapsed());
    window.addEventListener('swealth:sidebar', on);
    return () => window.removeEventListener('swealth:sidebar', on);
  }, []);

  const title = PAGE_META[location.pathname] ?? 'Fleet Command';
  const liveStreams = useMemo(() => cameras.filter((c) => c.status !== 'offline').length, [cameras]);
  const openAlerts = useMemo(() => alerts.filter((a) => OPEN_STATUSES.has(a.status)), [alerts]);
  const unreadCritical = openAlerts.filter((a) => a.severity === 'critical' && a.status === 'new').length;
  const latestSevere = useMemo(
    () => alerts.filter((a) => (a.severity === 'critical' || a.severity === 'high') && OPEN_STATUSES.has(a.status)).slice(0, 5),
    [alerts],
  );
  const threat = useMemo(() => deriveThreat(alerts), [alerts]);

  // bell shake + badge pop on new critical
  useEffect(() => {
    return onAppEvent((e) => {
      if (e.kind === 'alert' && e.alert?.severity === 'critical') {
        setShaking(true);
        setTimeout(() => setShaking(false), 700);
      }
    });
  }, []);

  // sidebar tenant card opens this switcher
  useEffect(() => {
    const open = () => toggleOrg();
    window.addEventListener('swealth:org-switcher', open);
    return () => window.removeEventListener('swealth:org-switcher', open);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const doSwitch = (orgId: string) => {
    closeOrg();
    if (orgId === org.id) return;
    setCrossfade(true);
    setTimeout(() => setCrossfade(false), 150);
    switchOrg(orgId);
  };

  return (
    <>
      <header
        className={cn(
          'fixed left-0 right-0 top-0 z-30 flex h-14 items-center gap-4 border-b border-line bg-base pr-4 transition-[padding] duration-200',
          collapsed ? 'pl-[72px]' : 'pl-[248px]',
        )}
      >
        {/* page context */}
        <div className="min-w-0 leading-tight">
          <h1 className="truncate font-sans text-[18px] font-semibold leading-6 tracking-[-0.01em] text-primary">{title}</h1>
          <div className="truncate font-mono text-[10px] uppercase tracking-[0.08em] text-muted">
            {org.name} / {title} · <span className="text-muted/70">{org.slug}</span>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-4">
          <TopClock />
          <span className="hidden items-center gap-1.5 font-mono text-[11px] text-accent lg:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-accent animate-live-pulse" />
            {liveStreams} STREAMS LIVE
          </span>
          <ThreatLevelGauge level={threat} />

          {/* alert bell */}
          <div className="relative" ref={bellRef}>
            <button
              onClick={toggleBell}
              className={cn('relative flex h-8 w-8 items-center justify-center rounded-sm text-secondary transition-colors hover:bg-raised hover:text-accent', shaking && 'animate-shake')}
              aria-label="Alert notifications"
            >
              <Bell size={16} />
              {unreadCritical > 0 && (
                <motion.span
                  key={unreadCritical}
                  initial={{ scale: 1.4 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.3 }}
                  className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 font-mono text-[9px] font-semibold text-primary"
                >
                  {unreadCritical}
                </motion.span>
              )}
            </button>
            <AnimatePresence>
              {bellOpen && (
                <motion.div initial={{ opacity: 0, scaleY: 0.95 }} animate={{ opacity: 1, scaleY: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.1 }} className={cn(ddPanel, 'w-[320px]')}>
                  <div className="border-b border-line px-2.5 py-2 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                    Latest high/critical
                  </div>
                  {latestSevere.length === 0 && (
                    <div className="px-2.5 py-3 font-mono text-[10px] uppercase text-accent">All clear</div>
                  )}
                  {latestSevere.map((a) => (
                    <button
                      key={a.id}
                      className={cn(ddItem, 'h-auto py-2')}
                      onClick={() => {
                        closeBell();
                        window.dispatchEvent(new CustomEvent('swealth:open-alert', { detail: { alertId: a.id } }));
                      }}
                    >
                      <SeverityBadge severity={a.severity} />
                      <span className="min-w-0 flex-1 truncate">{a.title}</span>
                      <span className="shrink-0 font-mono text-[9px] text-muted">{relTime(a.created_at)}</span>
                    </button>
                  ))}
                  <button className={cn(ddItem, 'border-t border-line text-accent')} onClick={() => { closeBell(); navigate('/alerts'); }}>
                    Open Alert Center →
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* mute toggle */}
          <button
            onClick={toggleMute}
            className="flex h-8 w-8 items-center justify-center rounded-sm text-secondary transition-colors hover:bg-raised hover:text-accent"
            title={muted ? 'Unmute alert ping' : 'Mute alert ping'}
          >
            {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>

          {/* org switcher */}
          <div className="relative" ref={orgRef}>
            <button onClick={toggleOrg} className="flex h-8 items-center gap-1.5 rounded-sm border border-line px-2 text-secondary transition-colors hover:border-line-strong hover:text-primary">
              <Building2 size={14} />
              <span className="max-w-[140px] truncate font-sans text-[12px] font-medium">{org.name}</span>
              <ChevronDown size={13} />
            </button>
            <AnimatePresence>
              {orgOpen && (
                <motion.div initial={{ opacity: 0, scaleY: 0.95 }} animate={{ opacity: 1, scaleY: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.1 }} className={cn(ddPanel, 'w-[260px]')}>
                  {orgs.map((o) => (
                    <button key={o.id} className={ddItem} onClick={() => doSwitch(o.id)}>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate">{o.name}</span>
                        <span className="block truncate font-mono text-[9px] text-muted">{o.location} · {o.slug}</span>
                      </span>
                      {o.id === org.id && <Check size={13} className="shrink-0 text-accent" />}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* user badge + role preview */}
          <div className="relative" ref={userRef}>
            <button onClick={toggleUser} className="flex h-8 items-center gap-2 rounded-sm px-1.5 transition-colors hover:bg-raised">
              <span className="flex h-6 w-6 items-center justify-center rounded-sm bg-raised font-mono text-[10px] font-semibold text-accent">EM</span>
              <span className="hidden text-left leading-tight xl:block">
                <span className="block font-sans text-[11px] font-medium text-primary">Estate Manager</span>
                <span className="block font-mono text-[9px] uppercase text-muted">{role}</span>
              </span>
              <ChevronDown size={12} className="text-muted" />
            </button>
            <AnimatePresence>
              {userOpen && (
                <motion.div initial={{ opacity: 0, scaleY: 0.95 }} animate={{ opacity: 1, scaleY: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.1 }} className={ddPanel}>
                  <div className="border-b border-line px-2.5 py-2 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                    Role preview
                  </div>
                  {(['manager', 'operator', 'guard'] as RolePreview[]).map((r) => (
                    <button key={r} className={ddItem} onClick={() => { setRolePreview(r); closeUser(); }}>
                      <span className="flex-1 uppercase">{r}</span>
                      {role === r && <Check size={13} className="text-accent" />}
                    </button>
                  ))}
                  <div className="border-t border-line px-2.5 py-1.5 font-mono text-[9px] text-muted">AUTH: GUEST DEMO MODE</div>
                  <button className={cn(ddItem, 'text-danger')} onClick={() => { closeUser(); navigate('/login'); }}>
                    <LogOut size={13} /> Sign out
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </header>

      {/* tenant-switch crossfade */}
      <AnimatePresence>
        {crossfade && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.075 }}
            className="pointer-events-none fixed inset-0 z-[60] bg-canvas"
          />
        )}
      </AnimatePresence>
    </>
  );
});

export default TopBar;
