/**
 * Aperture brand mark — hexagonal ring with 6 blade segments, accent stroke.
 * Blades draw in via stroke-dashoffset (GSAP drives the `data-drawn` reveal).
 */
import { forwardRef } from 'react';

const ACCENT = '#00D4AA';

/** regular hexagon point, flat-top orientation, radius r around (c,c) */
function hexPoint(c: number, r: number, i: number): [number, number] {
  const a = (Math.PI / 3) * i - Math.PI / 6;
  return [c + r * Math.cos(a), c + r * Math.sin(a)];
}

export const ApertureMark = forwardRef<SVGSVGElement, { size?: number }>(function ApertureMark({ size = 40 }, ref) {
  const c = 24;
  const R = 20; // ring radius
  const r = 9; // inner iris radius
  const ring = Array.from({ length: 6 }, (_, i) => hexPoint(c, R, i).join(',')).join(' ');
  // blades: chord from each inner vertex to the next-but-one outer edge
  const blades = Array.from({ length: 6 }, (_, i) => {
    const [x1, y1] = hexPoint(c, r, i);
    const [x2, y2] = hexPoint(c, R * 0.92, i + 2);
    return { x1, y1, x2, y2 };
  });
  return (
    <svg ref={ref} width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden>
      <polygon className="ap-ring" points={ring} stroke={ACCENT} strokeWidth={1.5} strokeLinejoin="round" />
      {blades.map((b, i) => (
        <line
          key={i}
          className="ap-blade"
          x1={b.x1}
          y1={b.y1}
          x2={b.x2}
          y2={b.y2}
          stroke={ACCENT}
          strokeWidth={1.5}
          strokeLinecap="round"
        />
      ))}
      <circle className="ap-iris" cx={c} cy={c} r={3} stroke={ACCENT} strokeWidth={1.5} />
    </svg>
  );
});
