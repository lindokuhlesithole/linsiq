/**
 * Auth form (login.md §2.3) — OPERATOR SIGN IN / GUEST DEMO tabs.
 * Operator: sign-in + sign-up client-side mock (Phase 1: any credentials
 * authenticate). Guest: one-tap demo entry. Failed validation shakes and
 * appends to the boot log.
 */
import { memo, useState } from 'react';
import type { FormEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, Eye, EyeOff, Info, Loader2 } from 'lucide-react';
import { SocInput } from '@/components/soc';
import { setSession } from './session';
import type { DemoSession } from './session';
import { lsGet } from '@/components/settings/shared';
import { cn } from '@/lib/utils';

type Tab = 'guest' | 'operator';
type OpMode = 'signin' | 'signup';

export const AuthForm = memo(function AuthForm({
  onBootLog,
  onSuccess,
}: {
  onBootLog: (text: string, tone: 'accent' | 'danger') => void;
  onSuccess: (session: DemoSession) => void;
}) {
  const [tab, setTab] = useState<Tab>('guest');
  const [opMode, setOpMode] = useState<OpMode>('signin');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(0);
  const [busy, setBusy] = useState(false);
  const [granted, setGranted] = useState(false);
  const production = lsGet<string>('swealth.auth_mode', 'guest') === 'production';

  const fail = (msg: string, bootLine?: string) => {
    setError(msg);
    setShake((s) => s + 1);
    if (bootLine) onBootLog(bootLine, 'danger');
  };

  const succeed = (session: DemoSession) => {
    setSession(session);
    setGranted(true);
    onBootLog(`access granted — welcome, ${session.name.split(' ')[0].toLowerCase()}`, 'accent');
    setTimeout(() => onSuccess(session), 400);
  };

  const enterGuest = () => {
    if (busy || granted) return;
    setBusy(true);
    succeed({ mode: 'guest', name: 'Estate Manager', at: new Date().toISOString() });
  };

  const submitOperator = (e: FormEvent) => {
    e.preventDefault();
    if (busy || granted) return;
    if (!email.trim() || !password) {
      fail('CREDENTIALS REQUIRED');
      return;
    }
    if (password.length < 4) {
      fail('PASSWORD TOO SHORT — MIN 4 CHARS', 'auth failure — attempt logged');
      return;
    }
    if (opMode === 'signup' && !name.trim()) {
      fail('OPERATOR NAME REQUIRED');
      return;
    }
    setError(null);
    setBusy(true);
    // simulated 900ms verify — any input works in Phase 1
    setTimeout(() => {
      const display = opMode === 'signup'
        ? name.trim()
        : email.trim().split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
      succeed({ mode: 'operator', name: display || 'Operator', email: email.trim(), at: new Date().toISOString() });
    }, 900);
  };

  const tabBtn = (id: Tab, label: string) => (
    <button
      key={id}
      onClick={() => { setTab(id); setError(null); }}
      className={cn(
        'flex h-8 flex-1 items-center justify-center font-sans text-[10px] font-semibold uppercase tracking-[0.08em] transition-colors duration-150',
        tab === id ? 'bg-accent-dim text-accent' : 'bg-inset text-muted hover:text-secondary',
      )}
    >
      {label}
    </button>
  );

  return (
    <div>
      {/* mode tabs — GUEST DEMO pre-selected (happy path) */}
      <div className="mb-3 flex overflow-hidden rounded-sm border border-line">
        {tabBtn('guest', 'Guest demo')}
        {tabBtn('operator', 'Operator sign in')}
      </div>

      <AnimatePresence mode="wait">
        {tab === 'guest' ? (
          <motion.div key="guest" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
            <p className="mb-3 font-sans text-[11px] text-muted">
              Full demo session as Estate Manager — no credentials needed. Role preview is available from the user menu once inside.
            </p>
            <button
              autoFocus
              onClick={enterGuest}
              disabled={granted}
              className={cn(
                'flex h-10 w-full items-center justify-center gap-2 rounded-sm font-sans text-[12px] font-semibold uppercase tracking-[0.02em]',
                'transition-all duration-300 hover:brightness-110 hover:-translate-y-px active:scale-[0.97]',
                granted ? 'bg-accent text-on-accent' : 'bg-accent text-on-accent',
              )}
            >
              {granted ? (
                <>
                  <Check size={14} strokeWidth={3} /> Access granted
                </>
              ) : busy ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                'Enter as guest — demo estate ▸'
              )}
            </button>
          </motion.div>
        ) : (
          <motion.form
            key="operator"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onSubmit={submitOperator}
          >
            {production && (
              <div className="mb-2 flex items-center gap-2 rounded-sm border border-info/30 bg-info-dim px-2.5 py-1.5">
                <Info size={12} className="shrink-0 text-info" />
                <span className="font-sans text-[10px] text-info">
                  Production auth lands in Phase 2 — demo verification is active
                </span>
              </div>
            )}
            {/* sign-in / sign-up sub-toggle */}
            <div className="mb-2.5 flex gap-3 border-b border-line">
              {(['signin', 'signup'] as OpMode[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => { setOpMode(m); setError(null); }}
                  className={cn(
                    'relative h-7 font-sans text-[10px] font-semibold uppercase tracking-[0.06em] transition-colors',
                    opMode === m ? 'text-accent' : 'text-muted hover:text-secondary',
                  )}
                >
                  {m === 'signin' ? 'Sign in' : 'Sign up'}
                  {opMode === m && <span className="absolute -bottom-px left-0 right-0 h-0.5 bg-accent" />}
                </button>
              ))}
            </div>
            <motion.div
              key={shake}
              animate={shake ? { x: [0, -6, 6, -4, 4, 0] } : false}
              transition={{ duration: 0.2 }}
              className="space-y-2"
            >
              {opMode === 'signup' && (
                <SocInput value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" autoComplete="name" />
              )}
              <SocInput
                autoFocus={opMode === 'signin'}
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="operator@swealth.os"
                autoComplete="email"
              />
              <div className="relative">
                <SocInput
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  autoComplete={opMode === 'signin' ? 'current-password' : 'new-password'}
                  className="pr-9"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  aria-label={showPw ? 'Hide password' : 'Show password'}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted transition-colors hover:text-secondary"
                >
                  {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </motion.div>
            <AnimatePresence>
              {error && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="mt-1.5 font-mono text-[10px] uppercase tracking-[0.06em] text-danger"
                >
                  {error}
                </motion.p>
              )}
            </AnimatePresence>
            <button
              type="submit"
              disabled={busy || granted}
              className={cn(
                'mt-3 flex h-9 w-full items-center justify-center gap-2 rounded-sm bg-accent font-sans text-[12px] font-semibold uppercase tracking-[0.02em] text-on-accent',
                'transition-all duration-100 hover:brightness-110 hover:-translate-y-px active:scale-[0.97] disabled:opacity-70',
              )}
            >
              {granted ? (
                <>
                  <Check size={14} strokeWidth={3} /> Access granted
                </>
              ) : busy ? (
                <>
                  <Loader2 size={13} className="animate-spin" /> Verifying…
                </>
              ) : opMode === 'signin' ? (
                'Authenticate'
              ) : (
                'Create account'
              )}
            </button>
            <p className="mt-2 font-sans text-[10px] text-muted">
              Phase 1: any credentials authenticate a demo session.
            </p>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  );
});
