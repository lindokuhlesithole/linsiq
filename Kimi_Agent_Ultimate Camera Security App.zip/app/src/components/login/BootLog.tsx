/**
 * Boot log (login.md §2.2) — bg-inset well, mono 10px terminal lines typed
 * character-by-character via GSAP, status words color-coded, block cursor.
 * Imperative `append()` lets the auth form log failures into the terminal.
 */
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import gsap from 'gsap';
import { cn } from '@/lib/utils';

export type BootTone = 'accent' | 'danger' | 'warning' | 'info' | 'muted';

export interface BootLine {
  text: string;
  status?: string;
  tone?: BootTone;
}

export interface BootLogHandle {
  append: (line: BootLine) => void;
}

const TONE_CLS: Record<BootTone, string> = {
  accent: 'text-accent',
  danger: 'text-danger',
  warning: 'text-warning',
  info: 'text-info',
  muted: 'text-muted',
};

interface Shown extends BootLine {
  shown: number;
}

export const BootLog = forwardRef<BootLogHandle, {
  lines: BootLine[];
  instant?: boolean;
  startDelay?: number;
  onComplete?: () => void;
  className?: string;
}>(function BootLog({ lines, instant = false, startDelay = 0, onComplete, className }, ref) {
  const [shown, setShown] = useState<Shown[]>(() => (instant ? lines.map((l) => ({ ...l, shown: l.text.length })) : []));
  const [done, setDone] = useState(instant);
  const scrollRef = useRef<HTMLDivElement>(null);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useImperativeHandle(ref, () => ({
    append: (line: BootLine) => {
      setShown((v) => [...v, { ...line, shown: line.text.length }].slice(-6));
    },
  }), []);

  useEffect(() => {
    if (instant) {
      onCompleteRef.current?.();
      return;
    }
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        delay: startDelay,
        onComplete: () => {
          setDone(true);
          onCompleteRef.current?.();
        },
      });
      lines.forEach((l, i) => {
        tl.call(() => setShown((v) => [...v, { ...l, shown: 0 }].slice(-6)));
        const proxy = { n: 0 };
        tl.to(proxy, {
          n: l.text.length,
          duration: Math.max(0.1, l.text.length * 0.012),
          ease: 'none',
          onUpdate: () =>
            setShown((v) => v.map((x, xi) => (xi === Math.min(i, v.length - 1) ? { ...x, shown: Math.floor(proxy.n) } : x))),
        }, '+=0.15');
      });
    });
    return () => ctx.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [instant, startDelay]);

  /* auto-scroll to newest line */
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [shown]);

  return (
    <div ref={scrollRef} className={cn('h-24 overflow-y-auto rounded-sm border border-line bg-inset p-2 font-mono text-[10px] leading-4', className)}>
      {shown.map((l, i) => (
        <div key={i} className="whitespace-pre-wrap">
          <span className="text-muted">&gt; </span>
          <span className="text-secondary">{l.text.slice(0, l.shown)}</span>
          {l.status && l.shown >= l.text.length && (
            <span className={cn('font-semibold', TONE_CLS[l.tone ?? 'accent'])}> {l.status}</span>
          )}
        </div>
      ))}
      <span className="animate-rec-blink text-accent">▮</span>
      {done && <span className="sr-only">boot complete</span>}
    </div>
  );
});
