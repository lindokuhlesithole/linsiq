/**
 * Demo session helpers (Phase 1 client-side auth fiction).
 * Session shape is stored under `swealth.session`; the login page restores it,
 * Settings displays it.
 */
import { lsGet, lsSet } from '@/components/settings/shared';

export const SESSION_KEY = 'swealth.session';
export const SEEN_BOOT_KEY = 'swealth.seen_boot';

export interface DemoSession {
  mode: 'guest' | 'operator';
  name: string;
  email?: string;
  at: string; // ISO
}

export function getSession(): DemoSession | null {
  const s = lsGet<DemoSession | null>(SESSION_KEY, null);
  if (!s || typeof s !== 'object' || !s.mode || !s.at) return null;
  return s;
}

export function setSession(s: DemoSession): void {
  lsSet(SESSION_KEY, s);
}

export function clearSession(): void {
  try {
    localStorage.removeItem(SESSION_KEY);
  } catch {
    /* noop */
  }
}
