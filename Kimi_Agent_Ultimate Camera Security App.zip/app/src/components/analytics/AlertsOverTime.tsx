/**
 * Alerts Over Time — stacked area by severity (analytics.md §2).
 * Buckets derived live from the alerts slice; legend isolates a series;
 * bucket click deep-links to /alerts filtered to that hour.
 */
import { memo, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { Alert, Severity } from '@/lib/types';
import { SEVERITY_HEX } from '@/components/soc';
import { FilterChip } from '@/components/soc';
import { fmtNum } from '@/lib/format';
import { AXIS_TICK, CHART, ChartPanel, ChartTooltip, ZeroNote } from './theme';
import type { RangeKey } from './ranges';
import { bucketCount, bucketLabel, bucketSpanMs } from './ranges';

const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low'];
const pad = (n: number) => String(n).padStart(2, '0');

interface Bucket {
  key: string;
  label: string;
  startMs: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
  total: number;
}

export const AlertsOverTime = memo(function AlertsOverTime({
  alerts,
  range,
  loading,
}: {
  alerts: Alert[];
  range: RangeKey;
  loading: boolean;
}) {
  const navigate = useNavigate();
  const [isolated, setIsolated] = useState<Severity | null>(null);

  const buckets = useMemo<Bucket[]>(() => {
    const n = bucketCount(range);
    const span = bucketSpanMs(range);
    const now = Date.now();
    const out: Bucket[] = [];
    for (let i = n - 1; i >= 0; i--) {
      const startMs = now - (i + 1) * span;
      out.push({
        key: String(startMs),
        label: bucketLabel(range, startMs),
        startMs,
        critical: 0, high: 0, medium: 0, low: 0, total: 0,
      });
    }
    const cutoff = now - n * span;
    for (const a of alerts) {
      const t = new Date(a.created_at).getTime();
      if (t < cutoff) continue;
      const idx = Math.min(n - 1, Math.floor((t - cutoff) / span));
      out[idx][a.severity] += 1;
      out[idx].total += 1;
    }
    return out;
  }, [alerts, range]);

  const peak = useMemo(() => buckets.reduce((m, b) => (b.total > m.total ? b : m), buckets[0]), [buckets]);
  const critTotal = useMemo(() => buckets.reduce((s, b) => s + b.critical, 0), [buckets]);

  const peakLabel = useMemo(() => {
    if (!peak || peak.total === 0) return 'NO ACTIVITY IN RANGE';
    const d = new Date(peak.startMs + bucketSpanMs(range) / 2);
    return range === '7D'
      ? `PEAK ${d.toLocaleDateString('en-ZA', { weekday: 'short' }).toUpperCase()} · ${fmtNum(peak.total)} ALERTS`
      : `PEAK ${pad(d.getHours())}:00 · ${fmtNum(peak.total)} ALERTS`;
  }, [peak, range]);

  return (
    <ChartPanel
      title="Alerts Over Time"
      loading={loading}
      right={
        <>
          {critTotal === 0 && <ZeroNote text="No critical alerts in range" />}
          <span className="font-mono text-[10px] text-secondary">{peakLabel}</span>
          <div className="flex items-center gap-1">
            {SEVERITIES.map((s) => (
              <FilterChip key={s} active={isolated === s} onClick={() => setIsolated((cur) => (cur === s ? null : s))}>
                <span className="inline-flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: SEVERITY_HEX[s] }} />
                  {s}
                </span>
              </FilterChip>
            ))}
          </div>
        </>
      }
    >
      <div className="h-[320px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={buckets}
            margin={{ top: 4, right: 4, bottom: 0, left: 0 }}
            onClick={(st) => {
              const b = (st?.activePayload?.[0]?.payload ?? null) as Bucket | null;
              if (!b) return;
              const q = new URLSearchParams({ from: new Date(b.startMs).toISOString(), to: new Date(b.startMs + bucketSpanMs(range)).toISOString() });
              if (isolated) q.set('severity', isolated);
              navigate(`/alerts?${q.toString()}`);
            }}
            className="cursor-pointer"
          >
            <CartesianGrid horizontal={false} vertical={false} stroke={CHART.grid} />
            <XAxis dataKey="label" tick={AXIS_TICK} axisLine={false} tickLine={false} interval="preserveStartEnd" minTickGap={40} />
            <YAxis width={28} tick={AXIS_TICK} axisLine={false} tickLine={false} allowDecimals={false} />
            <Tooltip content={<ChartTooltip />} cursor={{ stroke: CHART.cursor }} />
            {/* draw low→critical so critical lands on top (analytics.md §2) */}
            {(['low', 'medium', 'high', 'critical'] as Severity[]).map((s, i) => (
              <Area
                key={s}
                type="monotone"
                dataKey={s}
                name={s.toUpperCase()}
                stackId="sev"
                stroke={SEVERITY_HEX[s]}
                strokeWidth={1.5}
                fill={SEVERITY_HEX[s]}
                fillOpacity={isolated && isolated !== s ? 0.05 : 0.3}
                strokeOpacity={isolated && isolated !== s ? 0.15 : 1}
                isAnimationActive
                animationDuration={500}
                animationBegin={i * 120}
                dot={false}
                activeDot={{ r: 2.5, strokeWidth: 0 }}
              />
            ))}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </ChartPanel>
  );
});
