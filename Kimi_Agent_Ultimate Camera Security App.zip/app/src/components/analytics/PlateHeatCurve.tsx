/**
 * Plate-Read Volume Heat Curve (analytics.md §3).
 * Reads/hour stacked per ALPR gate; rush-hour shading bands 07:00–09:00 and
 * 16:30–18:30; current hour pulses as reads accumulate. Click → /alpr?hour=HH.
 */
import { memo, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, Cell, ReferenceArea, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { Camera, PlateRead } from '@/lib/types';
import { fmtNum } from '@/lib/format';
import { AXIS_TICK, CHART, ChartPanel, ChartTooltip } from './theme';

const pad = (n: number) => String(n).padStart(2, '0');
const GATE_COLORS = [CHART.accent, CHART.info, CHART.gate3] as const;

interface HourRow {
  hour: string;
  total: number;
  [gate: string]: number | string;
}

export const PlateHeatCurve = memo(function PlateHeatCurve({
  reads,
  cameras,
  loading,
}: {
  reads: PlateRead[];
  cameras: Camera[];
  loading: boolean;
}) {
  const navigate = useNavigate();
  const gates = useMemo(() => cameras.filter((c) => c.kind === 'fixed_alpr').slice(0, 3), [cameras]);

  const rows = useMemo<HourRow[]>(() => {
    const out: HourRow[] = Array.from({ length: 24 }, (_, h) => {
      const row: HourRow = { hour: pad(h), total: 0 };
      for (const g of gates) row[g.id] = 0;
      return row;
    });
    for (const r of reads) {
      const h = new Date(r.captured_at).getHours();
      const row = out[h];
      if (typeof row[r.camera_id] === 'number') (row[r.camera_id] as number) += 1;
      row.total += 1;
    }
    return out;
  }, [reads, gates]);

  const total = useMemo(() => rows.reduce((s, r) => s + r.total, 0), [rows]);
  const peakGate = useMemo(() => {
    let best: Camera | null = null;
    let bestN = -1;
    for (const g of gates) {
      const n = rows.reduce((s, r) => s + ((r[g.id] as number) ?? 0), 0);
      if (n > bestN) { bestN = n; best = g; }
    }
    return best;
  }, [rows, gates]);

  const currentHour = pad(new Date().getHours());

  return (
    <ChartPanel
      title="Plate-Read Volume · Gate Heat Curve"
      loading={loading}
      right={
        <span className="font-mono text-[10px] text-secondary">
          TOTAL {fmtNum(total)} · PEAK GATE {(peakGate?.name ?? '—').toUpperCase()}
        </span>
      }
    >
      <div className="h-[320px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={rows}
            margin={{ top: 4, right: 4, bottom: 0, left: 0 }}
            onClick={(st) => {
              const h = st?.activeLabel;
              if (typeof h === 'string') navigate(`/alpr?hour=${h}`);
            }}
            className="cursor-pointer"
          >
            <CartesianGrid horizontal={false} vertical={false} stroke={CHART.grid} />
            <XAxis dataKey="hour" tick={AXIS_TICK} axisLine={false} tickLine={false} interval={1} />
            <YAxis width={28} tick={AXIS_TICK} axisLine={false} tickLine={false} allowDecimals={false} />
            <Tooltip content={<ChartTooltip labelFormatter={(l) => `${l}:00–${l}:59`} />} cursor={{ fill: CHART.cursor }} />
            {/* rush-hour shading bands (fade in after bars) */}
            <ReferenceArea x1="07" x2="09" fill={CHART.warning} fillOpacity={0.08} />
            <ReferenceArea x1="16" x2="18" fill={CHART.warning} fillOpacity={0.08} />
            {gates.map((g, i) => (
              <Bar
                key={g.id}
                dataKey={g.id}
                name={g.name.toUpperCase()}
                stackId="gate"
                fill={GATE_COLORS[i % GATE_COLORS.length]}
                fillOpacity={0.85}
                isAnimationActive
                animationDuration={400}
                animationBegin={i * 20}
                radius={i === gates.length - 1 ? [1, 1, 0, 0] : 0}
              >
                {rows.map((r) => (
                  <Cell
                    key={r.hour}
                    className={r.hour === currentHour && i === gates.length - 1 ? 'animate-live-pulse' : undefined}
                  />
                ))}
              </Bar>
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-2 flex items-center gap-4">
        <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.08em] text-warning">
          <span className="h-2 w-3 rounded-[1px]" style={{ background: CHART.warning, opacity: 0.25 }} />
          AM rush 07:00–09:00 · PM rush 16:30–18:30
        </span>
        <span className="ml-auto flex items-center gap-3">
          {gates.map((g, i) => (
            <span key={g.id} className="flex items-center gap-1 font-mono text-[9px] uppercase tracking-[0.06em] text-muted">
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: GATE_COLORS[i % GATE_COLORS.length] }} />
              {g.name}
            </span>
          ))}
        </span>
      </div>
    </ChartPanel>
  );
});
