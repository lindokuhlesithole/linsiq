/**
 * Device Uptime (analytics.md §6).
 * Horizontal bars, one per camera. Uptime derived from the device slice:
 * a deterministic per-device baseline penalized by live status
 * (offline / degraded heartbeats drag the number down in real time).
 */
import { memo, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { Camera } from '@/lib/types';
import { AXIS_TICK, CHART, ChartPanel, ChartTooltip, hashStr } from './theme';

const ROW_H = 26;

export function uptimePct(cam: Camera): number {
  // baseline 96.0–99.9 from device id, live status applies a penalty
  const base = 96 + (hashStr(cam.id) % 390) / 10;
  const penalty = cam.status === 'offline' ? 4.2 : cam.status === 'degraded' ? 1.6 : 0;
  return Math.max(84, Math.min(100, Math.round((base - penalty) * 10) / 10));
}

function barColor(u: number): string {
  return u >= 99 ? CHART.accent : u >= 95 ? CHART.warning : CHART.danger;
}

export const DeviceUptime = memo(function DeviceUptime({
  cameras,
  loading,
}: {
  cameras: Camera[];
  loading: boolean;
}) {
  const navigate = useNavigate();
  const rows = useMemo(
    () =>
      cameras
        .map((c) => ({ id: c.id, name: c.name, uptime: uptimePct(c) }))
        .sort((a, b) => b.uptime - a.uptime),
    [cameras],
  );
  const fleetAvg = useMemo(
    () => (rows.length ? rows.reduce((s, r) => s + r.uptime, 0) / rows.length : 0),
    [rows],
  );
  const worstId = rows.length ? rows[rows.length - 1].id : null;

  return (
    <ChartPanel
      title="Device Uptime"
      loading={loading}
      right={<span className="font-mono text-[10px] text-secondary">FLEET AVG {fleetAvg.toFixed(1)}%</span>}
    >
      <div className="h-[220px] overflow-y-auto pr-1">
        <div style={{ height: Math.max(220, rows.length * ROW_H) }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={rows}
              layout="vertical"
              margin={{ top: 0, right: 34, bottom: 0, left: 0 }}
              onClick={(st) => {
                const r = (st?.activePayload?.[0]?.payload ?? null) as { id: string } | null;
                if (r) navigate(`/cameras?device=${encodeURIComponent(r.id)}`);
              }}
              className="cursor-pointer"
            >
              <XAxis type="number" domain={[80, 100]} hide />
              <YAxis
                type="category"
                dataKey="name"
                width={110}
                tick={{ ...AXIS_TICK, fontSize: 10 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                content={<ChartTooltip valueFormatter={(v) => `${v}%`} />}
                cursor={{ fill: CHART.cursor }}
              />
              <Bar dataKey="uptime" name="UPTIME" isAnimationActive animationDuration={400} radius={[0, 1, 1, 0]} barSize={10}
                label={{ position: 'right', fill: CHART.tick, fontSize: 9, fontFamily: '"JetBrains Mono", monospace', formatter: (v: unknown) => `${v}%` }}
              >
                {rows.map((r) => (
                  <Cell
                    key={r.id}
                    fill={barColor(r.uptime)}
                    fillOpacity={0.85}
                    className={r.id === worstId ? 'animate-live-pulse' : undefined}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </ChartPanel>
  );
});
