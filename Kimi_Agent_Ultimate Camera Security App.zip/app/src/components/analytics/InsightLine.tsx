/**
 * Auto-insight rotator (analytics.md §1).
 * Rotating mono 11px info callouts computed from live data; types in
 * character-by-character once per cycle start, cycles every 8s, pause on hover.
 */
import { memo, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const CYCLE_MS = 8000;
const CHAR_MS = 18;

export const InsightLine = memo(function InsightLine({ insights }: { insights: string[] }) {
  const [idx, setIdx] = useState(0);
  const [typed, setTyped] = useState(0);
  const [paused, setPaused] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const current = insights.length ? insights[idx % insights.length] : '';

  // type-in on cycle start
  useEffect(() => {
    setTyped(0);
    if (!current) return;
    const t = setInterval(() => {
      setTyped((n) => {
        if (n >= current.length) {
          clearInterval(t);
          return n;
        }
        return n + 1;
      });
    }, CHAR_MS);
    return () => clearInterval(t);
  }, [current]);

  // rotation
  useEffect(() => {
    if (insights.length < 2) return;
    if (paused) {
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = null;
      return;
    }
    timerRef.current = setInterval(() => setIdx((i) => (i + 1) % insights.length), CYCLE_MS);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [insights.length, paused]);

  if (!insights.length) return null;

  return (
    <div
      className="flex items-center gap-3"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <AnimatePresence mode="wait">
        <motion.p
          key={idx % insights.length}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="font-mono text-[11px] text-info"
        >
          {current.slice(0, typed)}
          {typed < current.length && <span className="text-accent">▮</span>}
        </motion.p>
      </AnimatePresence>
      <span className="flex items-center gap-1">
        {insights.map((_, i) => (
          <button
            key={i}
            aria-label={`Insight ${i + 1}`}
            onClick={() => setIdx(i)}
            className={cn('h-1 w-3 rounded-full transition-colors', i === idx % insights.length ? 'bg-info' : 'bg-raised hover:bg-muted')}
          />
        ))}
      </span>
    </div>
  );
});
