/**
 * Response-Time Distribution (analytics.md §4).
 * Histogram of alert ack/resolve latency vs the 4-minute tenant target.
 * Bars beyond target render warning (semantic encoding).
 */
import { memo, useMemo } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { Alert } from '@/lib/types';
import { fmtDurationSec } from '@/lib/format';
import { AXIS_TICK, CHART, ChartPanel, ChartTooltip } from './theme';

export const TARGET_RESPONSE_SEC = 240;

const BUCKETS = [
  { id: '<1m', label: '<1M', min: 0, max: 60 },
  { id: '1-2m', label: '1–2M', min: 60, max: 120 },
  { id: '2-5m', label: '2–5M', min: 120, max: 300 },
  { id: '5-10m', label: '5–10M', min: 300, max: 600 },
  { id: '>10m', label: '>10M', min: 600, max: Infinity },
] as const;

function responseSec(a: Alert): number | null {
  const end = a.acknowledged_at ?? a.resolved_at;
  if (!end) return null;
  const s = (new Date(end).getTime() - new Date(a.created_at).getTime()) / 1000;
  return s >= 0 ? s : null;
}

export const ResponseDistribution = memo(function ResponseDistribution({
  alerts,
  loading,
}: {
  alerts: Alert[];
  loading: boolean;
}) {
  const { rows, avg, median, responded } = useMemo(() => {
    const secs = alerts.map(responseSec).filter((s): s is number => s !== null).sort((a, b) => a - b);
    const counts = BUCKETS.map((b) => ({
      bucket: b.label,
      count: secs.filter((s) => s >= b.min && s < b.max).length,
      over: b.min >= TARGET_RESPONSE_SEC,
    }));
    const avgV = secs.length ? secs.reduce((s, x) => s + x, 0) / secs.length : 0;
    const medV = secs.length ? secs[Math.floor(secs.length / 2)] : 0;
    return { rows: counts, avg: avgV, median: medV, responded: secs.length };
  }, [alerts]);

  return (
    <ChartPanel
      title="Response-Time Distribution"
      loading={loading}
      right={
        <span className="font-mono text-[10px] text-secondary">
          AVG {fmtDurationSec(avg).toUpperCase()} · MEDIAN {fmtDurationSec(median).toUpperCase()}
        </span>
      }
    >
      {responded === 0 ? (
        <div className="flex h-[220px] items-center justify-center">
          <span className="font-mono text-[10px] uppercase tracking-[0.08em] text-muted">
            No acknowledged alerts in range — awaiting first response
          </span>
        </div>
      ) : (
        <div className="h-[220px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={rows} margin={{ top: 12, right: 4, bottom: 0, left: 0 }}>
              <CartesianGrid horizontal={false} vertical={false} stroke={CHART.grid} />
              <XAxis dataKey="bucket" tick={AXIS_TICK} axisLine={false} tickLine={false} />
              <YAxis width={28} tick={AXIS_TICK} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: CHART.cursor }} />
              <ReferenceLine
                x="2–5M"
                stroke={CHART.warning}
                strokeDasharray="4 3"
                label={{ value: 'TARGET 4M', position: 'top', fill: CHART.warning, fontSize: 9, fontFamily: '"JetBrains Mono", monospace' }}
              />
              <Bar dataKey="count" name="ALERTS" isAnimationActive animationDuration={400} radius={[1, 1, 0, 0]}>
                {rows.map((r) => (
                  <Cell key={r.bucket} fill={r.over ? CHART.warning : CHART.accent} fillOpacity={0.85} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </ChartPanel>
  );
});
