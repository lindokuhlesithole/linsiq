/**
 * Guard Performance Leaderboard (analytics.md §7).
 * Table-chart hybrid: rank · guard · shift · resolved · avg response · 7-shift sparkbar.
 * Squad-average footer row. Click → /operations guards tab.
 */
import { memo, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import type { Guard } from '@/lib/types';
import { fmtDurationSec } from '@/lib/format';
import { CHART, ChartPanel, hashStr } from './theme';
import { TARGET_RESPONSE_SEC } from './ResponseDistribution';
import { cn } from '@/lib/utils';

const RANK_STYLE = ['bg-accent-dim text-accent', 'bg-warning-dim text-warning', 'bg-info-dim text-info'];

/** 7-shift resolved-series, deterministic per guard */
function sparkSeries(g: Guard): number[] {
  const h = hashStr(g.id);
  return Array.from({ length: 7 }, (_, i) => {
    const v = Math.abs(Math.imul(h, i + 7) ^ (h >>> (i + 2)));
    return 1 + (v % Math.max(2, Math.round(g.alerts_resolved / 2)));
  });
}

const SparkBar = memo(function SparkBar({ values, color }: { values: number[]; color: string }) {
  const max = Math.max(...values, 1);
  return (
    <svg width={64} height={18} className="shrink-0" aria-hidden>
      {values.map((v, i) => {
        const h = Math.max(2, (v / max) * 16);
        return (
          <rect key={i} x={i * 9} y={18 - h} width={6} height={h} rx={1} fill={color} opacity={i === values.length - 1 ? 1 : 0.45} />
        );
      })}
    </svg>
  );
});

export const GuardLeaderboard = memo(function GuardLeaderboard({
  guards,
  loading,
}: {
  guards: Guard[];
  loading: boolean;
}) {
  const navigate = useNavigate();
  const ranked = useMemo(() => [...guards].sort((a, b) => b.alerts_resolved - a.alerts_resolved), [guards]);
  const squad = useMemo(() => {
    if (!ranked.length) return { resolved: 0, avg: 0 };
    return {
      resolved: Math.round(ranked.reduce((s, g) => s + g.alerts_resolved, 0) / ranked.length),
      avg: Math.round(ranked.reduce((s, g) => s + g.avg_response_sec, 0) / ranked.length),
    };
  }, [ranked]);

  return (
    <ChartPanel
      title="Guard Performance"
      loading={loading}
      right={<span className="font-mono text-[10px] text-secondary">TARGET {fmtDurationSec(TARGET_RESPONSE_SEC).toUpperCase()}</span>}
    >
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b border-line text-left">
              {['#', 'Guard', 'Shift', 'Resolved', 'Avg response', 'Last 7 shifts'].map((h, i) => (
                <th key={h} className={cn('pb-2 font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted', i >= 3 && i <= 4 && 'text-right')}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ranked.map((g, i) => {
              const over = g.avg_response_sec > TARGET_RESPONSE_SEC;
              return (
                <motion.tr
                  key={g.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.04, duration: 0.2 }}
                  onClick={() => navigate('/operations?tab=guards')}
                  className={cn('cursor-pointer border-b border-line/60 transition-colors hover:bg-raised/60', i === 0 && 'bg-accent-dim/40')}
                >
                  <td className="py-2 pr-2">
                    <span className={cn('inline-flex h-5 w-5 items-center justify-center rounded-sm font-mono text-[10px] font-semibold', RANK_STYLE[i] ?? 'bg-raised text-muted')}>
                      {i + 1}
                    </span>
                  </td>
                  <td className="py-2 pr-2">
                    <div className="font-sans text-[12px] font-medium text-primary">{g.full_name}</div>
                    <div className="font-mono text-[9px] text-muted">{g.badge_no}</div>
                  </td>
                  <td className="py-2 pr-2">
                    <span className="rounded-sm bg-raised px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.08em] text-secondary">
                      {g.shift}
                    </span>
                  </td>
                  <td className="py-2 pr-2 text-right font-mono text-[12px] text-primary">{g.alerts_resolved}</td>
                  <td className={cn('py-2 pr-2 text-right font-mono text-[12px]', over ? 'text-warning' : 'text-accent')}>
                    {fmtDurationSec(g.avg_response_sec)}
                  </td>
                  <td className="py-2 pl-2">
                    <SparkBar values={sparkSeries(g)} color={i === 0 ? CHART.accent : CHART.info} />
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
          <tfoot>
            <tr className="border-t border-line-strong">
              <td colSpan={3} className="pt-2 font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">
                Squad average
              </td>
              <td className="pt-2 text-right font-mono text-[11px] text-muted">{squad.resolved}</td>
              <td className="pt-2 text-right font-mono text-[11px] text-muted">{fmtDurationSec(squad.avg)}</td>
              <td />
            </tr>
          </tfoot>
        </table>
      </div>
    </ChartPanel>
  );
});
