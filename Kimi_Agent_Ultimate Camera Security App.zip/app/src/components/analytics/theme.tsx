/**
 * Analytics shared chart theme (analytics.md — global chart theme).
 * Dark-tactical Recharts defaults: mono 9px axes, hairline grids, custom tooltip,
 * LIVE dot per panel, chart-shaped skeleton.
 */
import { memo } from 'react';
import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

/* SVG-attribute color space (mirrors tokens in index.css / tailwind.config) */
export const CHART = {
  accent: '#00D4AA',
  warning: '#FF9F1C',
  danger: '#E71D36',
  info: '#4CC9F0',
  low: '#5C6B8A',
  muted: '#5C6B8A',
  gate3: '#3E5C82', // muted blue-grey third gate (analytics.md §3)
  grid: 'rgba(100,255,218,0.05)',
  cursor: 'rgba(100,255,218,0.15)',
  tick: '#5C6B8A',
} as const;

export const AXIS_TICK = { fontSize: 9, fontFamily: '"JetBrains Mono", monospace', fill: CHART.tick } as const;

/* ── Custom dark tooltip (analytics.md: surface-solid, mono rows, swatches) ─ */

interface TipPayload {
  name?: string;
  value?: number | string;
  color?: string;
  payload?: Record<string, unknown>;
}

export const ChartTooltip = memo(function ChartTooltip({
  active,
  label,
  payload,
  labelFormatter,
  valueFormatter,
}: {
  active?: boolean;
  label?: string | number;
  payload?: TipPayload[];
  labelFormatter?: (l: string | number) => string;
  valueFormatter?: (v: number | string) => string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-sm border border-line-strong bg-surface-solid px-2.5 py-2 shadow-drawer">
      {label !== undefined && (
        <div className="mb-1 font-mono text-[10px] uppercase tracking-[0.08em] text-muted">
          {labelFormatter ? labelFormatter(label) : label}
        </div>
      )}
      <div className="space-y-0.5">
        {payload.map((p, i) => (
          <div key={i} className="flex items-center gap-1.5 font-mono text-[10px]">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: p.color ?? CHART.accent }} />
            <span className="text-secondary">{p.name}</span>
            <span className="ml-auto pl-3 text-primary">{valueFormatter ? valueFormatter(p.value ?? 0) : p.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
});

/* ── LIVE dot (ambient pulse — only on genuinely live panels) ────────────── */

export const LiveDot = memo(function LiveDot({ className }: { className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5', className)}>
      <span className="h-1.5 w-1.5 animate-live-pulse rounded-full bg-accent" />
      <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-accent">Live</span>
    </span>
  );
});

/* ── Chart panel shell: surface card + header + LIVE dot ─────────────────── */

export const ChartPanel = memo(function ChartPanel({
  title,
  right,
  loading,
  className,
  children,
}: {
  title: string;
  right?: ReactNode;
  loading?: boolean;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section className={cn('flex flex-col rounded-sm border border-line bg-surface p-4 backdrop-blur-sm', className)}>
      <header className="mb-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">{title}</span>
          <LiveDot />
        </div>
        <div className="flex items-center gap-2">{right}</div>
      </header>
      {loading ? <ChartSkeleton /> : children}
    </section>
  );
});

/* ── Chart-shaped shimmer skeleton (analytics.md States) ─────────────────── */

export const ChartSkeleton = memo(function ChartSkeleton({ className }: { className?: string }) {
  const sheen = (
    <span className="pointer-events-none absolute inset-0 -translate-x-full animate-shimmer bg-[linear-gradient(90deg,transparent,rgba(0,212,170,0.06),transparent)]" />
  );
  return (
    <div className={cn('space-y-2', className)}>
      <div className="flex gap-2">
        {[0, 1, 2].map((i) => (
          <div key={i} className="relative h-3 w-16 overflow-hidden rounded-sm bg-raised">
            {sheen}
          </div>
        ))}
      </div>
      <div className="relative h-[220px] overflow-hidden rounded-sm bg-raised/60">
        {sheen}
        <div className="absolute inset-x-4 bottom-4 flex items-end gap-1.5">
          {[40, 65, 30, 80, 55, 70, 45, 90, 60, 35, 75, 50].map((h, i) => (
            <div key={i} className="flex-1 rounded-t-sm bg-raised" style={{ height: `${h}%` }} />
          ))}
        </div>
      </div>
    </div>
  );
});

/* ── Sparse-series celebratory note (analytics.md States) ────────────────── */

export const ZeroNote = memo(function ZeroNote({ text }: { text: string }) {
  return (
    <span className="rounded-sm bg-accent-dim px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.08em] text-accent">
      {text}
    </span>
  );
});

/* deterministic 32-bit string hash (pseudo-series seeded by entity id) */
export function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
