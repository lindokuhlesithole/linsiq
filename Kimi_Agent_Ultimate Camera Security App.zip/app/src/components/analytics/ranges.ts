/** Shared time-range model for the analytics page (24H | 48H | 7D). */

export type RangeKey = '24H' | '48H' | '7D';

export const RANGES: readonly { id: RangeKey; label: string; ms: number }[] = [
  { id: '24H', label: '24H', ms: 24 * 3600_000 },
  { id: '48H', label: '48H', ms: 48 * 3600_000 },
  { id: '7D', label: '7D', ms: 7 * 24 * 3600_000 },
];

export function rangeMs(range: RangeKey): number {
  return RANGES.find((r) => r.id === range)?.ms ?? 24 * 3600_000;
}

/** number of X buckets for the alerts-over-time chart */
export function bucketCount(range: RangeKey): number {
  return range === '7D' ? 7 : range === '48H' ? 48 : 24;
}

/** ms per bucket */
export function bucketSpanMs(range: RangeKey): number {
  return rangeMs(range) / bucketCount(range);
}

const pad = (n: number) => String(n).padStart(2, '0');

export function bucketLabel(range: RangeKey, startMs: number): string {
  const d = new Date(startMs);
  if (range === '7D') return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}`;
  return `${pad(d.getHours())}:00`;
}
