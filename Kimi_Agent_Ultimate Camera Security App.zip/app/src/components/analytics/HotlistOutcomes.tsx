/**
 * Hotlist Outcomes (analytics.md §5).
 * Donut (inner 60%) + outcome list with % bars. Click → /alerts?type=hotlist_hit&status=…
 * Hover syncs segment ↔ list row both directions.
 */
import { memo, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Cell, Pie, PieChart, ResponsiveContainer } from 'recharts';
import { BadgeCheck, CircleSlash, PackageCheck, Radar } from 'lucide-react';
import type { Alert } from '@/lib/types';
import { OPEN_STATUSES } from '@/lib/store';
import { fmtNum } from '@/lib/format';
import { CHART, ChartPanel, hashStr } from './theme';
import { cn } from '@/lib/utils';

type OutcomeKey = 'verified' | 'recovered' | 'false_alarm' | 'open';

const OUTCOME_META: Record<OutcomeKey, { label: string; color: string; icon: typeof Radar; status: string }> = {
  verified: { label: 'Resolved — Verified', color: CHART.accent, icon: BadgeCheck, status: 'resolved' },
  recovered: { label: 'Resolved — Recovered', color: CHART.info, icon: PackageCheck, status: 'resolved' },
  false_alarm: { label: 'False Alarm', color: CHART.muted, icon: CircleSlash, status: 'false_alarm' },
  open: { label: 'Open', color: CHART.danger, icon: Radar, status: 'open' },
};

export const HotlistOutcomes = memo(function HotlistOutcomes({
  alerts,
  loading,
}: {
  alerts: Alert[];
  loading: boolean;
}) {
  const navigate = useNavigate();
  const [hover, setHover] = useState<OutcomeKey | null>(null);

  const data = useMemo(() => {
    const hits = alerts.filter((a) => a.type === 'hotlist_hit');
    const counts: Record<OutcomeKey, number> = { verified: 0, recovered: 0, false_alarm: 0, open: 0 };
    for (const a of hits) {
      if (a.status === 'false_alarm') counts.false_alarm += 1;
      else if (OPEN_STATUSES.has(a.status)) counts.open += 1;
      // resolved hits split verified/recovered deterministically per alert id
      else counts[hashStr(a.id) % 3 === 0 ? 'recovered' : 'verified'] += 1;
    }
    return (Object.keys(counts) as OutcomeKey[])
      .map((k) => ({ key: k, name: OUTCOME_META[k].label, value: counts[k] }))
      .filter((d) => d.value > 0);
  }, [alerts]);

  const total = useMemo(() => data.reduce((s, d) => s + d.value, 0), [data]);

  const go = (k: OutcomeKey) => {
    navigate(`/alerts?type=hotlist_hit&status=${OUTCOME_META[k].status}`);
  };

  return (
    <ChartPanel
      title="Hotlist Hit Outcomes"
      loading={loading}
      right={<span className="font-mono text-[10px] text-secondary">{fmtNum(total)} HITS IN RANGE</span>}
    >
      {total === 0 ? (
        <div className="flex h-[220px] items-center justify-center">
          <span className="rounded-sm bg-accent-dim px-2 py-1 font-mono text-[10px] uppercase tracking-[0.08em] text-accent">
            No hotlist hits in range — gates quiet
          </span>
        </div>
      ) : (
        <div className="grid h-[220px] grid-cols-2 items-center gap-2">
          <div className="relative h-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  dataKey="value"
                  nameKey="name"
                  innerRadius="60%"
                  outerRadius="88%"
                  startAngle={90}
                  endAngle={-270}
                  strokeWidth={0}
                  isAnimationActive
                  animationDuration={600}
                  onMouseEnter={(_, i) => setHover(data[i]?.key ?? null)}
                  onMouseLeave={() => setHover(null)}
                  onClick={(_, i) => data[i] && go(data[i].key)}
                  className="cursor-pointer"
                >
                  {data.map((d) => (
                    <Cell
                      key={d.key}
                      fill={OUTCOME_META[d.key].color}
                      fillOpacity={hover && hover !== d.key ? 0.35 : 0.9}
                      style={hover === d.key ? { transform: 'scale(1.03)', transformOrigin: 'center', transition: 'transform 150ms' } : { transition: 'transform 150ms' }}
                    />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
              <span className="font-mono text-[22px] font-semibold leading-6 text-primary">{fmtNum(total)}</span>
              <span className="font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">Hits in range</span>
            </div>
          </div>
          <ul className="space-y-1.5">
            {(Object.keys(OUTCOME_META) as OutcomeKey[]).map((k) => {
              const meta = OUTCOME_META[k];
              const d = data.find((x) => x.key === k);
              const n = d?.value ?? 0;
              const pct = total ? Math.round((n / total) * 100) : 0;
              const Icon = meta.icon;
              return (
                <li key={k}>
                  <button
                    onClick={() => go(k)}
                    onMouseEnter={() => setHover(k)}
                    onMouseLeave={() => setHover(null)}
                    className={cn(
                      'w-full rounded-sm px-2 py-1.5 text-left transition-colors duration-150',
                      hover === k ? 'bg-raised' : 'hover:bg-raised/60',
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <Icon size={13} style={{ color: meta.color }} />
                      <span className="font-sans text-[12px] text-secondary">{meta.label}</span>
                      <span className="ml-auto font-mono text-[11px] text-primary">{fmtNum(n)}</span>
                      <span className="w-8 text-right font-mono text-[10px] text-muted">{pct}%</span>
                    </div>
                    <div className="mt-1 h-1 rounded-[1px] bg-raised">
                      <div
                        className="h-full rounded-[1px] transition-all duration-300"
                        style={{ width: `${pct}%`, background: meta.color, opacity: 0.85 }}
                      />
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </ChartPanel>
  );
});
