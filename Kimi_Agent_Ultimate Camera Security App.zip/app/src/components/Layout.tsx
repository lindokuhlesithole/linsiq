/**
 * Layout — app shell (design.md §5).
 * Fixed Sidebar (232px/56px, persisted) + fixed TopBar (56px) + content region.
 * Layout owns the top offset — pages never compensate.
 */
import { memo, useEffect, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { getSidebarCollapsed } from '@/lib/store';
import { useRealtimeStatus } from '@/hooks/useData';
import { fmtTime } from '@/lib/format';
import Sidebar from './Footer';
import TopBar from './Navbar';
import { AlertDetailDrawer } from './soc/AlertDetailDrawer';
import { RouteErrorBoundary } from './soc/feedback';
import { cn } from '@/lib/utils';

/* Paused-realtime banner (fleet-command.md States) */
const PausedBanner = memo(function PausedBanner() {
  const { running, lastTickAt, setRunning } = useRealtimeStatus();
  return (
    <AnimatePresence>
      {!running && (
        <motion.div
          initial={{ y: -28, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -28, opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="flex h-7 shrink-0 items-center justify-center gap-3 border-b border-warning/30 bg-warning-dim font-mono text-[10px] uppercase tracking-[0.08em] text-warning"
        >
          Live feed paused — data frozen at {fmtTime(lastTickAt)}
          <button className="underline underline-offset-2 hover:text-primary" onClick={() => setRunning(true)}>
            Resume
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
});

const NarrowNotice = memo(function NarrowNotice() {
  const [narrow, setNarrow] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 1023px)');
    const on = () => setNarrow(mq.matches);
    on();
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);
  if (!narrow) return null;
  return (
    <div className="flex h-6 shrink-0 items-center justify-center border-b border-line bg-raised font-mono text-[9px] uppercase tracking-[0.1em] text-muted">
      Desktop control room recommended (≥1280px)
    </div>
  );
});

export const Layout = memo(function Layout() {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(getSidebarCollapsed);
  const [drawerAlertId, setDrawerAlertId] = useState<string | null>(null);

  useEffect(() => {
    const on = () => setCollapsed(getSidebarCollapsed());
    window.addEventListener('swealth:sidebar', on);
    return () => window.removeEventListener('swealth:sidebar', on);
  }, []);

  // global alert-drawer host: toasts, bell dropdown, map popovers open here
  useEffect(() => {
    const onOpen = (e: Event) => {
      const id = (e as CustomEvent).detail?.alertId as string | undefined;
      if (id) setDrawerAlertId(id);
    };
    window.addEventListener('swealth:open-alert', onOpen);
    return () => window.removeEventListener('swealth:open-alert', onOpen);
  }, []);

  // login renders chromeless (page agent owns the full-screen layout)
  if (location.pathname === '/login') {
    return (
      <RouteErrorBoundary>
        <Outlet />
      </RouteErrorBoundary>
    );
  }

  return (
    <div className="h-screen overflow-hidden bg-canvas">
      <Sidebar />
      <TopBar />
      <main
        className={cn(
          'flex h-full flex-col pt-14 transition-[margin] duration-200 ease-in-out',
          collapsed ? 'ml-14' : 'ml-[232px]',
        )}
      >
        <NarrowNotice />
        <PausedBanner />
        <div className="min-h-0 flex-1">
          <RouteErrorBoundary key={location.pathname}>
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2, ease: [0.2, 0.8, 0.2, 1] }}
              className="h-full"
            >
              <Outlet />
            </motion.div>
          </RouteErrorBoundary>
        </div>
      </main>
      <AlertDetailDrawer alertId={drawerAlertId} open={!!drawerAlertId} onClose={() => setDrawerAlertId(null)} />
    </div>
  );
});

export default Layout;
