/**
 * Shared helpers for the Plate Intelligence + Alert Center pages.
 * Debounce hook, substring highlighting, plate auto-format, haversine.
 */
import { useEffect, useState } from 'react';

/* ── Debounce (150ms per design) ─────────────────────────────────────────── */

export function useDebounced<T>(value: T, delayMs = 150): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(t);
  }, [value, delayMs]);
  return debounced;
}

/* ── Substring highlight (space-insensitive for plates) ──────────────────── */

export interface HighlightParts {
  pre: string;
  mid: string;
  post: string;
}

/**
 * Find `query` inside `text` (case-insensitive, optionally ignoring spaces)
 * and split into pre/mid/post for accent highlighting.
 */
export function splitHighlight(text: string, query: string, ignoreSpaces = false): HighlightParts | null {
  const q = query.trim();
  if (!q) return null;
  const direct = text.toUpperCase().indexOf(q.toUpperCase());
  if (direct >= 0) {
    return { pre: text.slice(0, direct), mid: text.slice(direct, direct + q.length), post: text.slice(direct + q.length) };
  }
  if (!ignoreSpaces) return null;
  const squash = (s: string) => s.toUpperCase().replace(/\s+/g, '');
  const si = squash(text).indexOf(squash(q));
  if (si < 0 || !squash(q)) return null;
  // map squashed range back to original string indices
  let start = -1;
  let end = -1;
  let count = 0;
  for (let i = 0; i < text.length; i++) {
    if (/\s/.test(text[i])) continue;
    if (count === si && start < 0) start = i;
    if (count === si + squash(q).length - 1) {
      end = i + 1;
      break;
    }
    count++;
  }
  if (start < 0 || end < 0) return null;
  return { pre: text.slice(0, start), mid: text.slice(start, end), post: text.slice(end) };
}

/** Inline highlighted text — matched substring in accent. */
export function Highlight({ text, query, ignoreSpaces = false }: { text: string; query: string; ignoreSpaces?: boolean }) {
  const parts = splitHighlight(text, query, ignoreSpaces);
  if (!parts) return <>{text}</>;
  return (
    <>
      {parts.pre}
      <span className="text-accent">{parts.mid}</span>
      {parts.post}
    </>
  );
}

/* ── SA plate auto-format: "gp482913" → "GP 482-913" ─────────────────────── */

export function formatSaPlate(raw: string): string {
  const clean = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
  const letters = clean.match(/^[A-Z]{1,3}/)?.[0] ?? '';
  const digits = clean.slice(letters.length).replace(/[A-Z]/g, '').slice(0, 6);
  if (!digits) return letters;
  const d1 = digits.slice(0, 3);
  const d2 = digits.slice(3);
  return `${letters} ${d1}${d2 ? `-${d2}` : ''}`.trim();
}

/** Cheap haversine (km) for guard ETA / nearest-guard picks. */
export function haversineKm(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((aLat * Math.PI) / 180) * Math.cos((bLat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
