/**
 * HotlistManagerTab — two-pane hotlist manager (alpr.md §3).
 * Left: hotlist cards (kind, entries, enabled toggle, sync state).
 * Right: entries table with search, inline add row, CSV paste-import,
 * inline-confirm remove + undo strip. All mutations via useData hooks
 * (audit_log writes included). Role-gated: guard = read-only.
 */
import { memo, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Download, ListPlus, Plus, Trash2, Upload } from 'lucide-react';
import type { Hotlist, HotlistEntry, HotlistKind, HotlistPriority } from '@/lib/types';
import { addHotlistEntry, removeHotlistEntry, toggleHotlist, useCanOperate, useHotlists } from '@/hooks/useData';
import { fmtDateTime, relTime } from '@/lib/format';
import { DangerButton, GhostButton, IconButton, SocButton, SocInput, SocModal, ToggleSwitch } from '@/components/soc/primitives';
import { EmptyState, SkeletonRow } from '@/components/soc/feedback';
import { PlateChip } from '@/components/soc/PlateReadRow';
import { SeverityBadge } from '@/components/soc/StatusPill';
import { showToast } from '@/components/soc/Toast';
import { formatSaPlate, useDebounced } from './pageUtils';
import { cn } from '@/lib/utils';

const KIND_TAG: Record<HotlistKind, { label: string; cls: string }> = {
  national_sync: { label: 'NATIONAL SYNC', cls: 'bg-info-dim text-info' },
  stolen_vehicle: { label: 'STOLEN', cls: 'bg-danger-dim text-danger' },
  wanted_person_vehicle: { label: 'WANTED', cls: 'bg-warning-dim text-warning' },
  custom: { label: 'CUSTOM', cls: 'bg-raised text-muted' },
};

function syncLine(h: Hotlist): { text: string; cls: string } {
  if (!h.enabled) return { text: 'DISABLED — NOT SYNCED', cls: 'text-muted' };
  if (h.kind === 'national_sync') return { text: 'SYNCED 12M AGO', cls: 'text-accent' };
  if (h.kind === 'custom') return { text: 'LOCAL LIST · NO UPSTREAM', cls: 'text-muted' };
  return { text: 'SYNC PENDING', cls: 'text-warning' };
}

const PRIORITIES: HotlistPriority[] = ['critical', 'high', 'medium'];

export const HotlistManagerTab = memo(function HotlistManagerTab({ ready }: { ready: boolean }) {
  const hotlists = useHotlists();
  const canOperate = useCanOperate();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = hotlists.find((h) => h.id === selectedId) ?? hotlists[0];

  const [entryQuery, setEntryQuery] = useState('');
  const debEntryQuery = useDebounced(entryQuery, 150);
  const [adding, setAdding] = useState(false);
  const [csvOpen, setCsvOpen] = useState(false);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [undoEntry, setUndoEntry] = useState<{ listId: string; entry: HotlistEntry } | null>(null);

  const entries = useMemo(() => {
    if (!selected) return [];
    const q = debEntryQuery.trim().toUpperCase();
    if (!q) return selected.entries;
    return selected.entries.filter((e) => e.plate.includes(q) || e.reason.toUpperCase().includes(q));
  }, [selected, debEntryQuery]);

  const commitRemove = (listId: string, entry: HotlistEntry) => {
    removeHotlistEntry(listId, entry.id);
    setConfirmId(null);
    setUndoEntry({ listId, entry });
    showToast({ severity: 'medium', title: `${entry.plate} removed`, body: 'Undo available for 5s below' });
    setTimeout(() => setUndoEntry((u) => (u?.entry.id === entry.id ? null : u)), 5000);
  };

  const undoRemove = () => {
    if (!undoEntry) return;
    addHotlistEntry(undoEntry.listId, {
      plate: undoEntry.entry.plate,
      reason: undoEntry.entry.reason,
      priority: undoEntry.entry.priority,
      notes: undoEntry.entry.notes,
    });
    showToast({ severity: 'low', title: `${undoEntry.entry.plate} restored` });
    setUndoEntry(null);
  };

  if (!ready) {
    return (
      <div className="flex h-full">
        <div className="w-[300px] border-r border-line p-2">{Array.from({ length: 3 }, (_, i) => <SkeletonRow key={i} />)}</div>
        <div className="flex-1 p-2">{Array.from({ length: 6 }, (_, i) => <SkeletonRow key={i} variant="plate" />)}</div>
      </div>
    );
  }

  return (
    <div className="relative flex h-full min-h-0">
      {/* left — hotlist cards */}
      <aside className="flex w-[300px] shrink-0 flex-col border-r border-line">
        <div className="border-b border-line px-3 py-2 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
          Hotlists · {hotlists.length}
        </div>
        <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto p-2">
          {hotlists.map((h) => {
            const tag = KIND_TAG[h.kind];
            const sync = syncLine(h);
            const active = selected?.id === h.id;
            return (
              <button
                key={h.id}
                onClick={() => {
                  setSelectedId(h.id);
                  setAdding(false);
                  setConfirmId(null);
                }}
                className={cn(
                  'relative w-full rounded-sm border border-line bg-surface p-2.5 pl-3 text-left transition-colors duration-150 hover:border-line-strong',
                  active && 'border-line-strong bg-raised',
                )}
              >
                {active && <motion.span layoutId="hotlist-rail" className="absolute left-0 top-0 bottom-0 w-0.5 bg-accent" transition={{ duration: 0.18 }} />}
                <span className="flex items-center justify-between gap-2">
                  <span className="truncate font-sans text-[12px] font-semibold text-primary">{h.name}</span>
                  <ToggleSwitch
                    on={h.enabled}
                    disabled={!canOperate}
                    tooltip={!canOperate ? 'Requires OPERATOR role' : h.enabled ? 'Disable list' : 'Enable list'}
                    onChange={() => toggleHotlist(h.id)}
                  />
                </span>
                <span className="mt-1 flex items-center gap-1.5">
                  <span className={cn('rounded-sm px-1 py-px font-mono text-[9px] font-semibold', tag.cls)}>{tag.label}</span>
                  <span className="font-mono text-[10px] text-secondary">{h.entries.length} PLATES</span>
                </span>
                <span className="mt-1 block truncate font-sans text-[10px] text-muted" title={h.source}>
                  {h.source}
                </span>
                <span className={cn('mt-0.5 block font-mono text-[9px]', sync.cls)}>{sync.text}</span>
              </button>
            );
          })}
        </div>
      </aside>

      {/* right — entries table */}
      <div className="flex min-w-0 flex-1 flex-col">
        {!selected ? (
          <EmptyState icon={ListPlus} heading="No hotlists in this tenant" copy="Hotlists sync from SAPS national feeds or are curated locally by operators." className="flex-1" />
        ) : (
          <>
            {/* toolbar */}
            <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-line px-3 py-2">
              <div className="w-56">
                <SocInput mono value={entryQuery} onChange={(e) => setEntryQuery(e.target.value)} placeholder="Search plates / reasons…" aria-label="Search within hotlist" />
              </div>
              <span className="font-mono text-[10px] text-muted">
                {entries.length}/{selected.entries.length}
              </span>
              <span className="ml-auto flex items-center gap-2">
                <GhostButton disabled={!canOperate} tooltip={!canOperate ? 'Requires OPERATOR role' : 'Paste plate,reason,priority lines'} onClick={() => setCsvOpen(true)}>
                  <span className="inline-flex items-center gap-1.5"><Upload size={12} /> Import CSV</span>
                </GhostButton>
                <SocButton disabled={!canOperate} tooltip={!canOperate ? 'Requires OPERATOR role' : undefined} onClick={() => setAdding((a) => !a)}>
                  <span className="inline-flex items-center gap-1.5"><Plus size={13} /> Add plate</span>
                </SocButton>
              </span>
            </div>

            {/* column header */}
            <div className="grid h-8 shrink-0 grid-cols-[150px_minmax(0,1fr)_90px_150px_minmax(0,1fr)_64px] items-center gap-2.5 border-b border-line bg-surface-solid px-3 font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">
              <span>Plate</span>
              <span>Reason</span>
              <span>Priority</span>
              <span>Added by · at</span>
              <span>Notes</span>
              <span />
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto">
              <AnimatePresence initial={false}>
                {adding && canOperate && (
                  <AddEntryRow
                    key="add-row"
                    listName={selected.name}
                    onCancel={() => setAdding(false)}
                    onCommit={(entry) => {
                      addHotlistEntry(selected.id, entry);
                      showToast({ severity: 'high', title: `Added ${entry.plate} to ${selected.name}`, body: selected.enabled ? 'Next sighting fires a critical alert within 30s' : 'List disabled — enable it to arm matching' });
                      setAdding(false);
                    }}
                  />
                )}
              </AnimatePresence>
              {entries.length === 0 && !adding ? (
                <EmptyState
                  icon={ListPlus}
                  heading={debEntryQuery ? 'No entries match' : 'List is empty'}
                  copy={debEntryQuery ? 'Clear the search to see all plates on this list.' : 'Add a plate manually or paste a CSV import to arm this list.'}
                  actionLabel={debEntryQuery ? 'Clear search' : undefined}
                  onAction={debEntryQuery ? () => setEntryQuery('') : undefined}
                  className="py-10"
                />
              ) : (
                entries.map((e) => (
                  <div
                    key={e.id}
                    className="group relative grid h-11 grid-cols-[150px_minmax(0,1fr)_90px_150px_minmax(0,1fr)_64px] items-center gap-2.5 border-b border-line px-3 transition-colors hover:bg-raised/60"
                  >
                    <span><PlateChip plate={e.plate} hot={e.priority === 'critical'} small /></span>
                    <span className="truncate font-sans text-[12px] text-secondary" title={e.reason}>{e.reason}</span>
                    <span><SeverityBadge severity={e.priority} /></span>
                    <span className="truncate font-mono text-[10px] text-muted" title={fmtDateTime(e.added_at)}>
                      {e.added_by} · {relTime(e.added_at)}
                    </span>
                    <span className="truncate font-sans text-[11px] text-muted" title={e.notes ?? ''}>{e.notes ?? '—'}</span>
                    <span className="flex items-center justify-end gap-1">
                      <IconButton
                        tooltip={canOperate ? 'Remove plate' : 'Requires OPERATOR role'}
                        disabled={!canOperate}
                        onClick={() => setConfirmId(confirmId === e.id ? null : e.id)}
                      >
                        <Trash2 size={13} />
                      </IconButton>
                    </span>
                    {confirmId === e.id && (
                      <span className="absolute right-2 top-full z-30 mt-1 flex items-center gap-2 rounded-sm border border-line-strong bg-surface-solid px-2.5 py-1.5 shadow-drawer">
                        <span className="font-mono text-[10px] text-secondary">Remove {e.plate}?</span>
                        <DangerButton className="h-6 px-2 text-[10px]" onClick={() => commitRemove(selected.id, e)}>Confirm</DangerButton>
                        <GhostButton className="h-6 px-2 text-[10px]" onClick={() => setConfirmId(null)}>Cancel</GhostButton>
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>

            {/* undo strip */}
            <AnimatePresence>
              {undoEntry && (
                <motion.div
                  initial={{ y: 28, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 28, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="absolute bottom-3 left-1/2 z-40 flex -translate-x-1/2 items-center gap-3 rounded-sm border border-line-strong bg-surface-solid px-3 py-2 shadow-drawer"
                >
                  <span className="font-mono text-[10px] text-secondary">Removed {undoEntry.entry.plate}</span>
                  <GhostButton className="h-6 px-2 text-[10px]" onClick={undoRemove}>Undo</GhostButton>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}
      </div>

      <CsvImportModal
        open={csvOpen}
        onClose={() => setCsvOpen(false)}
        onImport={(rows) => {
          if (!selected) return;
          for (const r of rows) addHotlistEntry(selected.id, r);
          showToast({ severity: 'medium', title: `Imported ${rows.length} plates into ${selected.name}` });
          setCsvOpen(false);
        }}
      />
    </div>
  );
});

/* ── Inline add row (height-expand spring) ───────────────────────────────── */

const AddEntryRow = memo(function AddEntryRow({
  listName,
  onCommit,
  onCancel,
}: {
  listName: string;
  onCommit: (e: { plate: string; reason: string; priority: HotlistPriority; notes?: string }) => void;
  onCancel: () => void;
}) {
  const [plate, setPlate] = useState('');
  const [reason, setReason] = useState('');
  const [priority, setPriority] = useState<HotlistPriority>('high');
  const [notes, setNotes] = useState('');
  const valid = plate.trim().length >= 4 && reason.trim().length > 0;
  return (
    <motion.div
      initial={{ height: 0, opacity: 0 }}
      animate={{ height: 44, opacity: 1 }}
      exit={{ height: 0, opacity: 0 }}
      transition={{ type: 'spring', stiffness: 400, damping: 36 }}
      className="overflow-hidden border-b border-accent/30 bg-accent-dim/40"
    >
      <div className="grid h-11 grid-cols-[150px_minmax(0,1fr)_90px_150px_minmax(0,1fr)_64px] items-center gap-2.5 px-3">
        <input
          autoFocus
          value={plate}
          onChange={(e) => setPlate(formatSaPlate(e.target.value))}
          placeholder="GP 000-000"
          className="h-7 rounded-sm border border-line bg-inset px-2 font-mono text-[11px] uppercase text-primary placeholder:text-muted focus:border-accent focus:outline-none"
        />
        <input
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Reason (e.g. Stolen — SAPS case CAS 221/03/2026)"
          className="h-7 rounded-sm border border-line bg-inset px-2 font-sans text-[11px] text-primary placeholder:text-muted focus:border-accent focus:outline-none"
        />
        <select
          value={priority}
          onChange={(e) => setPriority(e.target.value as HotlistPriority)}
          className="h-7 rounded-sm border border-line bg-inset px-1 font-mono text-[10px] text-primary focus:border-accent focus:outline-none"
        >
          {PRIORITIES.map((p) => (
            <option key={p} value={p}>{p.toUpperCase()}</option>
          ))}
        </select>
        <span className="truncate font-mono text-[10px] text-muted" title={listName}>YOU · NOW</span>
        <input
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Notes (optional)"
          className="h-7 rounded-sm border border-line bg-inset px-2 font-sans text-[11px] text-primary placeholder:text-muted focus:border-accent focus:outline-none"
        />
        <span className="flex items-center justify-end gap-1">
          <SocButton className="h-6 px-2 text-[10px]" disabled={!valid} tooltip={valid ? undefined : 'Plate + reason required'} onClick={() => onCommit({ plate, reason, priority, notes: notes || undefined })}>
            Add
          </SocButton>
          <IconButton tooltip="Cancel" onClick={onCancel}>×</IconButton>
        </span>
      </div>
    </motion.div>
  );
});

/* ── CSV paste-import modal ──────────────────────────────────────────────── */

interface ParsedRow {
  plate: string;
  reason: string;
  priority: HotlistPriority;
  error?: string;
}

function parseCsv(text: string): ParsedRow[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((line) => {
      const [plateRaw = '', reasonRaw = '', prioRaw = 'high'] = line.split(',').map((s) => s.trim());
      const plate = formatSaPlate(plateRaw);
      const priority = prioRaw.toLowerCase() as HotlistPriority;
      if (!/^[A-Z]{2,3}\s?\d/.test(plate)) return { plate: plateRaw.toUpperCase(), reason: reasonRaw, priority: 'high', error: 'Invalid plate' };
      if (!reasonRaw) return { plate, reason: '', priority: 'high', error: 'Reason required' };
      if (!PRIORITIES.includes(priority)) return { plate, reason: reasonRaw, priority: 'high', error: `Bad priority "${prioRaw}"` };
      return { plate, reason: reasonRaw, priority };
    });
}

const CsvImportModal = memo(function CsvImportModal({
  open,
  onClose,
  onImport,
}: {
  open: boolean;
  onClose: () => void;
  onImport: (rows: { plate: string; reason: string; priority: HotlistPriority }[]) => void;
}) {
  const [text, setText] = useState('');
  const rows = useMemo(() => parseCsv(text), [text]);
  const valid = rows.filter((r) => !r.error);
  return (
    <SocModal open={open} onClose={onClose} title="Import plates — CSV paste" maxWidth={640}>
      <div className="space-y-3 p-4">
        <p className="font-sans text-[11px] text-muted">
          One entry per line: <span className="font-mono text-secondary">plate,reason,priority</span> — priority is critical | high | medium.
        </p>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={6}
          placeholder={'GP 482-913,Stolen — SAPS case CAS 221/03/2026,critical\nCA 555-010,Repeat tailgating offender,high'}
          className="w-full rounded-sm border border-line bg-inset p-2 font-mono text-[11px] text-primary placeholder:text-muted focus:border-accent focus:outline-none"
        />
        {rows.length > 0 && (
          <div className="max-h-44 overflow-y-auto rounded-sm border border-line">
            {rows.map((r, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -6 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.015 }}
                className={cn('grid h-8 grid-cols-[130px_minmax(0,1fr)_80px_minmax(0,1fr)] items-center gap-2 border-b border-line px-2 font-mono text-[10px]', r.error ? 'bg-danger-dim text-danger' : 'text-secondary')}
              >
                <span className="truncate">{r.plate}</span>
                <span className="truncate">{r.reason || '—'}</span>
                <span className="uppercase">{r.priority}</span>
                <span className="truncate text-right">{r.error ?? 'OK'}</span>
              </motion.div>
            ))}
          </div>
        )}
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] text-muted">
            {rows.length ? `${valid.length} VALID · ${rows.length - valid.length} ERRORS` : 'AWAITING INPUT'}
          </span>
          <div className="flex gap-2">
            <GhostButton onClick={onClose}>Cancel</GhostButton>
            <SocButton disabled={valid.length === 0} onClick={() => { onImport(valid); setText(''); }}>
              <span className="inline-flex items-center gap-1.5"><Download size={13} /> Import {valid.length || ''} plates</span>
            </SocButton>
          </div>
        </div>
      </div>
    </SocModal>
  );
});
