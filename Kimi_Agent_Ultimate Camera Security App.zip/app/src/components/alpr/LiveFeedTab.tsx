/**
 * LiveFeedTab — sticky filter bar + virtualized plate table (alpr.md §1).
 * Filters: plate search (150ms debounce), camera, direction, time range,
 * hotlist-only, live/pause with accumulating "+N new reads" pill.
 */
import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Flame, Pause, Play, ScanLine } from 'lucide-react';
import type { Direction, PlateRead } from '@/lib/types';
import { useCameras, useCanOperate, useHotlists, usePlateReads } from '@/hooks/useData';
import { FilterChip, SocInput, ToggleSwitch } from '@/components/soc/primitives';
import { EmptyState, SkeletonRow } from '@/components/soc/feedback';
import { useDebounced } from './pageUtils';
import { FEED_GRID, FEED_ROW_H, FeedRow } from './FeedRow';
import { cn } from '@/lib/utils';

const RANGES = [
  { label: 'LAST HOUR', ms: 3600_000 },
  { label: '6H', ms: 6 * 3600_000 },
  { label: '24H', ms: 24 * 3600_000 },
  { label: '48H', ms: 48 * 3600_000 },
] as const;

const OVERSCAN = 6;

export const LiveFeedTab = memo(function LiveFeedTab({
  ready,
  hotlistOnlyInitial = false,
  onViewVehicle,
}: {
  ready: boolean;
  hotlistOnlyInitial?: boolean;
  onViewVehicle: (read: PlateRead) => void;
}) {
  const cameras = useCameras();
  const hotlists = useHotlists();
  const canOperate = useCanOperate();

  const [query, setQuery] = useState('');
  const debouncedQuery = useDebounced(query, 150);
  const [cameraId, setCameraId] = useState('');
  const [direction, setDirection] = useState<'all' | Direction>('all');
  const [rangeMs, setRangeMs] = useState<number>(RANGES[2].ms);
  const [hotOnly, setHotOnly] = useState(hotlistOnlyInitial);
  const [paused, setPaused] = useState(false);
  const [frozen, setFrozen] = useState<PlateRead[] | null>(null);

  const filters = useMemo(
    () => ({
      cameraId: cameraId || undefined,
      direction: direction === 'all' ? undefined : direction,
      hotlistOnly: hotOnly || undefined,
      sinceMs: rangeMs,
      plateQuery: debouncedQuery || undefined,
    }),
    [cameraId, direction, hotOnly, rangeMs, debouncedQuery],
  );
  const reads = usePlateReads(filters);
  const filterKey = JSON.stringify(filters);

  // flush the frozen buffer whenever filters change
  useEffect(() => {
    setFrozen(null);
    setPaused(false);
  }, [filterKey]);

  const displayed = frozen ?? reads;
  const pendingCount = useMemo(() => {
    if (!frozen) return 0;
    const frozenIds = new Set(frozen.map((r) => r.id));
    let n = 0;
    for (const r of reads) {
      if (frozenIds.has(r.id)) break;
      n++;
    }
    return n;
  }, [frozen, reads]);

  const togglePause = useCallback(() => {
    setPaused((p) => {
      if (!p) {
        setFrozen(reads);
        return true;
      }
      setFrozen(null);
      return false;
    });
  }, [reads]);

  const flush = useCallback(() => {
    setFrozen(null);
    setPaused(false);
  }, []);

  const alprCams = useMemo(() => cameras.filter((c) => c.kind === 'fixed_alpr'), [cameras]);
  const camLabel = useMemo(() => {
    const m = new Map(cameras.map((c) => [c.id, `${c.name} · ${c.zone}`] as const));
    return (id: string) => m.get(id) ?? id;
  }, [cameras]);

  const resetFilters = useCallback(() => {
    setQuery('');
    setCameraId('');
    setDirection('all');
    setRangeMs(RANGES[2].ms);
    setHotOnly(false);
  }, []);

  /* ── Virtualized window (fixed 44px rows) ─────────────────────────────── */
  const scrollRef = useRef<HTMLDivElement>(null);
  const [viewport, setViewport] = useState({ top: 0, height: 480 });
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    let raf = 0;
    const measure = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setViewport({ top: el.scrollTop, height: el.clientHeight }));
    };
    measure();
    el.addEventListener('scroll', measure, { passive: true });
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => {
      el.removeEventListener('scroll', measure);
      ro.disconnect();
      cancelAnimationFrame(raf);
    };
    // re-attach when the scroll container remounts (empty ↔ data transitions)
  }, [ready, displayed.length === 0]);

  const startIdx = Math.max(0, Math.floor(viewport.top / FEED_ROW_H) - OVERSCAN);
  const endIdx = Math.min(displayed.length, Math.ceil((viewport.top + viewport.height) / FEED_ROW_H) + OVERSCAN);
  const windowRows = displayed.slice(startIdx, endIdx);

  // fresh flash: reads captured in the last 4s flash on mount
  const freshCutoff = Date.now() - 4000;

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* sticky filter bar */}
      <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-line px-3 py-2">
        <div className="w-64">
          <SocInput
            mono
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder='Search plate — try "482" or "CA 5"'
            aria-label="Search plate"
          />
        </div>
        <select
          value={cameraId}
          onChange={(e) => setCameraId(e.target.value)}
          className="h-8 rounded-sm border border-line bg-inset px-2 font-mono text-[11px] text-primary focus:border-accent focus:outline-none"
          aria-label="Filter by camera"
        >
          <option value="">ALL CAMERAS</option>
          {alprCams.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <div className="flex items-center gap-1">
          {(['all', 'inbound', 'outbound'] as const).map((d) => (
            <FilterChip key={d} active={direction === d} onClick={() => setDirection(d)}>
              {d === 'all' ? 'ALL' : d}
            </FilterChip>
          ))}
        </div>
        <select
          value={rangeMs}
          onChange={(e) => setRangeMs(Number(e.target.value))}
          className="h-8 rounded-sm border border-line bg-inset px-2 font-mono text-[11px] text-primary focus:border-accent focus:outline-none"
          aria-label="Time range"
        >
          {RANGES.map((r) => (
            <option key={r.ms} value={r.ms}>
              {r.label}
            </option>
          ))}
        </select>
        <span className={cn('flex items-center gap-1.5 rounded-full border px-2 py-0.5 transition-colors', hotOnly ? 'border-danger/40 bg-danger-dim' : 'border-transparent')}>
          <Flame size={11} className={hotOnly ? 'text-danger' : 'text-muted'} />
          <span className={cn('font-sans text-[10px] font-semibold uppercase tracking-[0.10em]', hotOnly ? 'text-danger' : 'text-secondary')}>Hotlist only</span>
          <ToggleSwitch on={hotOnly} onChange={setHotOnly} tooltip="Show hotlist hits only" />
        </span>
        <span className="ml-auto flex items-center gap-2">
          {paused && pendingCount > 0 && (
            <button
              onClick={flush}
              className="rounded-full border border-warning/40 bg-warning-dim px-2 py-0.5 font-mono text-[10px] font-semibold text-warning transition-transform hover:scale-105"
              title="Flush buffered reads into the table"
            >
              +{pendingCount} NEW
            </button>
          )}
          <button
            onClick={togglePause}
            className={cn(
              'flex h-7 items-center gap-1.5 rounded-sm border px-2.5 font-mono text-[10px] font-semibold uppercase tracking-[0.08em] transition-colors',
              paused ? 'border-warning/40 bg-warning-dim text-warning' : 'border-line-strong text-accent hover:border-accent',
            )}
          >
            {paused ? <Pause size={11} /> : <Play size={11} />}
            {paused ? 'PAUSED' : 'LIVE'}
          </button>
        </span>
      </div>

      {/* column header */}
      <div className={cn(FEED_GRID, 'h-8 shrink-0 border-b border-line bg-surface-solid px-3 font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted')}>
        <span>Plate</span>
        <span>Vehicle</span>
        <span>Camera</span>
        <span className="text-center">Dir</span>
        <span className="text-right">Conf</span>
        <span className="text-center">Hot</span>
        <span className="text-right">Captured</span>
      </div>

      {/* virtualized body */}
      {!ready ? (
        <div className="flex-1 overflow-hidden">
          {Array.from({ length: 10 }, (_, i) => (
            <SkeletonRow key={i} variant="plate" className="h-11" />
          ))}
        </div>
      ) : displayed.length === 0 ? (
        <EmptyState
          icon={ScanLine}
          heading="No plate reads match"
          copy="Widen the time range or clear the plate search to see reads from all ALPR gates."
          actionLabel="Clear filters"
          onAction={resetFilters}
          className="flex-1"
        />
      ) : (
        <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto">
          <div className="relative" style={{ height: displayed.length * FEED_ROW_H }}>
            {windowRows.map((read, i) => (
              <FeedRow
                key={read.id}
                read={read}
                cameraLabel={camLabel(read.camera_id)}
                query={debouncedQuery}
                canOperate={canOperate}
                hotlists={hotlists}
                onView={onViewVehicle}
                fresh={!paused && new Date(read.captured_at).getTime() > freshCutoff}
                style={{ top: (startIdx + i) * FEED_ROW_H, height: FEED_ROW_H }}
              />
            ))}
          </div>
        </div>
      )}

      {/* footer status line */}
      <div className="flex h-7 shrink-0 items-center justify-between border-t border-line px-3 font-mono text-[10px] text-muted">
        <span>
          {displayed.length.toLocaleString('en-ZA')} READS{displayed.length >= 2500 ? ' (BUFFER CAP)' : ''}
        </span>
        <span className={paused ? 'text-warning' : 'text-accent'}>{paused ? '❚❚ BUFFERING — insertion frozen' : '● STREAMING'}</span>
      </div>
    </div>
  );
});
