/**
 * VehicleSearchTab — "Vehicle Fingerprint" search (alpr.md §2).
 * Left filter panel (plate fragment, color swatches, make, body type,
 * camera multi-select, date range) + results grid of vehicle cards.
 */
import { memo, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CarFront, Flame } from 'lucide-react';
import type { PlateRead, VehicleType } from '@/lib/types';
import { useCameras, useHotlists, usePlateReads } from '@/hooks/useData';
import { fmtDateTime, relTime } from '@/lib/format';
import { evidenceThumbSvg, plateCropSvg } from '@/lib/procedural';
import { FilterChip, GhostButton, SocInput } from '@/components/soc/primitives';
import { EmptyState, SkeletonRow } from '@/components/soc/feedback';
import { PlateChip } from '@/components/soc/PlateReadRow';
import { useDebounced } from './pageUtils';
import { VEHICLE_COLOR_HEX, VehicleColorDot } from './FeedRow';
import { cn } from '@/lib/utils';

const SWATCHES = ['White', 'Silver', 'Grey', 'Black', 'Red', 'Blue', 'Green', 'Beige', 'Other'] as const;
const KNOWN_COLORS: Set<string> = new Set(SWATCHES.filter((s) => s !== 'Other'));

const MAKES = [
  { label: 'Toyota', match: 'Toyota' },
  { label: 'VW', match: 'VW' },
  { label: 'Ford', match: 'Ford' },
  { label: 'Isuzu', match: 'Isuzu' },
  { label: 'BMW', match: 'BMW' },
  { label: 'Mercedes', match: 'Mercedes-Benz' },
  { label: 'Hyundai', match: 'Hyundai' },
  { label: 'Kia', match: 'Kia' },
  { label: 'Nissan', match: 'Nissan' },
  { label: 'Other', match: '__other__' },
] as const;

const BODY_TYPES: { id: VehicleType; label: string }[] = [
  { id: 'sedan', label: 'SEDAN' },
  { id: 'hatch', label: 'HATCH' },
  { id: 'suv', label: 'SUV' },
  { id: 'bakkie', label: 'BAKKIE' },
  { id: 'truck', label: 'TRUCK' },
  { id: 'motorcycle', label: 'MOTO' },
  { id: 'taxi', label: 'TAXI' },
];

type SortMode = 'recent' | 'sightings' | 'confidence';

interface VehicleGroup {
  plate: string;
  latest: PlateRead;
  sightings: number;
  maxConf: number;
  hot: boolean;
}

export const VehicleSearchTab = memo(function VehicleSearchTab({
  ready,
  onViewVehicle,
}: {
  ready: boolean;
  onViewVehicle: (read: PlateRead) => void;
}) {
  const cameras = useCameras();
  const hotlists = useHotlists();
  const reads = usePlateReads();

  const [fragment, setFragment] = useState('');
  const debFragment = useDebounced(fragment, 150);
  const [color, setColor] = useState<string | null>(null);
  const [make, setMake] = useState('');
  const [types, setTypes] = useState<Set<VehicleType>>(new Set());
  const [camIds, setCamIds] = useState<Set<string>>(new Set());
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [sort, setSort] = useState<SortMode>('recent');

  const alprCams = useMemo(() => cameras.filter((c) => c.kind === 'fixed_alpr'), [cameras]);
  const camName = useMemo(() => {
    const m = new Map(cameras.map((c) => [c.id, c.name] as const));
    return (id: string) => m.get(id) ?? id;
  }, [cameras]);
  const hotPlates = useMemo(() => {
    const s = new Set<string>();
    for (const h of hotlists) for (const e of h.entries) s.add(e.plate);
    return s;
  }, [hotlists]);

  const groups = useMemo(() => {
    let out = reads;
    if (debFragment) {
      const q = debFragment.toUpperCase().replace(/\s+/g, '');
      out = out.filter((r) => r.plate.replace(/\s+/g, '').includes(q));
    }
    if (color) {
      out = color === 'Other' ? out.filter((r) => !KNOWN_COLORS.has(r.vehicle_color)) : out.filter((r) => r.vehicle_color === color);
    }
    if (make) {
      const m = MAKES.find((x) => x.label === make);
      if (m?.match === '__other__') {
        const known = MAKES.filter((x) => x.match !== '__other__').map((x) => x.match);
        out = out.filter((r) => !known.some((k) => r.vehicle_make.startsWith(k)));
      } else if (m) {
        out = out.filter((r) => r.vehicle_make.startsWith(m.match));
      }
    }
    if (types.size) out = out.filter((r) => types.has(r.vehicle_type));
    if (camIds.size) out = out.filter((r) => camIds.has(r.camera_id));
    if (start) out = out.filter((r) => new Date(r.captured_at).getTime() >= new Date(start).getTime());
    if (end) out = out.filter((r) => new Date(r.captured_at).getTime() <= new Date(end).getTime());

    const byPlate = new Map<string, VehicleGroup>();
    for (const r of out) {
      const g = byPlate.get(r.plate);
      if (!g) {
        byPlate.set(r.plate, { plate: r.plate, latest: r, sightings: 1, maxConf: r.confidence, hot: r.hotlist_hit || hotPlates.has(r.plate) });
      } else {
        g.sightings++;
        if (r.captured_at > g.latest.captured_at) g.latest = r;
        if (r.confidence > g.maxConf) g.maxConf = r.confidence;
        if (r.hotlist_hit) g.hot = true;
      }
    }
    const arr = [...byPlate.values()];
    if (sort === 'sightings') arr.sort((a, b) => b.sightings - a.sightings || b.latest.captured_at.localeCompare(a.latest.captured_at));
    else if (sort === 'confidence') arr.sort((a, b) => b.maxConf - a.maxConf);
    else arr.sort((a, b) => b.latest.captured_at.localeCompare(a.latest.captured_at));
    return arr;
  }, [reads, debFragment, color, make, types, camIds, start, end, sort, hotPlates]);

  const hasFilters = !!(debFragment || color || make || types.size || camIds.size || start || end);
  const relaxHint = useMemo(() => {
    if (color) return 'Try removing the color filter';
    if (make) return 'Try clearing the make select';
    if (types.size) return 'Try enabling more body types';
    if (camIds.size) return 'Try widening the camera selection';
    if (start || end) return 'Try widening the date range';
    if (debFragment) return 'Try a shorter plate fragment';
    return 'Loosen a fingerprint filter to see more vehicles';
  }, [color, make, types, camIds, start, end, debFragment]);

  const reset = () => {
    setFragment('');
    setColor(null);
    setMake('');
    setTypes(new Set());
    setCamIds(new Set());
    setStart('');
    setEnd('');
  };

  const toggleSet = <T,>(set: Set<T>, v: T, apply: (s: Set<T>) => void) => {
    const next = new Set(set);
    if (next.has(v)) next.delete(v);
    else next.add(v);
    apply(next);
  };

  const visible = groups.slice(0, 60);

  return (
    <div className="flex h-full min-h-0">
      {/* fingerprint filter panel */}
      <aside className="flex w-[280px] shrink-0 flex-col border-r border-line">
        <div className="border-b border-line px-3 py-2 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
          Fingerprint
        </div>
        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-3">
          <div>
            <label className="mb-1 block font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">Plate fragment</label>
            <SocInput mono value={fragment} onChange={(e) => setFragment(e.target.value)} placeholder='e.g. "482" or "CA 5"' />
          </div>
          <div>
            <label className="mb-1.5 block font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">
              Color {color && <span className="ml-1 text-accent">{color}</span>}
            </label>
            <div className="flex flex-wrap gap-2">
              {SWATCHES.map((s) => (
                <button
                  key={s}
                  title={s}
                  onClick={() => setColor((c) => (c === s ? null : s))}
                  className={cn(
                    'flex h-5 w-5 items-center justify-center rounded-full border transition-transform duration-100 hover:scale-110',
                    color === s ? 'border-accent ring-2 ring-accent-dim' : 'border-line-strong',
                  )}
                  style={{ background: s === 'Other' ? 'transparent' : (VEHICLE_COLOR_HEX[s] ?? '#5C6B8A') }}
                >
                  {s === 'Other' && <span className="font-mono text-[8px] text-muted">?</span>}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="mb-1 block font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">Make</label>
            <select
              value={make}
              onChange={(e) => setMake(e.target.value)}
              className="h-8 w-full rounded-sm border border-line bg-inset px-2 font-sans text-[12px] text-primary focus:border-accent focus:outline-none"
            >
              <option value="">Any make</option>
              {MAKES.map((m) => (
                <option key={m.label} value={m.label}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">Body type</label>
            <div className="flex flex-wrap gap-1">
              {BODY_TYPES.map((t) => (
                <FilterChip key={t.id} active={types.has(t.id)} onClick={() => toggleSet(types, t.id, setTypes)}>
                  {t.label}
                </FilterChip>
              ))}
            </div>
          </div>
          <div>
            <label className="mb-1.5 block font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">Cameras / zones</label>
            <div className="flex flex-wrap gap-1">
              {alprCams.map((c) => (
                <FilterChip key={c.id} active={camIds.has(c.id)} onClick={() => toggleSet(camIds, c.id, setCamIds)}>
                  {c.name}
                </FilterChip>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="mb-1 block font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">From</label>
              <input
                type="datetime-local"
                value={start}
                onChange={(e) => setStart(e.target.value)}
                className="h-8 w-full rounded-sm border border-line bg-inset px-2 font-mono text-[10px] text-primary focus:border-accent focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted">To</label>
              <input
                type="datetime-local"
                value={end}
                onChange={(e) => setEnd(e.target.value)}
                className="h-8 w-full rounded-sm border border-line bg-inset px-2 font-mono text-[10px] text-primary focus:border-accent focus:outline-none"
              />
            </div>
          </div>
        </div>
        <div className="flex shrink-0 items-center justify-between border-t border-line px-3 py-2">
          <motion.span
            key={groups.length}
            initial={{ backgroundColor: 'rgba(0,212,170,0.12)' }}
            animate={{ backgroundColor: 'rgba(0,0,0,0)' }}
            transition={{ duration: 0.3 }}
            className="rounded-sm px-1 font-mono text-[11px] font-semibold text-accent"
          >
            {groups.length.toLocaleString('en-ZA')} MATCHES
          </motion.span>
          <GhostButton className="h-6 px-2 text-[10px]" onClick={reset} disabled={!hasFilters}>
            Reset
          </GhostButton>
        </div>
      </aside>

      {/* results region */}
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex h-9 shrink-0 items-center justify-between border-b border-line px-3">
          <span className="font-mono text-[10px] text-muted">
            {visible.length < groups.length ? `SHOWING ${visible.length} OF ${groups.length}` : `${groups.length} VEHICLES`}
          </span>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortMode)}
            className="h-7 rounded-sm border border-line bg-inset px-2 font-mono text-[10px] text-primary focus:border-accent focus:outline-none"
            aria-label="Sort results"
          >
            <option value="recent">MOST RECENT</option>
            <option value="sightings">MOST SIGHTINGS</option>
            <option value="confidence">CONFIDENCE</option>
          </select>
        </div>
        {!ready ? (
          <div className="flex-1 overflow-hidden p-3">
            {Array.from({ length: 6 }, (_, i) => (
              <SkeletonRow key={i} variant="plate" className="h-11" />
            ))}
          </div>
        ) : groups.length === 0 ? (
          <EmptyState
            icon={CarFront}
            heading="No vehicles match this fingerprint"
            copy={relaxHint}
            actionLabel="Reset filters"
            onAction={reset}
            className="flex-1"
          />
        ) : (
          <div className="min-h-0 flex-1 overflow-y-auto p-3">
            <motion.div layout className="grid grid-cols-2 gap-3 xl:grid-cols-3 2xl:grid-cols-4">
              <AnimatePresence initial={false}>
                {visible.map((g, i) => (
                  <VehicleCard key={g.plate} group={g} camName={camName} index={i} onOpen={() => onViewVehicle(g.latest)} />
                ))}
              </AnimatePresence>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
});

/* ── Result card: procedural snapshot + plate crop + fingerprint line ────── */

const VehicleCard = memo(function VehicleCard({
  group,
  camName,
  index,
  onOpen,
}: {
  group: VehicleGroup;
  camName: (id: string) => string;
  index: number;
  onOpen: () => void;
}) {
  const r = group.latest;
  return (
    <motion.button
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.22, delay: Math.min(index, 16) * 0.025 }}
      onClick={onOpen}
      className={cn(
        'group overflow-hidden rounded-sm border bg-surface text-left backdrop-blur-sm transition-colors duration-150',
        group.hot ? 'border-danger-line hover:border-danger' : 'border-line hover:border-accent/50',
      )}
    >
      <span className="relative block aspect-[16/9] max-h-[86px] w-full overflow-hidden bg-inset [&>svg]:h-full [&>svg]:w-full [&>svg]:transition-transform [&>svg]:duration-150 group-hover:[&>svg]:scale-[1.03]">
        {evidenceThumbSvg('snapshot', r.snapshot_id, 192, 108)}
        {group.hot && (
          <span className="absolute right-1.5 top-1.5 flex items-center gap-0.5 rounded-sm bg-danger px-1 py-px font-mono text-[8px] font-semibold text-primary">
            <Flame size={8} /> HOT
          </span>
        )}
      </span>
      <span className="block border-y border-line bg-canvas px-1 py-0.5 [&>svg]:h-5 [&>svg]:w-full">{plateCropSvg(r.plate, 180, 20)}</span>
      <span className="block px-2 py-1.5">
        <span className="flex items-center justify-between gap-2">
          <PlateChip plate={r.plate} hot={group.hot} small />
          <span className="font-mono text-[9px] text-muted">×{group.sightings} SEEN</span>
        </span>
        <span className="mt-1 flex items-center gap-1.5 font-sans text-[10px] text-muted">
          <VehicleColorDot color={r.vehicle_color} size={7} />
          <span className="truncate">
            {r.vehicle_color} {r.vehicle_make} · {r.vehicle_type}
          </span>
        </span>
        <span className="mt-0.5 block truncate font-mono text-[9px] text-muted" title={fmtDateTime(r.captured_at)}>
          {camName(r.camera_id)} · {relTime(r.captured_at)}
        </span>
      </span>
    </motion.button>
  );
});
