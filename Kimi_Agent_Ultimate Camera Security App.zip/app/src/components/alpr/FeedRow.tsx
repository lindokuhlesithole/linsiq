/**
 * FeedRow — 44px virtualized live-feed row (alpr.md §1).
 * Plate chip with substring highlight, vehicle fingerprint, camera, direction,
 * confidence, HOT badge, relative time + hover quick actions (view / hotlist add).
 */
import { memo, useState } from 'react';
import type { CSSProperties } from 'react';
import { motion } from 'framer-motion';
import { ArrowDownLeft, ArrowUpRight, CarFront, Flame, ListPlus } from 'lucide-react';
import type { Hotlist, PlateRead } from '@/lib/types';
import { addHotlistEntry } from '@/hooks/useData';
import { fmtDateTime, relTime } from '@/lib/format';
import { IconButton } from '@/components/soc/primitives';
import { showToast } from '@/components/soc/Toast';
import { splitHighlight } from './pageUtils';
import { cn } from '@/lib/utils';

/** Grid template shared by header + rows (PLATE VEHICLE CAMERA DIR CONF HOT CAPTURED). */
export const FEED_GRID = 'grid grid-cols-[170px_minmax(0,1fr)_190px_36px_64px_52px_110px] items-center gap-2.5';
export const FEED_ROW_H = 44;

/* Plate chip with cross-segment highlight support (mirrors soc PlateChip anatomy).
 * Match ranges are computed against the full plate (space-insensitive), then
 * mapped onto the province band + body segments so "CA 5" lights both. */
const FeedPlateChip = memo(function FeedPlateChip({ plate, hot, query }: { plate: string; hot: boolean; query: string }) {
  const province = plate.slice(0, 2);
  const rest = plate.slice(2).trim();
  const restOffset = plate.length - rest.length;
  const parts = splitHighlight(plate, query, true);
  let bandHot = false;
  let restParts: { pre: string; mid: string; post: string } | null = null;
  if (parts) {
    const start = parts.pre.length;
    const end = start + parts.mid.length;
    bandHot = start < 2;
    const rs = start - restOffset;
    const re = end - restOffset;
    if (re > 0 && rs < rest.length) {
      const lo = Math.max(0, rs);
      const hi = Math.min(rest.length, re);
      restParts = { pre: rest.slice(0, lo), mid: rest.slice(lo, hi), post: rest.slice(hi) };
    }
  }
  return (
    <span className={cn('inline-flex items-stretch self-center overflow-hidden rounded-sm border bg-raised', hot ? 'border-danger' : 'border-line-strong')}>
      <span className={cn('flex items-center bg-info-dim px-1 font-mono text-[9px] font-semibold', bandHot ? 'text-accent' : 'text-info')}>{province}</span>
      <span className="px-1.5 font-mono text-[15px] font-semibold uppercase leading-6 tracking-[0.06em] text-primary">
        {restParts ? (
          <>
            {restParts.pre}
            <span className="text-accent">{restParts.mid}</span>
            {restParts.post}
          </>
        ) : (
          rest
        )}
      </span>
    </span>
  );
});

/* Quick "add to hotlist" popover */
const HotlistPicker = memo(function HotlistPicker({ read, hotlists, onDone }: { read: PlateRead; hotlists: Hotlist[]; onDone: () => void }) {
  return (
    <div
      className="absolute right-0 top-full z-30 mt-1 w-56 rounded-sm border border-line-strong bg-surface-solid shadow-drawer"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="border-b border-line px-2.5 py-1.5 font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">
        Add {read.plate} to hotlist
      </div>
      <div className="max-h-44 overflow-y-auto py-0.5">
        {hotlists.map((h) => (
          <button
            key={h.id}
            className="flex w-full items-center justify-between gap-2 px-2.5 py-1.5 text-left font-sans text-[11px] text-secondary transition-colors hover:bg-raised hover:text-primary"
            onClick={(e) => {
              e.stopPropagation();
              addHotlistEntry(h.id, { plate: read.plate, reason: 'Flagged from live feed', priority: 'high' });
              showToast({ severity: 'high', title: `${read.plate} added to ${h.name}`, body: 'Next sighting fires a critical alert within 30s' });
              onDone();
            }}
          >
            <span className="truncate">{h.name}</span>
            <span className={cn('shrink-0 font-mono text-[9px]', h.enabled ? 'text-accent' : 'text-muted')}>
              {h.enabled ? 'ACTIVE' : 'OFF'}
            </span>
          </button>
        ))}
        {hotlists.length === 0 && <div className="px-2.5 py-2 font-mono text-[10px] text-muted">No hotlists in this tenant</div>}
      </div>
    </div>
  );
});

export interface FeedRowProps {
  read: PlateRead;
  cameraLabel: string;
  query: string;
  canOperate: boolean;
  hotlists: Hotlist[];
  onView: (read: PlateRead) => void;
  style?: CSSProperties;
  fresh?: boolean;
}

export const FeedRow = memo(function FeedRow({ read, cameraLabel, query, canOperate, hotlists, onView, style, fresh = false }: FeedRowProps) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const lowConf = read.confidence < 0.9;
  return (
    <motion.div
      initial={fresh ? { backgroundColor: read.hotlist_hit ? 'rgba(231,29,54,0.14)' : 'rgba(0,212,170,0.12)' } : false}
      animate={{ backgroundColor: 'rgba(0,0,0,0)' }}
      transition={{ duration: 1 }}
      style={style}
      className={cn('group absolute left-0 right-0', read.hotlist_hit && 'bg-danger-dim/60')}
    >
      <button
        onClick={() => onView(read)}
        className={cn(FEED_GRID, 'relative h-11 w-full border-b border-line px-3 text-left transition-colors hover:bg-raised/60', read.hotlist_hit && 'pl-3.5')}
      >
        {read.hotlist_hit && <span className="absolute left-0 top-0 bottom-0 w-0.5 bg-danger" />}
        <span className="min-w-0">
          <FeedPlateChip plate={read.plate} hot={read.hotlist_hit} query={query} />
        </span>
        <span className="flex min-w-0 items-center gap-1.5">
          <VehicleColorDot color={read.vehicle_color} />
          <span className="truncate font-sans text-[12px] text-secondary">
            {read.vehicle_color} {read.vehicle_make}
          </span>
          <span className="shrink-0 rounded-sm bg-raised px-1 font-mono text-[9px] uppercase text-muted">{read.vehicle_type}</span>
        </span>
        <span className="min-w-0 font-mono text-[11px] text-muted">
          {cameraLabel}
        </span>
        <span className="flex items-center justify-center">
          {read.direction === 'inbound' ? (
            <ArrowDownLeft size={14} className="text-accent" aria-label="inbound" />
          ) : (
            <ArrowUpRight size={14} className="text-muted" aria-label="outbound" />
          )}
        </span>
        <span className={cn('text-right font-mono text-[11px]', lowConf ? 'text-warning' : 'text-secondary')}>
          {(read.confidence * 100).toFixed(1)}%
        </span>
        <span className="flex justify-center">
          {read.hotlist_hit && (
            <span className="flex items-center gap-0.5 rounded-sm bg-danger px-1 py-px font-mono text-[9px] font-semibold text-primary">
              <Flame size={9} /> HOT
            </span>
          )}
        </span>
        <span className="text-right font-mono text-[11px] text-muted" title={fmtDateTime(read.captured_at)}>
          {relTime(read.captured_at)}
        </span>
      </button>
      {/* hover quick actions */}
      <span className="absolute right-24 top-1/2 z-20 flex -translate-y-1/2 items-center gap-1 rounded-sm border border-line-strong bg-surface-solid/95 px-1 py-0.5 opacity-0 shadow-drawer transition-opacity duration-100 group-hover:opacity-100">
        <IconButton tooltip="View vehicle" onClick={(e) => { e.stopPropagation(); onView(read); }}>
          <CarFront size={13} />
        </IconButton>
        <span className="relative">
          <IconButton
            tooltip={canOperate ? 'Add to hotlist' : 'Requires OPERATOR role'}
            disabled={!canOperate}
            onClick={(e) => {
              e.stopPropagation();
              setPickerOpen((o) => !o);
            }}
          >
            <ListPlus size={13} />
          </IconButton>
          {pickerOpen && canOperate && <HotlistPicker read={read} hotlists={hotlists} onDone={() => setPickerOpen(false)} />}
        </span>
      </span>
    </motion.div>
  );
});

/* Local color dot (soc VehicleDot not exported with sizing control) */
const VEHICLE_COLOR_HEX: Record<string, string> = {
  White: '#E6F1FF', Silver: '#A8B2D1', Grey: '#5C6B8A', Black: '#1A2333',
  Blue: '#4CC9F0', Red: '#E71D36', Beige: '#C8BFA4', Green: '#00D4AA',
};

export const VehicleColorDot = memo(function VehicleColorDot({ color, size = 8 }: { color: string; size?: number }) {
  return (
    <span
      className="inline-block shrink-0 rounded-full border border-line-strong"
      style={{ background: VEHICLE_COLOR_HEX[color] ?? '#5C6B8A', width: size, height: size }}
      title={color}
    />
  );
});

export { VEHICLE_COLOR_HEX };
