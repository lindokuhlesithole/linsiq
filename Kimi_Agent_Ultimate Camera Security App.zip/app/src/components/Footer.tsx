/**
 * Footer.tsx — the SIDEBAR component (design.md §5.1).
 * Named Footer for contract compatibility with the swarm scaffold.
 */
import { memo, useEffect, useMemo, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  BarChart3, Cctv, ChevronsLeft, ChevronsRight, Crosshair, FolderOpen, Map as MapIcon,
  Radar, ScanLine, Settings, Siren,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { deriveThreat, getSidebarCollapsed, OPEN_STATUSES, setSidebarCollapsed, useStoreSelector } from '@/lib/store';
import { useClock, useOrg, useRole, useRealtimeStatus } from '@/hooks/useData';
import { ApertureMark } from '@/lib/procedural';
import { ThreatLevelGauge } from './soc/StatusPill';
import { cn } from '@/lib/utils';

interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  badge?: number;
  badgeTone?: 'danger' | 'warning';
}
interface NavSection {
  label: string;
  items: NavItem[];
}

const LiveTick = memo(function LiveTick() {
  useClock(1000);
  const { lastTickAt, running } = useRealtimeStatus();
  const age = Math.max(0, Math.floor((Date.now() - lastTickAt) / 1000));
  return (
    <span className="flex items-center gap-1.5 font-mono text-[9px] text-muted">
      <span className={cn('h-1.5 w-1.5 rounded-full', running ? 'bg-accent animate-live-pulse' : 'bg-warning')} />
      {running ? 'LIVE FEED' : 'PAUSED'} · tick {age}s
    </span>
  );
});

export const Sidebar = memo(function Sidebar() {
  const [collapsed, setCollapsed] = useState(getSidebarCollapsed);
  useEffect(() => {
    const onToggle = () => setCollapsed(getSidebarCollapsed());
    window.addEventListener('swealth:sidebar', onToggle);
    // auto-collapse below 1280px (design.md §5.3)
    const mq = window.matchMedia('(max-width: 1279px)');
    const onMq = (e: MediaQueryListEvent) => {
      if (e.matches) {
        setSidebarCollapsed(true);
        setCollapsed(true);
      }
    };
    mq.addEventListener('change', onMq);
    return () => {
      window.removeEventListener('swealth:sidebar', onToggle);
      mq.removeEventListener('change', onMq);
    };
  }, []);

  const org = useOrg();
  const role = useRole();
  const location = useLocation();
  const alerts = useStoreSelector((s) => s.byOrg[s.activeOrgId]?.alerts ?? []);
  const openAlerts = useMemo(() => alerts.filter((a) => OPEN_STATUSES.has(a.status)), [alerts]);
  const criticals = openAlerts.filter((a) => a.severity === 'critical').length;
  const threat = useMemo(() => deriveThreat(alerts), [alerts]);

  const sections: NavSection[] = [
    {
      label: 'Command',
      items: [
        { to: '/', label: 'Fleet Command', icon: Radar },
        { to: '/map', label: 'Tactical Map', icon: MapIcon },
        { to: '/operations', label: 'Live Operations', icon: Crosshair },
      ],
    },
    {
      label: 'Intelligence',
      items: [
        { to: '/cameras', label: 'Camera Network', icon: Cctv },
        { to: '/alpr', label: 'Plate Intelligence', icon: ScanLine },
        { to: '/alerts', label: 'AI Alert Center', icon: Siren, badge: openAlerts.length, badgeTone: criticals > 0 ? 'danger' : 'warning' },
        { to: '/incidents', label: 'Case Management', icon: FolderOpen },
        { to: '/analytics', label: 'Analytics', icon: BarChart3 },
      ],
    },
    {
      label: 'System',
      items: [{ to: '/settings', label: 'Settings', icon: Settings }],
    },
  ];

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 bottom-0 z-40 flex flex-col border-r border-line bg-base transition-[width] duration-200 ease-in-out',
        collapsed ? 'w-14' : 'w-[232px]',
      )}
    >
      {/* brand block */}
      <div className={cn('flex h-14 shrink-0 items-center gap-2 border-b border-line', collapsed ? 'justify-center px-0' : 'px-3')}>
        <ApertureMark size={collapsed ? 24 : 26} />
        {!collapsed && (
          <div className="min-w-0 leading-none">
            <div className="font-sans text-[14px] font-semibold tracking-[0.08em] text-primary">
              SWEALTH <span className="font-mono text-accent">OS</span>
            </div>
            <div className="mt-1 font-mono text-[9px] tracking-[0.14em] text-muted">COMMUNITY SAFETY PLATFORM</div>
          </div>
        )}
      </div>

      {/* tenant card */}
      {!collapsed && (
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('swealth:org-switcher'))}
          className="mx-2 mt-2 flex shrink-0 items-center justify-between gap-2 rounded-sm border border-line bg-inset px-2.5 py-2 text-left transition-colors hover:border-line-strong"
        >
          <div className="min-w-0">
            <div className="truncate font-sans text-[12px] font-semibold text-primary">{org.name}</div>
            <div className="truncate font-mono text-[10px] text-muted">{org.location}</div>
          </div>
          <ThreatLevelGauge level={threat} compact />
        </button>
      )}

      {/* nav sections */}
      <nav className="mt-3 min-h-0 flex-1 overflow-y-auto px-2">
        {sections.map((sec) => (
          <div key={sec.label} className="mb-3">
            {!collapsed && (
              <div className="px-2 pb-1 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                {sec.label}
              </div>
            )}
            {sec.items.map((item) => {
              const active = item.to === '/' ? location.pathname === '/' : location.pathname.startsWith(item.to);
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  title={collapsed ? item.label : undefined}
                  className={cn(
                    'relative mb-0.5 flex h-9 items-center gap-2.5 rounded-sm px-2.5 transition-colors duration-150',
                    active ? 'bg-raised' : 'hover:bg-raised/60',
                    collapsed && 'justify-center px-0',
                  )}
                >
                  {active && (
                    <motion.span
                      layoutId="nav-active"
                      className="absolute left-0 top-1 bottom-1 w-0.5 rounded-full bg-accent"
                      transition={{ type: 'spring', stiffness: 500, damping: 35, duration: 0.18 }}
                    />
                  )}
                  <item.icon size={16} className={cn('shrink-0', active ? 'text-accent' : 'text-secondary')} />
                  {!collapsed && (
                    <>
                      <span className={cn('flex-1 truncate font-sans text-[12px] font-medium', active ? 'text-accent' : 'text-secondary')}>
                        {item.label}
                      </span>
                      {typeof item.badge === 'number' && item.badge > 0 && (
                        <span
                          className={cn(
                            'rounded-full px-1.5 py-px font-mono text-[10px] font-semibold',
                            item.badgeTone === 'danger' ? 'bg-danger-dim text-danger' : 'bg-warning-dim text-warning',
                          )}
                        >
                          {item.badge}
                        </span>
                      )}
                    </>
                  )}
                </NavLink>
              );
            })}
          </div>
        ))}
      </nav>

      {/* footer */}
      <div className={cn('shrink-0 border-t border-line p-2', collapsed && 'flex flex-col items-center')}>
        <button
          onClick={() => {
            setSidebarCollapsed(!collapsed);
            setCollapsed(!collapsed);
          }}
          className="flex h-7 w-full items-center gap-2 rounded-sm px-2 text-secondary transition-colors hover:bg-raised hover:text-accent"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronsRight size={15} /> : <ChevronsLeft size={15} />}
          {!collapsed && <span className="font-sans text-[11px]">Collapse</span>}
        </button>
        {!collapsed && (
          <>
            <div className="mt-1 px-2">
              <LiveTick />
            </div>
            <div className="mt-2 flex items-center gap-2 rounded-sm bg-raised px-2 py-1.5">
              <span className="flex h-6 w-6 items-center justify-center rounded-sm bg-inset font-mono text-[10px] font-semibold text-accent">
                EM
              </span>
              <div className="min-w-0 leading-tight">
                <div className="truncate font-sans text-[11px] font-medium text-primary">Estate Manager</div>
                <div className="font-mono text-[9px] uppercase text-muted">{role} preview</div>
              </div>
            </div>
          </>
        )}
      </div>
    </aside>
  );
});

export default Sidebar;
