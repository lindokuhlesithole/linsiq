/**
 * Settings §1 — Organization / Tenant.
 * Current org card, radio-style tenant switcher (data-isolation demo),
 * RLS isolation indicator with PROVE ISOLATION live switch.
 */
import { memo, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, Loader2, Lock, ShieldCheck } from 'lucide-react';
import {
  useActiveOrgId, useAlerts, useCameras, useCanOperate, useOrg, useOrgs, useOrgSwitch, useThreatLevel,
} from '@/hooks/useData';
import { OPEN_STATUSES } from '@/lib/store';
import { GhostButton, ThreatLevelGauge, showToast } from '@/components/soc';
import { fmtCoord, fmtNum } from '@/lib/format';
import { SectionCard } from './shared';
import { cn } from '@/lib/utils';

export const TenantSection = memo(function TenantSection() {
  const org = useOrg();
  const orgs = useOrgs();
  const activeOrgId = useActiveOrgId();
  const switchOrg = useOrgSwitch();
  const cameras = useCameras();
  const alerts = useAlerts();
  const threat = useThreatLevel();
  const canOperate = useCanOperate();
  const [proving, setProving] = useState(false);

  const openAlerts = useMemo(() => alerts.filter((a) => OPEN_STATUSES.has(a.status)).length, [alerts]);

  const proveIsolation = () => {
    if (proving || !canOperate) return;
    const next = orgs.find((o) => o.id !== activeOrgId) ?? orgs[0];
    setProving(true);
    // 400ms spinner → crossfade (handled app-wide) → success
    setTimeout(() => {
      switchOrg(next.id);
      setProving(false);
      showToast({
        severity: 'medium',
        title: `Now viewing ${next.name}`,
        body: 'All metrics re-scoped — every query filtered by org_id (row-level isolation).',
      });
    }, 400);
  };

  return (
    <SectionCard
      title="Organization / Tenant"
      right={<span className="font-mono text-[9px] uppercase tracking-[0.08em] text-muted">{org.slug}</span>}
    >
      {/* current org card */}
      <div className="mb-3 flex items-start justify-between gap-3 rounded-sm border border-line-strong bg-raised/50 p-3">
        <div className="min-w-0">
          <div className="font-sans text-[14px] font-semibold text-primary">{org.name}</div>
          <div className="mt-0.5 font-mono text-[10px] text-muted">
            {org.location} · {fmtCoord(org.center_lat, org.center_lng)}
          </div>
        </div>
        <ThreatLevelGauge level={threat} compact />
      </div>

      {/* tenant switcher */}
      <div className="space-y-1.5" role="radiogroup" aria-label="Active tenant">
        {orgs.map((o) => {
          const active = o.id === activeOrgId;
          return (
            <button
              key={o.id}
              role="radio"
              aria-checked={active}
              disabled={!canOperate && !active}
              title={!canOperate && !active ? 'Requires MANAGER role' : undefined}
              onClick={() => {
                if (active) return;
                switchOrg(o.id);
                showToast({ severity: 'low', title: `Tenant switched — ${o.name}`, body: 'Every KPI and list re-scoped to this org.' });
              }}
              className={cn(
                'flex w-full items-center gap-3 rounded-sm border px-3 py-2 text-left transition-all duration-200',
                active
                  ? 'border-accent/50 bg-accent-dim/40 ring-1 ring-accent/40'
                  : 'border-line bg-inset hover:border-line-strong hover:bg-raised/50',
                !canOperate && !active && 'cursor-not-allowed opacity-40',
              )}
            >
              <span className={cn(
                'flex h-4 w-4 shrink-0 items-center justify-center rounded-full border',
                active ? 'border-accent bg-accent' : 'border-muted',
              )}>
                {active && <Check size={10} className="text-on-accent" strokeWidth={3} />}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate font-sans text-[12px] font-medium text-primary">
                  {o.name} — {o.location}
                </span>
                <AnimatePresence mode="wait">
                  <motion.span
                    key={active ? `live-${openAlerts}-${cameras.length}` : 'meta'}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="block font-mono text-[10px] text-muted"
                  >
                    {active
                      ? `${fmtNum(cameras.length)} CAMS · ${fmtNum(openAlerts)} ALERTS · THREAT: ${threat}`
                      : `${o.slug} · switch to view live stats`}
                  </motion.span>
                </AnimatePresence>
              </span>
              {active && (
                <span className="rounded-sm bg-accent-dim px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-[0.10em] text-accent">
                  Active
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* data isolation indicator */}
      <div className="mt-3 flex items-center gap-2.5 rounded-sm border border-line bg-inset px-3 py-2.5">
        <ShieldCheck size={16} className="shrink-0 text-accent" />
        <p className="min-w-0 flex-1 font-sans text-[11px] text-secondary">
          Row-level isolation active — all queries scoped to <span className="font-mono text-[10px] text-accent">org_id</span>
        </p>
        <GhostButton
          onClick={proveIsolation}
          disabled={proving || !canOperate}
          tooltip={canOperate ? 'Switch tenant and watch every number change' : 'Requires MANAGER role'}
          className="h-7 shrink-0 px-2 text-[10px]"
        >
          {proving ? <Loader2 size={12} className="animate-spin" /> : <Lock size={11} />}
          <span className="ml-1">{proving ? 'Re-scoping…' : 'Prove isolation'}</span>
        </GhostButton>
      </div>
    </SectionCard>
  );
});
