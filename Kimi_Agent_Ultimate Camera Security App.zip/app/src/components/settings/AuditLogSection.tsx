/**
 * Settings §5 — Audit Log Viewer (full width).
 * Virtualized dense table, filterable by query / entity-kind / time range,
 * LIVE pause toggle, client-generated CSV export. New entries insert at top.
 */
import { memo, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Download, FileSearch, Pause, Play } from 'lucide-react';
import type { AuditEntry } from '@/lib/types';
import { useActiveOrgId, useAuditLog } from '@/hooks/useData';
import { EmptyState, FilterChip, GhostButton, IconButton, SocInput, showToast } from '@/components/soc';
import { fmtDateTime, fmtTime } from '@/lib/format';
import { SectionCard } from './shared';
import { cn } from '@/lib/utils';

const ROW_H = 32;
const VIEW_H = 384;
const OVERSCAN = 6;

const KINDS = ['alert', 'camera', 'hotlist', 'incident', 'guard', 'drone', 'auth', 'system', 'organization'] as const;

const RANGES = [
  { id: '1H', ms: 3600_000 },
  { id: '24H', ms: 24 * 3600_000 },
  { id: 'ALL', ms: Infinity },
] as const;

/** action → semantic tag color (ACK/RESOLVE accent, EXPORT info, EDIT warning, AUTH muted) */
function actionClass(action: string): string {
  if (/acknowledge|resolve|dispatch|create/.test(action)) return 'bg-accent-dim text-accent';
  if (/export/.test(action)) return 'bg-info-dim text-info';
  if (/update|edit|toggle|add|remove|preview|switch/.test(action)) return 'bg-warning-dim text-warning';
  if (/auth|role|org/.test(action)) return 'bg-raised text-muted';
  return 'bg-raised text-secondary';
}

function initials(name: string): string {
  return name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
}

const AuditRow = memo(function AuditRow({ e, fresh }: { e: AuditEntry; fresh: boolean }) {
  return (
    <motion.div
      layout={false}
      initial={fresh ? { opacity: 0, y: -12, backgroundColor: 'rgba(0,212,170,0.10)' } : false}
      animate={{ opacity: 1, y: 0, backgroundColor: 'rgba(0,212,170,0)' }}
      transition={{ duration: 0.3 }}
      style={{ height: ROW_H }}
      className="flex items-center gap-3 border-b border-line/50 px-3 hover:bg-raised/50"
    >
      <span className="w-[120px] shrink-0 font-mono text-[10px] text-muted" title={fmtDateTime(e.created_at)}>
        {fmtTime(e.created_at)}
      </span>
      <span className="flex w-[150px] shrink-0 items-center gap-1.5">
        <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-sm bg-raised font-mono text-[8px] font-semibold text-secondary">
          {initials(e.actor)}
        </span>
        <span className="truncate font-sans text-[11px] text-secondary">{e.actor}</span>
      </span>
      <span className="w-[170px] shrink-0">
        <span className={cn('rounded-sm px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-[0.06em]', actionClass(e.action))}>
          {e.action}
        </span>
      </span>
      <span className="w-[150px] shrink-0 truncate font-mono text-[10px] text-info">
        {e.entity_kind} · {e.entity_id.slice(0, 14)}
      </span>
      <span className="min-w-0 flex-1 truncate font-sans text-[11px] text-secondary" title={e.detail}>
        {e.detail}
      </span>
    </motion.div>
  );
});

export const AuditLogSection = memo(function AuditLogSection({ className }: { className?: string }) {
  const orgId = useActiveOrgId();
  const live = useAuditLog();
  const [query, setQuery] = useState('');
  const [kind, setKind] = useState<string>('all');
  const [rangeId, setRangeId] = useState<(typeof RANGES)[number]['id']>('ALL');
  const [paused, setPaused] = useState(false);
  const frozenRef = useRef<AuditEntry[] | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);

  const entries = paused ? (frozenRef.current ?? live) : live;

  const filtered = useMemo(() => {
    const cutoff = RANGES.find((r) => r.id === rangeId)?.ms ?? Infinity;
    const nowMs = Date.now();
    const q = query.trim().toLowerCase();
    return entries.filter((e) => {
      if (kind !== 'all' && e.entity_kind !== kind) return false;
      if (nowMs - new Date(e.created_at).getTime() > cutoff) return false;
      if (q && !`${e.actor} ${e.action} ${e.detail} ${e.entity_id}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [entries, query, kind, rangeId]);

  const startIdx = Math.max(0, Math.floor(scrollTop / ROW_H) - OVERSCAN);
  const endIdx = Math.min(filtered.length, Math.ceil((scrollTop + VIEW_H) / ROW_H) + OVERSCAN);
  const windowRows = filtered.slice(startIdx, endIdx);

  const togglePause = () => {
    if (!paused) frozenRef.current = live;
    else frozenRef.current = null;
    setPaused(!paused);
  };

  const exportCsv = () => {
    const header = 'timestamp,actor,action,entity_kind,entity_id,detail';
    const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
    const lines = filtered.map((e) =>
      [fmtDateTime(e.created_at), esc(e.actor), e.action, e.entity_kind, e.entity_id, esc(e.detail)].join(','),
    );
    const blob = new Blob([[header, ...lines].join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `swealth-audit-${orgId}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast({ severity: 'medium', title: 'Audit CSV exported', body: `${filtered.length} entries written to download.` });
  };

  const clearFilters = () => {
    setQuery('');
    setKind('all');
    setRangeId('ALL');
  };

  return (
    <SectionCard
      className={className}
      title="Audit Log Viewer"
      live={!paused}
      right={<span className="font-mono text-[9px] uppercase tracking-[0.08em] text-muted">{filtered.length} / {entries.length} entries</span>}
    >
      {/* filter bar */}
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <SocInput
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search actor / action / detail…"
          className="h-7 w-[220px] text-[11px]"
        />
        <select
          value={kind}
          onChange={(e) => setKind(e.target.value)}
          className="h-7 rounded-sm border border-line bg-inset px-1.5 font-mono text-[10px] uppercase text-secondary focus:border-accent focus:outline-none"
          title="Entity kind"
        >
          <option value="all">all kinds</option>
          {KINDS.map((k) => (
            <option key={k} value={k}>{k}</option>
          ))}
        </select>
        <div className="flex items-center gap-1">
          {RANGES.map((r) => (
            <FilterChip key={r.id} active={rangeId === r.id} onClick={() => setRangeId(r.id)}>
              {r.id}
            </FilterChip>
          ))}
        </div>
        <IconButton onClick={togglePause} tooltip={paused ? 'Resume live tail' : 'Pause live tail'}>
          {paused ? <Play size={13} className="text-accent" /> : <Pause size={13} />}
        </IconButton>
        <GhostButton className="ml-auto h-7 px-2 text-[10px]" onClick={exportCsv}>
          <Download size={11} className="mr-1" /> Export CSV
        </GhostButton>
      </div>

      {/* header row */}
      <div className="flex items-center gap-3 border-b border-line-strong bg-inset px-3" style={{ height: 28 }}>
        {[
          ['TIMESTAMP', 'w-[120px]'],
          ['ACTOR', 'w-[150px]'],
          ['ACTION', 'w-[170px]'],
          ['ENTITY', 'w-[150px]'],
          ['DETAIL', 'flex-1'],
        ].map(([h, w]) => (
          <span key={h} className={cn('shrink-0 font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted', w)}>
            {h}
          </span>
        ))}
      </div>

      {/* virtualized body */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={FileSearch}
          heading="No audit entries match"
          copy="Loosen the query or widen the time range to see operator activity."
          actionLabel="Clear filters"
          onAction={clearFilters}
          className="h-[200px]"
        />
      ) : (
        <div
          ref={scrollRef}
          onScroll={(e) => setScrollTop((e.target as HTMLDivElement).scrollTop)}
          className="overflow-y-auto"
          style={{ height: VIEW_H }}
        >
          <div style={{ height: filtered.length * ROW_H, position: 'relative' }}>
            <div style={{ transform: `translateY(${startIdx * ROW_H}px)` }}>
              <AnimatePresence initial={false}>
                {windowRows.map((e, i) => (
                  <AuditRow key={e.id} e={e} fresh={!paused && startIdx + i === 0 && scrollTop < ROW_H} />
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      )}
    </SectionCard>
  );
});
