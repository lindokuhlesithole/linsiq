/**
 * Settings §6 — Demo Data.
 * Simulator explainer, store stats + seed hash, pause/resume live feed,
 * RESET DEMO DATA with typed confirmation + boot overlay, JSON snapshot export.
 */
import { memo, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Database, Download, Lock, Pause, Play } from 'lucide-react';
import {
  resetDemoData, useActiveOrgId, useAlerts, useAuditLog, useCameras, useDrones,
  useGuards, useHotlists, useIncidents, usePlateReads, useRealtimeStatus, useRole,
} from '@/hooks/useData';
import { DangerButton, GhostButton, SocInput, SocModal, showToast } from '@/components/soc';
import { fmtNum } from '@/lib/format';
import { SectionCard, hashStr } from './shared';
import { cn } from '@/lib/utils';

const BOOT_LINES = ['RESEEDING TENANTS…', 'REBUILDING 48H EVENT WINDOW…', 'DONE'];

export const DemoDataSection = memo(function DemoDataSection() {
  const orgId = useActiveOrgId();
  const role = useRole();
  const readOnly = role !== 'manager';
  const cameras = useCameras();
  const alerts = useAlerts();
  const reads = usePlateReads();
  const audit = useAuditLog();
  const guards = useGuards();
  const drones = useDrones();
  const hotlists = useHotlists();
  const incidents = useIncidents();
  const { running, setRunning } = useRealtimeStatus();

  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [booting, setBooting] = useState(false);

  const seedHash = useMemo(() => hashStr(`swealth-seed:${orgId}`).toString(16).padStart(8, '0'), [orgId]);

  const stats: [string, number][] = [
    ['plate_reads', reads.length],
    ['alerts', alerts.length],
    ['audit_log', audit.length],
    ['cameras', cameras.length],
    ['guards', guards.length],
    ['drones', drones.length],
    ['hotlists', hotlists.length],
    ['incidents', incidents.length],
  ];

  const doReset = () => {
    if (confirmText !== 'RESET') return;
    setConfirmOpen(false);
    setConfirmText('');
    setBooting(true);
    setTimeout(() => resetDemoData(), 900);
    setTimeout(() => window.location.assign('/'), 1700);
  };

  const exportSnapshot = () => {
    const snapshot = {
      exported_at: new Date().toISOString(),
      org_id: orgId,
      cameras, alerts, plateReads: reads, guards, drones, hotlists, incidents, auditLog: audit,
    };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `swealth-demo-snapshot-${orgId}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast({ severity: 'medium', title: 'Demo snapshot exported', body: 'Active tenant store serialized to JSON.' });
  };

  return (
    <SectionCard
      title="Demo Data"
      right={<span className="font-mono text-[9px] uppercase tracking-[0.08em] text-muted">seed {seedHash}</span>}
    >
      <ul className="mb-3 list-none space-y-1">
        {['Seeded RNG per tenant — deterministic rebuilds', 'localStorage persistence under swealth.* keys', '48-hour rolling event window per organization'].map((t) => (
          <li key={t} className="flex items-start gap-1.5 font-sans text-[11px] text-muted">
            <Database size={10} className="mt-0.5 shrink-0 text-muted" />
            {t}
          </li>
        ))}
      </ul>

      {/* store stats */}
      <div className="mb-3 grid grid-cols-4 gap-1.5">
        {stats.map(([k, v]) => (
          <div key={k} className="rounded-sm border border-line bg-inset px-2 py-1.5">
            <div className="font-mono text-[12px] text-primary">{fmtNum(v)}</div>
            <div className="truncate font-mono text-[8px] uppercase tracking-[0.06em] text-muted">{k}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <GhostButton onClick={() => setRunning(!running)} className="h-8 text-[10px]">
          {running ? <Pause size={11} className="mr-1" /> : <Play size={11} className="mr-1 text-accent" />}
          {running ? 'Pause live feed' : 'Resume live feed'}
        </GhostButton>
        <GhostButton onClick={exportSnapshot} className="h-8 text-[10px]">
          <Download size={11} className="mr-1" /> Export demo snapshot
        </GhostButton>
        <DangerButton
          onClick={() => setConfirmOpen(true)}
          disabled={readOnly}
          tooltip={readOnly ? 'Requires MANAGER role' : 'Reseed all tenants'}
          className="h-8 text-[10px]"
        >
          {readOnly && <Lock size={10} className="mr-1" />}
          Reset demo data
        </DangerButton>
      </div>

      {/* confirm popover */}
      <SocModal open={confirmOpen} onClose={() => setConfirmOpen(false)} title="Reset demo data" maxWidth={420}>
        <div className="p-4">
          <p className="font-sans text-[12px] text-secondary">
            Reseeds all tenants to their initial state. Edits, resolved alerts and audit trails are discarded.
          </p>
          <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.08em] text-muted">
            Type <span className="text-danger">RESET</span> to confirm
          </p>
          <SocInput
            mono
            value={confirmText}
            onChange={(e) => setConfirmText(e.target.value.toUpperCase())}
            placeholder="RESET"
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && doReset()}
            className={cn('mt-2', confirmText && confirmText !== 'RESET' && 'border-danger animate-live-pulse')}
          />
          <div className="mt-3 flex justify-end gap-2">
            <GhostButton onClick={() => setConfirmOpen(false)}>Cancel</GhostButton>
            <DangerButton onClick={doReset} disabled={confirmText !== 'RESET'}>
              Reseed everything
            </DangerButton>
          </div>
        </div>
      </SocModal>

      {/* boot overlay */}
      <AnimatePresence>
        {booting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-canvas"
          >
            <div className="font-mono text-[12px]">
              {BOOT_LINES.map((l, i) => (
                <motion.div
                  key={l}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.25 + i * 0.45, duration: 0.2 }}
                  className={cn('py-0.5', i === BOOT_LINES.length - 1 ? 'text-accent' : 'text-secondary')}
                >
                  &gt; {l}
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </SectionCard>
  );
});
