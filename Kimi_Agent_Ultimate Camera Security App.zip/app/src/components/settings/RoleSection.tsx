/**
 * Settings §2 — Access & Role Preview.
 * Auth mode segmented toggle (guest ↔ production placeholder), current session,
 * RBAC role preview cards + permission matrix.
 */
import { memo, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, Info, LogIn, Minus, X } from 'lucide-react';
import type { RolePreview } from '@/lib/types';
import { setRolePreview, useClock, useRole } from '@/hooks/useData';
import { GhostButton, showToast } from '@/components/soc';
import { relTime } from '@/lib/format';
import { SectionCard, lsGet, lsSet } from './shared';
import { SESSION_KEY } from '@/components/login/session';
import { cn } from '@/lib/utils';

const AUTH_MODE_KEY = 'swealth.auth_mode';
type AuthMode = 'guest' | 'production';

const ROLE_CARDS: { id: RolePreview; tag: string; caps: { ok: boolean; text: string }[] }[] = [
  {
    id: 'manager',
    tag: 'Full access',
    caps: [
      { ok: true, text: 'PTZ control + presets' },
      { ok: true, text: 'Hotlist & routing rules edit' },
      { ok: true, text: 'Tenant switch + demo reset' },
    ],
  },
  {
    id: 'operator',
    tag: 'No hotlist edits / config',
    caps: [
      { ok: true, text: 'PTZ control + evidence export' },
      { ok: false, text: 'Routing rules & demo reset' },
      { ok: false, text: 'Tenant switching' },
    ],
  },
  {
    id: 'guard',
    tag: 'Field view',
    caps: [
      { ok: true, text: 'Operations + Fleet Command only' },
      { ok: false, text: 'Analytics / Settings hidden' },
      { ok: false, text: 'PTZ, hotlist, exports' },
    ],
  },
];

const MATRIX: { cap: string; manager: boolean; operator: boolean; guard: boolean }[] = [
  { cap: 'PTZ control', manager: true, operator: true, guard: false },
  { cap: 'Hotlist edit', manager: true, operator: false, guard: false },
  { cap: 'Evidence export', manager: true, operator: true, guard: false },
  { cap: 'Routing rules', manager: true, operator: false, guard: false },
  { cap: 'Role preview', manager: true, operator: true, guard: true },
];

export const RoleSection = memo(function RoleSection() {
  const role = useRole();
  const now = useClock(1000);
  const [authMode, setAuthMode] = useState<AuthMode>(() => lsGet<AuthMode>(AUTH_MODE_KEY, 'guest'));
  const [phase2Notice, setPhase2Notice] = useState(false);
  const session = useMemo(() => lsGet<{ mode: string; name: string; at: string } | null>(SESSION_KEY, null), []);

  /* production placeholder: notice + auto-revert after 2s (settings.md §2) */
  const pickAuthMode = (m: AuthMode) => {
    if (m === authMode) return;
    if (m === 'production') {
      setAuthMode('production');
      lsSet(AUTH_MODE_KEY, 'production');
      setPhase2Notice(true);
      setTimeout(() => {
        setAuthMode('guest');
        lsSet(AUTH_MODE_KEY, 'guest');
        setPhase2Notice(false);
      }, 2000);
      return;
    }
    setAuthMode('guest');
    lsSet(AUTH_MODE_KEY, 'guest');
    setPhase2Notice(false);
  };

  useEffect(() => {
    if (authMode === 'production' && !phase2Notice) {
      // loaded a persisted production selection — treat as placeholder, revert
      const t = setTimeout(() => { setAuthMode('guest'); lsSet(AUTH_MODE_KEY, 'guest'); }, 2000);
      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const applyRole = (r: RolePreview) => {
    if (r === role) return;
    setRolePreview(r);
    showToast({
      severity: 'medium',
      title: `Previewing as ${r.toUpperCase()}`,
      body: r === 'manager' ? 'Full access restored.' : 'The whole console is now gated to this role — disabled controls show tooltips.',
    });
  };

  const initials = (session?.name ?? 'Estate Manager').split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();

  return (
    <SectionCard
      title="Access & Role Preview"
      right={
        role !== 'manager' ? (
          <span className="rounded-sm bg-warning-dim px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-[0.10em] text-warning">
            Previewing as {role}
          </span>
        ) : (
          <span className="rounded-sm bg-accent-dim px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-[0.10em] text-accent">
            Full access
          </span>
        )
      }
    >
      {/* auth mode segmented toggle */}
      <div className="mb-3">
        <div className="flex overflow-hidden rounded-sm border border-line">
          {(['guest', 'production'] as AuthMode[]).map((m) => (
            <button
              key={m}
              onClick={() => pickAuthMode(m)}
              className={cn(
                'flex h-8 flex-1 items-center justify-center gap-1.5 font-sans text-[10px] font-semibold uppercase tracking-[0.08em] transition-colors duration-150',
                authMode === m ? 'bg-accent-dim text-accent' : 'bg-inset text-muted hover:text-secondary',
              )}
            >
              {m === 'guest' ? 'Guest demo' : 'Production (Supabase)'}
              {m === 'production' && (
                <span className="rounded-sm bg-raised px-1 py-px font-mono text-[8px] text-muted">PHASE 2</span>
              )}
            </button>
          ))}
        </div>
        <AnimatePresence>
          {phase2Notice && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="mt-2 flex items-center gap-2 rounded-sm border border-info/30 bg-info-dim px-2.5 py-2 animate-shake"
            >
              <Info size={13} className="shrink-0 text-info" />
              <span className="font-sans text-[11px] text-info">
                Production auth lands in Phase 2 — guest session continues
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* current session */}
      <div className="mb-3 flex items-center gap-2.5 rounded-sm border border-line bg-inset px-3 py-2">
        <span className="flex h-7 w-7 items-center justify-center rounded-sm bg-raised font-mono text-[10px] font-semibold text-accent">
          {initials}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="truncate font-sans text-[12px] font-medium text-primary">{session?.name ?? 'Estate Manager'}</span>
            <span className="rounded-sm bg-accent-dim px-1 py-px font-mono text-[8px] font-semibold uppercase tracking-[0.08em] text-accent">
              admin
            </span>
          </div>
          <div className="font-mono text-[9px] text-muted">
            {session ? `${session.mode} session · opened ${relTime(session.at, now.getTime())}` : 'implicit demo session'}
          </div>
        </div>
        <LogIn size={13} className="text-muted" />
      </div>

      {/* role preview cards */}
      <div className="grid grid-cols-3 gap-2">
        {ROLE_CARDS.map((c) => {
          const active = role === c.id;
          return (
            <button
              key={c.id}
              onClick={() => applyRole(c.id)}
              className={cn(
                'rounded-sm border p-2.5 text-left transition-all duration-200',
                active ? 'border-accent/50 bg-accent-dim/30 ring-1 ring-accent/40' : 'border-line bg-inset hover:border-line-strong hover:bg-raised/40',
              )}
            >
              <div className="flex items-center justify-between">
                <span className={cn('font-mono text-[10px] font-semibold uppercase tracking-[0.10em]', active ? 'text-accent' : 'text-primary')}>
                  {c.id}
                </span>
                {active && <Check size={12} className="text-accent" />}
              </div>
              <div className="mt-0.5 font-sans text-[10px] text-muted">{c.tag}</div>
              <ul className="mt-1.5 space-y-1">
                {c.caps.map((cap) => (
                  <li key={cap.text} className="flex items-start gap-1 font-sans text-[10px] leading-3.5 text-muted">
                    {cap.ok ? <Check size={10} className="mt-px shrink-0 text-accent" /> : <X size={10} className="mt-px shrink-0 text-danger" />}
                    {cap.text}
                  </li>
                ))}
              </ul>
            </button>
          );
        })}
      </div>

      {role !== 'manager' && (
        <GhostButton className="mt-2.5 w-full" onClick={() => applyRole('manager')}>
          Exit preview — restore manager
        </GhostButton>
      )}

      {/* permission matrix */}
      <table className="mt-3 w-full border-collapse">
        <thead>
          <tr className="border-b border-line">
            <th className="pb-1.5 text-left font-sans text-[9px] font-semibold uppercase tracking-[0.10em] text-muted">Capability</th>
            {(['manager', 'operator', 'guard'] as const).map((r) => (
              <th key={r} className={cn('pb-1.5 text-center font-mono text-[9px] uppercase tracking-[0.08em]', role === r ? 'text-accent' : 'text-muted')}>
                {r.slice(0, 3).toUpperCase()}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {MATRIX.map((row, ri) => (
            <motion.tr
              key={row.cap}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: Math.min(ri * 0.01, 0.15) }}
              className="border-b border-line/50"
            >
              <td className="py-1.5 font-sans text-[11px] text-secondary">{row.cap}</td>
              {(['manager', 'operator', 'guard'] as const).map((r) => (
                <td key={r} className="py-1.5 text-center">
                  {row[r] ? (
                    <Check size={11} className="inline text-accent" />
                  ) : (
                    <Minus size={11} className="inline text-muted" />
                  )}
                </td>
              ))}
            </motion.tr>
          ))}
        </tbody>
      </table>
    </SectionCard>
  );
});
