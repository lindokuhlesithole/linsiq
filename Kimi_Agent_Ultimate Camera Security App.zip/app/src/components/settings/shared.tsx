/**
 * Settings shared pieces: section card shell, localStorage helpers,
 * deterministic hash, small atoms.
 */
import { memo } from 'react';
import type { ReactNode } from 'react';
import { LiveDot } from '@/components/analytics/theme';
import { cn } from '@/lib/utils';

export { LiveDot };

/* ── Section card: surface panel, micro-label header + status chip ───────── */

export const SectionCard = memo(function SectionCard({
  title,
  right,
  live,
  className,
  children,
}: {
  title: ReactNode;
  right?: ReactNode;
  live?: boolean;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section className={cn('rounded-sm border border-line bg-surface backdrop-blur-sm', className)}>
      <header className="flex h-9 items-center justify-between gap-2 border-b border-line px-3">
        <span className="flex items-center gap-2.5 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
          {title}
          {live && <LiveDot />}
        </span>
        <div className="flex items-center gap-2">{right}</div>
      </header>
      <div className="p-4">{children}</div>
    </section>
  );
});

/* ── localStorage helpers (all keys under the swealth. prefix) ───────────── */

export function lsGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : (JSON.parse(raw) as T);
  } catch {
    return fallback;
  }
}

export function lsSet(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota / privacy mode — non-fatal in demo */
  }
}

/* deterministic 32-bit hash (seed hash, pseudo stats) */
export function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/* ── Micro atoms ─────────────────────────────────────────────────────────── */

export const MicroLabel = memo(function MicroLabel({ children }: { children: ReactNode }) {
  return (
    <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">{children}</span>
  );
});
