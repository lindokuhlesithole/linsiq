/**
 * Settings §3 — Alert Routing Rules editor.
 * Per severity: role select, channel chips (multi), escalate-after input, enabled
 * toggle. Dirty rows get a warning rail; the footer bar saves/discards.
 * Rules persist per-tenant to localStorage (Phase 1 — the data layer exposes
 * read-only routing rules; overrides layer on top).
 */
import { memo, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Lock, Save, Undo2 } from 'lucide-react';
import type { RoutingChannel, RoutingRole, Severity } from '@/lib/types';
import { useActiveOrgId, useAlerts, useClock, useRole, useRoutingRules } from '@/hooks/useData';
import { FilterChip, GhostButton, SeverityBadge, SocButton, SocInput, ToggleSwitch, showToast } from '@/components/soc';
import { fmtCountdown } from '@/lib/format';
import { SectionCard, lsGet, lsSet } from './shared';
import { cn } from '@/lib/utils';

const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low'];
const ROLES: RoutingRole[] = ['supervisor', 'operator', 'manager', 'guard'];
const CHANNELS: RoutingChannel[] = ['push', 'sms', 'email', 'radio'];

interface RuleDraft {
  severity: Severity;
  role: RoutingRole;
  channels: RoutingChannel[];
  escalate_after_sec: number;
  enabled: boolean;
}

function rulesKey(orgId: string): string {
  return `swealth.routing_rules.${orgId}`;
}

export const RoutingRulesSection = memo(function RoutingRulesSection() {
  const orgId = useActiveOrgId();
  const baseRules = useRoutingRules();
  const openAlerts = useAlerts({ openOnly: true });
  const role = useRole();
  const now = useClock(1000);
  const readOnly = role !== 'manager';

  const saved = useMemo<RuleDraft[]>(() => {
    const overrides = lsGet<Partial<Record<Severity, RuleDraft>>>(rulesKey(orgId), {});
    return SEVERITIES.map((sev) => {
      const base = baseRules.find((r) => r.severity === sev);
      const o = overrides[sev];
      return {
        severity: sev,
        role: o?.role ?? base?.role ?? 'operator',
        channels: o?.channels ?? (base ? [base.channel] : ['push']),
        escalate_after_sec: o?.escalate_after_sec ?? base?.escalate_after_sec ?? 900,
        enabled: o?.enabled ?? base?.enabled ?? true,
      };
    });
  }, [baseRules, orgId]);

  const [draft, setDraft] = useState<RuleDraft[]>(saved);
  const [flash, setFlash] = useState(false);
  useEffect(() => setDraft(saved), [saved]);

  const dirty = useMemo(() => draft.filter((d, i) => JSON.stringify(d) !== JSON.stringify(saved[i])), [draft, saved]);

  const patch = (sev: Severity, p: Partial<RuleDraft>) =>
    setDraft((rows) => rows.map((r) => (r.severity === sev ? { ...r, ...p } : r)));

  const save = () => {
    const overrides: Partial<Record<Severity, RuleDraft>> = {};
    for (const d of draft) overrides[d.severity] = d;
    lsSet(rulesKey(orgId), overrides);
    setFlash(true);
    setTimeout(() => setFlash(false), 700);
    showToast({
      severity: 'low',
      title: 'Routing rules saved',
      body: `${dirty.length} severit${dirty.length === 1 ? 'y' : 'ies'} updated — escalation timers re-armed.`,
    });
  };

  /* live preview: open count + next escalation deadline per severity */
  const preview = useMemo(() => {
    const out = new Map<Severity, { open: number; nextEscSec: number | null }>();
    for (const sev of SEVERITIES) {
      const rows = openAlerts
        .filter((a) => a.severity === sev)
        .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
      const rule = draft.find((d) => d.severity === sev);
      let nextEscSec: number | null = null;
      if (rows.length && rule?.enabled) {
        const oldest = new Date(rows[0].created_at).getTime();
        nextEscSec = Math.max(0, Math.round(rule.escalate_after_sec - (now.getTime() - oldest) / 1000));
      }
      out.set(sev, { open: rows.length, nextEscSec });
    }
    return out;
  }, [openAlerts, draft, now]);

  return (
    <SectionCard
      title="Alert Routing Rules"
      right={
        readOnly ? (
          <span className="flex items-center gap-1 font-mono text-[9px] uppercase tracking-[0.08em] text-muted" title="Requires MANAGER role">
            <Lock size={10} /> Read-only
          </span>
        ) : (
          <span className="font-mono text-[9px] uppercase tracking-[0.08em] text-muted">Per-severity escalation</span>
        )
      }
    >
      <div className="space-y-1.5">
        {draft.map((d) => {
          const isDirty = dirty.some((x) => x.severity === d.severity);
          const pv = preview.get(d.severity);
          return (
            <div
              key={d.severity}
              className={cn(
                'relative rounded-sm border border-line bg-inset py-2 pl-3.5 pr-2 transition-colors duration-150',
                flash && 'bg-accent-dim/40',
              )}
            >
              {/* dirty rail */}
              <span className={cn(
                'absolute left-0 top-0 h-full w-0.5 rounded-l-sm transition-opacity duration-150',
                isDirty ? 'bg-warning opacity-100' : 'opacity-0',
              )} />
              <div className="flex flex-wrap items-center gap-2">
                <SeverityBadge severity={d.severity} className="w-[74px] justify-center" />
                {/* role select */}
                <select
                  value={d.role}
                  disabled={readOnly}
                  title={readOnly ? 'Requires MANAGER role' : 'Route to role'}
                  onChange={(e) => patch(d.severity, { role: e.target.value as RoutingRole })}
                  className="h-7 rounded-sm border border-line bg-inset px-1.5 font-mono text-[10px] uppercase text-secondary focus:border-accent focus:outline-none disabled:cursor-not-allowed disabled:opacity-40"
                >
                  {ROLES.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                {/* channel chips (multi) */}
                <div className="flex items-center gap-1">
                  {CHANNELS.map((ch) => {
                    const on = d.channels.includes(ch);
                    return (
                      <FilterChip
                        key={ch}
                        active={on}
                        className={cn(readOnly && 'pointer-events-none opacity-40')}
                        onClick={() => {
                          if (readOnly) return;
                          patch(d.severity, {
                            channels: on ? d.channels.filter((c) => c !== ch) : [...d.channels, ch],
                          });
                        }}
                      >
                        {ch}
                      </FilterChip>
                    );
                  })}
                </div>
                {/* escalate after */}
                <div className="flex items-center gap-1">
                  <SocInput
                    mono
                    type="number"
                    min={30}
                    step={30}
                    value={d.escalate_after_sec}
                    disabled={readOnly}
                    title={readOnly ? 'Requires MANAGER role' : 'Escalate after (seconds)'}
                    onChange={(e) => patch(d.severity, { escalate_after_sec: Math.max(30, Number(e.target.value) || 30) })}
                    className="h-7 w-[72px] px-1.5 text-[10px]"
                  />
                  <span className="font-mono text-[9px] uppercase text-muted">sec</span>
                </div>
                <ToggleSwitch
                  on={d.enabled}
                  disabled={readOnly}
                  tooltip={readOnly ? 'Requires MANAGER role' : d.enabled ? 'Disable routing' : 'Enable routing'}
                  onChange={(v) => patch(d.severity, { enabled: v })}
                />
                {/* live preview */}
                <span className={cn(
                  'ml-auto font-mono text-[9px] uppercase tracking-[0.06em]',
                  pv?.nextEscSec !== null && pv?.nextEscSec !== undefined && pv.nextEscSec < 60 ? 'text-warning' : 'text-muted',
                )}>
                  {pv?.open
                    ? `${pv.open} open${pv.nextEscSec !== null ? ` · next esc ${fmtCountdown(pv.nextEscSec)}` : ''}`
                    : '0 open'}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <p className="mt-2.5 font-sans text-[11px] text-muted">
        Escalation chains: unacked alerts bump severity and re-route after the timer.
      </p>

      {/* unsaved-changes footer bar */}
      <AnimatePresence>
        {dirty.length > 0 && !readOnly && (
          <motion.div
            initial={{ y: 24, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 24, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="mt-3 flex items-center gap-2 rounded-sm border border-warning/40 bg-warning-dim px-3 py-2"
          >
            <span className="flex-1 font-mono text-[10px] font-semibold uppercase tracking-[0.08em] text-warning">
              {dirty.length} unsaved change{dirty.length === 1 ? '' : 's'}
            </span>
            <GhostButton className="h-7 px-2 text-[10px]" onClick={() => setDraft(saved)}>
              <Undo2 size={11} className="mr-1" /> Discard
            </GhostButton>
            <SocButton className="h-7 px-2 text-[10px]" onClick={save}>
              <Save size={11} className="mr-1" /> Save
            </SocButton>
          </motion.div>
        )}
      </AnimatePresence>
    </SectionCard>
  );
});
