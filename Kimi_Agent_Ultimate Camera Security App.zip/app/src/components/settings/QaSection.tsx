/**
 * Settings §7 — Display & QA Diagnostics (collapsible, collapsed by default).
 * Contrast grid with computed WCAG ratios, live type-scale specimen,
 * keyboard shortcut reference, app-wide REDUCE MOTION override.
 */
import { memo, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { ToggleSwitch } from '@/components/soc';
import { SectionCard, lsGet, lsSet } from './shared';
import { cn } from '@/lib/utils';

const REDUCE_KEY = 'swealth.reduce_motion';
const STYLE_ID = 'swealth-reduce-motion-style';

function applyReduceMotion(on: boolean): void {
  lsSet(REDUCE_KEY, on);
  document.documentElement.classList.toggle('swealth-reduce-motion', on);
  let tag = document.getElementById(STYLE_ID);
  if (on && !tag) {
    tag = document.createElement('style');
    tag.id = STYLE_ID;
    tag.textContent =
      '.swealth-reduce-motion *,.swealth-reduce-motion *::before,.swealth-reduce-motion *::after' +
      '{animation-duration:0.01ms!important;animation-iteration-count:1!important;transition-duration:0.01ms!important}';
    document.head.appendChild(tag);
  }
}

/* ── WCAG contrast math on the design tokens ─────────────────────────────── */

function lum(hex: string): number {
  const c = hex.replace('#', '');
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(c.slice(i, i + 2), 16) / 255).map((v) =>
    v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4),
  );
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function ratio(fg: string, bg: string): number {
  const [l1, l2] = [lum(fg), lum(bg)].sort((a, b) => b - a);
  return (l1 + 0.05) / (l2 + 0.05);
}

const CONTRAST_PAIRS: { fg: string; fgHex: string; bg: string; bgHex: string }[] = [
  { fg: 'primary', fgHex: '#E6F1FF', bg: 'canvas', bgHex: '#060D1A' },
  { fg: 'primary', fgHex: '#E6F1FF', bg: 'base', bgHex: '#0A192F' },
  { fg: 'primary', fgHex: '#E6F1FF', bg: 'surface-solid', bgHex: '#112240' },
  { fg: 'secondary', fgHex: '#A8B2D1', bg: 'base', bgHex: '#0A192F' },
  { fg: 'secondary', fgHex: '#A8B2D1', bg: 'surface-solid', bgHex: '#112240' },
  { fg: 'muted', fgHex: '#5C6B8A', bg: 'base', bgHex: '#0A192F' },
  { fg: 'accent', fgHex: '#00D4AA', bg: 'canvas', bgHex: '#060D1A' },
  { fg: 'accent', fgHex: '#00D4AA', bg: 'base', bgHex: '#0A192F' },
  { fg: 'warning', fgHex: '#FF9F1C', bg: 'base', bgHex: '#0A192F' },
  { fg: 'danger', fgHex: '#E71D36', bg: 'base', bgHex: '#0A192F' },
  { fg: 'info', fgHex: '#4CC9F0', bg: 'base', bgHex: '#0A192F' },
  { fg: 'on-accent', fgHex: '#04101F', bg: 'accent', bgHex: '#00D4AA' },
];

const TYPE_SPECIMEN: { label: string; cls: string; note: string; sample: string }[] = [
  { label: 'Page title', cls: 'font-sans text-[18px] font-semibold tracking-[-0.01em] text-primary', note: '18/24 Inter 600', sample: 'Fleet Command' },
  { label: 'Section heading', cls: 'font-sans text-[13px] font-semibold uppercase tracking-[0.04em] text-primary', note: '13/18 Inter 600', sample: 'Camera network' },
  { label: 'Panel label', cls: 'font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted', note: '10/14 Inter 600', sample: 'Live plate feed' },
  { label: 'Body', cls: 'font-sans text-[13px] text-secondary', note: '13/20 Inter 400', sample: 'Perimeter sweep complete — all sectors nominal.' },
  { label: 'KPI value', cls: 'font-mono text-[26px] font-semibold leading-[30px] tracking-[-0.02em] text-primary', note: '26/30 Mono 600', sample: '2,847' },
  { label: 'Data mono', cls: 'font-mono text-[12px] text-primary', note: '12/16 Mono 400', sample: 'GP 482-913 · 98.2%' },
  { label: 'Timestamp', cls: 'font-mono text-[11px] text-muted', note: '11/14 Mono 400', sample: '2026-02-14 03:42:17' },
];

const SHORTCUTS: [string, string][] = [
  ['/', 'Focus global search'],
  ['g d', 'Fleet Command'],
  ['g c', 'Camera Network'],
  ['g a', 'AI Alert Center'],
  ['g m', 'Tactical Map'],
  ['?', 'Toggle this diagnostics panel'],
  ['Esc', 'Close drawer / modal'],
];

export const QaSection = memo(function QaSection() {
  const [open, setOpen] = useState(false);
  const [reduceMotion, setReduceMotion] = useState<boolean>(() => lsGet(REDUCE_KEY, false));

  useEffect(() => {
    if (lsGet(REDUCE_KEY, false)) applyReduceMotion(true);
  }, []);

  const toggleReduce = (v: boolean) => {
    setReduceMotion(v);
    applyReduceMotion(v);
  };

  return (
    <SectionCard
      title={
        <button className="flex items-center gap-2" onClick={() => setOpen(!open)} aria-expanded={open}>
          <motion.span animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
            <ChevronDown size={13} className="text-muted" />
          </motion.span>
          Display &amp; QA Diagnostics
        </button>
      }
      right={<span className="rounded-sm bg-raised px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.08em] text-muted">Diagnostics</span>}
    >
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.2, 0.8, 0.2, 1] }}
            className="-m-4 overflow-hidden"
          >
            <div className="space-y-4 p-4">
              {/* contrast grid */}
              <div>
                <div className="mb-2 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                  Contrast grid — WCAG AA
                </div>
                <div className="grid grid-cols-2 gap-1.5 md:grid-cols-3">
                  {CONTRAST_PAIRS.map((p) => {
                    const r = ratio(p.fgHex, p.bgHex);
                    const pass = r >= 4.5;
                    return (
                      <div key={`${p.fg}-${p.bg}`} className="flex items-center gap-2 rounded-sm border border-line bg-inset px-2 py-1.5">
                        <span
                          className="flex h-6 w-10 items-center justify-center rounded-sm font-mono text-[9px]"
                          style={{ color: p.fgHex, background: p.bgHex, border: '1px solid rgba(100,255,218,0.12)' }}
                        >
                          Aa
                        </span>
                        <span className="min-w-0 flex-1 truncate font-mono text-[9px] text-muted">
                          {p.fg}/{p.bg}
                        </span>
                        <span className="font-mono text-[9px] text-secondary">{r.toFixed(1)}</span>
                        <span className={cn(
                          'rounded-sm px-1 py-px font-mono text-[8px] font-semibold uppercase',
                          pass ? 'bg-accent-dim text-accent' : 'bg-raised text-muted',
                        )}>
                          {pass ? 'Pass' : 'Fail'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* type scale specimen */}
              <div>
                <div className="mb-2 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                  Type scale specimen
                </div>
                <div className="space-y-1.5">
                  {TYPE_SPECIMEN.map((t) => (
                    <div key={t.label} className="flex items-baseline gap-3 border-b border-line/50 pb-1.5">
                      <span className="w-[110px] shrink-0 font-mono text-[9px] uppercase tracking-[0.06em] text-muted">{t.note}</span>
                      <span className={cn('truncate', t.cls)}>{t.sample}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* keyboard shortcuts */}
              <div>
                <div className="mb-2 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                  Keyboard shortcuts
                </div>
                <div className="grid grid-cols-2 gap-1.5 md:grid-cols-3">
                  {SHORTCUTS.map(([keys, desc]) => (
                    <div key={keys} className="flex items-center gap-2 rounded-sm border border-line bg-inset px-2 py-1.5">
                      <span className="flex gap-1">
                        {keys.split(' ').map((k) => (
                          <kbd
                            key={k}
                            className="rounded-sm border border-line-strong bg-raised px-1.5 py-0.5 font-mono text-[10px] text-primary transition-transform duration-100 hover:translate-y-px"
                          >
                            {k}
                          </kbd>
                        ))}
                      </span>
                      <span className="truncate font-sans text-[11px] text-secondary">{desc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* motion toggle */}
              <div className="flex items-center gap-3 rounded-sm border border-line bg-inset px-3 py-2.5">
                <ToggleSwitch on={reduceMotion} onChange={toggleReduce} tooltip="Override to prefers-reduced-motion behavior app-wide" />
                <div>
                  <div className="font-sans text-[12px] font-medium text-primary">Reduce motion</div>
                  <div className="font-sans text-[10px] text-muted">
                    Kills ambient loops app-wide (LIVE pulses, scan bands, ticker motion) — instant state changes remain.
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {!open && (
        <button onClick={() => setOpen(true)} className="block w-full text-left font-sans text-[11px] text-muted hover:text-secondary">
          Collapsed — expand for contrast grid, type specimen, shortcuts and motion controls.
        </button>
      )}
    </SectionCard>
  );
});
