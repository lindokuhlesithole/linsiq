/**
 * Settings §4 — Hotlist Sync Status.
 * Rows per hotlist with sync StatusPill, last-sync relative time, entries,
 * source endpoint; SYNC NOW runs the simulated 800ms sync (4% error path).
 */
import { memo, useEffect, useState } from 'react';
import { Loader2, RefreshCw } from 'lucide-react';
import { useActiveOrgId, useClock, useHotlists } from '@/hooks/useData';
import { GhostButton, StatusPill, showToast } from '@/components/soc';
import { fmtNum, relTime } from '@/lib/format';
import { SectionCard, hashStr, lsGet, lsSet } from './shared';
import { cn } from '@/lib/utils';

type SyncState = 'synced' | 'pending' | 'error' | 'syncing';

interface SyncRec {
  state: SyncState;
  lastSync: string; // ISO
}

function syncKey(orgId: string): string {
  return `swealth.hotlist_sync.${orgId}`;
}

function seedSync(hotlistId: string): SyncRec {
  const h = hashStr(hotlistId);
  const mins = 4 + (h % 46);
  return {
    state: h % 5 === 0 ? 'pending' : 'synced',
    lastSync: new Date(Date.now() - mins * 60_000).toISOString(),
  };
}

const PILL: Record<SyncState, { status: string; label: string }> = {
  synced: { status: 'online', label: 'Synced' },
  pending: { status: 'degraded', label: 'Pending' },
  error: { status: 'offline', label: 'Error' },
  syncing: { status: 'motion', label: 'Syncing' },
};

const KIND_TAG: Record<string, string> = {
  stolen_vehicle: 'STOLEN',
  wanted_person_vehicle: 'WANTED',
  custom: 'CUSTOM',
  national_sync: 'NATIONAL',
};

export const HotlistSyncSection = memo(function HotlistSyncSection() {
  const orgId = useActiveOrgId();
  const hotlists = useHotlists();
  const now = useClock(1000);
  const [sync, setSync] = useState<Record<string, SyncRec>>(() => lsGet(syncKey(orgId), {}));
  const [flashId, setFlashId] = useState<string | null>(null);

  useEffect(() => setSync(lsGet(syncKey(orgId), {})), [orgId]);

  const recFor = (id: string): SyncRec => sync[id] ?? seedSync(id);

  const persist = (next: Record<string, SyncRec>) => {
    setSync(next);
    lsSet(syncKey(orgId), next);
  };

  const syncNow = (id: string, name: string) => {
    const cur = recFor(id);
    if (cur.state === 'syncing') return;
    persist({ ...sync, [id]: { ...cur, state: 'syncing' } });
    setTimeout(() => {
      const failed = Math.random() < 0.04;
      const latest = lsGet<Record<string, SyncRec>>(syncKey(orgId), {});
      const rec: SyncRec = failed
        ? { state: 'error', lastSync: recFor(id).lastSync }
        : { state: 'synced', lastSync: new Date().toISOString() };
      persist({ ...latest, [id]: rec });
      setFlashId(id);
      setTimeout(() => setFlashId(null), 500);
      showToast(
        failed
          ? { severity: 'critical', title: `${name} sync failed`, body: 'Upstream endpoint timeout — retry when the link recovers.' }
          : { severity: 'low', title: `${name} synced`, body: 'Entries reconciled against the national feed.' },
      );
    }, 800);
  };

  return (
    <SectionCard
      title="Hotlist Sync Status"
      right={<span className="font-mono text-[9px] uppercase tracking-[0.08em] text-muted">{hotlists.length} lists</span>}
    >
      <div className="space-y-1.5">
        {hotlists.map((h) => {
          const rec = recFor(h.id);
          const pill = PILL[rec.state];
          return (
            <div
              key={h.id}
              className={cn(
                'flex items-center gap-2.5 rounded-sm border border-line bg-inset px-2.5 py-2 transition-colors duration-500',
                flashId === h.id && (rec.state === 'error' ? 'bg-danger-dim/50' : 'bg-accent-dim/40'),
              )}
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="truncate font-sans text-[12px] font-medium text-primary">{h.name}</span>
                  <span className="rounded-sm bg-raised px-1 py-px font-mono text-[8px] uppercase tracking-[0.08em] text-secondary">
                    {KIND_TAG[h.kind] ?? h.kind}
                  </span>
                  {!h.enabled && (
                    <span className="rounded-sm bg-raised px-1 py-px font-mono text-[8px] uppercase text-muted">disabled</span>
                  )}
                </div>
                <div className="mt-0.5 truncate font-mono text-[9px] text-muted">
                  {h.source} · {fmtNum(h.entries.length)} entries
                </div>
              </div>
              <span className="hidden font-mono text-[9px] text-muted sm:block">
                {rec.state === 'syncing' ? 'reconciling…' : relTime(rec.lastSync, now.getTime())}
              </span>
              <StatusPill status={pill.status} label={pill.label} />
              <GhostButton
                className="h-7 shrink-0 px-2 text-[10px]"
                disabled={rec.state === 'syncing'}
                onClick={() => syncNow(h.id, h.name)}
                tooltip="Reconcile against upstream source"
              >
                {rec.state === 'syncing' ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />}
                <span className="ml-1">{rec.state === 'error' ? 'Retry' : 'Sync now'}</span>
              </GhostButton>
            </div>
          );
        })}
      </div>
      <p className="mt-2.5 font-sans text-[11px] text-muted">
        National sync mirrors SAPS &amp; RTMC stolen-vehicle feeds every 15 minutes; local edits propagate on the next cycle.
      </p>
    </SectionCard>
  );
});
