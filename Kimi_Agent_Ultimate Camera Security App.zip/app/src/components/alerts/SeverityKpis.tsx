/**
 * SeverityKpis — five compact tiles (alerts.md §1, h 72px).
 * CRITICAL / HIGH / MEDIUM / LOW / RESOLVED 24H with 24h sparklines.
 * Tiles act as severity filters; critical tile pulses while unacknowledged.
 */
import { memo, useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkline } from '@/components/soc/KpiTile';
import { cn } from '@/lib/utils';

export interface SeverityTileSpec {
  id: string;
  label: string;
  count: number;
  spark: number[];
  accent: string;
  active: boolean;
  pulse?: boolean;
  onToggle: () => void;
}

const SeverityKpiTile = memo(function SeverityKpiTile({ spec, index }: { spec: SeverityTileSpec; index: number }) {
  const [flash, setFlash] = useState(false);
  const prev = useRef(spec.count);
  useEffect(() => {
    if (prev.current !== spec.count) {
      prev.current = spec.count;
      setFlash(true);
      const t = setTimeout(() => setFlash(false), 400);
      return () => clearTimeout(t);
    }
  }, [spec.count]);
  return (
    <motion.button
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22, delay: index * 0.05, ease: 'easeOut' }}
      onClick={spec.onToggle}
      aria-pressed={spec.active}
      className={cn(
        'relative h-[72px] w-full overflow-hidden rounded-sm border bg-surface p-2.5 text-left backdrop-blur-sm transition-colors duration-150 hover:border-line-strong',
        spec.active ? 'border-line-strong' : 'border-line',
      )}
      style={spec.active ? { background: `${spec.accent}1F` } : undefined}
    >
      <span
        className={cn('absolute left-0 right-0 top-0 h-0.5', spec.pulse && 'animate-live-pulse')}
        style={{ background: spec.accent }}
      />
      <span className="flex h-full flex-col justify-between">
        <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">{spec.label}</span>
        <span className="flex items-end justify-between gap-2">
          <motion.span
            key={spec.count}
            initial={{ scale: 1.08 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.2 }}
            className={cn('rounded-sm px-1 -ml-1 font-mono text-[22px] font-semibold leading-[26px] text-primary', flash && 'bg-accent-dim')}
          >
            {spec.count}
          </motion.span>
          <Sparkline data={spec.spark} stroke={spec.accent} w={56} hgt={22} />
        </span>
      </span>
    </motion.button>
  );
});

export const SeverityKpis = memo(function SeverityKpis({ tiles }: { tiles: SeverityTileSpec[] }) {
  return (
    <div className="grid shrink-0 grid-cols-5 gap-3">
      {tiles.map((t, i) => (
        <SeverityKpiTile key={t.id} spec={t} index={i} />
      ))}
    </div>
  );
});
