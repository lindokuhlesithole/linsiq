/**
 * Alert feed rows for the Alert Center (alerts.md §3).
 * Composes shared soc primitives (SeverityBadge, StatusPill, alertTypeIcon,
 * groupAlerts) with page-specific needs the shared AlertRow doesn't expose:
 * search-term highlighting, hover quick actions (ACK / RESOLVE / DISPATCH),
 * keyboard triage (a / r), fresh-arrival flash, escalation countdown badge.
 */
import { memo, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCheck, ChevronDown, Siren, ShieldCheck } from 'lucide-react';
import type { Alert, AlertRoutingRule } from '@/lib/types';
import { useClock } from '@/hooks/useData';
import { fmtCountdown, relTime } from '@/lib/format';
import { alertTypeIcon } from '@/components/soc/AlertRow';
import { SeverityBadge, StatusPill } from '@/components/soc/StatusPill';
import { Highlight } from '@/components/alpr/pageUtils';
import { cn } from '@/lib/utils';

const RAIL: Record<string, string> = {
  critical: 'bg-danger',
  high: 'bg-warning',
  medium: 'bg-info',
  low: 'bg-severity-low',
};

const SEV_DIM: Record<string, string> = {
  critical: 'rgba(231,29,54,0.14)',
  high: 'rgba(255,159,28,0.12)',
  medium: 'rgba(76,201,240,0.12)',
  low: 'rgba(92,107,138,0.12)',
};

/* ── Routing badge with ticking escalation countdown (isolated 1s clock) ─── */

const RoutingBadge = memo(function RoutingBadge({ alert, rule }: { alert: Alert; rule?: AlertRoutingRule }) {
  const now = useClock(1000);
  if (!rule) return null;
  if (alert.status !== 'new') {
    return (
      <span className="rounded-sm bg-info-dim px-1 py-px font-mono text-[9px] text-info">
        → {rule.role.toUpperCase()} · {rule.channel.toUpperCase()}
      </span>
    );
  }
  if (alert.escalated) {
    const sinceSec = alert.escalated_at ? (now.getTime() - new Date(alert.escalated_at).getTime()) / 1000 : 0;
    return (
      <span className="rounded-sm bg-warning-dim px-1 py-px font-mono text-[9px] font-semibold text-warning">
        ESC → MANAGER · PUSH +{fmtCountdown(sinceSec)}
      </span>
    );
  }
  const ageSec = (now.getTime() - new Date(alert.created_at).getTime()) / 1000;
  const remain = rule.escalate_after_sec - ageSec;
  if (remain <= 0) {
    return <span className="rounded-sm bg-warning-dim px-1 py-px font-mono text-[9px] font-semibold text-warning">ESC 00:00</span>;
  }
  if (remain < rule.escalate_after_sec * 0.5) {
    return <span className="rounded-sm bg-warning-dim px-1 py-px font-mono text-[9px] text-warning">ESC {fmtCountdown(remain)}</span>;
  }
  return (
    <span className="rounded-sm bg-info-dim px-1 py-px font-mono text-[9px] text-info">
      → {rule.role.toUpperCase()} · {rule.channel.toUpperCase()}
  </span>
  );
});

/* ── Single alert row ────────────────────────────────────────────────────── */

export interface FeedRowActions {
  onOpen: (a: Alert) => void;
  onAck: (a: Alert) => void;
  onResolve: (a: Alert) => void;
  onDispatch: (a: Alert) => void;
}

export interface AlertFeedRowProps extends FeedRowActions {
  alert: Alert;
  rule?: AlertRoutingRule;
  query: string;
  canOperate: boolean;
  fresh?: boolean;
  dense?: boolean;
  stagger?: number;
}

export const AlertFeedRow = memo(function AlertFeedRow({
  alert,
  rule,
  query,
  canOperate,
  fresh = false,
  dense = false,
  stagger = 0,
  onOpen,
  onAck,
  onResolve,
  onDispatch,
}: AlertFeedRowProps) {
  const Icon = alertTypeIcon(alert.type);
  const isNew = alert.status === 'new';
  const isOpen = alert.status === 'new' || alert.status === 'acknowledged' || alert.status === 'responding';
  return (
    <motion.div
      initial={{ opacity: 0, y: fresh ? -24 : -8 }}
      animate={{
        opacity: 1,
        y: 0,
        backgroundColor: fresh
          ? [SEV_DIM[alert.severity] ?? SEV_DIM.low, 'rgba(0,0,0,0)']
          : 'rgba(0,0,0,0)',
      }}
      transition={{
        opacity: { duration: 0.22, delay: stagger },
        y: { duration: 0.25, delay: stagger },
        backgroundColor: { duration: 1.2, delay: stagger },
      }}
      className={cn('group relative', alert.escalated && isNew && 'bg-warning-dim/40')}
      onKeyDown={(e) => {
        if (e.key === 'a' && isNew) {
          e.preventDefault();
          onAck(alert);
        } else if (e.key === 'r' && isOpen && canOperate) {
          e.preventDefault();
          onResolve(alert);
        }
      }}
    >
      <button
        onClick={() => onOpen(alert)}
        title="Open triage drawer — [a] acknowledge · [r] resolve"
        className={cn(
          'relative flex w-full items-center gap-2.5 border-b border-line px-3 pl-3.5 text-left transition-colors hover:bg-raised/60',
          dense ? 'h-10' : 'h-12',
        )}
      >
        <span className={cn('absolute left-0 top-0 bottom-0 w-0.5', RAIL[alert.severity])} />
        <span className={cn('flex h-6 w-6 shrink-0 items-center justify-center rounded-sm', alert.severity === 'critical' ? 'bg-danger-dim' : alert.severity === 'high' ? 'bg-warning-dim' : 'bg-info-dim')}>
          <Icon size={14} className={alert.severity === 'critical' ? 'text-danger' : alert.severity === 'high' ? 'text-warning' : 'text-info'} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate font-sans text-[12px] font-medium text-primary">
            <Highlight text={alert.title} query={query} />
          </span>
          {!dense && (
            <span className="block truncate font-sans text-[11px] text-muted">
              <Highlight text={alert.ai_summary} query={query} />
            </span>
          )}
        </span>
        <span className="hidden w-28 shrink-0 truncate font-mono text-[10px] text-muted md:block">{alert.source_name}</span>
        <span className="hidden shrink-0 lg:block">
          <RoutingBadge alert={alert} rule={rule} />
        </span>
        <SeverityBadge severity={alert.severity} className="shrink-0" />
        <StatusPill status={alert.status} className="hidden shrink-0 sm:inline-flex" />
        <span className="w-14 shrink-0 text-right font-mono text-[10px] text-muted" title={alert.created_at}>
          {relTime(alert.created_at)}
        </span>
      </button>

      {/* hover quick actions — power triage without opening the drawer */}
      {isOpen && (
        <span className="absolute right-[136px] top-1/2 z-20 hidden -translate-y-1/2 items-center gap-1 rounded-sm border border-line-strong bg-surface-solid/95 px-1 py-0.5 opacity-0 shadow-drawer transition-opacity duration-100 group-hover:opacity-100 md:flex">
          <button
            disabled={!isNew}
            title={isNew ? 'Acknowledge [a]' : 'Already acknowledged'}
            onClick={(e) => { e.stopPropagation(); onAck(alert); }}
            className="flex h-6 items-center gap-1 rounded-sm px-1.5 font-sans text-[9px] font-semibold uppercase tracking-[0.08em] text-secondary transition-colors hover:bg-accent-dim hover:text-accent disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-secondary"
          >
            <CheckCheck size={11} /> Ack
          </button>
          <button
            disabled={!canOperate}
            title={canOperate ? 'Resolve [r]' : 'Requires OPERATOR role'}
            onClick={(e) => { e.stopPropagation(); onResolve(alert); }}
            className="flex h-6 items-center gap-1 rounded-sm px-1.5 font-sans text-[9px] font-semibold uppercase tracking-[0.08em] text-secondary transition-colors hover:bg-accent-dim hover:text-accent disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-secondary"
          >
            <ShieldCheck size={11} /> Resolve
          </button>
          <button
            disabled={!canOperate}
            title={canOperate ? 'Dispatch nearest on-duty guard' : 'Requires OPERATOR role'}
            onClick={(e) => { e.stopPropagation(); onDispatch(alert); }}
            className="flex h-6 items-center gap-1 rounded-sm px-1.5 font-sans text-[9px] font-semibold uppercase tracking-[0.08em] text-secondary transition-colors hover:bg-warning-dim hover:text-warning disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-secondary"
          >
            <Siren size={11} /> Dispatch
          </button>
        </span>
      )}
    </motion.div>
  );
});

/* ── Grouped feed row: collapses repeats from same source+type ───────────── */

export interface AlertGroup {
  key: string;
  head: Alert;
  children: Alert[];
}

export const AlertFeedGroup = memo(function AlertFeedGroup({
  group,
  rules,
  query,
  canOperate,
  freshIds,
  actions,
}: {
  group: AlertGroup;
  rules: AlertRoutingRule[];
  query: string;
  canOperate: boolean;
  freshIds: Set<string>;
  actions: FeedRowActions;
}) {
  const [open, setOpen] = useState(false);
  const rule = useMemo(
    () => rules.find((r) => r.enabled && r.severity === group.head.severity),
    [rules, group.head.severity],
  );
  const single = group.children.length <= 1;
  return (
    <div className="border-b border-line">
      <div className="relative">
        {!single && (
          <span className="absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-sm bg-accent-dim px-1 font-mono text-[9px] font-semibold text-accent">
            ×{group.children.length}
          </span>
        )}
        <div className={cn(!single && 'pl-8')}>
          <AlertFeedRow
            alert={group.head}
            rule={rule}
            query={query}
            canOperate={canOperate}
            fresh={freshIds.has(group.head.id)}
            onOpen={single ? actions.onOpen : () => setOpen((o) => !o)}
            onAck={actions.onAck}
            onResolve={actions.onResolve}
            onDispatch={actions.onDispatch}
          />
        </div>
        {!single && (
          <button
            onClick={() => setOpen((o) => !o)}
            className="absolute right-2 top-1/2 z-10 -translate-y-1/2 text-muted transition-colors hover:text-accent"
            aria-label={open ? 'Collapse group' : 'Expand group'}
          >
            <ChevronDown size={14} className={cn('transition-transform duration-200', open && 'rotate-180')} />
          </button>
        )}
      </div>
      <AnimatePresence initial={false}>
        {open && !single && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden bg-inset/60"
          >
            {group.children.map((c, i) => (
              <AlertFeedRow
                key={c.id}
                alert={c}
                rule={rule}
                query={query}
                canOperate={canOperate}
                fresh={freshIds.has(c.id)}
                dense
                stagger={i * 0.04}
                {...actions}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
});
