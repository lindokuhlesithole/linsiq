/**
 * CameraInventoryTable — dense device table (cameras.md §3).
 * Status / name / kind / zone / health / 24h uptime sparkline / last event / actions.
 * Windowed rendering when the inventory exceeds 100 rows.
 */
import { memo, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Cctv, MapPin, Maximize2, Move, ScanLine, Siren } from 'lucide-react';
import type { Camera, Organization } from '@/lib/types';
import { useClock } from '@/hooks/useData';
import { fmtHeartbeat, relTime } from '@/lib/format';
import { StatusPill } from '@/components/soc';
import { EmptyState, SkeletonRow } from '@/components/soc/feedback';
import { IconButton } from '@/components/soc/primitives';
import { KIND_META, camCode, uptimeProfile } from './utils';
import { cn } from '@/lib/utils';

export interface CamLastEvent {
  kind: 'plate' | 'alert';
  label: string;
  at: string;
}

export type Density = 'comfortable' | 'compact';

/* ── tiny cells ──────────────────────────────────────────────────────────── */

const HeartbeatCell = memo(function HeartbeatCell({ cam }: { cam: Camera }) {
  const now = useClock(1000);
  const age = (now.getTime() - new Date(cam.last_heartbeat).getTime()) / 1000;
  return (
    <span
      title={`Last heartbeat ${cam.last_heartbeat}`}
      className={cn('font-mono text-[10px]', age > 30 ? 'text-danger' : age > 15 ? 'text-warning' : 'text-muted')}
    >
      {fmtHeartbeat(cam.last_heartbeat, now.getTime())}
    </span>
  );
});

const StorageBar = memo(function StorageBar({ pct }: { pct: number }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="h-1 w-14 overflow-hidden rounded-full bg-raised">
        <motion.span
          className={cn('block h-full rounded-full', pct > 95 ? 'bg-danger' : pct > 80 ? 'bg-warning' : 'bg-accent')}
          initial={false}
          animate={{ width: `${Math.min(100, pct)}%` }}
          transition={{ duration: 0.3 }}
        />
      </span>
      <span className="font-mono text-[9px] text-muted">{Math.round(pct)}%</span>
    </span>
  );
});

const UptimeSpark = memo(function UptimeSpark({ cam }: { cam: Camera }) {
  const profile = useMemo(() => uptimeProfile(cam), [cam]);
  const w = 80;
  const seg = w / 24;
  const pct = Math.round((profile.filter(Boolean).length / 24) * 100);
  return (
    <span className="flex items-center gap-1.5" title={`${pct}% uptime over the last 24h`}>
      <svg width={w} height={20} className="shrink-0" aria-hidden>
        {profile.map((up, i) => (
          <rect
            key={i}
            x={i * seg + 0.5}
            y={up ? 4 : 8}
            width={seg - 1}
            height={up ? 12 : 5}
            fill={up ? '#00D4AA' : '#E71D36'}
            opacity={up ? 0.75 : 0.9}
          />
        ))}
      </svg>
      <span className="font-mono text-[9px] text-muted">{pct}%</span>
    </span>
  );
});

/* ── row ─────────────────────────────────────────────────────────────────── */

const CameraRow = memo(function CameraRow({
  cam,
  code,
  density,
  isNew,
  lastEvent,
  onOpen,
}: {
  cam: Camera;
  code: string;
  density: Density;
  isNew: boolean;
  lastEvent?: CamLastEvent;
  onOpen: (cam: Camera) => void;
}) {
  const navigate = useNavigate();
  const meta = KIND_META[cam.kind];
  const KindIcon = meta.icon;
  const offline = cam.status === 'offline';
  const h = density === 'comfortable' ? 'h-11' : 'h-8';
  const open = () => onOpen(cam);

  return (
    <motion.tr
      layout="position"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      onClick={open}
      className={cn(
        'cursor-pointer border-b border-line transition-colors hover:bg-raised',
        h,
        offline && 'bg-danger-dim/30',
      )}
    >
      <td className="px-3">
        <StatusPill status={cam.status} />
      </td>
      <td className="px-2">
        <div className="flex items-center gap-2">
          <div className="min-w-0">
            <div className={cn('truncate font-sans text-[12px] font-medium', offline ? 'text-muted' : 'text-primary')}>{cam.name}</div>
            <div className="font-mono text-[9px] text-muted">{code}</div>
          </div>
          {isNew && (
            <span className="shrink-0 rounded-sm bg-accent-dim px-1 py-px font-mono text-[8px] font-semibold uppercase tracking-[0.08em] text-accent">
              New
            </span>
          )}
        </div>
      </td>
      <td className="px-2">
        <span className="flex items-center gap-1.5">
          <KindIcon size={14} className="text-secondary" />
          <span className="font-mono text-[10px] uppercase text-muted">{meta.label}</span>
        </span>
      </td>
      <td className="px-2 font-sans text-[12px] text-secondary">{cam.zone}</td>
      <td className="px-2">
        <div className={cn('flex items-center gap-3', density === 'compact' && 'gap-2')}>
          <HeartbeatCell cam={cam} />
          <StorageBar pct={cam.storage_used_pct} />
          {density === 'comfortable' && <span className="font-mono text-[10px] text-muted">{cam.firmware}</span>}
        </div>
      </td>
      <td className="px-2">
        <UptimeSpark cam={cam} />
      </td>
      <td className="px-2">
        {lastEvent ? (
          <span className="flex items-center gap-1.5" title={lastEvent.at}>
            {lastEvent.kind === 'plate' ? <ScanLine size={12} className="text-info" /> : <Siren size={12} className="text-warning" />}
            <span className="font-mono text-[10px] text-muted">
              {lastEvent.label} · {relTime(lastEvent.at)}
            </span>
          </span>
        ) : (
          <span className="font-mono text-[10px] text-muted">—</span>
        )}
      </td>
      <td className="px-2">
        <span className="flex items-center justify-end gap-0.5 pr-1">
          <IconButton
            tooltip="Open detail drawer"
            onClick={(e) => {
              e.stopPropagation();
              open();
            }}
          >
            <Maximize2 size={13} />
          </IconButton>
          <IconButton
            tooltip="Locate on tactical map"
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/map?focus=${cam.id}`);
            }}
          >
            <MapPin size={13} />
          </IconButton>
          {cam.ptz_enabled && (
            <IconButton
              tooltip="PTZ control"
              onClick={(e) => {
                e.stopPropagation();
                open();
              }}
            >
              <Move size={13} />
            </IconButton>
          )}
        </span>
      </td>
    </motion.tr>
  );
});

/* ── table ───────────────────────────────────────────────────────────────── */

const COLS = ['STATUS', 'NAME', 'KIND', 'ZONE', 'HEALTH', 'UPTIME 24H', 'LAST EVENT', ''] as const;

export const CameraInventoryTable = memo(function CameraInventoryTable({
  cameras,
  allCameras,
  org,
  density,
  newSince,
  lastEvents,
  loading,
  filtersActive,
  onClearFilters,
  onOpen,
}: {
  cameras: Camera[];
  allCameras: Camera[];
  org: Organization;
  density: Density;
  newSince: Record<string, number>;
  lastEvents: Map<string, CamLastEvent>;
  loading: boolean;
  filtersActive: boolean;
  onClearFilters: () => void;
  onOpen: (cam: Camera) => void;
}) {
  const rowH = density === 'comfortable' ? 44 : 32;
  const codeOf = useMemo(() => {
    const m = new Map<string, string>();
    allCameras.forEach((c, i) => m.set(c.id, camCode(org, i)));
    return m;
  }, [allCameras, org]);

  // windowed rendering only when inventory grows past 100 rows
  const virtualize = cameras.length > 100;
  const [scrollTop, setScrollTop] = useState(0);
  const viewportH = 560;
  const startIdx = virtualize ? Math.max(0, Math.floor(scrollTop / rowH) - 5) : 0;
  const endIdx = virtualize ? Math.min(cameras.length, startIdx + Math.ceil(viewportH / rowH) + 10) : cameras.length;
  const visible = cameras.slice(startIdx, endIdx);

  if (loading) {
    return (
      <div className="divide-y divide-line">
        {Array.from({ length: 8 }, (_, i) => (
          <SkeletonRow key={i} />
        ))}
      </div>
    );
  }

  if (cameras.length === 0) {
    return (
      <EmptyState
        icon={Cctv}
        heading="No cameras match these filters"
        copy="Widen the status/kind/zone selection or clear the search string to see the full fleet."
        actionLabel={filtersActive ? 'Clear filters' : undefined}
        onAction={filtersActive ? onClearFilters : undefined}
        className="min-h-[280px]"
      />
    );
  }

  return (
    <div className="overflow-auto" style={{ maxHeight: virtualize ? viewportH : undefined }} onScroll={(e) => virtualize && setScrollTop(e.currentTarget.scrollTop)}>
      <table className="w-full border-collapse">
        <thead className="sticky top-0 z-10 bg-surface-solid">
          <tr className="border-b border-line">
            {COLS.map((c, i) => (
              <th
                key={i}
                className={cn(
                  'h-8 px-2 text-left font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-muted',
                  i === 0 && 'px-3',
                  i === COLS.length - 1 && 'w-24',
                )}
              >
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {virtualize && startIdx > 0 && (
            <tr>
              <td colSpan={COLS.length} style={{ height: startIdx * rowH, padding: 0 }} />
            </tr>
          )}
          {visible.map((cam) => (
            <CameraRow
              key={cam.id}
              cam={cam}
              code={codeOf.get(cam.id) ?? cam.id}
              density={density}
              isNew={!!newSince[cam.id] && Date.now() - newSince[cam.id] < 5 * 60_000}
              lastEvent={lastEvents.get(cam.id)}
              onOpen={onOpen}
            />
          ))}
          {virtualize && endIdx < cameras.length && (
            <tr>
              <td colSpan={COLS.length} style={{ height: (cameras.length - endIdx) * rowH, padding: 0 }} />
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
});
