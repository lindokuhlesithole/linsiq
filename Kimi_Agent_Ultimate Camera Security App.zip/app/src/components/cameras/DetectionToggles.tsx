/** AI detection toggle list — shared by Add Camera wizard step 4 and the camera drawer. */
import { memo } from 'react';
import type { CameraKind } from '@/lib/types';
import { ToggleSwitch } from '@/components/soc/primitives';
import { DETECTION_DEFS } from './utils';
import type { DetectionMap } from './utils';
import { cn } from '@/lib/utils';

export const DetectionToggles = memo(function DetectionToggles({
  kind,
  value,
  onChange,
  disabled = false,
  dense = false,
}: {
  kind: CameraKind;
  value: DetectionMap;
  onChange: (next: DetectionMap) => void;
  disabled?: boolean;
  dense?: boolean;
}) {
  return (
    <div className={cn('divide-y divide-line rounded-sm border border-line', dense && 'text-[12px]')}>
      {DETECTION_DEFS.map((d) => {
        const locked = d.key === 'plates' && kind === 'fixed_alpr';
        const on = locked ? true : value[d.key];
        return (
          <div key={d.key} className={cn('flex items-center gap-3 px-3', dense ? 'h-10' : 'h-12')}>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 font-sans text-[12px] font-medium text-primary">
                {d.label}
                {locked && (
                  <span className="rounded-sm bg-accent-dim px-1 font-mono text-[8px] font-semibold uppercase tracking-[0.08em] text-accent">
                    Locked on · ALPR
                  </span>
                )}
              </div>
              {!dense && <div className="truncate font-sans text-[10px] text-muted">{d.desc}</div>}
            </div>
            <ToggleSwitch
              on={on}
              disabled={disabled || locked}
              tooltip={locked ? 'Required for ALPR gate cameras' : disabled ? 'Requires OPERATOR role' : undefined}
              onChange={(v) => !locked && onChange({ ...value, [d.key]: v })}
            />
          </div>
        );
      })}
    </div>
  );
});
