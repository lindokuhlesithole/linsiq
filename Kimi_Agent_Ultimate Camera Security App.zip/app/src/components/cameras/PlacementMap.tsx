/**
 * PlacementMap — Add Camera wizard step 3 mini-map (cameras.md §4).
 * Estate streets only, existing cameras dimmed; click drops the marker,
 * dragging from the marker rotates the FOV cone / heading.
 */
import { memo, useCallback, useMemo, useRef } from 'react';
import { motion } from 'framer-motion';
import type { Camera } from '@/lib/types';
import { getTenantGeometry } from '@/lib/procedural';
import { useActiveOrgId } from '@/hooks/useData';
import { FovCone } from '@/components/soc';
import { cn } from '@/lib/utils';

export interface PlacementValue {
  lat: number;
  lng: number;
  heading_deg: number;
}

export const PlacementMap = memo(function PlacementMap({
  value,
  onChange,
  existingCameras,
  className,
}: {
  value: PlacementValue | null;
  onChange: (v: PlacementValue) => void;
  existingCameras: Camera[];
  className?: string;
}) {
  const orgId = useActiveOrgId();
  const geo = useMemo(() => getTenantGeometry(orgId), [orgId]);
  const svgRef = useRef<SVGSVGElement>(null);
  const draggingHeading = useRef(false);

  const toSvg = useCallback((clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const pt = new DOMPoint(clientX, clientY).matrixTransform(svg.getScreenCTM()?.inverse());
    return { x: pt.x, y: pt.y };
  }, []);

  const place = useCallback(
    (clientX: number, clientY: number) => {
      const p = toSvg(clientX, clientY);
      const ll = geo.unproject(p.x, p.y);
      onChange({ lat: ll.lat, lng: ll.lng, heading_deg: value?.heading_deg ?? 0 });
    },
    [geo, onChange, toSvg, value],
  );

  const rotateTo = useCallback(
    (clientX: number, clientY: number) => {
      if (!value) return;
      const m = geo.project(value.lat, value.lng);
      const p = toSvg(clientX, clientY);
      const deg = Math.round((Math.atan2(p.x - m.x, -(p.y - m.y)) * 180) / Math.PI);
      onChange({ ...value, heading_deg: ((deg % 360) + 360) % 360 });
    },
    [geo, onChange, toSvg, value],
  );

  const marker = value ? geo.project(value.lat, value.lng) : null;

  return (
    <div className={cn('scan-grid relative overflow-hidden rounded-sm border border-line bg-inset', className)}>
      <svg
        ref={svgRef}
        viewBox={geo.viewBox}
        className="h-full w-full cursor-crosshair"
        preserveAspectRatio="xMidYMid meet"
        onMouseDown={(e) => {
          if (draggingHeading.current) return;
          place(e.clientX, e.clientY);
        }}
        onMouseMove={(e) => {
          if (draggingHeading.current) rotateTo(e.clientX, e.clientY);
        }}
        onMouseUp={() => {
          draggingHeading.current = false;
        }}
        onMouseLeave={() => {
          draggingHeading.current = false;
        }}
      >
        {geo.water && <path d={geo.water} fill="rgba(76,201,240,0.07)" stroke="rgba(76,201,240,0.18)" strokeWidth="1" />}
        {geo.streets.map((d, i) => (
          <path key={i} d={d} fill="none" stroke="#1B2F52" strokeWidth={i === 0 ? 10 : 6} strokeLinecap="round" />
        ))}
        <path d={geo.boundary} fill="none" stroke="rgba(100,255,218,0.25)" strokeWidth="1.4" strokeDasharray="7 5" />
        {geo.zones.map((z) => (
          <text key={z.label} x={z.x} y={z.y} fontFamily='"JetBrains Mono", monospace' fontSize="11" fill="#5C6B8A" letterSpacing="1.5">
            {z.label}
          </text>
        ))}

        {/* existing cameras, dimmed */}
        {existingCameras.map((c) => {
          const p = geo.project(c.lat, c.lng);
          return (
            <rect
              key={c.id}
              x={p.x - 4}
              y={p.y - 4}
              width={8}
              height={8}
              transform={`rotate(45 ${p.x} ${p.y})`}
              fill="#5C6B8A"
              opacity="0.45"
            />
          );
        })}

        {/* placed marker + FOV cone + heading handle */}
        {marker && value && (
          <g>
            <FovCone x={marker.x} y={marker.y} heading={value.heading_deg} len={64} />
            {/* rotate handle at cone tip */}
            <circle
              cx={marker.x + Math.cos(((value.heading_deg - 90) * Math.PI) / 180) * 64}
              cy={marker.y + Math.sin(((value.heading_deg - 90) * Math.PI) / 180) * 64}
              r={7}
              fill="#0A192F"
              stroke="#00D4AA"
              strokeWidth="1.6"
              className="cursor-grab"
              onMouseDown={(e) => {
                e.stopPropagation();
                draggingHeading.current = true;
              }}
            />
            <motion.g
              key={`${value.lat.toFixed(5)}:${value.lng.toFixed(5)}`}
              initial={{ scale: 1.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 380, damping: 18 }}
              style={{ transformOrigin: `${marker.x}px ${marker.y}px` }}
            >
              <circle cx={marker.x} cy={marker.y} r={10} fill="none" stroke="#00D4AA" strokeWidth="1" opacity="0.5">
                <animate attributeName="r" values="7;18" dur="1.2s" repeatCount="2" />
                <animate attributeName="opacity" values="0.7;0" dur="1.2s" repeatCount="2" />
              </circle>
              <rect
                x={marker.x - 6}
                y={marker.y - 6}
                width={12}
                height={12}
                transform={`rotate(45 ${marker.x} ${marker.y})`}
                fill="#00D4AA"
                stroke="#060D1A"
                strokeWidth="1.6"
              />
            </motion.g>
            <text
              x={marker.x + 14}
              y={marker.y - 10}
              fontFamily='"JetBrains Mono", monospace'
              fontSize="11"
              fill="#00D4AA"
            >
              {String(Math.round(value.heading_deg)).padStart(3, '0')}°
            </text>
          </g>
        )}
      </svg>

      {!value && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <span className="rounded-sm border border-line bg-surface-solid/85 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.1em] text-muted backdrop-blur-sm">
            Click the map to place the camera
          </span>
        </div>
      )}
      <div className="pointer-events-none absolute bottom-2 right-2 rounded-sm border border-line bg-surface-solid/85 px-2 py-1 font-mono text-[9px] text-muted backdrop-blur-sm">
        {value ? `${value.lat.toFixed(5)}, ${value.lng.toFixed(5)} · HDG ${Math.round(value.heading_deg)}°` : '— —'}
      </div>
      <div className="pointer-events-none absolute left-2 top-2 rounded-sm border border-line bg-surface-solid/85 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.08em] text-muted backdrop-blur-sm">
        Drag cone handle to aim
      </div>
    </div>
  );
});
