/**
 * AddCameraWizard — 4-step + review onboarding modal (cameras.md §4).
 * TYPE → CONNECTION (RTSP/ONVIF probe) → PLACEMENT (mini-map) → AI DETECTION → REVIEW.
 * Submit calls addCamera(): the device joins inventory, maps and the simulator.
 */
import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, Eye, EyeOff, Loader2, PlugZap } from 'lucide-react';
import type { Camera, CameraKind } from '@/lib/types';
import { addCamera, useCameras, useOrg } from '@/hooks/useData';
import { GhostButton, SocButton, SocInput, SocModal } from '@/components/soc/primitives';
import { showToast } from '@/components/soc';
import { ApertureMark } from '@/lib/procedural';
import { PlacementMap } from './PlacementMap';
import type { PlacementValue } from './PlacementMap';
import { DetectionToggles } from './DetectionToggles';
import { KIND_META, camCode, defaultDetections } from './utils';
import type { DetectionMap } from './utils';
import { cn } from '@/lib/utils';

const STEPS = ['TYPE', 'CONNECTION', 'PLACEMENT', 'AI DETECTION', 'REVIEW'] as const;
const WIZARD_KINDS: CameraKind[] = ['fixed_alpr', 'ptz', 'bullet', 'doorbell'];
const RESOLUTIONS = ['1920×1080', '2560×1440', '4K'];
const FPS_OPTS = [15, 25, 30];

type TestState = 'idle' | 'testing' | 'ok' | 'failed' | 'skipped';

function titleCaseZone(z: string): string {
  return z
    .toLowerCase()
    .split(' ')
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(' ');
}

export const AddCameraWizard = memo(function AddCameraWizard({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: (cam: Camera) => void;
}) {
  const org = useOrg();
  const cameras = useCameras();
  const zones = useMemo(() => Array.from(new Set(cameras.map((c) => c.zone))).sort(), [cameras]);

  const [step, setStep] = useState(0);
  const dirRef = useRef(1);
  const [kind, setKind] = useState<CameraKind>('bullet');
  const [name, setName] = useState('');
  const [nameTouched, setNameTouched] = useState(false);
  const [zone, setZone] = useState('');
  const [rtsp, setRtsp] = useState('');
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [resolution, setResolution] = useState(RESOLUTIONS[0]);
  const [fps, setFps] = useState(25);
  const [test, setTest] = useState<TestState>('idle');
  const [placement, setPlacement] = useState<PlacementValue | null>(null);
  const [detections, setDetections] = useState<DetectionMap>(defaultDetections('bullet'));
  const [created, setCreated] = useState<Camera | null>(null);
  const testTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const reset = useCallback(() => {
    setStep(0);
    setKind('bullet');
    setName('');
    setNameTouched(false);
    setZone('');
    setRtsp('');
    setUser('');
    setPass('');
    setResolution(RESOLUTIONS[0]);
    setFps(25);
    setTest('idle');
    setPlacement(null);
    setDetections(defaultDetections('bullet'));
    setCreated(null);
  }, []);

  useEffect(() => {
    if (open) reset();
    return () => {
      if (testTimer.current) clearTimeout(testTimer.current);
    };
  }, [open, reset]);

  // auto-suggest name from kind + zone while the operator hasn't typed one
  useEffect(() => {
    if (nameTouched || !zone) return;
    const base = `${titleCaseZone(zone)} ${KIND_META[kind].label === 'ALPR FIXED' ? 'ALPR' : KIND_META[kind].label.toLowerCase().replace(/^./, (c) => c.toUpperCase())}`;
    const n = cameras.filter((c) => c.name.startsWith(base)).length + 1;
    setName(`${base} ${n}`);
  }, [kind, zone, cameras, nameTouched]);

  // kind change → plates detection default + test reset
  useEffect(() => {
    setDetections(defaultDetections(kind));
    setTest('idle');
  }, [kind]);

  const runTest = useCallback(() => {
    setTest('testing');
    if (testTimer.current) clearTimeout(testTimer.current);
    testTimer.current = setTimeout(() => {
      setTest(Math.random() < 0.04 ? 'failed' : 'ok');
    }, 800);
  }, []);

  const rtspValid = /^(rtsp|onvif):\/\/.+/i.test(rtsp.trim());
  const canNext =
    step === 0 ? !!kind
    : step === 1 ? name.trim().length > 1 && !!zone && rtspValid && (test === 'ok' || test === 'skipped')
    : step === 2 ? !!placement
    : true;

  const go = useCallback(
    (next: number) => {
      dirRef.current = next > step ? 1 : -1;
      setStep(next);
    },
    [step],
  );

  const submit = useCallback(() => {
    if (!placement) return;
    const cam = addCamera({
      name: name.trim(),
      zone,
      kind,
      rtsp_url: rtsp.trim(),
      lat: placement.lat,
      lng: placement.lng,
      heading_deg: placement.heading_deg,
      ptz_enabled: kind === 'ptz',
    });
    setCreated(cam);
    showToast({ severity: 'low', title: 'Camera onboarded', body: `${cam.name} joined the ${zone} network` });
    testTimer.current = setTimeout(() => {
      onCreated(cam);
      onClose();
    }, 1400);
  }, [kind, name, onClose, onCreated, placement, rtsp, zone]);

  const stepVariants = {
    enter: (d: number) => ({ x: 24 * d, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (d: number) => ({ x: -24 * d, opacity: 0 }),
  };

  const fieldLabel = 'mb-1 block font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted';
  const selectCls =
    'h-8 w-full rounded-sm border border-line bg-inset px-2 font-sans text-[12px] text-primary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent-dim';

  return (
    <SocModal open={open} onClose={onClose} maxWidth={640} title={<span className="font-mono text-[11px] uppercase tracking-[0.12em]">Connect camera</span>}>
      {created ? (
        /* ── success panel ─────────────────────────────────────────────── */
        <div className="flex flex-col items-center gap-3 px-6 py-10">
          <motion.div
            initial={{ scale: 0.7, opacity: 0, rotate: -30 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 18 }}
          >
            <ApertureMark size={44} />
          </motion.div>
          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.15, type: 'spring', stiffness: 300, damping: 20 }}
            className="flex h-8 w-8 items-center justify-center rounded-full border border-accent bg-accent-dim"
          >
            <Check size={16} className="text-accent" />
          </motion.div>
          <div className="font-mono text-[13px] font-semibold uppercase tracking-[0.2em] text-accent">Camera online</div>
          <div className="font-mono text-[11px] text-muted">
            {camCode(org, cameras.findIndex((c) => c.id === created.id))} · {created.name}
          </div>
        </div>
      ) : (
        <>
          {/* ── step tracker ──────────────────────────────────────────── */}
          <div className="flex items-center gap-1 border-b border-line px-5 py-3">
            {STEPS.map((label, i) => (
              <div key={label} className={cn('flex items-center gap-1', i > 0 && 'flex-1')}>
                {i > 0 && (
                  <span className="relative mx-1 h-px flex-1 bg-line-strong">
                    <motion.span
                      className="absolute inset-y-0 left-0 bg-accent"
                      initial={false}
                      animate={{ width: step >= i ? '100%' : '0%' }}
                      transition={{ duration: 0.3 }}
                    />
                  </span>
                )}
                <button
                  onClick={() => i < step && go(i)}
                  disabled={i >= step}
                  className={cn(
                    'flex h-5 w-5 shrink-0 items-center justify-center rounded-full border font-mono text-[9px] transition-colors',
                    i < step && 'border-accent bg-accent-dim text-accent cursor-pointer',
                    i === step && 'border-accent text-accent animate-live-pulse',
                    i > step && 'border-line-strong text-muted',
                  )}
                >
                  {i < step ? <Check size={10} /> : i + 1}
                </button>
                <span className={cn('hidden font-sans text-[9px] font-semibold uppercase tracking-[0.08em] sm:block', i === step ? 'text-accent' : 'text-muted')}>
                  {label}
                </span>
              </div>
            ))}
          </div>

          {/* ── step body ─────────────────────────────────────────────── */}
          <div className="min-h-[340px] overflow-y-auto px-5 py-4">
            <AnimatePresence mode="wait" custom={dirRef.current}>
              <motion.div
                key={step}
                custom={dirRef.current}
                variants={stepVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.22, ease: [0.2, 0.8, 0.2, 1] }}
              >
                {step === 0 && (
                  <div className="grid grid-cols-2 gap-2">
                    {WIZARD_KINDS.map((k) => {
                      const meta = KIND_META[k];
                      const Icon = meta.icon;
                      const active = kind === k;
                      return (
                        <button
                          key={k}
                          onClick={() => setKind(k)}
                          className={cn(
                            'relative flex h-24 flex-col items-start gap-1.5 rounded-sm border p-3 text-left transition-colors duration-150',
                            active ? 'border-accent bg-accent-dim' : 'border-line bg-inset hover:border-line-strong',
                          )}
                        >
                          {active && (
                            <span className="absolute right-2 top-2 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-on-accent">
                              <Check size={10} />
                            </span>
                          )}
                          <Icon size={18} className={active ? 'text-accent' : 'text-secondary'} />
                          <span className="font-mono text-[11px] font-semibold uppercase tracking-[0.08em] text-primary">{meta.label}</span>
                          <span className="font-sans text-[10px] text-muted">{meta.blurb}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {step === 1 && (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className={fieldLabel}>Camera name</label>
                      <SocInput
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          setNameTouched(true);
                        }}
                        placeholder="North Gate ALPR 2"
                      />
                    </div>
                    <div>
                      <label className={fieldLabel}>Zone</label>
                      <select className={selectCls} value={zone} onChange={(e) => setZone(e.target.value)}>
                        <option value="">Select zone…</option>
                        {zones.map((z) => (
                          <option key={z} value={z}>
                            {z}
                          </option>
                        ))}
                        <option value="NEW PERIMETER">NEW PERIMETER</option>
                      </select>
                    </div>
                    <div className="col-span-2">
                      <label className={fieldLabel}>RTSP / ONVIF URL</label>
                      <SocInput
                        mono
                        value={rtsp}
                        onChange={(e) => {
                          setRtsp(e.target.value);
                          setTest('idle');
                        }}
                        placeholder="rtsp://192.168.…"
                      />
                      {rtsp && !rtspValid && (
                        <div className="mt-1 font-mono text-[9px] text-danger">URL must start with rtsp:// or onvif://</div>
                      )}
                    </div>
                    <div>
                      <label className={fieldLabel}>Username</label>
                      <SocInput value={user} onChange={(e) => setUser(e.target.value)} placeholder="admin" autoComplete="off" />
                    </div>
                    <div>
                      <label className={fieldLabel}>Password</label>
                      <div className="relative">
                        <SocInput
                          type={showPass ? 'text' : 'password'}
                          value={pass}
                          onChange={(e) => setPass(e.target.value)}
                          placeholder="••••••••"
                          autoComplete="new-password"
                          className="pr-8"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPass((s) => !s)}
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-muted hover:text-accent"
                          title={showPass ? 'Hide password' : 'Reveal password'}
                        >
                          {showPass ? <EyeOff size={13} /> : <Eye size={13} />}
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className={fieldLabel}>Resolution</label>
                      <select
                        className={selectCls}
                        value={resolution}
                        onChange={(e) => {
                          setResolution(e.target.value);
                          setTest('idle');
                        }}
                      >
                        {RESOLUTIONS.map((r) => (
                          <option key={r}>{r}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className={fieldLabel}>FPS</label>
                      <select
                        className={selectCls}
                        value={fps}
                        onChange={(e) => {
                          setFps(Number(e.target.value));
                          setTest('idle');
                        }}
                      >
                        {FPS_OPTS.map((f) => (
                          <option key={f} value={f}>
                            {f}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-span-2 flex items-center gap-3 rounded-sm border border-line bg-inset px-3 py-2">
                      <GhostButton onClick={runTest} disabled={!rtspValid || test === 'testing'} className="h-7">
                        {test === 'testing' ? (
                          <span className="inline-flex items-center gap-1.5">
                            <Loader2 size={12} className="animate-spin" /> Probing…
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5">
                            <PlugZap size={12} /> Test connection
                          </span>
                        )}
                      </GhostButton>
                      {test === 'ok' && (
                        <span className="font-mono text-[10px] text-accent">
                          LINK ESTABLISHED · {resolution === '1920×1080' ? '1080p' : resolution === '4K' ? '2160p' : '1440p'}@{fps}
                        </span>
                      )}
                      {test === 'failed' && (
                        <span className="font-mono text-[10px] text-danger">HANDSHAKE FAILED — check host / credentials, then retry</span>
                      )}
                      {test === 'skipped' && (
                        <span className="font-mono text-[10px] text-warning">TEST SKIPPED — device will be probed after onboarding</span>
                      )}
                      {test === 'idle' && (
                        <button className="ml-auto font-mono text-[9px] uppercase tracking-[0.08em] text-muted underline underline-offset-2 hover:text-warning" onClick={() => setTest('skipped')}>
                          Skip test
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-2">
                    <PlacementMap value={placement} onChange={setPlacement} existingCameras={cameras} className="h-[290px]" />
                    <div className="flex justify-between font-mono text-[10px] text-muted">
                      <span>
                        {placement ? `LAT ${placement.lat.toFixed(5)} · LNG ${placement.lng.toFixed(5)} · HDG ${Math.round(placement.heading_deg)}°` : 'NO POSITION SET'}
                      </span>
                      <span>{zone || '—'}</span>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div className="space-y-2">
                    <p className="font-sans text-[11px] text-muted">
                      Edge AI models to run on this device. Changes apply immediately after onboarding.
                    </p>
                    <DetectionToggles kind={kind} value={detections} onChange={setDetections} />
                  </div>
                )}

                {step === 4 && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 rounded-sm border border-line bg-inset p-3 font-mono text-[10px]">
                      {(
                        [
                          ['NAME', name],
                          ['CODE', camCode(org, cameras.length)],
                          ['KIND', KIND_META[kind].label],
                          ['ZONE', zone],
                          ['STREAM', rtsp],
                          ['AUTH', user ? `${user} / ••••••` : 'none'],
                          ['RES', `${resolution} @ ${fps}fps`],
                          ['POSITION', placement ? `${placement.lat.toFixed(5)}, ${placement.lng.toFixed(5)}` : '—'],
                          ['HEADING', placement ? `${Math.round(placement.heading_deg)}°` : '—'],
                          ['LINK TEST', test === 'ok' ? 'PASSED' : 'SKIPPED'],
                          ['PTZ', kind === 'ptz' ? 'ENABLED' : '—'],
                          [
                            'AI MODELS',
                            Object.entries(detections)
                              .filter(([k, v]) => v || (k === 'plates' && kind === 'fixed_alpr'))
                              .map(([k]) => k.replace('_', '/'))
                              .join(', ') || 'none',
                          ],
                        ] as [string, string][]
                      ).map(([k, v]) => (
                        <div key={k} className="flex justify-between gap-3">
                          <span className="shrink-0 text-muted">{k}</span>
                          <span className="truncate text-secondary">{v}</span>
                        </div>
                      ))}
                    </div>
                    {placement && (
                      <div className="pointer-events-none">
                        <PlacementMap value={placement} onChange={() => undefined} existingCameras={cameras} className="h-[120px]" />
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* ── footer ────────────────────────────────────────────────── */}
          <div className="flex items-center justify-between border-t border-line px-5 py-3">
            <GhostButton onClick={() => (step === 0 ? onClose() : go(step - 1))} className="h-8">
              {step === 0 ? 'Cancel' : 'Back'}
            </GhostButton>
            <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-muted">
              Step {step + 1} of {STEPS.length}
            </span>
            {step < STEPS.length - 1 ? (
              <SocButton onClick={() => go(step + 1)} disabled={!canNext} tooltip={!canNext ? 'Complete this step to continue' : undefined} className="h-8">
                Next
              </SocButton>
            ) : (
              <SocButton onClick={submit} disabled={!placement || !name.trim() || !zone || !rtspValid} className="h-8">
                Connect camera
              </SocButton>
            )}
          </div>
        </>
      )}
    </SocModal>
  );
});
