/**
 * CameraDetailDrawer — 480px right drawer (cameras.md §5).
 * Live feed + stat strip + CONTROLS (PTZ pad / AI toggles) / ACTIVITY / HEALTH tabs,
 * reboot cycle simulation, role-gated controls.
 */
import { memo, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, RotateCcw, ScanLine, Siren } from 'lucide-react';
import type { Camera } from '@/lib/types';
import { useAlerts, useCanOperate, useClock, usePlateReads } from '@/hooks/useData';
import { fmtDateTime, fmtTime, relTime } from '@/lib/format';
import { CameraScene } from '@/lib/procedural';
import { PlateReadRow, PtzPad, StatusPill, showToast } from '@/components/soc';
import { DangerButton, IconButton, SocDrawer, SocTabs } from '@/components/soc/primitives';
import { EmptyState } from '@/components/soc/feedback';
import { DetectionToggles } from './DetectionToggles';
import { KIND_META, hashCode, loadDetections, saveDetections, uptimePct } from './utils';
import { cn } from '@/lib/utils';

type Tab = 'controls' | 'activity' | 'health';
const REBOOT_SEC = 20;

const BurnIn = memo(function BurnIn() {
  const now = useClock(1000);
  return <span className="hud-text font-mono text-[11px]">{fmtDateTime(now)}</span>;
});

/* ── feed ────────────────────────────────────────────────────────────────── */

const Feed = memo(function Feed({ cam, frozen, rebooting }: { cam: Camera; frozen?: boolean; rebooting?: boolean }) {
  const offline = cam.status === 'offline';
  return (
    <div className="relative aspect-video w-full shrink-0 overflow-hidden border-b border-line bg-inset">
      {offline || rebooting ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 bg-canvas">
          <svg className="absolute inset-0 h-full w-full opacity-30" aria-hidden>
            <filter id={`drawer-noise-${cam.id}`}>
              <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" />
              <feColorMatrix type="matrix" values="0 0 0 0 0.9 0 0 0 0 0.2 0 0 0 0 0.25 0 0 0 0.4 0" />
            </filter>
            <rect width="100%" height="100%" filter={`url(#drawer-noise-${cam.id})`} />
          </svg>
          <span className="relative font-mono text-[13px] font-semibold uppercase tracking-[0.2em] text-danger">
            {rebooting ? 'Device rebooting' : 'Signal lost'}
          </span>
          <span className="relative font-mono text-[10px] text-muted">last seen {fmtDateTime(cam.last_heartbeat)}</span>
        </div>
      ) : (
        <>
          <CameraScene seed={cam.id} kind={cam.kind} noisy={cam.status === 'degraded'} className="absolute inset-0 h-full w-full" />
          <div className="scanlines absolute inset-0" />
          {!frozen && <div className="scan-band absolute inset-0 overflow-hidden" />}
          <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-2">
            <div className="flex items-start justify-between">
              <span className="hud-text font-mono text-[11px] uppercase">
                {cam.name} · {cam.zone}
              </span>
              {!frozen && (
                <span className="flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-danger animate-rec-blink" />
                  <span className="hud-text font-mono text-[10px] font-semibold">REC</span>
                </span>
              )}
              {frozen && <span className="hud-text font-mono text-[10px] font-semibold uppercase">Last image</span>}
            </div>
            <div className="flex items-end justify-between">
              <BurnIn />
              <span className="hud-text font-mono text-[10px]">
                {cam.resolution} · {cam.fps}FPS
              </span>
            </div>
          </div>
        </>
      )}
    </div>
  );
});

/* ── health helpers ──────────────────────────────────────────────────────── */

function heartbeatLog(cam: Camera): { at: string; ms: number }[] {
  const out: { at: string; ms: number }[] = [];
  const t0 = new Date(cam.last_heartbeat).getTime();
  for (let i = 0; i < 20; i++) {
    const h = hashCode(`${cam.id}:hb:${i}`);
    out.push({ at: new Date(t0 - i * (4800 + (h % 900))).toISOString(), ms: 18 + (h % 46) });
  }
  return out;
}

const StorageHistory = memo(function StorageHistory({ cam }: { cam: Camera }) {
  const pts = useMemo(() => {
    const arr: number[] = [];
    let v = Math.max(4, cam.storage_used_pct - 14);
    for (let i = 0; i < 24; i++) {
      const h = hashCode(`${cam.id}:st:${i}`);
      v = Math.min(cam.storage_used_pct, v + 0.4 + (h % 10) / 12);
      arr.push(v);
    }
    arr[23] = cam.storage_used_pct;
    return arr;
  }, [cam]);
  const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${(i / 23) * 100} ${26 - (p / 100) * 24}`).join(' ');
  return (
    <svg viewBox="0 0 100 26" className="h-[26px] w-full" preserveAspectRatio="none" aria-hidden>
      <path d={d} fill="none" stroke="#00D4AA" strokeWidth="1.2" />
    </svg>
  );
});

/* ── drawer ──────────────────────────────────────────────────────────────── */

export const CameraDetailDrawer = memo(function CameraDetailDrawer({
  camera,
  code,
  open,
  onClose,
}: {
  camera: Camera | null;
  code: string;
  open: boolean;
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const canOperate = useCanOperate();
  const [tab, setTab] = useState<Tab>('controls');
  const [rebootEnd, setRebootEnd] = useState<number | null>(null);
  const now = useClock(rebootEnd ? 500 : 60_000);
  const reads = usePlateReads(camera ? { cameraId: camera.id, limit: 10 } : undefined);
  const allAlerts = useAlerts(camera ? { sinceMs: 24 * 3600_000, limit: 60 } : undefined);

  const [detections, setDetections] = useState(() => (camera ? loadDetections(camera) : loadDetections({ kind: 'bullet' } as Camera)));
  useEffect(() => {
    if (camera) setDetections(loadDetections(camera));
  }, [camera]);

  useEffect(() => {
    if (open) setTab('controls');
  }, [open, camera?.id]);

  const camAlerts = useMemo(
    () => (camera ? allAlerts.filter((a) => a.source_id === camera.id).slice(0, 10) : []),
    [allAlerts, camera],
  );

  const rebootRemaining = rebootEnd ? Math.max(0, Math.ceil((rebootEnd - now.getTime()) / 1000)) : 0;
  const rebooting = rebootRemaining > 0;

  useEffect(() => {
    if (rebootEnd && !rebooting) {
      setRebootEnd(null);
      if (camera) showToast({ severity: 'low', title: 'Camera back online', body: `${camera.name} recovered after reboot` });
    }
  }, [rebootEnd, rebooting, camera]);

  if (!camera) {
    return <SocDrawer open={open} onClose={onClose} title="Camera">{null}</SocDrawer>;
  }

  const offline = camera.status === 'offline';
  const meta = KIND_META[camera.kind];
  const up = uptimePct(camera);

  return (
    <SocDrawer
      open={open}
      onClose={onClose}
      title={
        <div className="flex min-w-0 items-center gap-2">
          <span className="truncate font-sans text-[14px] font-semibold text-primary">{camera.name}</span>
          <span className="shrink-0 font-mono text-[10px] text-muted">{code}</span>
          <span className="shrink-0 rounded-sm bg-raised px-1.5 py-px font-mono text-[9px] uppercase tracking-[0.08em] text-secondary">
            {meta.label}
          </span>
        </div>
      }
      headerRight={
        <div className="flex items-center gap-1.5">
          {rebooting ? (
            <StatusPill status="degraded" label={`Rebooting ${rebootRemaining}s`} />
          ) : (
            <StatusPill status={camera.status} />
          )}
          <IconButton
            tooltip="Locate on tactical map"
            onClick={() => {
              onClose();
              navigate(`/map?focus=${camera.id}`);
            }}
          >
            <MapPin size={14} />
          </IconButton>
        </div>
      }
    >
      <div className="flex h-full flex-col">
        <Feed cam={camera} rebooting={rebooting} />

        {/* stat strip */}
        <div className="grid shrink-0 grid-cols-4 divide-x divide-line border-b border-line">
          <div className="px-3 py-2">
            <div className="font-sans text-[9px] font-semibold uppercase tracking-[0.1em] text-muted">Stream</div>
            <div className="mt-0.5 font-mono text-[11px] text-primary">
              {camera.resolution === '1920×1080' ? '1080p' : camera.resolution}@{camera.fps}
            </div>
          </div>
          <div className="px-3 py-2">
            <div className="font-sans text-[9px] font-semibold uppercase tracking-[0.1em] text-muted">Storage</div>
            <div className="mt-0.5 font-mono text-[11px] text-primary">{Math.round(camera.storage_used_pct)}%</div>
            <div className="mt-1 h-1 overflow-hidden rounded-full bg-raised">
              <div
                className={cn('h-full rounded-full', camera.storage_used_pct > 95 ? 'bg-danger' : camera.storage_used_pct > 80 ? 'bg-warning' : 'bg-accent')}
                style={{ width: `${Math.min(100, camera.storage_used_pct)}%` }}
              />
            </div>
          </div>
          <div className="px-3 py-2">
            <div className="font-sans text-[9px] font-semibold uppercase tracking-[0.1em] text-muted">Uptime 24h</div>
            <div className={cn('mt-0.5 font-mono text-[11px]', up < 90 ? 'text-warning' : 'text-primary')}>{up.toFixed(1)}%</div>
          </div>
          <div className="px-3 py-2">
            <div className="font-sans text-[9px] font-semibold uppercase tracking-[0.1em] text-muted">Firmware</div>
            <div className="mt-0.5 truncate font-mono text-[11px] text-primary">{camera.firmware}</div>
          </div>
        </div>

        <div className="shrink-0 px-5 pt-3">
          <SocTabs
            idScope="cam-drawer"
            tabs={[
              { id: 'controls' as Tab, label: 'Controls' },
              { id: 'activity' as Tab, label: 'Activity', count: reads.length + camAlerts.length },
              { id: 'health' as Tab, label: 'Health' },
            ]}
            active={tab}
            onChange={(t) => setTab(t as Tab)}
          />
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
          {tab === 'controls' && (
            <div className={cn('space-y-4', rebooting && 'pointer-events-none opacity-40')}>
              {camera.ptz_enabled ? (
                offline ? (
                  <div className="space-y-2">
                    <div className="rounded-sm border border-line bg-inset p-3 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
                      PTZ offline — last known frame
                    </div>
                    <Feed cam={camera} frozen />
                  </div>
                ) : (
                  <PtzPad cameraId={camera.id} />
                )
              ) : (
                <div className="rounded-sm border border-line bg-inset p-3 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
                  Fixed camera — no PTZ head installed
                </div>
              )}

              <div>
                <div className="mb-2 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">AI detection models</div>
                <DetectionToggles
                  kind={camera.kind}
                  value={detections}
                  disabled={!canOperate}
                  dense
                  onChange={(next) => {
                    setDetections(next);
                    saveDetections(camera.id, next);
                    showToast({ severity: 'low', title: 'Detection updated', body: camera.name });
                  }}
                />
              </div>

              <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 font-mono text-[10px]">
                <div className="flex justify-between"><span className="text-muted">ZONE</span><span className="text-secondary">{camera.zone}</span></div>
                <div className="flex justify-between"><span className="text-muted">HEADING</span><span className="text-secondary">{camera.heading_deg}°</span></div>
                <div className="col-span-2 flex justify-between gap-4"><span className="text-muted">RTSP</span><span className="truncate text-secondary">{camera.rtsp_url}</span></div>
              </div>
            </div>
          )}

          {tab === 'activity' && (
            <div className="-mx-5">
              {reads.length === 0 && camAlerts.length === 0 ? (
                <EmptyState icon={ScanLine} heading="No recent activity" copy="No plate reads or AI events from this camera in the current window." />
              ) : (
                <>
                  {camAlerts.map((a) => (
                    <button
                      key={a.id}
                      onClick={() => window.dispatchEvent(new CustomEvent('swealth:open-alert', { detail: { alertId: a.id } }))}
                      className="flex h-9 w-full items-center gap-2.5 border-b border-line px-3 text-left transition-colors hover:bg-raised/60"
                    >
                      <Siren size={13} className={a.severity === 'critical' ? 'text-danger' : 'text-warning'} />
                      <span className="min-w-0 flex-1 truncate font-sans text-[11px] text-secondary">{a.title}</span>
                      <StatusPill status={a.status} />
                      <span className="w-14 shrink-0 text-right font-mono text-[10px] text-muted" title={a.created_at}>
                        {relTime(a.created_at)}
                      </span>
                    </button>
                  ))}
                  {reads.map((r) => (
                    <PlateReadRow key={r.id} read={r} camera={camera} onClick={() => navigate('/alpr')} />
                  ))}
                </>
              )}
              {camera.kind === 'fixed_alpr' && (
                <div className="px-3 py-2">
                  <button onClick={() => navigate('/alpr')} className="font-mono text-[10px] uppercase tracking-[0.08em] text-accent hover:underline underline-offset-2">
                    View all in ALPR →
                  </button>
                </div>
              )}
            </div>
          )}

          {tab === 'health' && (
            <div className="space-y-4">
              <div>
                <div className="mb-1.5 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">Heartbeat log</div>
                <div className="max-h-44 overflow-y-auto rounded-sm border border-line bg-inset">
                  {heartbeatLog(camera).map((h, i) => (
                    <div key={i} className="flex h-6 items-center justify-between border-b border-line/50 px-2 font-mono text-[10px] last:border-0">
                      <span className={i === 0 ? 'text-accent' : 'text-muted'}>♥ {fmtTime(h.at)}</span>
                      <span className="text-secondary">{h.ms}ms</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div className="mb-1.5 flex justify-between">
                  <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">Storage history · 24h</span>
                  <span className="font-mono text-[10px] text-secondary">{Math.round(camera.storage_used_pct)}%</span>
                </div>
                <div className="rounded-sm border border-line bg-inset px-2 py-1">
                  <StorageHistory cam={camera} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 font-mono text-[10px]">
                <div className="flex justify-between"><span className="text-muted">INSTALLED</span><span className="text-secondary">{fmtDateTime(camera.install_date).slice(0, 10)}</span></div>
                <div className="flex justify-between"><span className="text-muted">FW UPDATE</span><span className="text-secondary">{camera.firmware} · {relTime(camera.install_date)}</span></div>
              </div>
              <DangerButton
                disabled={rebooting}
                tooltip={rebooting ? 'Reboot already in progress' : 'Simulate a 20s offline → recover cycle'}
                onClick={() => {
                  setRebootEnd(Date.now() + REBOOT_SEC * 1000);
                  showToast({ severity: 'medium', title: 'Reboot command sent', body: `${camera.name} cycling for ${REBOOT_SEC}s` });
                }}
              >
                <span className="inline-flex items-center gap-1.5">
                  <RotateCcw size={12} /> {rebooting ? `Rebooting ${rebootRemaining}s` : 'Reboot device'}
                </span>
              </DangerButton>
            </div>
          )}
        </div>
      </div>
    </SocDrawer>
  );
});
