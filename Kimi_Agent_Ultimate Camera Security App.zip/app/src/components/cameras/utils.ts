/** Shared helpers for the Camera Network page (deterministic, seed-driven). */
import type { Camera, CameraKind, Organization } from '@/lib/types';
import { BellRing, Cctv, Move3d, ScanLine } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

/* deterministic string hash */
export function hashCode(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h >>> 0);
}

export const KIND_META: Record<CameraKind, { label: string; icon: LucideIcon; blurb: string }> = {
  fixed_alpr: { label: 'ALPR FIXED', icon: ScanLine, blurb: 'Gate plate capture, high-shutter' },
  ptz: { label: 'PTZ', icon: Move3d, blurb: 'Pan-tilt-zoom patrol' },
  bullet: { label: 'BULLET', icon: Cctv, blurb: 'Fixed overview' },
  doorbell: { label: 'DOORBELL', icon: BellRing, blurb: 'Entrance intercom' },
  drone_mount: { label: 'DRONE MOUNT', icon: Cctv, blurb: 'Aircraft-mounted payload' },
};

/** Short device code, e.g. SL-CAM-04 (derived from org slug + inventory index). */
export function camCode(org: Organization | undefined, index: number): string {
  const prefix = org ? org.slug.split('-').map((w) => w[0]).join('').toUpperCase() : 'SW';
  return `${prefix}-CAM-${String(index + 1).padStart(2, '0')}`;
}

/**
 * Deterministic 24h uptime profile: one boolean per hour (index 0 = 23h ago).
 * Offline cameras are down for their recent stretch; everyone else has rare seeded gaps.
 */
export function uptimeProfile(cam: Camera, nowMs: number = Date.now()): boolean[] {
  const out: boolean[] = [];
  const hourIdx = Math.floor(nowMs / 3600_000);
  for (let i = 0; i < 24; i++) {
    const h = hashCode(`${cam.id}:${hourIdx - 23 + i}`);
    let up = h % 41 !== 0; // ~2.4% seeded downtime
    if (cam.status === 'offline' && i >= 19) up = false; // current outage tail
    if (cam.status === 'degraded' && i >= 22) up = h % 3 !== 0; // flaky recent hours
    out.push(up);
  }
  return out;
}

/** 24h uptime percentage derived from the profile. */
export function uptimePct(cam: Camera, nowMs?: number): number {
  const p = uptimeProfile(cam, nowMs);
  return (p.filter(Boolean).length / p.length) * 100;
}

/* ── AI detection toggles (persisted per camera — no store field exists) ─── */

export type DetectionKey = 'plates' | 'persons' | 'vehicles' | 'loitering' | 'fire_smoke' | 'tripwire';

export const DETECTION_DEFS: { key: DetectionKey; label: string; desc: string }[] = [
  { key: 'plates', label: 'License plates', desc: 'ALPR capture + hotlist matching' },
  { key: 'persons', label: 'Persons', desc: 'Human detection and tracking in frame' },
  { key: 'vehicles', label: 'Vehicles', desc: 'Vehicle classification and attributes' },
  { key: 'loitering', label: 'Loitering', desc: 'Dwell-time anomaly beyond threshold' },
  { key: 'fire_smoke', label: 'Fire / Smoke', desc: 'Visual flame and smoke plume detection' },
  { key: 'tripwire', label: 'Perimeter tripwire', desc: 'Virtual line-crossing events' },
];

export type DetectionMap = Record<DetectionKey, boolean>;

export function defaultDetections(kind: CameraKind): DetectionMap {
  return {
    plates: kind === 'fixed_alpr',
    persons: true,
    vehicles: true,
    loitering: false,
    fire_smoke: false,
    tripwire: kind === 'bullet' || kind === 'ptz',
  };
}

const aiKey = (camId: string) => `swealth.cam_ai.${camId}`;

export function loadDetections(cam: Camera): DetectionMap {
  try {
    const raw = localStorage.getItem(aiKey(cam.id));
    if (raw) return { ...defaultDetections(cam.kind), ...(JSON.parse(raw) as Partial<DetectionMap>) };
  } catch {
    /* ignore */
  }
  return defaultDetections(cam.kind);
}

export function saveDetections(camId: string, d: DetectionMap): void {
  try {
    localStorage.setItem(aiKey(camId), JSON.stringify(d));
  } catch {
    /* ignore */
  }
}
