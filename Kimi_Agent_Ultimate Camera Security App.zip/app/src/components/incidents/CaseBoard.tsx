/**
 * CaseBoard — four-column status board with HTML5 drag-and-drop status
 * changes (incidents.md §2). Drops onto CLOSED / ESCALATED_SAPS open the
 * gated StatusConfirm popover at the drop point.
 */
import { memo, useMemo, useState } from 'react';
import type { DragEvent as ReactDragEvent } from 'react';
import { motion } from 'framer-motion';
import { ScanLine } from 'lucide-react';
import type { Alert, AlertEvidence, Incident, IncidentStatus, PlateRead } from '@/lib/types';
import { SeverityBadge, alertTypeIcon, showToast } from '@/components/soc';
import { relTime } from '@/lib/format';
import { StatusConfirm } from './StatusConfirm';
import type { StatusConfirmRequest } from './StatusConfirm';
import { cn } from '@/lib/utils';

export const BOARD_STATUSES: { id: IncidentStatus; label: string; top: string; badge: string }[] = [
  { id: 'open', label: 'Open', top: 'border-t-warning', badge: 'text-warning' },
  { id: 'investigating', label: 'Investigating', top: 'border-t-info', badge: 'text-info' },
  { id: 'escalated_saps', label: 'Escalated SAPS', top: 'border-t-danger', badge: 'text-danger' },
  { id: 'closed', label: 'Closed', top: 'border-t-accent', badge: 'text-accent' },
];

/* ── Case card ───────────────────────────────────────────────────────────── */

export const CaseCard = memo(function CaseCard({
  incident,
  alerts,
  plateReads,
  evidenceCount,
  canOperate,
  onOpen,
  onDragStart,
}: {
  incident: Incident;
  alerts: Alert[];
  plateReads: PlateRead[];
  evidenceCount: number;
  canOperate: boolean;
  onOpen: (id: string) => void;
  onDragStart: (id: string, e: ReactDragEvent) => void;
}) {
  const linkedAlerts = useMemo(
    () => alerts.filter((a) => incident.linked_alert_ids.includes(a.id)),
    [alerts, incident.linked_alert_ids],
  );
  const sightings = plateReads.filter((r) => incident.linked_plate_reads.includes(r.id)).length;

  return (
    <motion.div
      layout="position"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22, ease: [0.2, 0.8, 0.2, 1] }}
    >
      <div
        draggable={canOperate}
        onDragStart={(e) => onDragStart(incident.id, e)}
        onClick={() => onOpen(incident.id)}
        className={cn(
          'group cursor-pointer rounded-sm border border-line bg-surface p-3 transition-colors hover:border-line-strong',
          canOperate && 'cursor-grab active:cursor-grabbing',
        )}
      >
      <div className="flex items-center justify-between gap-2">
        <span className="font-mono text-[12px] font-semibold text-primary">{incident.case_no}</span>
        <SeverityBadge severity={incident.priority} />
      </div>
      <div
        className="mt-1.5 font-sans text-[13px] font-medium leading-[18px] text-primary"
        style={{ display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}
      >
        {incident.title}
      </div>
      <div className="mt-1.5 space-y-0.5 font-mono text-[10px] text-muted">
        <div>INV: {incident.assigned_investigator.toUpperCase()}</div>
        <div>
          {incident.linked_alert_ids.length} ALERTS · {sightings} SIGHTINGS · {evidenceCount} EVIDENCE
        </div>
        <div>OPENED {relTime(incident.created_at).toUpperCase()}</div>
      </div>
      <div className="mt-2 flex items-center gap-1.5">
        {linkedAlerts.slice(0, 5).map((a) => {
          const Icon = alertTypeIcon(a.type);
          const color =
            a.severity === 'critical'
              ? 'text-danger'
              : a.severity === 'high'
                ? 'text-warning'
                : a.severity === 'medium'
                  ? 'text-info'
                  : 'text-muted';
          return <Icon key={a.id} size={13} className={color} />;
        })}
        {sightings > 0 && <ScanLine size={13} className="text-info" />}
        <span className="ml-auto font-mono text-[10px] font-semibold uppercase tracking-[0.06em] text-accent opacity-0 transition-opacity group-hover:opacity-100">
          Open →
        </span>
      </div>
      </div>
    </motion.div>
  );
});

/* ── Board ───────────────────────────────────────────────────────────────── */

export const CaseBoard = memo(function CaseBoard({
  incidents,
  alerts,
  plateReads,
  evidence,
  canOperate,
  statusFilter,
  onOpen,
  onStatusChange,
}: {
  incidents: Incident[];
  alerts: Alert[];
  plateReads: PlateRead[];
  evidence: AlertEvidence[];
  canOperate: boolean;
  statusFilter: IncidentStatus | null;
  onOpen: (id: string) => void;
  /** perform the (already-confirmed) status change; returns false if noop */
  onStatusChange: (id: string, target: IncidentStatus, confirmValue?: string) => void;
}) {
  const [dropTarget, setDropTarget] = useState<IncidentStatus | null>(null);
  const [confirm, setConfirm] = useState<(StatusConfirmRequest & { incidentId: string }) | null>(null);

  const evidenceByAlert = useMemo(() => {
    const m = new Map<string, number>();
    for (const e of evidence) m.set(e.alert_id, (m.get(e.alert_id) ?? 0) + 1);
    return m;
  }, [evidence]);

  const evidenceCountFor = (inc: Incident) =>
    inc.linked_alert_ids.reduce((s, id) => s + (evidenceByAlert.get(id) ?? 0), 0);

  const handleDrop = (status: IncidentStatus) => (e: ReactDragEvent) => {
    e.preventDefault();
    setDropTarget(null);
    const id = e.dataTransfer.getData('swealth/incident');
    if (!id) return;
    const inc = incidents.find((i) => i.id === id);
    if (!inc || inc.status === status) return;
    if (!canOperate) {
      showToast({ severity: 'medium', title: 'Requires OPERATOR role', body: 'Status changes are read-only in Guard preview.' });
      return;
    }
    const host = (e.currentTarget as HTMLElement).getBoundingClientRect();
    if (status === 'closed' || status === 'escalated_saps') {
      setConfirm({ incidentId: id, target: status, x: e.clientX - host.left, y: e.clientY - host.top });
    } else {
      onStatusChange(id, status);
    }
  };

  const confirmIncident = confirm ? incidents.find((i) => i.id === confirm.incidentId) : null;

  return (
    <div className="relative flex-1 min-h-0">
      <div className="flex h-full min-h-0 gap-3 overflow-x-auto pb-1">
        {BOARD_STATUSES.map((col) => {
          const items = incidents.filter((i) => i.status === col.id);
          const dimmed = statusFilter !== null && statusFilter !== col.id;
          return (
            <div
              key={col.id}
              className={cn(
                'flex min-w-[280px] flex-1 flex-col rounded-sm transition-opacity duration-200',
                dimmed && 'opacity-35',
              )}
              onDragOver={(e) => {
                if (!canOperate) return;
                e.preventDefault();
                setDropTarget(col.id);
              }}
              onDragLeave={() => setDropTarget((t) => (t === col.id ? null : t))}
              onDrop={handleDrop(col.id)}
            >
              <div
                className={cn(
                  'flex items-center justify-between rounded-t-sm border border-b-0 border-line border-t-2 bg-surface px-3 py-2',
                  col.top,
                )}
              >
                <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                  {col.label}
                </span>
                <span className={cn('font-mono text-[11px] font-semibold', col.badge)}>{items.length}</span>
              </div>
              <div
                className={cn(
                  'min-h-0 flex-1 space-y-2 overflow-y-auto rounded-b-sm border border-line bg-inset/40 p-2 transition-colors',
                  dropTarget === col.id && 'border-accent/40 bg-accent-dim/30',
                )}
              >
                {items.length === 0 ? (
                  <div className="flex h-24 items-center justify-center rounded-sm border border-dashed border-line">
                    <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
                      No cases
                    </span>
                  </div>
                ) : (
                  items.map((inc) => (
                    <CaseCard
                      key={inc.id}
                      incident={inc}
                      alerts={alerts}
                      plateReads={plateReads}
                      evidenceCount={evidenceCountFor(inc)}
                      canOperate={canOperate}
                      onOpen={onOpen}
                      onDragStart={(id, e) => {
                        e.dataTransfer.setData('swealth/incident', id);
                        e.dataTransfer.effectAllowed = 'move';
                      }}
                    />
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* gated transition popover at drop point */}
      {confirm && confirmIncident && (
        <StatusConfirm
          request={confirm}
          caseNo={confirmIncident.case_no}
          onConfirm={(value) => {
            onStatusChange(confirm.incidentId, confirm.target, value);
            setConfirm(null);
          }}
          onCancel={() => setConfirm(null)}
        />
      )}
    </div>
  );
});
