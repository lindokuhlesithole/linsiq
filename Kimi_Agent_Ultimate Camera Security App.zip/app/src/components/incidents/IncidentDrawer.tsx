/**
 * IncidentDrawer — 560px case detail (incidents.md §4): status workflow
 * stepper, OVERVIEW / EVIDENCE / TIMELINE / NOTES tabs, append-only notes,
 * sticky footer with the evidence-pack export + chain-of-custody line.
 */
import { memo, useMemo, useState } from 'react';
import type { MouseEvent as ReactMouseEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, FileSearch, Lock } from 'lucide-react';
import type { Alert, Incident, IncidentStatus, PlateRead } from '@/lib/types';
import { updateIncident, useAuditLog, useCameras, useEvidence } from '@/hooks/useData';
import {
  AlertRow,
  EmptyState,
  EvidenceGrid,
  PlateReadRow,
  SeverityBadge,
  SocButton,
  SocDrawer,
  SocTabs,
  StatusPill,
} from '@/components/soc';
import { fmtDateTime, fmtTime, relTime } from '@/lib/format';
import { ExportEvidenceButton } from './ExportEvidenceButton';
import { StatusConfirm } from './StatusConfirm';
import type { StatusConfirmRequest } from './StatusConfirm';
import { cn } from '@/lib/utils';

type Tab = 'overview' | 'evidence' | 'timeline' | 'notes';

const WORKFLOW: { id: IncidentStatus; label: string }[] = [
  { id: 'open', label: 'Open' },
  { id: 'investigating', label: 'Investigating' },
  { id: 'escalated_saps', label: 'Escalated SAPS' },
  { id: 'closed', label: 'Closed' },
];

function workflowIndex(s: IncidentStatus): number {
  return s === 'escalated_saps' ? 2 : s === 'closed' ? 3 : s === 'investigating' ? 1 : 0;
}

interface TlEntry {
  at: string;
  label: string;
  detail: string;
  tone: 'critical' | 'high' | 'medium' | 'low' | 'accent' | 'muted';
}

const TONE_CLASS: Record<TlEntry['tone'], string> = {
  critical: 'bg-danger',
  high: 'bg-warning',
  medium: 'bg-info',
  low: 'bg-severity-low',
  accent: 'bg-accent',
  muted: 'bg-muted',
};

export const IncidentDrawer = memo(function IncidentDrawer({
  incident,
  open,
  onClose,
  canOperate,
  alerts,
  plateReads,
  onStatusChange,
}: {
  incident: Incident | null;
  open: boolean;
  onClose: () => void;
  canOperate: boolean;
  alerts: Alert[];
  plateReads: PlateRead[];
  onStatusChange: (id: string, target: IncidentStatus, confirmValue?: string) => void;
}) {
  const navigate = useNavigate();
  const cameras = useCameras();
  const allEvidence = useEvidence();
  const auditLog = useAuditLog();
  const [tab, setTab] = useState<Tab>('overview');
  const [noteDraft, setNoteDraft] = useState('');
  const [confirm, setConfirm] = useState<(StatusConfirmRequest & { incidentId: string }) | null>(null);
  const [exportNonce, setExportNonce] = useState(0);

  const linkedAlerts = useMemo(
    () => (incident ? alerts.filter((a) => incident.linked_alert_ids.includes(a.id)) : []),
    [alerts, incident],
  );
  const linkedReads = useMemo(
    () => (incident ? plateReads.filter((r) => incident.linked_plate_reads.includes(r.id)) : []),
    [plateReads, incident],
  );
  const linkedEvidence = useMemo(
    () => (incident ? allEvidence.filter((e) => incident.linked_alert_ids.includes(e.alert_id)) : []),
    [allEvidence, incident],
  );
  const custodyTrail = useMemo(
    () =>
      incident
        ? auditLog.filter((a) => a.entity_id === incident.id || incident.linked_alert_ids.includes(a.entity_id))
        : [],
    [auditLog, incident],
  );

  /* evidence grouped by source alert */
  const evidenceGroups = useMemo(() => {
    const groups: { key: string; label: string; items: typeof linkedEvidence }[] = [];
    for (const a of linkedAlerts) {
      const items = linkedEvidence.filter((e) => e.alert_id === a.id);
      if (items.length > 0) groups.push({ key: a.id, label: `${a.source_name} — ${a.type.replace(/_/g, ' ').toUpperCase()}`, items });
    }
    return groups;
  }, [linkedAlerts, linkedEvidence]);

  /* merged chronological timeline */
  const timeline = useMemo<TlEntry[]>(() => {
    if (!incident) return [];
    const out: TlEntry[] = [];
    out.push({ at: incident.created_at, label: 'CASE OPENED', detail: `${incident.case_no} — ${incident.title}`, tone: 'accent' });
    for (const a of linkedAlerts) {
      out.push({ at: a.created_at, label: `ALERT — ${a.severity.toUpperCase()}`, detail: a.title, tone: a.severity });
      if (a.acknowledged_at)
        out.push({ at: a.acknowledged_at, label: 'ALERT ACK', detail: `${a.title} — ${a.acknowledged_by ?? 'operator'}`, tone: 'medium' });
      if (a.resolved_at)
        out.push({ at: a.resolved_at, label: `ALERT ${a.status === 'false_alarm' ? 'FALSE ALARM' : 'RESOLVED'}`, detail: a.title, tone: 'accent' });
    }
    for (const r of linkedReads) {
      const cam = cameras.find((c) => c.id === r.camera_id);
      out.push({
        at: r.captured_at,
        label: 'PLATE SIGHTING',
        detail: `${r.plate} @ ${cam?.name ?? r.camera_id} · ${r.direction.toUpperCase()} · ${Math.round(r.confidence * 100)}%`,
        tone: 'medium',
      });
    }
    for (const n of incident.notes) {
      out.push({ at: n.created_at, label: `NOTE — ${n.author.toUpperCase()}`, detail: n.text, tone: 'muted' });
    }
    for (const a of custodyTrail) {
      if (a.action.startsWith('incident.'))
        out.push({ at: a.created_at, label: a.action.replace('.', ' · ').toUpperCase(), detail: a.detail, tone: 'low' });
      if (a.action === 'evidence.export')
        out.push({ at: a.created_at, label: 'EVIDENCE EXPORT', detail: a.detail, tone: 'accent' });
    }
    if (incident.closed_at)
      out.push({
        at: incident.closed_at,
        label: incident.status === 'escalated_saps' ? 'ESCALATED TO SAPS' : 'CASE CLOSED',
        detail: incident.disposition ? `Disposition — ${incident.disposition}` : incident.status.replace('_', ' '),
        tone: incident.status === 'escalated_saps' ? 'high' : 'accent',
      });
    return out.sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime());
  }, [incident, linkedAlerts, linkedReads, cameras, custodyTrail]);

  const closed = incident?.status === 'closed';
  const terminal = incident ? incident.status === 'closed' || incident.status === 'escalated_saps' : false;
  const lastAction = custodyTrail.length > 0 ? custodyTrail[0] : null;

  const requestStatus = (target: IncidentStatus, e: ReactMouseEvent) => {
    if (!incident || !canOperate || terminal || target === incident.status) return;
    if (target === 'closed' || target === 'escalated_saps') {
      const host = (e.currentTarget as HTMLElement).closest('[data-drawer-host]')?.getBoundingClientRect();
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      setConfirm({
        incidentId: incident.id,
        target,
        x: host ? rect.left - host.left - 200 : 40,
        y: host ? rect.top - host.top - 40 : 80,
      });
    } else {
      onStatusChange(incident.id, target);
    }
  };

  const appendNote = () => {
    if (!incident || noteDraft.trim().length === 0) return;
    const text = closed ? `[POST-CLOSURE] ${noteDraft.trim()}` : noteDraft.trim();
    updateIncident(incident.id, { addNote: text });
    setNoteDraft('');
  };

  return (
    <SocDrawer
      open={open}
      onClose={onClose}
      width={560}
      title={
        <div className="flex min-w-0 items-center gap-2">
          <span className="font-mono text-[16px] font-semibold text-primary">{incident?.case_no ?? '—'}</span>
          {incident && <SeverityBadge severity={incident.priority} />}
          {incident && <StatusPill status={incident.status} />}
        </div>
      }
    >
      {!incident ? (
        <div className="p-5 font-mono text-[11px] text-muted">Case not found in current tenant scope.</div>
      ) : (
        <div className="relative flex min-h-full flex-col" data-drawer-host>
          <div className="flex-1 px-5 pb-4">
            {/* title + meta */}
            <div className="pt-4">
              <div className="font-sans text-[14px] font-semibold leading-5 text-primary">{incident.title}</div>
              <div className="mt-1 font-mono text-[10px] text-muted">
                INV: {incident.assigned_investigator.toUpperCase()} · OPENED {fmtDateTime(incident.created_at)} · AGE{' '}
                {relTime(incident.created_at).toUpperCase()}
              </div>
              {closed && (
                <div className="mt-2 rounded-sm bg-accent-dim px-2 py-1 font-mono text-[10px] uppercase tracking-[0.06em] text-accent">
                  Closed — {incident.disposition ?? 'disposition not recorded'}
                </div>
              )}
              {incident.status === 'escalated_saps' && (
                <div className="mt-2 rounded-sm bg-danger-dim px-2 py-1 font-mono text-[10px] uppercase tracking-[0.06em] text-danger">
                  Escalated to SAPS — national handover in progress
                </div>
              )}
            </div>

            {/* status workflow stepper */}
            <div className="mt-4 rounded-sm border border-line bg-inset p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">
                  Status workflow
                </span>
                {(!canOperate || terminal) && (
                  <span className="flex items-center gap-1 font-mono text-[9px] uppercase text-muted">
                    <Lock size={9} /> {!canOperate ? 'Requires OPERATOR role' : 'Locked'}
                  </span>
                )}
              </div>
              <div className="flex items-center">
                {WORKFLOW.map((step, i) => {
                  const current = workflowIndex(incident.status);
                  const isCurrent = incident.status === step.id || (incident.status === 'closed' && step.id === 'closed');
                  const isDone = i < current || (terminal && step.id === incident.status);
                  const clickable = canOperate && !terminal && !isCurrent;
                  return (
                    <div key={step.id} className="flex flex-1 items-center last:flex-none">
                      <button
                        disabled={!clickable}
                        onClick={(e) => requestStatus(step.id, e)}
                        title={
                          !canOperate
                            ? 'Requires OPERATOR role'
                            : terminal
                              ? 'Workflow locked — case is terminal'
                              : isCurrent
                                ? 'Current status'
                                : `Move case to ${step.label}`
                        }
                        className={cn('group flex flex-col items-center gap-1', clickable && 'cursor-pointer')}
                      >
                        <span
                          className={cn(
                            'flex h-4 w-4 items-center justify-center rounded-full border transition-all duration-200',
                            isDone && !isCurrent && 'border-accent bg-accent',
                            isCurrent && (terminal ? 'border-accent bg-accent' : 'border-warning bg-warning-dim animate-live-pulse'),
                            !isDone && !isCurrent && 'border-line-strong bg-raised group-hover:border-accent',
                          )}
                        >
                          {isDone && <Check size={10} className="text-on-accent" strokeWidth={3} />}
                        </span>
                        <span
                          className={cn(
                            'whitespace-nowrap font-mono text-[8px] uppercase tracking-[0.06em]',
                            isCurrent ? (terminal ? 'text-accent' : 'text-warning') : isDone ? 'text-accent' : 'text-muted',
                          )}
                        >
                          {step.label}
                        </span>
                      </button>
                      {i < WORKFLOW.length - 1 && (
                        <span className={cn('mx-1 mb-4 h-px flex-1', i < current ? 'bg-accent' : 'bg-line-strong')} />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* tabs */}
            <div className="mt-3">
              <SocTabs
                idScope="incident-detail"
                tabs={[
                  { id: 'overview' as Tab, label: 'Overview' },
                  { id: 'evidence' as Tab, label: 'Evidence', count: linkedEvidence.length },
                  { id: 'timeline' as Tab, label: 'Timeline' },
                  { id: 'notes' as Tab, label: 'Notes', count: incident.notes.length },
                ]}
                active={tab}
                onChange={(t) => setTab(t as Tab)}
              />
            </div>

            <div className="py-4">
              {/* OVERVIEW */}
              {tab === 'overview' && (
                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.18 }}>
                  <p className="font-sans text-[13px] leading-5 text-secondary">{incident.summary}</p>

                  <div className="mb-1 mt-4 font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">
                    Linked alerts ({linkedAlerts.length})
                  </div>
                  {linkedAlerts.length === 0 ? (
                    <div className="rounded-sm border border-dashed border-line px-3 py-3 font-mono text-[10px] text-muted">
                      No alerts linked — link alerts when creating a case or from the Alert Center.
                    </div>
                  ) : (
                    <div className="overflow-hidden rounded-sm border border-line">
                      {linkedAlerts.map((a) => (
                        <AlertRow key={a.id} alert={a} dense onClick={() => navigate('/alerts')} />
                      ))}
                    </div>
                  )}

                  <div className="mb-1 mt-4 font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">
                    Linked plate sightings ({linkedReads.length})
                  </div>
                  {linkedReads.length === 0 ? (
                    <div className="rounded-sm border border-dashed border-line px-3 py-3 font-mono text-[10px] text-muted">
                      No plate sightings linked to this case.
                    </div>
                  ) : (
                    <div className="overflow-hidden rounded-sm border border-line">
                      {linkedReads.map((r) => (
                        <PlateReadRow
                          key={r.id}
                          read={r}
                          camera={cameras.find((c) => c.id === r.camera_id)}
                          onClick={() => navigate('/alpr')}
                        />
                      ))}
                    </div>
                  )}
                </motion.div>
              )}

              {/* EVIDENCE */}
              {tab === 'evidence' && (
                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.18 }}>
                  {linkedEvidence.length === 0 ? (
                    <EmptyState
                      icon={FileSearch}
                      heading="No evidence linked"
                      copy="Link alerts from the Overview tab — their snapshots, plate crops and clips aggregate here."
                      actionLabel="Go to overview"
                      onAction={() => setTab('overview')}
                    />
                  ) : (
                    evidenceGroups.map((g) => (
                      <div key={g.key} className="mb-3">
                        <div className="mb-1 font-mono text-[9px] uppercase tracking-[0.12em] text-muted">{g.label}</div>
                        <div className="overflow-hidden rounded-sm border border-line">
                          <EvidenceGrid evidence={g.items} />
                        </div>
                      </div>
                    ))
                  )}
                </motion.div>
              )}

              {/* TIMELINE */}
              {tab === 'timeline' && (
                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.18 }}>
                  <div className="relative ml-1.5 border-l border-line-strong pl-4">
                    {timeline.map((e, i) => (
                      <div key={`${e.at}-${i}`} className="relative pb-3 last:pb-0">
                        <span className={cn('absolute -left-[21px] top-1 h-2 w-2 rounded-full', TONE_CLASS[e.tone])} />
                        <div className="flex items-baseline justify-between gap-2">
                          <span className="font-mono text-[9px] font-semibold uppercase tracking-[0.08em] text-secondary">
                            {e.label}
                          </span>
                          <span className="shrink-0 font-mono text-[9px] text-muted" title={fmtDateTime(e.at)}>
                            {fmtTime(e.at)}
                          </span>
                        </div>
                        <div className="mt-0.5 line-clamp-2 font-sans text-[11px] leading-4 text-muted">{e.detail}</div>
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => setExportNonce((n) => n + 1)}
                    disabled={!canOperate}
                    title={canOperate ? 'Export evidence pack' : 'Requires OPERATOR role'}
                    className="mt-3 font-mono text-[10px] font-semibold uppercase tracking-[0.08em] text-accent transition-colors hover:brightness-125 disabled:cursor-not-allowed disabled:text-muted"
                  >
                    Export →
                  </button>
                </motion.div>
              )}

              {/* NOTES (append-only) */}
              {tab === 'notes' && (
                <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.18 }}>
                  <div className="space-y-2">
                    {incident.notes.length === 0 && (
                      <div className="rounded-sm border border-dashed border-line px-3 py-3 font-mono text-[10px] text-muted">
                        No investigator notes yet — append the first one below. Notes are append-only by design.
                      </div>
                    )}
                    {incident.notes.map((n) => (
                      <motion.div
                        key={n.id}
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.25 }}
                        className="max-w-[85%] rounded-sm border border-line bg-inset px-3 py-2"
                      >
                        <div className="flex items-center gap-2 font-mono text-[9px] text-muted">
                          <span className="font-semibold text-info">{n.author}</span>
                          <span title={fmtDateTime(n.created_at)}>{fmtDateTime(n.created_at)}</span>
                          {n.text.startsWith('[POST-CLOSURE]') && (
                            <span className="rounded-sm bg-accent-dim px-1 font-semibold text-accent">POST-CLOSURE</span>
                          )}
                        </div>
                        <div className="mt-1 whitespace-pre-wrap font-sans text-[13px] leading-5 text-primary">
                          {n.text.replace('[POST-CLOSURE] ', '')}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <div className="mt-3 rounded-sm border border-line bg-inset p-2">
                    <textarea
                      value={noteDraft}
                      onChange={(e) => setNoteDraft(e.target.value)}
                      rows={3}
                      placeholder={closed ? 'Post-closure remark…' : 'Append investigator note…'}
                      className="w-full resize-none bg-transparent px-1 font-sans text-[12px] text-primary placeholder:text-muted focus:outline-none"
                    />
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[9px] text-muted">APPEND-ONLY · NO EDIT / DELETE</span>
                      <SocButton className="h-7" disabled={noteDraft.trim().length === 0} onClick={appendNote}>
                        Append note
                      </SocButton>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          </div>

          {/* sticky footer */}
          <div className="sticky bottom-0 z-10 border-t border-line-strong bg-surface-solid px-5 py-3">
            <div className="flex items-center gap-3">
              {canOperate ? (
                <ExportEvidenceButton incidentId={incident.id} requestNonce={exportNonce} />
              ) : (
                <div className="flex h-8 flex-1 items-center justify-center gap-1.5 rounded-sm bg-raised px-3 font-sans text-[12px] font-semibold uppercase tracking-[0.02em] text-muted" title="Requires OPERATOR role">
                  <Lock size={12} /> Export evidence pack
                </div>
              )}
            </div>
            <div className="mt-1.5 font-mono text-[9px] text-muted">
              {custodyTrail.length} AUDIT ENTRIES · LAST ACTION {lastAction ? fmtTime(lastAction.created_at) : '—'} ·
              CHAIN-OF-CUSTODY VERIFIED
            </div>
          </div>

          {/* gated transition popover */}
          {confirm && (
            <div className="absolute inset-0 z-30">
              <StatusConfirm
                request={confirm}
                caseNo={incident.case_no}
                onConfirm={(value) => {
                  onStatusChange(confirm.incidentId, confirm.target, value);
                  setConfirm(null);
                }}
                onCancel={() => setConfirm(null)}
              />
            </div>
          )}
        </div>
      )}
    </SocDrawer>
  );
});
