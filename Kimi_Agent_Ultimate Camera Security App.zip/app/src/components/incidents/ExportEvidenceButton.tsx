/**
 * ExportEvidenceButton — the acceptance-critical evidence-pack flow
 * (incidents.md §4). Click → GSAP progress sequence through four build
 * steps → exportEvidencePack() composes + downloads the multi-page PDF →
 * success check state + toast. The hooks-layer mutation writes the audit
 * entry itself.
 */
import { memo, useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { Check, FileDown } from 'lucide-react';
import { exportEvidencePack } from '@/hooks/useData';
import { showToast } from '@/components/soc';
import { cn } from '@/lib/utils';

const STEPS = ['Collecting timeline', 'Rendering plate table', 'Embedding evidence', 'Signing audit excerpt'] as const;

type Phase = 'idle' | 'working' | 'done';

export const ExportEvidenceButton = memo(function ExportEvidenceButton({
  incidentId,
  /** bump to trigger the same flow from elsewhere (timeline EXPORT → link) */
  requestNonce = 0,
}: {
  incidentId: string;
  requestNonce?: number;
}) {
  const [phase, setPhase] = useState<Phase>('idle');
  const [step, setStep] = useState(0);
  const [pct, setPct] = useState(0);
  const barRef = useRef<HTMLSpanElement>(null);
  const tlRef = useRef<gsap.core.Timeline | null>(null);
  const runningRef = useRef(false);
  const lastNonce = useRef(requestNonce);

  useEffect(
    () => () => {
      tlRef.current?.kill();
    },
    [],
  );

  const run = () => {
    if (runningRef.current) return;
    runningRef.current = true;
    setPhase('working');
    setStep(0);
    setPct(0);
    const prog = { v: 0 };
    const tl = gsap.timeline({
      onComplete: () => {
        let ok = false;
        let file = '';
        try {
          const res = exportEvidencePack(incidentId);
          ok = res.ok;
          file = res.file;
        } catch (err) {
          console.error('[evidence-pack]', err);
        }
        runningRef.current = false;
        if (ok) {
          setPhase('done');
          showToast({ severity: 'low', title: 'Evidence pack exported — logged to audit', body: file });
          setTimeout(() => setPhase('idle'), 1800);
        } else {
          setPhase('idle');
          setPct(0);
          showToast({ severity: 'high', title: 'Export failed', body: 'Case data unavailable in current scope.' });
        }
      },
    });
    STEPS.forEach((_, i) => {
      tl.call(() => setStep(i));
      tl.to(prog, {
        v: (i + 1) / STEPS.length,
        duration: 0.3,
        ease: 'power1.inOut',
        onUpdate: () => {
          setPct(Math.round(prog.v * 100));
          if (barRef.current) barRef.current.style.transform = `scaleX(${prog.v})`;
        },
      });
    });
    tlRef.current = tl;
  };

  /* external trigger (timeline tab EXPORT →) */
  useEffect(() => {
    if (requestNonce !== lastNonce.current) {
      lastNonce.current = requestNonce;
      run();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [requestNonce]);

  if (phase === 'working') {
    return (
      <div className="flex h-8 flex-1 items-center gap-2 rounded-sm border border-accent/40 bg-accent-dim px-3">
        <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.06em] text-accent">
          Generating… {pct}%
        </span>
        <span className="relative h-0.5 min-w-0 flex-1 overflow-hidden rounded-full bg-raised">
          <span
            ref={barRef}
            className="absolute inset-0 origin-left rounded-full bg-accent"
            style={{ transform: 'scaleX(0)' }}
          />
        </span>
        <span key={step} className="w-36 truncate text-right font-mono text-[9px] text-muted">
          {STEPS[step]}
        </span>
      </div>
    );
  }

  if (phase === 'done') {
    return (
      <div className="flex h-8 flex-1 items-center justify-center gap-1.5 rounded-sm bg-accent px-3 font-sans text-[12px] font-semibold uppercase tracking-[0.02em] text-on-accent">
        <Check size={14} strokeWidth={3} /> Pack exported
      </div>
    );
  }

  return (
    <button
      onClick={run}
      className={cn(
        'flex h-8 flex-1 items-center justify-center gap-1.5 rounded-sm bg-accent px-3 font-sans text-[12px] font-semibold uppercase tracking-[0.02em] text-on-accent',
        'transition-all duration-100 hover:brightness-110 hover:-translate-y-px active:scale-[0.97]',
      )}
    >
      <FileDown size={14} /> Export evidence pack
    </button>
  );
});
