/**
 * NewCaseModal — create a case from scratch or from alerts/plate reads
 * (incidents.md §3). Link picker: searchable multi-select of open alerts
 * and recent hotlist plate reads; selections render as removable chips.
 */
import { memo, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, Search, X } from 'lucide-react';
import type { Alert, Camera, IncidentPriority, PlateRead } from '@/lib/types';
import { createIncident, useCameras, useGuards } from '@/hooks/useData';
import type { Incident } from '@/lib/types';
import {
  GhostButton,
  PlateChip,
  SeverityBadge,
  SocButton,
  SocInput,
  SocModal,
  alertTypeIcon,
  showToast,
} from '@/components/soc';
import { relTime } from '@/lib/format';
import { cn } from '@/lib/utils';

const PRIORITIES: IncidentPriority[] = ['critical', 'high', 'medium', 'low'];

export const NewCaseModal = memo(function NewCaseModal({
  open,
  onClose,
  openAlerts,
  hotlistReads,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  openAlerts: Alert[];
  hotlistReads: PlateRead[];
  onCreated: (inc: Incident) => void;
}) {
  const cameras = useCameras();
  const guards = useGuards();
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<IncidentPriority>('medium');
  const [investigator, setInvestigator] = useState('Estate Manager');
  const [summary, setSummary] = useState('');
  const [alertQuery, setAlertQuery] = useState('');
  const [plateQuery, setPlateQuery] = useState('');
  const [selAlerts, setSelAlerts] = useState<string[]>([]);
  const [selReads, setSelReads] = useState<string[]>([]);
  const [creating, setCreating] = useState(false);

  const camById = useMemo(() => new Map(cameras.map((c) => [c.id, c])), [cameras]);

  const filteredAlerts = useMemo(() => {
    const q = alertQuery.toLowerCase();
    return openAlerts
      .filter((a) => !q || a.title.toLowerCase().includes(q) || a.source_name.toLowerCase().includes(q))
      .slice(0, 8);
  }, [openAlerts, alertQuery]);

  const filteredReads = useMemo(() => {
    const q = plateQuery.toUpperCase().replace(/\s+/g, '');
    return hotlistReads
      .filter((r) => !q || r.plate.replace(/\s+/g, '').includes(q))
      .slice(0, 8);
  }, [hotlistReads, plateQuery]);

  const reset = () => {
    setTitle('');
    setPriority('medium');
    setInvestigator('Estate Manager');
    setSummary('');
    setAlertQuery('');
    setPlateQuery('');
    setSelAlerts([]);
    setSelReads([]);
    setCreating(false);
  };

  const toggle = (list: string[], set: (v: string[]) => void, id: string) =>
    set(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

  const canCreate = title.trim().length >= 6 && !creating;

  const submit = () => {
    if (!canCreate) return;
    setCreating(true);
    const inc = createIncident({
      title: title.trim(),
      priority,
      assigned_investigator: investigator,
      summary: summary.trim() || `Case opened by ${investigator}. ${selAlerts.length} alert(s), ${selReads.length} plate sighting(s) linked at creation.`,
      linked_alert_ids: selAlerts,
      linked_plate_reads: selReads,
    });
    /* button morph → check, then close + spring card onto the board */
    setTimeout(() => {
      showToast({ severity: 'low', title: `Case ${inc.case_no} opened`, body: inc.title });
      onCreated(inc);
      reset();
      onClose();
    }, 450);
  };

  const selAlertObjs = openAlerts.filter((a) => selAlerts.includes(a.id));
  const selReadObjs = hotlistReads.filter((r) => selReads.includes(r.id));

  return (
    <SocModal open={open} onClose={onClose} title="New case" maxWidth={560}>
      <div className="max-h-[72vh] space-y-3 overflow-y-auto p-5">
        {/* title */}
        <div>
          <div className="mb-1 font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">Title</div>
          <SocInput
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Hotlisted silver VW Polo circling Lakeside perimeter"
          />
          {title.length > 0 && title.trim().length < 6 && (
            <div className="mt-0.5 font-mono text-[9px] text-warning">Title too short — give the case a workable name.</div>
          )}
        </div>

        {/* priority + investigator */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="mb-1 font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">Priority</div>
            <div className="flex flex-wrap gap-1">
              {PRIORITIES.map((p) => (
                <button
                  key={p}
                  onClick={() => setPriority(p)}
                  className={cn('rounded-sm transition-all', priority === p ? 'ring-1 ring-accent' : 'opacity-55 hover:opacity-90')}
                >
                  <SeverityBadge severity={p} />
                </button>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-1 font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">Investigator</div>
            <select
              value={investigator}
              onChange={(e) => setInvestigator(e.target.value)}
              className="h-8 w-full rounded-sm border border-line bg-inset px-2 font-sans text-[12px] text-primary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent-dim"
            >
              <option>Estate Manager</option>
              <option>T. Mokoena</option>
              {guards.map((g) => (
                <option key={g.id}>{g.full_name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* summary */}
        <div>
          <div className="mb-1 font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">Summary</div>
          <textarea
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            rows={3}
            placeholder="What happened, why it matters, first investigative steps…"
            className="w-full resize-none rounded-sm border border-line bg-inset px-2.5 py-2 font-sans text-[12px] text-primary placeholder:text-muted focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent-dim"
          />
        </div>

        {/* selected chips */}
        {(selAlertObjs.length > 0 || selReadObjs.length > 0) && (
          <div className="flex flex-wrap gap-1">
            <AnimatePresence initial={false}>
              {selAlertObjs.map((a) => (
                <motion.span
                  key={a.id}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  className="flex items-center gap-1 rounded-sm border border-line-strong bg-raised px-1.5 py-0.5 font-sans text-[10px] text-secondary"
                >
                  <span className="max-w-[180px] truncate">{a.title}</span>
                  <button onClick={() => setSelAlerts(selAlerts.filter((x) => x !== a.id))} className="text-muted hover:text-danger">
                    <X size={10} />
                  </button>
                </motion.span>
              ))}
              {selReadObjs.map((r) => (
                <motion.span
                  key={r.id}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  className="flex items-center gap-1 rounded-sm border border-line-strong bg-raised px-1.5 py-0.5"
                >
                  <PlateChip plate={r.plate} small hot={r.hotlist_hit} />
                  <button onClick={() => setSelReads(selReads.filter((x) => x !== r.id))} className="text-muted hover:text-danger">
                    <X size={10} />
                  </button>
                </motion.span>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* link pickers */}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-sm border border-line">
            <div className="flex items-center gap-1.5 border-b border-line px-2 py-1.5">
              <Search size={11} className="text-muted" />
              <input
                value={alertQuery}
                onChange={(e) => setAlertQuery(e.target.value)}
                placeholder="Link open alerts…"
                className="h-5 w-full bg-transparent font-sans text-[11px] text-primary placeholder:text-muted focus:outline-none"
              />
            </div>
            <div className="max-h-40 overflow-y-auto">
              {filteredAlerts.length === 0 && (
                <div className="px-2 py-3 font-mono text-[10px] text-muted">No matching open alerts.</div>
              )}
              {filteredAlerts.map((a) => {
                const Icon = alertTypeIcon(a.type);
                const on = selAlerts.includes(a.id);
                return (
                  <button
                    key={a.id}
                    onClick={() => toggle(selAlerts, setSelAlerts, a.id)}
                    className={cn(
                      'relative flex w-full items-center gap-2 border-b border-line/50 py-1.5 pl-3 pr-2 text-left transition-colors last:border-0 hover:bg-raised',
                      on && 'bg-accent-dim/40',
                    )}
                  >
                    <span
                      className={cn(
                        'absolute left-0 top-0 bottom-0 w-0.5',
                        a.severity === 'critical' ? 'bg-danger' : a.severity === 'high' ? 'bg-warning' : a.severity === 'medium' ? 'bg-info' : 'bg-severity-low',
                      )}
                    />
                    <Icon size={12} className="shrink-0 text-muted" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-sans text-[11px] text-primary">{a.title}</span>
                      <span className="block font-mono text-[9px] text-muted">
                        {a.severity.toUpperCase()} · {relTime(a.created_at)}
                      </span>
                    </span>
                    {on && <Check size={12} className="shrink-0 text-accent" />}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-sm border border-line">
            <div className="flex items-center gap-1.5 border-b border-line px-2 py-1.5">
              <Search size={11} className="text-muted" />
              <input
                value={plateQuery}
                onChange={(e) => setPlateQuery(e.target.value)}
                placeholder="Link hotlist plates…"
                className="h-5 w-full bg-transparent font-mono text-[11px] uppercase text-primary placeholder:normal-case placeholder:text-muted focus:outline-none"
              />
            </div>
            <div className="max-h-40 overflow-y-auto">
              {filteredReads.length === 0 && (
                <div className="px-2 py-3 font-mono text-[10px] text-muted">No matching hotlist reads.</div>
              )}
              {filteredReads.map((r) => {
                const on = selReads.includes(r.id);
                const cam: Camera | undefined = camById.get(r.camera_id);
                return (
                  <button
                    key={r.id}
                    onClick={() => toggle(selReads, setSelReads, r.id)}
                    className={cn(
                      'flex w-full items-center gap-2 border-b border-line/50 px-2 py-1.5 text-left transition-colors last:border-0 hover:bg-raised',
                      on && 'bg-accent-dim/40',
                    )}
                  >
                    <PlateChip plate={r.plate} small hot={r.hotlist_hit} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-mono text-[9px] text-muted">
                        {cam?.name ?? r.camera_id} · {relTime(r.captured_at)}
                      </span>
                    </span>
                    {on && <Check size={12} className="shrink-0 text-accent" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* footer */}
      <div className="flex items-center gap-2 border-t border-line-strong px-5 py-3">
        <SocButton onClick={submit} disabled={!canCreate} className={cn('min-w-[140px]', creating && 'pointer-events-none')}>
          {creating ? (
            <span className="inline-flex items-center gap-1.5">
              <Check size={13} /> Case opened
            </span>
          ) : (
            'Create case'
          )}
        </SocButton>
        <GhostButton onClick={onClose}>Cancel</GhostButton>
        <span className="ml-auto font-mono text-[9px] text-muted">
          {selAlerts.length} ALERTS · {selReads.length} SIGHTINGS LINKED
        </span>
      </div>
    </SocModal>
  );
});
