/**
 * StatusConfirm — inline popover for gated case status transitions
 * (incidents.md §2/§4): CLOSED requires a disposition, ESCALATED_SAPS
 * requires a SAPS reference. Rendered near the drop/click point.
 */
import { memo, useState } from 'react';
import { motion } from 'framer-motion';
import type { IncidentStatus } from '@/lib/types';
import { SocButton, GhostButton } from '@/components/soc';
import { cn } from '@/lib/utils';

export const DISPOSITIONS = [
  'Suspect apprehended',
  'Vehicle recovered',
  'Referred to SAPS',
  'Insufficient evidence',
  'Duplicate',
] as const;

export interface StatusConfirmRequest {
  target: IncidentStatus;
  /** position within the relatively-positioned host container */
  x: number;
  y: number;
}

export const StatusConfirm = memo(function StatusConfirm({
  request,
  caseNo,
  onConfirm,
  onCancel,
}: {
  request: StatusConfirmRequest;
  caseNo: string;
  /** disposition for closed, SAPS reference for escalated_saps */
  onConfirm: (value: string) => void;
  onCancel: () => void;
}) {
  const isClose = request.target === 'closed';
  const [disposition, setDisposition] = useState<string>(DISPOSITIONS[0]);
  const [sapsRef, setSapsRef] = useState('');

  const valid = isClose ? Boolean(disposition) : sapsRef.trim().length >= 4;

  return (
    <>
      <div className="absolute inset-0 z-30" onClick={onCancel} />
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.12 }}
        className="absolute z-40 w-[280px] rounded-sm border border-line-strong bg-surface-solid p-3 shadow-drawer"
        style={{
          left: `min(max(8px, ${request.x}px), calc(100% - 288px))`,
          top: `min(max(8px, ${request.y}px), calc(100% - 200px))`,
        }}
      >
        <div
          className={cn(
            'font-mono text-[10px] font-semibold uppercase tracking-[0.1em]',
            isClose ? 'text-accent' : 'text-danger',
          )}
        >
          {isClose ? `Close ${caseNo}` : `Escalate ${caseNo} to SAPS`}
        </div>

        {isClose ? (
          <div className="mt-2 space-y-1">
            <div className="font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">
              Disposition (required)
            </div>
            {DISPOSITIONS.map((d) => (
              <button
                key={d}
                onClick={() => setDisposition(d)}
                className={cn(
                  'flex w-full items-center gap-2 rounded-sm border px-2 py-1 text-left font-sans text-[11px] transition-colors',
                  disposition === d
                    ? 'border-accent/40 bg-accent-dim text-accent'
                    : 'border-line text-secondary hover:bg-raised',
                )}
              >
                <span className={cn('h-1.5 w-1.5 rounded-full', disposition === d ? 'bg-accent' : 'bg-muted')} />
                {d}
              </button>
            ))}
          </div>
        ) : (
          <div className="mt-2">
            <div className="font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">
              SAPS case reference (required)
            </div>
            <input
              autoFocus
              value={sapsRef}
              onChange={(e) => setSapsRef(e.target.value)}
              placeholder="CAS 112/03/2026"
              className="mt-1 h-8 w-full rounded-sm border border-line bg-inset px-2.5 font-mono text-[12px] text-primary placeholder:text-muted focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent-dim"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && valid) onConfirm(sapsRef.trim());
              }}
            />
            <div className="mt-1 font-mono text-[9px] text-muted">
              Reference is written to the case notes and audit trail.
            </div>
          </div>
        )}

        <div className="mt-3 flex items-center gap-2">
          <SocButton className="h-7 flex-1" disabled={!valid} onClick={() => onConfirm(isClose ? disposition : sapsRef.trim())}>
            {isClose ? 'Confirm close' : 'Confirm escalation'}
          </SocButton>
          <GhostButton className="h-7" onClick={onCancel}>
            Cancel
          </GhostButton>
        </div>
      </motion.div>
    </>
  );
});
