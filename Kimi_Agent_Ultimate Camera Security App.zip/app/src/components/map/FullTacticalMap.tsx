/**
 * FullTacticalMap — full-viewport tactical map for `/map` (map.md §1/§6).
 * Composes the shared map conventions (geometry, FOV cones, trails, severity hex)
 * with page-only extras: ALPR gate layer, zone-label layer, alert heat layer,
 * LIVE/REPLAY marker sets, entity inspector with quick actions, focus deep-links,
 * zoom controls, compass and scale bar.
 */
import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Minus, Plus, RotateCcw, X } from 'lucide-react';
import type { Alert, Camera } from '@/lib/types';
import {
  acknowledgeAlert, useActiveOrgId, useAlerts, useAudioSensors, useCameras, useCanOperate, useDrones, useGuards,
} from '@/hooks/useData';
import { OPEN_STATUSES } from '@/lib/store';
import { getTenantGeometry } from '@/lib/procedural';
import { fmtCoord, fmtHeartbeat, relTime } from '@/lib/format';
import { SEVERITY_HEX, StatusPill, showToast } from '@/components/soc';
import { GhostButton, IconButton, SocButton } from '@/components/soc/primitives';

export interface MapPageLayers {
  cameras: boolean;
  alprGates: boolean;
  drones: boolean;
  guards: boolean;
  audio: boolean;
  heat: boolean;
  zones: boolean;
  alerts: boolean;
}

export const DEFAULT_MAP_LAYERS: MapPageLayers = {
  cameras: true,
  alprGates: true,
  drones: true,
  guards: true,
  audio: true,
  heat: false,
  zones: true,
  alerts: true,
};

export type MapMode = 'live' | 'replay';

const CAM_HEX: Record<string, string> = {
  online: '#00D4AA', recording: '#00D4AA', motion: '#4CC9F0', degraded: '#FF9F1C', offline: '#E71D36',
};
const GUARD_HEX: Record<string, string> = { on_duty: '#00D4AA', responding: '#FF9F1C', on_break: '#4CC9F0', off_duty: '#5C6B8A' };

interface Selection {
  kind: 'camera' | 'drone' | 'guard' | 'alert' | 'sensor';
  id: string;
}

const Fov = memo(function Fov({ x, y, heading, len, tint }: { x: number; y: number; heading: number; len: number; tint?: string }) {
  const half = 30;
  const rad = (d: number) => ((d - 90) * Math.PI) / 180;
  const x1 = x + Math.cos(rad(heading - half)) * len;
  const y1 = y + Math.sin(rad(heading - half)) * len;
  const x2 = x + Math.cos(rad(heading + half)) * len;
  const y2 = y + Math.sin(rad(heading + half)) * len;
  return (
    <path
      d={`M ${x} ${y} L ${x1} ${y1} A ${len} ${len} 0 0 1 ${x2} ${y2} Z`}
      fill={tint ?? 'rgba(0,212,170,0.08)'}
      stroke={tint ? 'rgba(231,29,54,0.30)' : 'rgba(0,212,170,0.20)'}
      strokeWidth="1"
    />
  );
});

export const FullTacticalMap = memo(function FullTacticalMap({
  layers,
  mode,
  replayAt,
  focusId,
  onFocusDone,
}: {
  layers: MapPageLayers;
  mode: MapMode;
  replayAt: number | null;
  focusId: string | null;
  onFocusDone: () => void;
}) {
  const navigate = useNavigate();
  const canOperate = useCanOperate();
  const orgId = useActiveOrgId();
  const cameras = useCameras();
  const drones = useDrones();
  const guards = useGuards();
  const alerts = useAlerts();
  const sensors = useAudioSensors();

  const geo = useMemo(() => getTenantGeometry(orgId), [orgId]);
  const [view, setView] = useState({ k: 1, px: 0, py: 0 });
  const [cursor, setCursor] = useState<{ lat: number; lng: number } | null>(null);
  const [sel, setSel] = useState<Selection | null>(null);
  const [focusPing, setFocusPing] = useState<{ x: number; y: number; key: number } | null>(null);
  const [rect, setRect] = useState({ w: 1000, h: 620 });
  const dragRef = useRef<{ startX: number; startY: number; px: number; py: number; moved: boolean } | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      const r = el.getBoundingClientRect();
      setRect({ w: r.width, h: r.height });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const replay = mode === 'replay' && replayAt !== null;
  const windowEnd = replay ? replayAt : Date.now();
  const windowStart = windowEnd - 2 * 3600_000;

  const openAlerts = useMemo(() => alerts.filter((a) => OPEN_STATUSES.has(a.status)), [alerts]);
  const windowAlerts = useMemo(
    () =>
      alerts.filter((a) => {
        const t = new Date(a.created_at).getTime();
        return t >= windowStart && t <= windowEnd;
      }),
    [alerts, windowStart, windowEnd],
  );
  const heatAlerts = useMemo(() => windowAlerts.filter((a) => a.severity !== 'low'), [windowAlerts]);
  // markers actually drawn for the alert layer
  const visibleAlerts = replay ? windowAlerts : openAlerts;

  const hotCameraIds = useMemo(
    () => new Set(openAlerts.filter((a) => a.type === 'hotlist_hit').map((a) => a.source_id)),
    [openAlerts],
  );

  /* ── pan / zoom ──────────────────────────────────────────────────────── */
  const zoomTo = useCallback((k2: number, cx?: number, cy?: number) => {
    setView((v) => {
      const k = Math.min(3, Math.max(0.6, k2));
      if (cx === undefined || cy === undefined) return { ...v, k };
      return { k, px: cx - ((cx - v.px) / v.k) * k, py: cy - ((cy - v.py) / v.k) * k };
    });
  }, []);

  const toLocal = useCallback((clientX: number, clientY: number) => {
    const r = wrapRef.current?.getBoundingClientRect();
    if (!r) return { x: 0, y: 0 };
    return { x: clientX - r.left, y: clientY - r.top };
  }, []);

  const onWheel = useCallback(
    (e: React.WheelEvent) => {
      const l = toLocal(e.clientX, e.clientY);
      zoomTo(view.k * (e.deltaY < 0 ? 1.15 : 1 / 1.15), l.x, l.y);
    },
    [toLocal, view.k, zoomTo],
  );

  /* ── focus deep-link (?focus=<entityId>) ─────────────────────────────── */
  useEffect(() => {
    if (!focusId) return;
    const cam = cameras.find((c) => c.id === focusId);
    const drone = drones.find((d) => d.id === focusId);
    const guard = guards.find((g) => g.id === focusId);
    const alert = alerts.find((a) => a.id === focusId);
    const sensor = sensors.find((s) => s.id === focusId);
    const lat = cam?.lat ?? drone?.lat ?? guard?.lat ?? alert?.lat ?? sensor?.lat;
    const lng = cam?.lng ?? drone?.lng ?? guard?.lng ?? alert?.lng ?? sensor?.lng;
    if (lat === undefined || lng === undefined) {
      onFocusDone();
      return;
    }
    const p = geo.project(lat, lng);
    const k = 2.2;
    setView({ k, px: rect.w / 2 - p.x * k, py: rect.h / 2 - p.y * k });
    setFocusPing({ x: p.x, y: p.y, key: Date.now() });
    if (cam) setSel({ kind: 'camera', id: cam.id });
    else if (drone) setSel({ kind: 'drone', id: drone.id });
    else if (guard) setSel({ kind: 'guard', id: guard.id });
    else if (alert) setSel({ kind: 'alert', id: alert.id });
    else if (sensor) setSel({ kind: 'sensor', id: sensor.id });
    onFocusDone();
  }, [focusId, cameras, drones, guards, alerts, sensors, geo, rect.w, rect.h, onFocusDone]);

  /* ── selection / inspector ───────────────────────────────────────────── */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSel(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const selEntity = useMemo(() => {
    if (!sel) return null;
    if (sel.kind === 'camera') {
      const c = cameras.find((x) => x.id === sel.id);
      if (!c) return null;
      const p = geo.project(c.lat, c.lng);
      return {
        kind: sel.kind, id: c.id, title: c.name, status: c.status, p,
        rows: [
          ['ZONE', c.zone],
          ['RES', `${c.resolution}@${c.fps}`],
          ['HEARTBEAT', fmtHeartbeat(c.last_heartbeat)],
          ['STORAGE', `${Math.round(c.storage_used_pct)}%`],
        ] as [string, string][],
        viewTo: c.kind === 'fixed_alpr' ? '/alpr' : '/cameras',
        quick: c.ptz_enabled ? { label: 'Take control', to: '/operations' } : null,
      };
    }
    if (sel.kind === 'drone') {
      const d = drones.find((x) => x.id === sel.id);
      if (!d) return null;
      const p = geo.project(d.lat, d.lng);
      return {
        kind: sel.kind, id: d.id, title: d.callsign, status: d.status, p,
        rows: [
          ['BATTERY', `${Math.round(d.battery_pct)}%`],
          ['ALT', `${Math.round(d.altitude_m)}m`],
          ['SPEED', `${d.speed_mps.toFixed(1)} m/s`],
          ['WAYPOINT', `${d.current_waypoint + 1}/${d.waypoints.length}`],
        ] as [string, string][],
        viewTo: '/operations',
        quick: null,
      };
    }
    if (sel.kind === 'guard') {
      const g = guards.find((x) => x.id === sel.id);
      if (!g) return null;
      const p = geo.project(g.lat, g.lng);
      return {
        kind: sel.kind, id: g.id, title: g.full_name, status: g.status, p,
        rows: [
          ['BADGE', g.badge_no],
          ['SHIFT', g.shift.toUpperCase()],
          ['RESOLVED', String(g.alerts_resolved)],
          ['AVG RESP', `${Math.round(g.avg_response_sec)}s`],
        ] as [string, string][],
        viewTo: '/operations',
        quick: { label: 'Dispatch', to: '/operations' },
      };
    }
    if (sel.kind === 'sensor') {
      const s = sensors.find((x) => x.id === sel.id);
      if (!s) return null;
      const p = geo.project(s.lat, s.lng);
      return {
        kind: sel.kind, id: s.id, title: s.name, status: s.status, p,
        rows: [
          ['ZONE', s.zone],
          ['RADIUS', `${s.triangulation_radius_m}m`],
          ['POS', fmtCoord(s.lat, s.lng)],
        ] as [string, string][],
        viewTo: '/operations',
        quick: null,
      };
    }
    const a = alerts.find((x) => x.id === sel.id);
    if (!a) return null;
    const p = geo.project(a.lat, a.lng);
    return {
      kind: sel.kind, id: a.id, title: a.title, status: a.status, p, alert: a,
      rows: [
        ['SEVERITY', a.severity.toUpperCase()],
        ['SOURCE', a.source_name],
        ['AGE', relTime(a.created_at)],
        ['CONF', `${Math.round(a.ai_confidence * 100)}%`],
      ] as [string, string][],
      viewTo: '/alerts',
      quick: null,
    };
  }, [sel, cameras, drones, guards, sensors, alerts, geo]);

  const anchor = selEntity ? { x: selEntity.p.x * view.k + view.px, y: selEntity.p.y * view.k + view.py } : null;

  /* ── scale bar ───────────────────────────────────────────────────────── */
  const scaleBar = useMemo(() => {
    const mPerUnit = (((geo.bbox.maxLat - geo.bbox.minLat) * 111320) / geo.height) * (geo.height / rect.h);
    const pxPerUnit = view.k;
    const candidates = [10, 25, 50, 100, 250, 500];
    for (const m of candidates) {
      const px = (m / mPerUnit) * pxPerUnit;
      if (px >= 48 && px <= 140) return { m, px };
    }
    return { m: 100, px: (100 / mPerUnit) * pxPerUnit };
  }, [geo, view.k, rect.h]);

  const smooth = { transition: 'transform 900ms linear' };
  const gateCams = cameras.filter((c) => c.kind === 'fixed_alpr');
  const stdCams = cameras.filter((c) => c.kind !== 'fixed_alpr');

  const clickCam = (c: Camera) => setSel({ kind: 'camera', id: c.id });

  const camGlyph = (c: Camera, gate: boolean) => {
    const p = geo.project(c.lat, c.lng);
    const offline = c.status === 'offline';
    const hex = CAM_HEX[c.status] ?? '#5C6B8A';
    const hot = hotCameraIds.has(c.id);
    return (
      <g key={c.id} style={smooth} opacity={offline ? 0.4 : 1}>
        <Fov x={p.x} y={p.y} heading={c.heading_deg} len={gate ? 78 : 52} tint={hot ? 'rgba(231,29,54,0.10)' : undefined} />
        {offline && (
          <text x={p.x + 9} y={p.y - 7} fontFamily='"JetBrains Mono", monospace' fontSize="8" fill="#E71D36">
            OFFLINE
          </text>
        )}
        {gate ? (
          <g
            className="cursor-pointer"
            onClick={(e) => {
              e.stopPropagation();
              clickCam(c);
            }}
          >
            <rect x={p.x - 5.5} y={p.y - 5.5} width={11} height={11} fill={hex} stroke={offline ? '#E71D36' : '#060D1A'} strokeWidth="1.4" />
            <line x1={p.x - 3} y1={p.y} x2={p.x + 3} y2={p.y} stroke="#04101F" strokeWidth="1.6" />
          </g>
        ) : (
          <rect
            x={p.x - 5} y={p.y - 5} width={10} height={10}
            transform={`rotate(45 ${p.x} ${p.y})`}
            fill={hex} stroke={offline ? '#E71D36' : '#060D1A'} strokeWidth="1.4"
            className="cursor-pointer"
            onClick={(e) => {
              e.stopPropagation();
              clickCam(c);
            }}
          />
        )}
      </g>
    );
  };

  return (
    <div
      ref={wrapRef}
      className="scan-grid relative h-full w-full select-none overflow-hidden bg-inset"
      onWheel={onWheel}
      onMouseDown={(e) => {
        dragRef.current = { startX: e.clientX, startY: e.clientY, px: view.px, py: view.py, moved: false };
      }}
      onMouseMove={(e) => {
        const l = toLocal(e.clientX, e.clientY);
        const sx = ((l.x - view.px) / view.k / rect.w) * geo.width;
        const sy = ((l.y - view.py) / view.k / rect.h) * geo.height;
        setCursor(geo.unproject(sx, sy));
        const d = dragRef.current;
        if (d) {
          if (Math.abs(e.clientX - d.startX) + Math.abs(e.clientY - d.startY) > 4) d.moved = true;
          setView((v) => ({ ...v, px: d.px + (e.clientX - d.startX), py: d.py + (e.clientY - d.startY) }));
        }
      }}
      onMouseUp={() => {
        if (dragRef.current && !dragRef.current.moved) setSel(null);
        dragRef.current = null;
      }}
      onMouseLeave={() => {
        dragRef.current = null;
        setCursor(null);
      }}
      onDoubleClick={(e) => {
        const l = toLocal(e.clientX, e.clientY);
        zoomTo(view.k * 1.4, l.x, l.y);
      }}
      role="application"
      aria-label="Full tactical map"
    >
      <svg viewBox={geo.viewBox} className="h-full w-full" preserveAspectRatio="xMidYMid meet" style={{ cursor: dragRef.current?.moved ? 'grabbing' : 'grab' }}>
        <defs>
          <radialGradient id="heat-critical">
            <stop offset="0%" stopColor="#E71D36" stopOpacity="0.30" />
            <stop offset="100%" stopColor="#E71D36" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="heat-high">
            <stop offset="0%" stopColor="#FF9F1C" stopOpacity="0.26" />
            <stop offset="100%" stopColor="#FF9F1C" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="heat-medium">
            <stop offset="0%" stopColor="#4CC9F0" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#4CC9F0" stopOpacity="0" />
          </radialGradient>
          <filter id="heat-blur" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="12" />
          </filter>
        </defs>
        <g
          style={{
            transform: `translate(${view.px}px, ${view.py}px) scale(${view.k})`,
            transformOrigin: '0 0',
            transition: dragRef.current ? 'none' : 'transform 200ms ease-out',
          }}
        >
          {/* estate geometry */}
          {geo.water && <path d={geo.water} fill="rgba(76,201,240,0.06)" stroke="rgba(76,201,240,0.15)" strokeWidth="1" />}
          {geo.streets.map((d, i) => (
            <path key={i} d={d} fill="none" stroke="#1B2F52" strokeWidth={i === 0 ? 10 : 6} strokeLinecap="round" />
          ))}
          <path d={geo.boundary} fill="none" stroke="rgba(100,255,218,0.25)" strokeWidth="2" strokeDasharray="7 5">
            <animate attributeName="stroke-dashoffset" values="0;120" dur="20s" repeatCount="indefinite" />
          </path>
          {layers.zones &&
            geo.zones.map((z) => (
              <text key={z.label} x={z.x} y={z.y} fontFamily='"JetBrains Mono", monospace' fontSize="11" fill="#5C6B8A" letterSpacing="1.5">
                {z.label}
              </text>
            ))}
          {layers.zones && geo.waterLabel && (
            <text x={geo.waterLabel.x} y={geo.waterLabel.y} fontFamily='"JetBrains Mono", monospace' fontSize="10" fill="rgba(76,201,240,0.5)" letterSpacing="2">
              {geo.waterLabel.label}
            </text>
          )}

          {/* alert heat layer */}
          {layers.heat && (
            <g filter="url(#heat-blur)">
              {heatAlerts.map((a) => {
                const p = geo.project(a.lat, a.lng);
                const g = a.severity === 'critical' ? 'heat-critical' : a.severity === 'high' ? 'heat-high' : 'heat-medium';
                return <circle key={`h-${a.id}`} cx={p.x} cy={p.y} r={a.severity === 'critical' ? 60 : 44} fill={`url(#${g})`} />;
              })}
            </g>
          )}

          {/* audio sensors */}
          {layers.audio &&
            sensors.map((s) => {
              const p = geo.project(s.lat, s.lng);
              const r = (s.triangulation_radius_m / 111320 / (geo.bbox.maxLat - geo.bbox.minLat)) * geo.height;
              return (
                <g key={s.id} style={smooth} opacity={s.status === 'offline' ? 0.4 : 1}>
                  <circle cx={p.x} cy={p.y} r={r} fill="none" stroke="rgba(76,201,240,0.22)" strokeWidth="1" strokeDasharray="4 4" />
                  <circle cx={p.x} cy={p.y} r={r * 0.5} fill="none" stroke="rgba(76,201,240,0.14)" strokeWidth="1" strokeDasharray="3 4" />
                  <circle
                    cx={p.x} cy={p.y} r={3.2} fill="#4CC9F0" opacity="0.85" className="cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSel({ kind: 'sensor', id: s.id });
                    }}
                  />
                </g>
              );
            })}

          {/* cameras + FOV */}
          {layers.cameras && stdCams.map((c) => camGlyph(c, false))}
          {layers.alprGates && gateCams.map((c) => camGlyph(c, true))}

          {/* drones */}
          {layers.drones &&
            drones.map((d) => {
              const p = geo.project(d.lat, d.lng);
              const color = d.status === 'responding' ? '#E71D36' : '#4CC9F0';
              const trail = d.trail.map((t) => geo.project(t.lat, t.lng));
              const tgt =
                d.status === 'responding' && d.respond_target ? d.respond_target
                : d.status === 'returning' ? { lat: d.base_lat, lng: d.base_lng }
                : d.waypoints[d.current_waypoint];
              const tp = tgt ? geo.project(tgt.lat, tgt.lng) : null;
              return (
                <g key={d.id}>
                  {trail.length > 1 &&
                    trail.slice(0, -1).map((t, i) => (
                      <line key={i} x1={t.x} y1={t.y} x2={trail[i + 1].x} y2={trail[i + 1].y} stroke={color} strokeWidth="1.4" opacity={(i / trail.length) * 0.55} />
                    ))}
                  {tp && <line x1={p.x} y1={p.y} x2={tp.x} y2={tp.y} stroke={color} strokeWidth="1" strokeDasharray="3 4" opacity="0.5" />}
                  {replay && (
                    <text x={p.x + 10} y={p.y - 8} fontFamily='"JetBrains Mono", monospace' fontSize="8" fill="#5C6B8A">
                      STALE
                    </text>
                  )}
                  <g style={smooth}>
                    <polygon
                      points={`${p.x},${p.y - 6} ${p.x + 5.5},${p.y + 4.5} ${p.x - 5.5},${p.y + 4.5}`}
                      fill={color} stroke="#060D1A" strokeWidth="1.2" className="cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSel({ kind: 'drone', id: d.id });
                      }}
                    />
                  </g>
                </g>
              );
            })}

          {/* guards */}
          {layers.guards &&
            guards.map((g) => {
              const p = geo.project(g.lat, g.lng);
              const color = GUARD_HEX[g.status] ?? '#5C6B8A';
              const dest = g.dispatch_target ? geo.project(g.dispatch_target.lat, g.dispatch_target.lng) : null;
              return (
                <g key={g.id}>
                  {dest && <line x1={p.x} y1={p.y} x2={dest.x} y2={dest.y} stroke="#FF9F1C" strokeWidth="1.2" strokeDasharray="5 4" opacity="0.7" />}
                  {replay && (
                    <text x={p.x + 9} y={p.y - 8} fontFamily='"JetBrains Mono", monospace' fontSize="8" fill="#5C6B8A">
                      STALE
                    </text>
                  )}
                  <g style={smooth}>
                    <circle cx={p.x} cy={p.y} r={5.5} fill="none" stroke={color} strokeWidth="1.6" />
                    <circle
                      cx={p.x} cy={p.y} r={2.2} fill={color} className="cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSel({ kind: 'guard', id: g.id });
                      }}
                    />
                  </g>
                </g>
              );
            })}

          {/* alert markers (live = open alerts; replay = window history) */}
          {layers.alerts &&
            visibleAlerts.map((a) => {
              const p = geo.project(a.lat, a.lng);
              const color = SEVERITY_HEX[a.severity];
              const liveAtCursor = replay ? !a.resolved_at || new Date(a.resolved_at).getTime() > windowEnd : true;
              return (
                <g key={a.id}>
                  {liveAtCursor ? (
                    <circle cx={p.x} cy={p.y} r={replay ? 9.6 : 5} fill="none" stroke={color} strokeWidth="1.4">
                      <animate attributeName="r" values={replay ? '9.6;16' : '4;16'} dur="1.6s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="0.9;0" dur="1.6s" repeatCount="indefinite" />
                    </circle>
                  ) : (
                    <circle cx={p.x} cy={p.y} r={8} fill="none" stroke={color} strokeWidth="1" opacity="0.4" />
                  )}
                  <circle
                    cx={p.x} cy={p.y} r={3.4} fill={color} className="cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSel({ kind: 'alert', id: a.id });
                    }}
                  />
                </g>
              );
            })}

          {/* one-time focus ring */}
          {focusPing && (
            <circle key={focusPing.key} cx={focusPing.x} cy={focusPing.y} r={8} fill="none" stroke="#00D4AA" strokeWidth="2">
              <animate attributeName="r" values="8;40" dur="1s" repeatCount="3" />
              <animate attributeName="opacity" values="0.9;0" dur="1s" repeatCount="3" />
            </circle>
          )}
        </g>
      </svg>

      {/* REPLAY frame tint + tag */}
      {replay && (
        <>
          <div className="pointer-events-none absolute inset-0 border border-warning" />
          <div className="absolute left-1/2 top-2 z-10 -translate-x-1/2 rounded-sm border border-warning/50 bg-surface-solid/90 px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.2em] text-warning animate-live-pulse">
            Replay
          </div>
        </>
      )}

      {/* zoom controls */}
      <div className="absolute bottom-3 left-3 z-10 flex flex-col gap-1">
        <IconButton tooltip="Zoom in" className="border border-line bg-surface-solid/85 backdrop-blur-sm" onClick={() => zoomTo(view.k * 1.3)}>
          <Plus size={14} />
        </IconButton>
        <IconButton tooltip="Zoom out" className="border border-line bg-surface-solid/85 backdrop-blur-sm" onClick={() => zoomTo(view.k / 1.3)}>
          <Minus size={14} />
        </IconButton>
        <IconButton tooltip="Reset view" className="border border-line bg-surface-solid/85 backdrop-blur-sm" onClick={() => setView({ k: 1, px: 0, py: 0 })}>
          <RotateCcw size={13} />
        </IconButton>
      </div>

      {/* compass rose */}
      <div className="pointer-events-none absolute right-3 top-3 z-10 flex h-10 w-10 items-center justify-center rounded-sm border border-line bg-surface-solid/85 backdrop-blur-sm">
        <svg width="26" height="26" viewBox="0 0 26 26" aria-hidden>
          <polygon points="13,3 16,14 13,11.5 10,14" fill="#A8B2D1" />
          <text x="13" y="24" textAnchor="middle" fontFamily='"JetBrains Mono", monospace' fontSize="8" fill="#5C6B8A">
            N
          </text>
        </svg>
      </div>

      {/* scale bar + cursor coordinates */}
      <div className="absolute bottom-3 right-3 z-10 flex flex-col items-end gap-1">
        <div className="rounded-sm border border-line bg-surface-solid/85 px-2 py-1 backdrop-blur-sm">
          <div className="h-1 border-b border-l border-r border-secondary" style={{ width: Math.max(24, Math.min(140, scaleBar.px)) }} />
          <div className="mt-0.5 text-right font-mono text-[9px] text-muted">{scaleBar.m}m</div>
        </div>
        <div className="rounded-sm border border-line bg-surface-solid/85 px-2 py-1 font-mono text-[9px] text-muted backdrop-blur-sm">
          {cursor ? fmtCoord(cursor.lat, cursor.lng) : '— —'} · ZOOM {(view.k * 100).toFixed(0)}%
        </div>
      </div>

      {/* entity inspector */}
      <AnimatePresence>
        {selEntity && anchor && (
          <motion.div
            key={`${selEntity.kind}:${selEntity.id}`}
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute z-20 w-[260px] rounded-sm border border-line-strong bg-surface-solid p-3 shadow-drawer"
            style={{
              left: `min(max(8px, ${anchor.x + 14}px), calc(100% - 268px))`,
              top: `min(max(8px, ${anchor.y - 20}px), calc(100% - 230px))`,
              transformOrigin: 'left center',
            }}
          >
            {/* leader tick back toward the marker */}
            <span className="absolute -left-3 top-5 h-px w-3 bg-line-strong" />
            <div className="flex items-start justify-between gap-2">
              <span className="min-w-0 truncate font-sans text-[12px] font-semibold text-primary">{selEntity.title}</span>
              <div className="flex shrink-0 items-center gap-1">
                <StatusPill status={selEntity.status} />
                <button onClick={() => setSel(null)} className="text-muted hover:text-primary" title="Close (Esc)">
                  <X size={12} />
                </button>
              </div>
            </div>
            <div className="mt-2 space-y-1">
              {selEntity.rows.map(([k, v]) => (
                <div key={k} className="flex justify-between font-mono text-[10px]">
                  <span className="text-muted">{k}</span>
                  <span className="text-secondary">{v}</span>
                </div>
              ))}
            </div>
            <div className="mt-2.5 flex items-center gap-2">
              <GhostButton className="h-6 px-2 text-[10px]" onClick={() => navigate(selEntity.viewTo)}>
                View →
              </GhostButton>
              {selEntity.kind === 'alert' && OPEN_STATUSES.has((selEntity as { alert?: Alert }).alert?.status ?? 'resolved') && (
                <SocButton
                  className="h-6 px-2 text-[10px]"
                  disabled={!canOperate}
                  tooltip={canOperate ? 'Acknowledge this alert' : 'Requires OPERATOR role'}
                  onClick={() => {
                    acknowledgeAlert(selEntity.id);
                    showToast({ severity: 'low', title: 'Alert acknowledged', body: selEntity.title });
                  }}
                >
                  Acknowledge
                </SocButton>
              )}
              {selEntity.quick && (
                <GhostButton className="h-6 px-2 text-[10px]" onClick={() => navigate(selEntity.quick!.to)}>
                  {selEntity.quick.label}
                </GhostButton>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
});
