/**
 * TimeScrubber — 2h replay timeline bar (map.md §5).
 * Severity-colored alert ticks, draggable playhead, 1×/10×/30×/60× playback,
 * LIVE jump-to-now. Collapses to a hint bar while the map is in LIVE mode.
 */
import { memo, useCallback, useEffect, useRef, useState } from 'react';
import { Pause, Play } from 'lucide-react';
import type { Alert } from '@/lib/types';
import { fmtTime } from '@/lib/format';
import { SEVERITY_HEX, showToast } from '@/components/soc';
import { GhostButton, IconButton } from '@/components/soc/primitives';
import { cn } from '@/lib/utils';

const SPEEDS = [1, 10, 30, 60] as const;

export const TimeScrubber = memo(function TimeScrubber({
  active,
  offsetSec,
  onOffsetChange,
  alerts,
  windowSec = 7200,
}: {
  active: boolean;
  offsetSec: number;
  onOffsetChange: (sec: number) => void;
  alerts: Alert[];
  windowSec?: number;
}) {
  const [playing, setPlaying] = useState(false);
  const [speedIdx, setSpeedIdx] = useState(2); // 30×
  const trackRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const edgeToasted = useRef<number>(0);
  const raf = useRef<number>(0);
  const lastT = useRef<number>(0);
  const offsetRef = useRef(offsetSec);
  offsetRef.current = offsetSec;

  const clamp = useCallback((s: number) => Math.min(0, Math.max(-windowSec, Math.round(s))), [windowSec]);

  const edgeToast = useCallback((msg: string) => {
    if (Date.now() - edgeToasted.current < 3000) return;
    edgeToasted.current = Date.now();
    showToast({ severity: 'medium', title: msg });
  }, []);

  /* playback loop */
  useEffect(() => {
    if (!playing) return;
    lastT.current = performance.now();
    const tick = (t: number) => {
      const dt = (t - lastT.current) / 1000;
      lastT.current = t;
      const next = offsetRef.current + dt * SPEEDS[speedIdx];
      if (next >= 0) {
        onOffsetChange(0);
        setPlaying(false);
        return;
      }
      onOffsetChange(clamp(next));
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [playing, speedIdx, clamp, onOffsetChange]);

  useEffect(() => {
    if (!active) setPlaying(false);
  }, [active]);

  const seekFromClient = useCallback(
    (clientX: number) => {
      const r = trackRef.current?.getBoundingClientRect();
      if (!r) return;
      const frac = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
      const next = clamp(-(1 - frac) * windowSec);
      if (next <= -windowSec) edgeToast('Start of replay window');
      onOffsetChange(next);
    },
    [clamp, edgeToast, onOffsetChange, windowSec],
  );

  if (!active) {
    return (
      <div className="flex h-7 shrink-0 items-center justify-center border-t border-line bg-surface backdrop-blur-sm">
        <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-muted">
          Replay available — switch mode to scrub the last 2 hours
        </span>
      </div>
    );
  }

  const now = Date.now();
  const scrubTime = now + offsetSec * 1000;
  const minAgo = Math.round(-offsetSec / 60);
  const frac = 1 + offsetSec / windowSec; // 0..1 position of playhead

  const ticks = alerts
    .filter((a) => {
      const t = new Date(a.created_at).getTime();
      return t >= now - windowSec * 1000 && t <= now;
    })
    .map((a) => ({
      id: a.id,
      frac: (new Date(a.created_at).getTime() - (now - windowSec * 1000)) / (windowSec * 1000),
      color: SEVERITY_HEX[a.severity],
      tall: a.severity === 'critical',
      passed: new Date(a.created_at).getTime() <= scrubTime,
    }));

  return (
    <div className="flex h-16 shrink-0 items-center gap-3 border-t border-line bg-surface px-3 backdrop-blur-sm">
      {/* controls */}
      <div className="flex shrink-0 items-center gap-1.5">
        <IconButton
          tooltip={playing ? 'Pause playback' : 'Play (restarts at −2h from live edge)'}
          className="border border-line"
          onClick={() => {
            if (!playing && offsetSec === 0) onOffsetChange(-windowSec);
            setPlaying((p) => !p);
          }}
        >
          {playing ? <Pause size={14} /> : <Play size={14} />}
        </IconButton>
        <button
          onClick={() => setSpeedIdx((i) => (i + 1) % SPEEDS.length)}
          title="Cycle playback speed"
          className="h-7 w-11 rounded-sm border border-line bg-raised font-mono text-[10px] font-semibold text-secondary transition-colors hover:border-accent hover:text-accent"
        >
          {SPEEDS[speedIdx]}×
        </button>
        <GhostButton
          className="h-7 px-2 text-[10px]"
          onClick={() => {
            setPlaying(false);
            onOffsetChange(0);
          }}
        >
          Live ⏵
        </GhostButton>
      </div>

      {/* timeline track */}
      <div
        ref={trackRef}
        className="relative h-10 flex-1 cursor-crosshair rounded-sm border border-line bg-inset"
        onPointerDown={(e) => {
          dragging.current = true;
          e.currentTarget.setPointerCapture(e.pointerId);
          setPlaying(false);
          seekFromClient(e.clientX);
        }}
        onPointerMove={(e) => {
          if (dragging.current) seekFromClient(e.clientX);
        }}
        onPointerUp={() => {
          dragging.current = false;
        }}
      >
        {/* hour ticks */}
        {[0, 1, 2].map((h) => (
          <div key={h} className="absolute top-0 bottom-0" style={{ left: `${(h / 2) * 100}%` }}>
            <span className="absolute top-0 bottom-0 w-px bg-line-strong" />
            <span className="absolute bottom-0.5 left-1 font-mono text-[8px] text-muted">
              {h === 2 ? 'NOW' : `−${2 - h}H`}
            </span>
          </div>
        ))}
        {/* alert ticks */}
        {ticks.map((t) => (
          <span
            key={t.id}
            className={cn('absolute w-[2px] rounded-full transition-transform', t.passed && 'scale-y-110')}
            style={{
              left: `${t.frac * 100}%`,
              bottom: 8,
              height: t.tall ? 18 : 11,
              background: t.color,
              opacity: t.passed ? 0.95 : 0.4,
            }}
          />
        ))}
        {/* playhead */}
        <div className="absolute top-0 bottom-0" style={{ left: `${frac * 100}%` }}>
          <span className="absolute top-0 bottom-0 w-px bg-accent" />
          <span
            className={cn(
              'absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-accent bg-surface-solid',
              playing && 'animate-live-pulse',
            )}
          />
        </div>
      </div>

      {/* readout */}
      <div className="w-28 shrink-0 text-right">
        <div className="font-mono text-[12px] text-primary">{fmtTime(scrubTime)}</div>
        <div className="font-mono text-[9px] uppercase tracking-[0.08em] text-muted">
          {offsetSec === 0 ? 'LIVE EDGE' : `−${minAgo >= 60 ? `${Math.floor(minAgo / 60)}H ${minAgo % 60}M` : `${minAgo} MIN`}`}
        </div>
      </div>
    </div>
  );
});
