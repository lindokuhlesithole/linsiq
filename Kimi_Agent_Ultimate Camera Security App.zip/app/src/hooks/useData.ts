/**
 * SWEALTH OS — hooks contract (info.md §7).
 * ALL UI reads data through these hooks — never directly from the simulator.
 * Every hook scopes to the active org (`swealth.active_org_id`).
 * Every mutation writes an audit_log entry.
 */
import { useCallback, useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type {
  Alert,
  AlertFilter,
  AlertRoutingRule,
  Camera,
  CameraKind,
  HotlistEntry,
  HotlistPriority,
  Incident,
  Organization,
  PlateReadFilters,
  PtzAction,
  PtzCommand,
  RolePreview,
  ThreatLevel,
} from '@/lib/types';
import { deriveThreat, OPEN_STATUSES, store, useStoreSelector, writeAudit } from '@/lib/store';
import { getRealtimeSnapshot, resetSimulatorSession, setRealtimeRunning, subscribeRealtime } from '@/lib/simulator';
import type { OrgState } from '@/lib/seed';
import { fmtDateTime, fmtDurationSec, fmtTime } from '@/lib/format';

/* ── Org scoping ─────────────────────────────────────────────────────────── */

export function useActiveOrgId(): string {
  return useStoreSelector((s) => s.activeOrgId);
}

export function useOrgState(): OrgState {
  const orgId = useActiveOrgId();
  return useStoreSelector((s) => s.byOrg[orgId]);
}

export function useOrg(): Organization {
  const orgId = useActiveOrgId();
  return useStoreSelector((s) => s.orgs.find((o) => o.id === orgId) ?? s.orgs[0]);
}

export function useOrgs(): Organization[] {
  return useStoreSelector((s) => s.orgs);
}

/** Switch the active tenant (TopBar org switcher / sidebar tenant card). */
export function useOrgSwitch(): (orgId: string) => void {
  return useCallback((orgId: string) => {
    store.setActiveOrg(orgId);
    writeAudit(orgId, {
      actor: 'Estate Manager', action: 'org.switch', entity_kind: 'organization',
      entity_id: orgId, detail: 'Operator switched active tenant context',
    });
  }, []);
}

/* ── Entity hooks (stable slice references) ──────────────────────────────── */

export function useCameras(): Camera[] {
  return useOrgState().cameras;
}

export function useCamera(id: string | null | undefined): Camera | undefined {
  const cams = useCameras();
  return useMemo(() => cams.find((c) => c.id === id), [cams, id]);
}

export function useHotlists() {
  return useOrgState().hotlists;
}

export function useAudioEvents() {
  return useOrgState().audioEvents;
}

export function useAudioSensors() {
  return useOrgState().audioSensors;
}

export function useDrones() {
  return useOrgState().drones;
}

export function useGuards() {
  return useOrgState().guards;
}

export function useIncidents(): Incident[] {
  return useOrgState().incidents;
}

export function useAuditLog() {
  return useOrgState().auditLog;
}

export function useRoutingRules(): AlertRoutingRule[] {
  return useOrgState().routingRules;
}

export function usePtzCommands(): PtzCommand[] {
  return useOrgState().ptzCommands;
}

export function useEvidence() {
  return useOrgState().evidence;
}

/* ── Filtered hooks (memoized derivations) ───────────────────────────────── */

export function usePlateReads(filters?: PlateReadFilters) {
  const reads = useOrgState().plateReads;
  const fKey = JSON.stringify(filters ?? {});
  return useMemo(() => {
    const f = (filters ?? {}) as PlateReadFilters;
    let out = reads;
    if (f.cameraId) out = out.filter((r) => r.camera_id === f.cameraId);
    if (f.direction) out = out.filter((r) => r.direction === f.direction);
    if (f.hotlistOnly) out = out.filter((r) => r.hotlist_hit);
    if (f.sinceMs) {
      const cutoff = Date.now() - f.sinceMs;
      out = out.filter((r) => new Date(r.captured_at).getTime() >= cutoff);
    }
    if (f.plateQuery) {
      const q = f.plateQuery.toUpperCase().replace(/\s+/g, '');
      out = out.filter((r) => r.plate.replace(/\s+/g, '').includes(q));
    }
    if (f.limit) out = out.slice(0, f.limit);
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reads, fKey]);
}

export function useAlerts(filter?: AlertFilter): Alert[] {
  const alerts = useOrgState().alerts;
  const fKey = JSON.stringify(filter ?? {});
  return useMemo(() => {
    const f = (filter ?? {}) as AlertFilter;
    let out = alerts;
    if (f.severities?.length) out = out.filter((a) => f.severities!.includes(a.severity));
    if (f.statuses?.length) out = out.filter((a) => f.statuses!.includes(a.status));
    if (f.types?.length) out = out.filter((a) => f.types!.includes(a.type));
    if (f.openOnly) out = out.filter((a) => OPEN_STATUSES.has(a.status));
    if (f.sinceMs) {
      const cutoff = Date.now() - f.sinceMs;
      out = out.filter((a) => new Date(a.created_at).getTime() >= cutoff);
    }
    if (f.query) {
      const q = f.query.toLowerCase();
      out = out.filter((a) => a.title.toLowerCase().includes(q) || a.ai_summary.toLowerCase().includes(q));
    }
    if (f.limit) out = out.slice(0, f.limit);
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [alerts, fKey]);
}

export function useAlert(id: string | null | undefined): Alert | undefined {
  const alerts = useOrgState().alerts;
  return useMemo(() => alerts.find((a) => a.id === id), [alerts, id]);
}

/* ── Realtime status & clock ─────────────────────────────────────────────── */

export function useRealtimeStatus(): { running: boolean; lastTickAt: number; setRunning: (r: boolean) => void } {
  const snap = useSyncExternalStore(subscribeRealtime, getRealtimeSnapshot, getRealtimeSnapshot);
  return { ...snap, setRunning: setRealtimeRunning };
}

/** Wall-clock ticking once per second — isolate in small components. */
export function useClock(intervalMs: number = 1000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

/* ── Threat level (derived from open alerts, design.md §2.4) ─────────────── */

export function useThreatLevel(): ThreatLevel {
  const alerts = useOrgState().alerts;
  return useMemo(() => deriveThreat(alerts), [alerts]);
}

/* ── Role preview & mute ─────────────────────────────────────────────────── */

export function useRole(): RolePreview {
  return useStoreSelector((s) => s.role);
}

export function setRolePreview(role: RolePreview): void {
  store.setRole(role);
  writeAudit(store.getState().activeOrgId, {
    actor: 'Estate Manager', action: 'role.preview', entity_kind: 'system',
    entity_id: 'role', detail: `Role preview switched to ${role.toUpperCase()}`,
  });
}

/** operator+ required for PTZ / hotlist edits / evidence export (info.md §8) */
export function useCanOperate(): boolean {
  const role = useRole();
  return role === 'manager' || role === 'operator';
}

export function useMuted(): boolean {
  return useStoreSelector((s) => s.muted);
}

export function toggleMute(): void {
  store.setMuted(!store.getState().muted);
}

/* ── Mutations (all write audit_log) ─────────────────────────────────────── */

const ACTOR = 'Estate Manager';
let mutCounter = 0;
const mutId = (p: string) => `${p}-ui-${Date.now().toString(36)}-${++mutCounter}`;

export function acknowledgeAlert(alertId: string, actor: string = ACTOR): void {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const now = new Date().toISOString();
  store.setOrgSlices(orgId, {
    alerts: org.alerts.map((a) =>
      a.id === alertId && (a.status === 'new' || a.status === 'responding')
        ? { ...a, status: 'acknowledged' as const, acknowledged_by: actor, acknowledged_at: now, updated_at: now }
        : a,
    ),
  });
  writeAudit(orgId, { actor, action: 'alert.acknowledge', entity_kind: 'alert', entity_id: alertId, detail: 'Alert acknowledged by operator' });
}

export function resolveAlert(alertId: string, outcome: 'resolved' | 'false_alarm' = 'resolved', reason?: string, actor: string = ACTOR): void {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const now = new Date().toISOString();
  store.setOrgSlices(orgId, {
    alerts: org.alerts.map((a) =>
      a.id === alertId ? { ...a, status: outcome, resolved_at: now, updated_at: now } : a,
    ),
  });
  writeAudit(orgId, {
    actor, action: outcome === 'false_alarm' ? 'alert.false_alarm' : 'alert.resolve',
    entity_kind: 'alert', entity_id: alertId,
    detail: reason ? `${outcome === 'false_alarm' ? 'False alarm' : 'Resolved'} — ${reason}` : `Alert ${outcome}`,
  });
}

export function assignGuard(alertId: string, guardId: string, actor: string = ACTOR): void {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const guard = org.guards.find((g) => g.id === guardId);
  const alert = org.alerts.find((a) => a.id === alertId);
  if (!guard || !alert) return;
  const now = new Date().toISOString();
  store.setOrgSlices(orgId, {
    alerts: org.alerts.map((a) =>
      a.id === alertId ? { ...a, assigned_guard_id: guardId, status: a.status === 'new' ? ('acknowledged' as const) : a.status, updated_at: now } : a,
    ),
  });
  writeAudit(orgId, { actor, action: 'alert.assign_guard', entity_kind: 'alert', entity_id: alertId, detail: `Assigned to ${guard.full_name} (${guard.badge_no})` });
}

/** One-click dispatch: guard goes `responding`, alert goes `responding`. */
export function dispatchGuard(guardId: string, alertId: string, actor: string = ACTOR): void {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const guard = org.guards.find((g) => g.id === guardId);
  const alert = org.alerts.find((a) => a.id === alertId);
  if (!guard || !alert) return;
  const now = new Date().toISOString();
  store.setOrgSlices(orgId, {
    guards: org.guards.map((g) =>
      g.id === guardId
        ? { ...g, status: 'responding' as const, dispatch_target: { lat: alert.lat, lng: alert.lng, alert_id: alertId } }
        : g,
    ),
    alerts: org.alerts.map((a) =>
      a.id === alertId ? { ...a, status: 'responding' as const, assigned_guard_id: guardId, updated_at: now } : a,
    ),
  });
  writeAudit(orgId, {
    actor, action: 'guard.dispatch', entity_kind: 'guard', entity_id: guardId,
    detail: `${guard.full_name} dispatched to alert "${alert.title}"`,
  });
}

/**
 * PTZ command with 3-stage lifecycle (info.md §3):
 * dispatched → acknowledged (180–400ms) → completed (600–2500ms), ~4% failure.
 */
export function sendPtzCommand(
  cameraId: string,
  action: PtzAction,
  payload: Record<string, string | number> = {},
  actor: string = ACTOR,
): string {
  const orgId = store.getState().activeOrgId;
  const id = mutId('ptz');
  const now = new Date().toISOString();
  const cmd: PtzCommand = {
    id, org_id: orgId, camera_id: cameraId, action, payload,
    status: 'dispatched', dispatched_at: now, acknowledged_at: null, completed_at: null, error: null,
    created_by: actor,
  };
  store.setOrgSlices(orgId, { ptzCommands: [cmd, ...store.getOrgState(orgId).ptzCommands].slice(0, 60) });
  const patch = (p: Partial<PtzCommand>) => {
    const org = store.getOrgState(orgId);
    store.setOrgSlices(orgId, {
      ptzCommands: org.ptzCommands.map((c) => (c.id === id ? { ...c, ...p } : c)),
    });
  };
  setTimeout(() => {
    patch({ status: 'acknowledged', acknowledged_at: new Date().toISOString() });
    setTimeout(() => {
      const failed = Math.random() < 0.04;
      patch(
        failed
          ? { status: 'failed', error: 'Gimbal timeout — no response from camera head', completed_at: new Date().toISOString() }
          : { status: 'completed', completed_at: new Date().toISOString() },
      );
    }, 600 + Math.random() * 1900);
  }, 180 + Math.random() * 220);
  writeAudit(orgId, {
    actor, action: 'ptz.command', entity_kind: 'camera', entity_id: cameraId,
    detail: `PTZ ${action}${payload.preset ? ` (preset ${payload.preset})` : ''}`,
  });
  return id;
}

/** Add-camera wizard completion → camera joins the simulator immediately. */
export function addCamera(input: {
  name: string;
  zone: string;
  kind: CameraKind;
  rtsp_url: string;
  lat: number;
  lng: number;
  heading_deg: number;
  ptz_enabled?: boolean;
}, actor: string = ACTOR): Camera {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const cam: Camera = {
    id: mutId('cam'),
    org_id: orgId,
    name: input.name,
    zone: input.zone,
    kind: input.kind,
    rtsp_url: input.rtsp_url,
    resolution: input.kind === 'fixed_alpr' ? '4K' : '1920×1080',
    fps: input.kind === 'fixed_alpr' ? 30 : 25,
    status: 'online',
    ptz_enabled: input.ptz_enabled ?? input.kind === 'ptz',
    storage_used_pct: 2,
    lat: input.lat,
    lng: input.lng,
    heading_deg: input.heading_deg,
    last_heartbeat: new Date().toISOString(),
    firmware: 'v6.2.4',
    install_date: new Date().toISOString(),
  };
  store.setOrgSlices(orgId, { cameras: [...org.cameras, cam] });
  writeAudit(orgId, { actor, action: 'camera.add', entity_kind: 'camera', entity_id: cam.id, detail: `Camera "${cam.name}" onboarded via wizard (${cam.kind}, ${cam.zone})` });
  return cam;
}

export function addHotlistEntry(
  hotlistId: string,
  entry: { plate: string; reason: string; priority: HotlistPriority; notes?: string },
  actor: string = ACTOR,
): HotlistEntry {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const e: HotlistEntry = {
    id: mutId('hle'),
    plate: entry.plate.toUpperCase().trim(),
    reason: entry.reason,
    priority: entry.priority,
    added_by: actor,
    added_at: new Date().toISOString(),
    notes: entry.notes,
  };
  store.setOrgSlices(orgId, {
    hotlists: org.hotlists.map((h) =>
      h.id === hotlistId ? { ...h, entries: [e, ...h.entries] } : h,
    ),
  });
  writeAudit(orgId, { actor, action: 'hotlist.entry_add', entity_kind: 'hotlist', entity_id: hotlistId, detail: `Added plate ${e.plate} (${e.priority}) — ${e.reason}` });
  return e;
}

export function removeHotlistEntry(hotlistId: string, entryId: string, actor: string = ACTOR): void {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const list = org.hotlists.find((h) => h.id === hotlistId);
  const entry = list?.entries.find((e) => e.id === entryId);
  store.setOrgSlices(orgId, {
    hotlists: org.hotlists.map((h) =>
      h.id === hotlistId ? { ...h, entries: h.entries.filter((e) => e.id !== entryId) } : h,
    ),
  });
  writeAudit(orgId, { actor, action: 'hotlist.entry_remove', entity_kind: 'hotlist', entity_id: hotlistId, detail: `Removed plate ${entry?.plate ?? entryId}` });
}

export function toggleHotlist(hotlistId: string, actor: string = ACTOR): void {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const list = org.hotlists.find((h) => h.id === hotlistId);
  if (!list) return;
  store.setOrgSlices(orgId, {
    hotlists: org.hotlists.map((h) => (h.id === hotlistId ? { ...h, enabled: !h.enabled } : h)),
  });
  writeAudit(orgId, { actor, action: 'hotlist.toggle', entity_kind: 'hotlist', entity_id: hotlistId, detail: `${list.name} ${list.enabled ? 'disabled' : 'enabled'}` });
}

export function createIncident(input: {
  title: string;
  priority?: Incident['priority'];
  linked_alert_ids?: string[];
  linked_plate_reads?: string[];
  summary?: string;
  assigned_investigator?: string;
}, actor: string = ACTOR): Incident {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const activeOrg = store.getState().orgs.find((o) => o.id === orgId);
  const prefix = activeOrg ? activeOrg.slug.split('-').map((w) => w[0]).join('').toUpperCase() : 'SW';
  const seq = 42 + org.incidents.length + 1;
  const inc: Incident = {
    id: mutId('inc'),
    org_id: orgId,
    case_no: `${prefix}-2026-${String(seq).padStart(4, '0')}`,
    title: input.title,
    status: 'open',
    priority: input.priority ?? 'medium',
    linked_alert_ids: input.linked_alert_ids ?? [],
    linked_plate_reads: input.linked_plate_reads ?? [],
    assigned_investigator: input.assigned_investigator ?? actor,
    summary: input.summary ?? 'Case opened by operator.',
    created_at: new Date().toISOString(),
    closed_at: null,
    disposition: null,
    notes: [],
  };
  store.setOrgSlices(orgId, { incidents: [inc, ...org.incidents] });
  writeAudit(orgId, { actor, action: 'incident.create', entity_kind: 'incident', entity_id: inc.id, detail: `Case ${inc.case_no} opened — ${inc.title}` });
  return inc;
}

export function updateIncident(id: string, patch: Partial<Pick<Incident, 'status' | 'priority' | 'summary' | 'disposition' | 'assigned_investigator'>> & { addNote?: string }, actor: string = ACTOR): void {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const now = new Date().toISOString();
  store.setOrgSlices(orgId, {
    incidents: org.incidents.map((inc) => {
      if (inc.id !== id) return inc;
      const { addNote, ...rest } = patch;
      const next: Incident = { ...inc, ...rest };
      if (rest.status === 'closed' || rest.status === 'escalated_saps') next.closed_at = now;
      if (addNote) {
        next.notes = [...inc.notes, { id: mutId('nt'), author: actor, text: addNote, created_at: now }];
      }
      return next;
    }),
  });
  writeAudit(orgId, { actor, action: 'incident.update', entity_kind: 'incident', entity_id: id, detail: patch.addNote ? `Note appended: ${patch.addNote.slice(0, 80)}` : `Case updated (${Object.keys(patch).join(', ')})` });
}

/* ── Evidence pack export (jspdf + autotable, fully implemented) ─────────── */

export function exportEvidencePack(incidentId: string, actor: string = ACTOR): { ok: boolean; file: string } {
  const orgId = store.getState().activeOrgId;
  const org = store.getOrgState(orgId);
  const appState = store.getState();
  const inc = org.incidents.find((i) => i.id === incidentId);
  const orgMeta = appState.orgs.find((o) => o.id === orgId);
  if (!inc) return { ok: false, file: '' };

  const linkedAlerts = org.alerts.filter((a) => inc.linked_alert_ids.includes(a.id));
  const linkedReads = org.plateReads.filter((r) => inc.linked_plate_reads.includes(r.id));
  const linkedEvidence = org.evidence.filter((e) => linkedAlerts.some((a) => a.id === e.alert_id));
  const auditTrail = org.auditLog.filter((a) => inc.linked_alert_ids.includes(a.entity_id) || a.entity_id === inc.id).slice(0, 25);

  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const NAVY: [number, number, number] = [10, 25, 47];
  const ACCENT: [number, number, number] = [0, 180, 148];
  const MUTED: [number, number, number] = [92, 107, 138];

  // Cover band
  doc.setFillColor(...NAVY);
  doc.rect(0, 0, 595, 110, 'F');
  doc.setTextColor(...ACCENT);
  doc.setFont('courier', 'bold');
  doc.setFontSize(15);
  doc.text('SWEALTH OS — EVIDENCE PACK', 40, 46);
  doc.setTextColor(230, 241, 255);
  doc.setFontSize(10);
  doc.setFont('courier', 'normal');
  doc.text(`${inc.case_no}  ·  ${orgMeta?.name ?? orgId}  ·  exported ${fmtDateTime(new Date())} SAST`, 40, 66);
  doc.setTextColor(...MUTED);
  doc.setFontSize(8);
  doc.text('CHAIN OF CUSTODY DOCUMENT — generated from the simulated Phase 1 data layer. Handle per CJIS-style policy.', 40, 86);

  // Case summary
  doc.setTextColor(20, 28, 44);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('Case Summary', 40, 140);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  const summaryLines = doc.splitTextToSize(
    `Title: ${inc.title}\nStatus: ${inc.status.toUpperCase()}   Priority: ${inc.priority.toUpperCase()}   Investigator: ${inc.assigned_investigator}\nOpened: ${fmtDateTime(inc.created_at)}${inc.closed_at ? `   Closed: ${fmtDateTime(inc.closed_at)}` : ''}\n\n${inc.summary}`,
    515,
  ) as string[];
  doc.text(summaryLines, 40, 158);

  let y = 158 + summaryLines.length * 12 + 18;

  // Timeline table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Alert Timeline', 40, y);
  autoTable(doc, {
    startY: y + 8,
    margin: { left: 40, right: 40 },
    head: [['TIME', 'SEVERITY', 'TYPE', 'TITLE', 'STATUS']],
    body: linkedAlerts.map((a) => [fmtTime(a.created_at) + ' ' + a.created_at.slice(0, 10), a.severity.toUpperCase(), a.type, a.title, a.status.toUpperCase()]),
    styles: { font: 'courier', fontSize: 7.5, cellPadding: 4 },
    headStyles: { fillColor: NAVY, textColor: [230, 241, 255] },
    alternateRowStyles: { fillColor: [244, 247, 251] },
  });
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;

  // Plate sightings table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Plate Sightings', 40, y);
  autoTable(doc, {
    startY: y + 8,
    margin: { left: 40, right: 40 },
    head: [['PLATE', 'VEHICLE', 'CAMERA', 'DIR', 'CONF', 'CAPTURED']],
    body: linkedReads.map((r) => {
      const cam = org.cameras.find((c) => c.id === r.camera_id);
      return [r.plate, `${r.vehicle_color} ${r.vehicle_make}`, cam?.name ?? r.camera_id, r.direction.toUpperCase(), `${Math.round(r.confidence * 100)}%`, fmtDateTime(r.captured_at)];
    }),
    styles: { font: 'courier', fontSize: 7.5, cellPadding: 4 },
    headStyles: { fillColor: NAVY, textColor: [230, 241, 255] },
    alternateRowStyles: { fillColor: [244, 247, 251] },
  });
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;

  // Evidence register
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Evidence Register', 40, y);
  autoTable(doc, {
    startY: y + 8,
    margin: { left: 40, right: 40 },
    head: [['ID', 'KIND', 'ALERT', 'STORAGE PATH', 'CAPTURED']],
    body: linkedEvidence.map((e) => [e.id, e.kind, e.alert_id, e.storage_path, fmtDateTime(e.captured_at)]),
    styles: { font: 'courier', fontSize: 7, cellPadding: 4 },
    headStyles: { fillColor: NAVY, textColor: [230, 241, 255] },
    alternateRowStyles: { fillColor: [244, 247, 251] },
  });
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;

  // Chain of custody (audit excerpt)
  if (y > 700) {
    doc.addPage();
    y = 60;
  }
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Chain of Custody — Audit Excerpt', 40, y);
  autoTable(doc, {
    startY: y + 8,
    margin: { left: 40, right: 40 },
    head: [['TIME', 'ACTOR', 'ACTION', 'DETAIL']],
    body: auditTrail.map((a) => [fmtDateTime(a.created_at), a.actor, a.action, a.detail]),
    styles: { font: 'courier', fontSize: 7, cellPadding: 4 },
    headStyles: { fillColor: NAVY, textColor: [230, 241, 255] },
    alternateRowStyles: { fillColor: [244, 247, 251] },
  });

  const file = `${inc.case_no}-evidence-pack.pdf`;
  doc.save(file);
  writeAudit(orgId, {
    actor, action: 'evidence.export', entity_kind: 'incident', entity_id: inc.id,
    detail: `Evidence pack exported for ${inc.case_no} (${linkedAlerts.length} alerts, ${linkedReads.length} plate sightings, ${linkedEvidence.length} evidence items, avg response ${fmtDurationSec(240)})`,
  });
  return { ok: true, file };
}

/* ── Demo reset ──────────────────────────────────────────────────────────── */

export function resetDemoData(): void {
  store.resetDemoData();
  resetSimulatorSession();
}
