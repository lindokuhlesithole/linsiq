/** SWEALTH OS — time & number formatting helpers (mono data conventions). */

const pad = (n: number) => String(n).padStart(2, '0');

/** HH:MM:SS (24h) */
export function fmtTime(d: Date | string | number): string {
  const dt = d instanceof Date ? d : new Date(d);
  return `${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`;
}

/** HH:MM:SS SAST suffix variant for the TopBar clock */
export function fmtClock(d: Date): string {
  return fmtTime(d);
}

/** YYYY-MM-DD HH:MM:SS */
export function fmtDateTime(d: Date | string | number): string {
  const dt = d instanceof Date ? d : new Date(d);
  return `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())} ${fmtTime(dt)}`;
}

/** Relative under 1h ("12s ago", "4m ago"), absolute after (design.md §8) */
export function relTime(iso: string | number | Date, nowMs: number = Date.now()): string {
  const t = typeof iso === 'string' || typeof iso === 'number' ? new Date(iso).getTime() : iso.getTime();
  const diff = Math.max(0, nowMs - t);
  const sec = Math.floor(diff / 1000);
  if (sec < 5) return 'now';
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  return fmtDateTime(t);
}

/** 1,234 grouping */
export function fmtNum(n: number): string {
  return n.toLocaleString('en-ZA');
}

/** seconds → "4m 32s" */
export function fmtDurationSec(sec: number): string {
  const s = Math.round(sec);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const rem = s % 60;
  if (m < 60) return `${m}m ${pad(rem)}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${pad(m % 60)}m`;
}

/** mm:ss countdown */
export function fmtCountdown(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
}

/** lat/lng readout */
export function fmtCoord(lat: number, lng: number): string {
  return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
}

/** heartbeat age like "♥ 3s" */
export function fmtHeartbeat(iso: string, nowMs: number = Date.now()): string {
  const age = Math.max(0, Math.floor((nowMs - new Date(iso).getTime()) / 1000));
  return `♥ ${age}s`;
}
