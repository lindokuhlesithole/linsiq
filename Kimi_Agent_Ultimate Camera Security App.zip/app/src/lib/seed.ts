/**
 * SWEALTH OS — deterministic demo seed (info.md §3–§4).
 * Seeded RNG per tenant so reloads show a consistent world.
 * Referential integrity is guaranteed: every alert source_id resolves,
 * every plate read's camera exists, every evidence row links to an alert.
 */
import type {
  Alert,
  AlertEvidence,
  AlertRoutingRule,
  AlertStatus,
  AudioEvent,
  AudioSensor,
  AuditEntry,
  Camera,
  CameraKind,
  Direction,
  Drone,
  DroneStatus,
  Guard,
  GuardStatus,
  Hotlist,
  HotlistEntry,
  Incident,
  Organization,
  PlateRead,
  Province,
  PtzCommand,
  Severity,
  VehicleType,
  Waypoint,
} from './types';

/* ── RNG ─────────────────────────────────────────────────────────────────── */

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

class Rng {
  private next: () => number;
  constructor(seed: number) {
    this.next = mulberry32(seed);
  }
  f(): number {
    return this.next();
  }
  int(min: number, max: number): number {
    return Math.floor(this.f() * (max - min + 1)) + min;
  }
  pick<T>(arr: readonly T[]): T {
    return arr[Math.floor(this.f() * arr.length)];
  }
  chance(p: number): boolean {
    return this.f() < p;
  }
  weighted<T>(items: readonly (readonly [T, number])[]): T {
    const total = items.reduce((s, [, w]) => s + w, 0);
    let r = this.f() * total;
    for (const [v, w] of items) {
      r -= w;
      if (r <= 0) return v;
    }
    return items[items.length - 1][0];
  }
  jitter(base: number, range: number): number {
    return base + (this.f() - 0.5) * range;
  }
}

/* ── Shared vocabularies (South African realism) ─────────────────────────── */

export const SA_FIRST = [
  'Thandi', 'Pieter', 'Sipho', 'Johan', 'Naledi', 'Sifiso', 'Anika', 'Bongani',
  'Lerato', 'Kobus', 'Ayanda', 'Marius', 'Zanele', 'Riaan', 'Nomvula', 'André',
] as const;
export const SA_LAST = [
  'Mokoena', 'van der Merwe', 'Ndlovu', 'Botha', 'Khumalo', 'Dlamini', 'Fourie',
  'Zulu', 'Molefe', 'Pretorius', 'Ngcobo', 'Venter', 'Mahlangu', 'Erasmus',
  'Sithole', 'du Plessis',
] as const;

const VEHICLE_MAKES: readonly (readonly [string, number])[] = [
  ['Toyota Hilux', 22], ['VW Polo', 18], ['Ford Ranger', 14], ['Isuzu D-Max', 10],
  ['Toyota Quantum', 9], ['Toyota Corolla', 8], ['Hyundai i20', 6], ['Nissan NP200', 6],
  ['BMW 3 Series', 4], ['Mercedes-Benz C-Class', 3], ['Kia Picanto', 4], ['Suzuki Swift', 4],
  ['Haval Jolion', 4], ['Toyota Fortuner', 5],
];
const MAKE_TYPE: Record<string, VehicleType> = {
  'Toyota Hilux': 'bakkie', 'VW Polo': 'hatch', 'Ford Ranger': 'bakkie',
  'Isuzu D-Max': 'bakkie', 'Toyota Quantum': 'taxi', 'Toyota Corolla': 'sedan',
  'Hyundai i20': 'hatch', 'Nissan NP200': 'bakkie', 'BMW 3 Series': 'sedan',
  'Mercedes-Benz C-Class': 'sedan', 'Kia Picanto': 'hatch', 'Suzuki Swift': 'hatch',
  'Haval Jolion': 'suv', 'Toyota Fortuner': 'suv',
};
const VEHICLE_COLORS: readonly (readonly [string, number])[] = [
  ['White', 38], ['Silver', 22], ['Grey', 14], ['Black', 10], ['Blue', 7],
  ['Red', 5], ['Beige', 3], ['Green', 1],
];

export const HOTLIST_REASONS = [
  'Stolen vehicle — SAPS case ref open', 'Hijacking suspect vehicle — Lyttelton SAPS',
  'Repeat tailgating offender at gates', 'Unpaid contractor — access revoked',
  'Linked to housebreaking in estate', 'Wanted person vehicle — crime intelligence',
  'Abandoned vehicle report — verify ownership', 'Boom-gate ramming incident 2026-01',
  'Armed robbery lookout — provincial sync', 'Suspicious loitering near perimeter',
] as const;

/* ── Tenant configs ──────────────────────────────────────────────────────── */

interface TenantConfig {
  id: string;
  name: string;
  slug: string;
  location: string;
  prefix: string; // case_no + id prefix
  center_lat: number;
  center_lng: number;
  spread: number; // lat/lng radius for entity placement
  provinces: readonly (readonly [Province, number])[];
  zones: string[];
  gates: { name: string; zone: string; dLat: number; dLng: number; heading: number }[];
  cameraCount: number;
  droneCount: number;
  guardCount: number;
  plateReadCount: number;
  alertCount: number;
  incidentCount: number;
  rngSeed: number;
}

export const TENANTS: TenantConfig[] = [
  {
    id: 'org-silver-lakes', name: 'Silver Lakes Estate', slug: 'silver-lakes',
    location: 'Pretoria, Gauteng', prefix: 'SL',
    center_lat: -25.7835, center_lng: 28.3612, spread: 0.0075,
    provinces: [['GP', 78], ['NW', 6], ['MP', 5], ['LP', 4], ['KZN', 4], ['CA', 3]],
    zones: ['NORTH GATE', 'MAIN GATE', 'SOUTH GATE', 'LAKESIDE', 'CLUBHOUSE', 'PERIMETER W', 'PERIMETER E', 'GOLF VIEW'],
    gates: [
      { name: 'North Gate ALPR', zone: 'NORTH GATE', dLat: 0.0072, dLng: -0.001, heading: 178 },
      { name: 'Main Gate ALPR', zone: 'MAIN GATE', dLat: -0.0008, dLng: -0.0074, heading: 92 },
      { name: 'South Gate ALPR', zone: 'SOUTH GATE', dLat: -0.0072, dLng: 0.0022, heading: 4 },
      { name: 'Lakeside Boom ALPR', zone: 'LAKESIDE', dLat: 0.0028, dLng: 0.0068, heading: 268 },
    ],
    cameraCount: 12, droneCount: 3, guardCount: 7,
    plateReadCount: 2500, alertCount: 96, incidentCount: 7, rngSeed: 20260701,
  },
  {
    id: 'org-waterfall-heights', name: 'Waterfall Heights Estate', slug: 'waterfall-heights',
    location: 'Midrand, Gauteng', prefix: 'WH',
    center_lat: -25.9987, center_lng: 28.0913, spread: 0.0062,
    provinces: [['GP', 82], ['NW', 5], ['LP', 4], ['MP', 4], ['KZN', 3], ['CA', 2]],
    zones: ['WEST GATE', 'EAST GATE', 'RIDGE VIEW', 'CLUBHOUSE', 'PERIMETER N', 'PERIMETER S'],
    gates: [
      { name: 'West Gate ALPR', zone: 'WEST GATE', dLat: 0.0005, dLng: -0.006, heading: 88 },
      { name: 'East Gate ALPR', zone: 'EAST GATE', dLat: -0.001, dLng: 0.0058, heading: 272 },
      { name: 'Ridge Gate ALPR', zone: 'RIDGE VIEW', dLat: 0.0058, dLng: 0.0012, heading: 182 },
    ],
    cameraCount: 10, droneCount: 2, guardCount: 6,
    plateReadCount: 1200, alertCount: 72, incidentCount: 5, rngSeed: 20260702,
  },
  {
    id: 'org-camps-bay-marina', name: 'Camps Bay Marina', slug: 'camps-bay-marina',
    location: 'Cape Town, Western Cape', prefix: 'CB',
    center_lat: -33.9521, center_lng: 18.3798, spread: 0.0058,
    provinces: [['CA', 55], ['WC', 22], ['GP', 10], ['EC', 6], ['KZN', 4], ['NW', 3]],
    zones: ['MARINA GATE', 'HARBOUR WALK', 'PROMENADE', 'DOCK B', 'CLUBHOUSE', 'PERIMETER'],
    gates: [
      { name: 'Marina Gate ALPR', zone: 'MARINA GATE', dLat: 0.0054, dLng: -0.0008, heading: 175 },
      { name: 'Dock B ALPR', zone: 'DOCK B', dLat: -0.0052, dLng: 0.0015, heading: 355 },
      { name: 'Promenade ALPR', zone: 'PROMENADE', dLat: 0.0002, dLng: 0.0054, heading: 265 },
    ],
    cameraCount: 9, droneCount: 2, guardCount: 5,
    plateReadCount: 1200, alertCount: 64, incidentCount: 4, rngSeed: 20260703,
  },
];

/* ── Org state container shape (owned here; store/simulator import it) ───── */

export interface OrgState {
  cameras: Camera[];
  plateReads: PlateRead[]; // newest first
  hotlists: Hotlist[];
  audioSensors: AudioSensor[];
  audioEvents: AudioEvent[]; // newest first
  drones: Drone[];
  guards: Guard[];
  alerts: Alert[]; // newest first
  evidence: AlertEvidence[];
  incidents: Incident[];
  routingRules: AlertRoutingRule[];
  ptzCommands: PtzCommand[];
  auditLog: AuditEntry[]; // newest first
}

/* ── Helpers ─────────────────────────────────────────────────────────────── */

export function makePlate(rng: Rng, provinces: readonly (readonly [Province, number])[]): { plate: string; province: Province } {
  const province = rng.weighted(provinces);
  const plate = `${province} ${rng.int(100, 999)}-${rng.int(100, 999)}`;
  return { plate, province };
}

/** Time-of-day activity weight (SAST): gates busiest 07:00–09:00 / 16:30–18:30 */
export function hourWeight(hourFloat: number): number {
  const gauss = (h: number, mu: number, sigma: number) => Math.exp(-((h - mu) ** 2) / (2 * sigma * sigma));
  let w = 0.22 + 2.6 * gauss(hourFloat, 8, 1.15) + 2.8 * gauss(hourFloat, 17.5, 1.2) + 0.5 * gauss(hourFloat, 13, 2.2);
  if (hourFloat < 5) w *= 0.3;
  return w;
}

function sampleTime(rng: Rng, nowMs: number, windowH: number, weightByHour: boolean): number {
  for (let tries = 0; tries < 40; tries++) {
    const t = nowMs - rng.f() * windowH * 3600_000;
    if (!weightByHour) return t;
    const h = new Date(t).getHours() + new Date(t).getMinutes() / 60; // local ≈ SAST for demo
    if (rng.f() < hourWeight(h) / 3.2) return t;
  }
  return nowMs - rng.f() * windowH * 3600_000;
}

const iso = (ms: number) => new Date(ms).toISOString();

/* ── Entity builders ─────────────────────────────────────────────────────── */

function buildOrg(cfg: TenantConfig, now: number): Organization {
  return {
    id: cfg.id, name: cfg.name, slug: cfg.slug, location: cfg.location,
    center_lat: cfg.center_lat, center_lng: cfg.center_lng,
    threat_level: 'LOW',
    created_at: iso(now - 400 * 24 * 3600_000),
  };
}

function buildCameras(rng: Rng, cfg: TenantConfig, now: number): Camera[] {
  const cams: Camera[] = [];
  const resPool = ['4K', '2688×1520', '1920×1080'];
  let n = 0;
  const mk = (
    name: string, zone: string, kind: CameraKind, lat: number, lng: number,
    heading: number, ptz: boolean,
  ): Camera => {
    n += 1;
    return {
      id: `cam-${cfg.prefix.toLowerCase()}-${String(n).padStart(2, '0')}`,
      org_id: cfg.id, name, zone, kind,
      rtsp_url: `rtsp://10.${cfg.rngSeed % 200}.${Math.abs(Math.floor(lat * 1000)) % 250}.${n + 10}/h264/ch1`,
      resolution: kind === 'fixed_alpr' ? '4K' : rng.pick(resPool),
      fps: kind === 'fixed_alpr' ? 30 : rng.pick([15, 25, 30]),
      status: rng.chance(0.9) ? (kind === 'fixed_alpr' ? 'recording' : rng.weighted([['online', 6], ['recording', 3], ['motion', 1]] as const)) : 'degraded',
      ptz_enabled: ptz,
      storage_used_pct: rng.int(34, 78),
      lat, lng, heading_deg: heading,
      last_heartbeat: iso(now - rng.int(1, 8) * 1000),
      firmware: `v${rng.int(4, 6)}.${rng.int(0, 9)}.${rng.int(0, 20)}`,
      install_date: iso(now - rng.int(90, 900) * 24 * 3600_000),
    };
  };
  // ALPR gate cameras (≥3, with heading_deg)
  for (const g of cfg.gates) {
    cams.push(mk(g.name, g.zone, 'fixed_alpr', cfg.center_lat + g.dLat, cfg.center_lng + g.dLng, g.heading, false));
  }
  // Fill remaining with PTZ / bullet / doorbell spread around the estate
  const remaining = cfg.cameraCount - cfg.gates.length;
  const kinds: CameraKind[] = [];
  const ptzCount = Math.max(2, Math.round(remaining * 0.3));
  for (let i = 0; i < ptzCount; i++) kinds.push('ptz');
  while (kinds.length < remaining - 1) kinds.push('bullet');
  kinds.push('doorbell');
  const otherZones = cfg.zones.filter((z) => !cfg.gates.some((g) => g.zone === z));
  for (let i = 0; i < remaining; i++) {
    const zone = otherZones[i % otherZones.length] ?? cfg.zones[0];
    const lat = cfg.center_lat + rng.jitter(0, cfg.spread * 1.5);
    const lng = cfg.center_lng + rng.jitter(0, cfg.spread * 1.5);
    const kind = kinds[i];
    const label = kind === 'ptz' ? 'PTZ' : kind === 'doorbell' ? 'Doorbell' : 'Bullet';
    cams.push(mk(`${zone.charAt(0) + zone.slice(1).toLowerCase()} ${label} ${i + 1}`, zone, kind, lat, lng, rng.int(0, 359), kind === 'ptz'));
  }
  return cams;
}

function buildDrones(rng: Rng, cfg: TenantConfig, now: number): Drone[] {
  const drones: Drone[] = [];
  const models = ['DJI Matrice 30T', 'DJI Mavic 3T', 'Parrot ANAFI USA'];
  for (let i = 0; i < cfg.droneCount; i++) {
    const base_lat = cfg.center_lat + rng.jitter(0, cfg.spread * 0.3);
    const base_lng = cfg.center_lng + rng.jitter(0, cfg.spread * 0.3);
    const wpCount = rng.int(4, 6);
    const waypoints: Waypoint[] = [];
    for (let w = 0; w < wpCount; w++) {
      const ang = (w / wpCount) * Math.PI * 2;
      waypoints.push({
        lat: cfg.center_lat + Math.sin(ang) * cfg.spread * rng.jitter(0.75, 0.25),
        lng: cfg.center_lng + Math.cos(ang) * cfg.spread * rng.jitter(0.75, 0.25),
        label: `WP-${w + 1}`,
      });
    }
    const status: DroneStatus = i === 0 ? 'patrolling' : rng.weighted([['patrolling', 3], ['charging', 2], ['idle', 1]] as const);
    const wp0 = waypoints[0];
    drones.push({
      id: `drn-${cfg.prefix.toLowerCase()}-${i + 1}`,
      org_id: cfg.id,
      callsign: `FALCON-${cfg.prefix}${i + 1}`,
      model: rng.pick(models),
      status,
      battery_pct: status === 'charging' ? rng.int(15, 60) : rng.int(48, 97),
      altitude_m: status === 'patrolling' ? rng.int(45, 90) : 0,
      speed_mps: status === 'patrolling' ? rng.jitter(8, 3) : 0,
      signal_pct: rng.int(78, 99),
      lat: status === 'patrolling' ? wp0.lat : base_lat,
      lng: status === 'patrolling' ? wp0.lng : base_lng,
      base_lat, base_lng,
      waypoints,
      current_waypoint: 1 % waypoints.length,
      last_heartbeat: iso(now - rng.int(1, 5) * 1000),
      respond_target: null,
      trail: [],
    });
  }
  return drones;
}

function buildGuards(rng: Rng, cfg: TenantConfig): Guard[] {
  const guards: Guard[] = [];
  const usedNames = new Set<string>();
  for (let i = 0; i < cfg.guardCount; i++) {
    let full = `${rng.pick(SA_FIRST)} ${rng.pick(SA_LAST)}`;
    while (usedNames.has(full)) full = `${rng.pick(SA_FIRST)} ${rng.pick(SA_LAST)}`;
    usedNames.add(full);
    const base_lat = cfg.center_lat + rng.jitter(0, cfg.spread * 1.1);
    const base_lng = cfg.center_lng + rng.jitter(0, cfg.spread * 1.1);
    const status: GuardStatus = rng.weighted([['on_duty', 7], ['on_break', 1], ['off_duty', 2]] as const);
    guards.push({
      id: `grd-${cfg.prefix.toLowerCase()}-${i + 1}`,
      org_id: cfg.id,
      full_name: full,
      badge_no: `${cfg.prefix}-G${100 + i}`,
      shift: rng.pick(['day', 'night', 'swing'] as const),
      status,
      lat: base_lat + rng.jitter(0, cfg.spread * 0.3),
      lng: base_lng + rng.jitter(0, cfg.spread * 0.3),
      base_lat, base_lng,
      alerts_resolved: rng.int(8, 120),
      avg_response_sec: rng.int(150, 520),
      phone: `+27 ${rng.int(60, 83)} ${rng.int(100, 999)} ${rng.int(1000, 9999)}`,
      dispatch_target: null,
    });
  }
  return guards;
}

function buildHotlists(rng: Rng, cfg: TenantConfig, now: number): Hotlist[] {
  const specs: { name: string; kind: Hotlist['kind']; source: string; count: [number, number]; prio: HotlistEntry['priority'][] }[] = [
    { name: 'SAPS Stolen Vehicles — Gauteng Sync', kind: 'national_sync', source: 'SAPS eNATIS sync · hourly', count: [24, 40], prio: ['critical', 'critical', 'high', 'high', 'medium'] },
    { name: 'Estate Watchlist — Repeat Offenders', kind: 'custom', source: 'Estate security office', count: [15, 24], prio: ['high', 'high', 'medium', 'medium', 'critical'] },
    { name: 'Contractor Blacklist', kind: 'custom', source: 'Facilities management', count: [15, 22], prio: ['medium', 'medium', 'high'] },
  ];
  return specs.map((s, si) => {
    const count = rng.int(s.count[0], s.count[1]);
    const entries: HotlistEntry[] = [];
    const seen = new Set<string>();
    while (entries.length < count) {
      const { plate } = makePlate(rng, cfg.provinces);
      if (seen.has(plate)) continue;
      seen.add(plate);
      entries.push({
        id: `hle-${cfg.prefix.toLowerCase()}-${si + 1}-${entries.length + 1}`,
        plate,
        reason: rng.pick(HOTLIST_REASONS),
        priority: rng.pick(s.prio),
        added_by: rng.pick(['SAPS Sync', 'Estate Manager', 'Control Room', 'S. Nkosi (Supervisor)']),
        added_at: iso(now - rng.int(1, 90) * 24 * 3600_000),
        notes: rng.chance(0.4) ? `Verified ${iso(now - rng.int(1, 20) * 24 * 3600_000).slice(0, 10)} — flag on sight` : undefined,
      });
    }
    return {
      id: `hot-${cfg.prefix.toLowerCase()}-${si + 1}`,
      org_id: cfg.id,
      name: s.name, kind: s.kind, source: s.source,
      enabled: true, entries,
    };
  });
}

function buildAudioSensors(rng: Rng, cfg: TenantConfig): AudioSensor[] {
  const sensors: AudioSensor[] = [];
  const count = Math.min(4, Math.max(3, cfg.zones.length - 3));
  for (let i = 0; i < count; i++) {
    sensors.push({
      id: `sns-${cfg.prefix.toLowerCase()}-${i + 1}`,
      org_id: cfg.id,
      name: `Acoustic Node ${cfg.prefix}-${i + 1}`,
      zone: cfg.zones[(i * 2 + 1) % cfg.zones.length],
      lat: cfg.center_lat + rng.jitter(0, cfg.spread * 1.3),
      lng: cfg.center_lng + rng.jitter(0, cfg.spread * 1.3),
      triangulation_radius_m: rng.int(180, 420),
      status: 'online',
    });
  }
  return sensors;
}

/* ── Plate reads / audio events / alerts / incidents ─────────────────────── */

export function makeVehicle(rng: Rng): { make: string; type: VehicleType; color: string } {
  const make = rng.weighted(VEHICLE_MAKES);
  return { make, type: MAKE_TYPE[make] ?? 'sedan', color: rng.weighted(VEHICLE_COLORS) };
}

function buildPlateReads(rng: Rng, cfg: TenantConfig, cams: Camera[], hotlists: Hotlist[], now: number): PlateRead[] {
  const alprCams = cams.filter((c) => c.kind === 'fixed_alpr');
  const otherCams = cams.filter((c) => c.kind !== 'doorbell' && c.kind !== 'fixed_alpr');
  const hotEntries = hotlists.filter((h) => h.enabled).flatMap((h) => h.entries.map((e) => ({ entry: e, hotlist: h })));
  const reads: PlateRead[] = [];
  const usedIds = new Set<string>();
  for (let i = 0; i < cfg.plateReadCount; i++) {
    const at = sampleTime(rng, now, 48, true);
    const cam = rng.chance(0.78) && alprCams.length ? rng.pick(alprCams) : rng.pick(otherCams.length ? otherCams : alprCams);
    const isHit = hotEntries.length > 0 && rng.chance(1 / 300);
    let plate: string;
    let province: Province;
    let hotlist_id: string | undefined;
    if (isHit) {
      const h = rng.pick(hotEntries);
      plate = h.entry.plate;
      province = plate.slice(0, 2) as Province;
      hotlist_id = h.hotlist.id;
    } else {
      const p = makePlate(rng, cfg.provinces);
      plate = p.plate;
      province = p.province;
    }
    const v = makeVehicle(rng);
    const dir: Direction = new Date(at).getHours() < 12 ? (rng.chance(0.68) ? 'inbound' : 'outbound') : (rng.chance(0.62) ? 'outbound' : 'inbound');
    let id = `pr-${cfg.prefix.toLowerCase()}-${i + 1}`;
    while (usedIds.has(id)) id += 'x';
    usedIds.add(id);
    reads.push({
      id, org_id: cfg.id, camera_id: cam.id, plate, province,
      vehicle_color: v.color, vehicle_make: v.make, vehicle_type: v.type,
      direction: dir, confidence: Math.round(rng.jitter(0.93, 0.12) * 100) / 100,
      snapshot_id: `snap-${id}`,
      hotlist_hit: isHit, hotlist_id,
      captured_at: iso(at),
    });
  }
  reads.sort((a, b) => b.captured_at.localeCompare(a.captured_at));
  return reads;
}

const ALERT_TITLES: Record<string, (src: string, extra?: string) => { title: string; summary: string }> = {
  hotlist_hit: (src, extra) => ({
    title: `Hotlist vehicle detected — ${extra ?? 'unknown plate'}`,
    summary: `ALPR matched plate ${extra ?? ''} against an active hotlist at ${src}. Vehicle fingerprint logged; gate footage and plate crop attached. Recommend immediate guard verification.`,
  }),
  perimeter_breach: (src) => ({
    title: `Perimeter breach — ${src}`,
    summary: `Thermal+motion fusion detected human crossing at the perimeter line near ${src}. Confidence sustained across 3 frames; no matching resident access event in window.`,
  }),
  unidentified_person: (src) => ({
    title: `Unidentified person on camera — ${src}`,
    summary: `Person detected loitering outside resident access hours at ${src}. No biometric or access-tag match on record. Clothing descriptors extracted for search.`,
  }),
  gunshot: (src) => ({
    title: `Gunshot detected — triangulated near ${src}`,
    summary: `Acoustic sensors confirmed a gunshot signature (2+ nodes). Triangulation radius tightened; nearest drone auto-dispatched for aerial confirmation.`,
  }),
  drone_anomaly: (src) => ({
    title: `Drone telemetry anomaly — ${src}`,
    summary: `${src} reported signal/battery drift outside patrol envelope. Auto-failsafe armed; monitoring for recovery before RTB is forced.`,
  }),
  offline_device: (src) => ({
    title: `Device offline — ${src}`,
    summary: `${src} missed 3 consecutive heartbeats. Last known state captured; field reset recommended if not recovered within 10 minutes.`,
  }),
  fire_smoke: (src) => ({
    title: `Possible smoke signature — ${src}`,
    summary: `Vision model flagged a smoke-like plume in frame at ${src}. Thermal channel inconclusive. Awaiting operator confirmation.`,
  }),
  loitering: (src) => ({
    title: `Loitering vehicle — ${src}`,
    summary: `Vehicle stationary in no-stopping zone near ${src} for over 6 minutes. Plate captured; no resident association.`,
  }),
  tailgating: (src) => ({
    title: `Tailgating event — ${src}`,
    summary: `Second vehicle followed a resident through the boom at ${src} within 2.1s. Plate captured on exit camera; cross-checking hotlists.`,
  }),
};

function buildAlerts(
  rng: Rng, cfg: TenantConfig, cams: Camera[], drones: Drone[], sensors: AudioSensor[],
  reads: PlateRead[], audioEvents: AudioEvent[], now: number,
): { alerts: Alert[]; evidence: AlertEvidence[] } {
  const alerts: Alert[] = [];
  const evidence: AlertEvidence[] = [];
  const hitReads = reads.filter((r) => r.hotlist_hit);
  const types: (readonly [Alert['type'], number])[] = [
    ['perimeter_breach', 16], ['unidentified_person', 14], ['loitering', 14],
    ['tailgating', 12], ['offline_device', 10], ['drone_anomaly', 8],
    ['fire_smoke', 5], ['gunshot', 4],
  ];
  let alertNum = 0;
  let evNum = 0;
  const pushEvidence = (orgId: string, alertId: string, kind: AlertEvidence['kind'], at: number, seed: string) => {
    evNum += 1;
    evidence.push({
      id: `ev-${cfg.prefix.toLowerCase()}-${evNum}`,
      org_id: orgId, alert_id: alertId, kind,
      storage_path: `proc://${kind}/${seed}`,
      captured_at: iso(at),
    });
  };
  const mkAlert = (
    type: Alert['type'], at: number, source: { kind: Alert['source_kind']; id: string; name: string; lat: number; lng: number },
    severity: Severity, plateRead?: PlateRead, forceStatus?: AlertStatus,
  ): Alert => {
    alertNum += 1;
    const id = `al-${cfg.prefix.toLowerCase()}-${String(alertNum).padStart(3, '0')}`;
    const { title, summary } = ALERT_TITLES[type](source.name, plateRead?.plate);
    // newer alerts skew open; older skew resolved
    const ageH = (now - at) / 3600_000;
    const status: AlertStatus = forceStatus ?? (ageH < 2
      ? rng.weighted([['new', 5], ['acknowledged', 3], ['responding', 2], ['resolved', 2], ['false_alarm', 1]] as const)
      : rng.weighted([['resolved', 12], ['false_alarm', 3], ['acknowledged', 1], ['new', 1]] as const));
    const ack = status !== 'new';
    const resolved = status === 'resolved' || status === 'false_alarm';
    const alert: Alert = {
      id, org_id: cfg.id, type, severity,
      source_kind: source.kind, source_id: source.id, source_name: source.name,
      title, ai_summary: summary,
      ai_confidence: Math.round(rng.jitter(0.87, 0.16) * 100) / 100,
      status,
      assigned_guard_id: null,
      lat: source.lat + rng.jitter(0, 0.0004), lng: source.lng + rng.jitter(0, 0.0004),
      plate_read_id: plateRead?.id ?? null,
      created_at: iso(at),
      updated_at: iso(at + rng.int(30, 3600) * 1000),
      acknowledged_by: ack ? rng.pick(['Estate Manager', 'S. Nkosi', 'Control Room Op 2']) : null,
      acknowledged_at: ack ? iso(at + rng.int(45, 900) * 1000) : null,
      resolved_at: resolved ? iso(at + rng.int(300, 5400) * 1000) : null,
    };
    pushEvidence(cfg.id, id, 'snapshot', at, id);
    if (type === 'hotlist_hit' && plateRead) pushEvidence(cfg.id, id, 'plate_crop', at, plateRead.plate);
    if (type === 'gunshot') pushEvidence(cfg.id, id, 'audio_clip', at, id);
    if (type === 'fire_smoke' || type === 'perimeter_breach') pushEvidence(cfg.id, id, 'thermal', at, id);
    if (rng.chance(0.3)) pushEvidence(cfg.id, id, 'video_clip', at, id);
    return alert;
  };

  // Hotlist-hit alerts tied to real hotlist plate reads (referential integrity)
  const usedReads = Math.min(hitReads.length, Math.round(cfg.alertCount * 0.22));
  for (let i = 0; i < usedReads; i++) {
    const pr = hitReads[Math.floor((i / Math.max(1, usedReads)) * hitReads.length)];
    const cam = cams.find((c) => c.id === pr.camera_id);
    if (!cam) continue;
    alerts.push(mkAlert('hotlist_hit', new Date(pr.captured_at).getTime() + rng.int(1, 8) * 1000, { kind: 'alpr', id: cam.id, name: cam.name, lat: cam.lat, lng: cam.lng }, hotSeverity(rng), pr));
  }
  // Gunshot alerts tied to real audio events
  for (const ae of audioEvents.filter((e) => e.kind === 'gunshot')) {
    alerts.push(mkAlert('gunshot', new Date(ae.captured_at).getTime(), { kind: 'audio', id: ae.sensor_id, name: sensors.find((s) => s.id === ae.sensor_id)?.name ?? 'Acoustic node', lat: ae.lat, lng: ae.lng }, 'critical'));
  }
  // Fill remainder with weighted types
  while (alerts.length < cfg.alertCount) {
    const type = rng.weighted(types);
    const at = sampleTime(rng, now, 48, false);
    let source: { kind: Alert['source_kind']; id: string; name: string; lat: number; lng: number };
    if (type === 'drone_anomaly') {
      const d = rng.pick(drones);
      source = { kind: 'drone', id: d.id, name: d.callsign, lat: d.lat, lng: d.lng };
    } else if (type === 'gunshot') {
      const s = rng.pick(sensors);
      source = { kind: 'audio', id: s.id, name: s.name, lat: s.lat, lng: s.lng };
    } else {
      const c = rng.pick(cams);
      source = { kind: 'camera', id: c.id, name: c.name, lat: c.lat, lng: c.lng };
    }
    alerts.push(mkAlert(type, at, source, severityFor(rng, type)));
  }
  // Mark stale 'new' alerts as already-escalated so the live engine does not
  // fire a backlog escalation storm on first load.
  const ESC_WINDOW: Record<string, number> = { critical: 300, high: 900, medium: 3600, low: 7200 };
  for (const a of alerts) {
    if (a.status === 'new') {
      const ageSec = (now - new Date(a.created_at).getTime()) / 1000;
      if (ageSec > (ESC_WINDOW[a.severity] ?? 3600)) {
        a.escalated = true;
        a.escalated_at = iso(new Date(a.created_at).getTime() + (ESC_WINDOW[a.severity] ?? 3600) * 1000);
      }
    }
  }
  alerts.sort((a, b) => b.created_at.localeCompare(a.created_at));
  return { alerts, evidence };
}

function hotSeverity(rng: Rng): Severity {
  return rng.weighted([['critical', 5], ['high', 4], ['medium', 1]] as const);
}
function severityFor(rng: Rng, type: Alert['type']): Severity {
  if (type === 'gunshot') return 'critical';
  if (type === 'fire_smoke') return rng.weighted([['critical', 2], ['high', 3], ['medium', 1]] as const);
  if (type === 'perimeter_breach') return rng.weighted([['high', 4], ['critical', 2], ['medium', 3]] as const);
  return rng.weighted([['low', 3], ['medium', 4], ['high', 3], ['critical', 1]] as const);
}

function buildAudioEvents(rng: Rng, cfg: TenantConfig, sensors: AudioSensor[], now: number): AudioEvent[] {
  const events: AudioEvent[] = [];
  const count = cfg.id === 'org-silver-lakes' ? 5 : 3;
  for (let i = 0; i < count; i++) {
    const s = rng.pick(sensors);
    const at = sampleTime(rng, now, 48, false);
    events.push({
      id: `ae-${cfg.prefix.toLowerCase()}-${i + 1}`,
      org_id: cfg.id, sensor_id: s.id,
      kind: rng.weighted([['gunshot', 2], ['glass_break', 3], ['scream', 2], ['explosion', 1]] as const),
      confidence: Math.round(rng.jitter(0.84, 0.18) * 100) / 100,
      lat: s.lat + rng.jitter(0, 0.001), lng: s.lng + rng.jitter(0, 0.001),
      triangulation_radius_m: s.triangulation_radius_m,
      sensors_confirmed: rng.int(2, Math.max(2, sensors.length)),
      status: rng.weighted([['confirmed', 5], ['dismissed', 3], ['new', 2]] as const),
      captured_at: iso(at),
    });
  }
  events.sort((a, b) => b.captured_at.localeCompare(a.captured_at));
  return events;
}

function buildIncidents(rng: Rng, cfg: TenantConfig, alerts: Alert[], now: number): Incident[] {
  const incidents: Incident[] = [];
  const linkable = alerts.filter((a) => a.severity === 'critical' || a.severity === 'high');
  const titles = [
    'Repeat tailgating at main gate — pattern analysis',
    'Stolen vehicle sighting — SAPS coordination',
    'Perimeter breach cluster — west wall',
    'Night loitering near clubhouse — escalation',
    'Contractor access violation — boom incident',
    'Gunshot report — external perimeter',
    'Gate camera tampering attempt',
    'Hotlist hit — repeat offender vehicle',
  ];
  for (let i = 0; i < Math.min(cfg.incidentCount, titles.length); i++) {
    const linked = linkable.slice(i * 2, i * 2 + rng.int(1, 3));
    const created = now - rng.int(2, 40) * 24 * 3600_000;
    const closed = rng.chance(0.45);
    incidents.push({
      id: `inc-${cfg.prefix.toLowerCase()}-${i + 1}`,
      org_id: cfg.id,
      case_no: `${cfg.prefix}-2026-${String(38 + i).padStart(4, '0')}`,
      title: titles[i],
      status: closed ? (rng.chance(0.25) ? 'escalated_saps' : 'closed') : rng.pick(['open', 'investigating'] as const),
      priority: rng.weighted([['critical', 1], ['high', 3], ['medium', 3], ['low', 1]] as const),
      linked_alert_ids: linked.map((a) => a.id),
      linked_plate_reads: linked.map((a) => a.plate_read_id).filter((x): x is string => !!x),
      assigned_investigator: rng.pick(['S. Nkosi', 'Estate Manager', 'P. van der Merwe', 'T. Mokoena']),
      summary: `Case opened from correlated alert activity. ${linked.length} linked alert(s) with attached evidence; chain of custody maintained in audit log.`,
      created_at: iso(created),
      closed_at: closed ? iso(created + rng.int(24, 200) * 3600_000) : null,
      disposition: closed ? rng.pick(['Referred to SAPS — case ref pending', 'Resolved internally — access revoked', 'Unfounded — false alarm pattern']) : null,
      notes: [{
        id: `nt-${cfg.prefix.toLowerCase()}-${i + 1}-1`,
        author: 'S. Nkosi',
        text: 'Initial triage complete. Evidence reviewed and preserved.',
        created_at: iso(created + 3600_000),
      }],
    });
  }
  incidents.sort((a, b) => b.created_at.localeCompare(a.created_at));
  return incidents;
}

function buildRoutingRules(cfg: TenantConfig): AlertRoutingRule[] {
  const spec: [Severity, AlertRoutingRule['role'], AlertRoutingRule['channel'], number][] = [
    ['critical', 'supervisor', 'sms', 300],
    ['high', 'operator', 'push', 900],
    ['medium', 'operator', 'push', 3600],
    ['low', 'guard', 'radio', 7200],
  ];
  return spec.map(([severity, role, channel, escalate_after_sec], i) => ({
    id: `rule-${cfg.prefix.toLowerCase()}-${i + 1}`,
    org_id: cfg.id, severity, role, channel, escalate_after_sec, enabled: true,
  }));
}

function buildAudit(rng: Rng, cfg: TenantConfig, alerts: Alert[], now: number): AuditEntry[] {
  const entries: AuditEntry[] = [];
  let n = 0;
  const push = (at: number, actor: string, action: string, kind: string, id: string, detail: string) => {
    n += 1;
    entries.push({ id: `aud-${cfg.prefix.toLowerCase()}-${n}`, org_id: cfg.id, actor, action, entity_kind: kind, entity_id: id, detail, created_at: iso(at) });
  };
  for (const a of alerts) {
    if (a.acknowledged_at && a.acknowledged_by) push(new Date(a.acknowledged_at).getTime(), a.acknowledged_by, 'alert.acknowledge', 'alert', a.id, `Acknowledged "${a.title}"`);
    if (a.resolved_at) push(new Date(a.resolved_at).getTime(), a.acknowledged_by ?? 'Estate Manager', a.status === 'false_alarm' ? 'alert.false_alarm' : 'alert.resolve', 'alert', a.id, `${a.status === 'false_alarm' ? 'Marked false alarm' : 'Resolved'} — ${a.title}`);
  }
  for (let i = 0; i < 12; i++) {
    push(now - rng.int(1, 45) * 24 * 3600_000, rng.pick(['Estate Manager', 'S. Nkosi', 'Control Room Op 2']),
      rng.pick(['hotlist.entry_add', 'hotlist.sync', 'camera.config_update', 'incident.update', 'evidence.export']),
      rng.pick(['hotlist', 'camera', 'incident', 'evidence']),
      `${cfg.prefix.toLowerCase()}-${rng.int(1, 40)}`, 'Routine administrative action (seeded history)');
  }
  entries.sort((a, b) => b.created_at.localeCompare(a.created_at));
  return entries.slice(0, 140);
}

/* ── Assembly ────────────────────────────────────────────────────────────── */

export interface SeedResult {
  orgs: Organization[];
  byOrg: Record<string, OrgState>;
}

export function generateSeed(nowMs: number = Date.now()): SeedResult {
  const orgs: Organization[] = [];
  const byOrg: Record<string, OrgState> = {};
  for (const cfg of TENANTS) {
    const rng = new Rng(cfg.rngSeed);
    const org = buildOrg(cfg, nowMs);
    const cameras = buildCameras(rng, cfg, nowMs);
    const drones = buildDrones(rng, cfg, nowMs);
    const guards = buildGuards(rng, cfg);
    const hotlists = buildHotlists(rng, cfg, nowMs);
    const audioSensors = buildAudioSensors(rng, cfg);
    const audioEvents = buildAudioEvents(rng, cfg, audioSensors, nowMs);
    const plateReads = buildPlateReads(rng, cfg, cameras, hotlists, nowMs);
    const { alerts, evidence } = buildAlerts(rng, cfg, cameras, drones, audioSensors, plateReads, audioEvents, nowMs);
    const incidents = buildIncidents(rng, cfg, alerts, nowMs);
    const routingRules = buildRoutingRules(cfg);
    const auditLog = buildAudit(rng, cfg, alerts, nowMs);
    orgs.push(org);
    byOrg[cfg.id] = {
      cameras, plateReads, hotlists, audioSensors, audioEvents, drones, guards,
      alerts, evidence, incidents, routingRules, ptzCommands: [], auditLog,
    };
  }
  return { orgs, byOrg };
}
