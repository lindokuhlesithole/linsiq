/**
 * SWEALTH OS — lightweight external store (useSyncExternalStore-compatible).
 * Holds full app state per org, supports fine-grained selector subscriptions,
 * persists to localStorage under the `swealth.` key prefix.
 */
import { useSyncExternalStore } from 'react';
import type { Alert, AuditEntry, Organization, RolePreview, Severity, ThreatLevel } from './types';
import { generateSeed, type OrgState, type SeedResult } from './seed';

export const LS_PREFIX = 'swealth.';
const LS_STATE = `${LS_PREFIX}state.v1`;
export const LS_ACTIVE_ORG = `${LS_PREFIX}active_org_id`;
const LS_ROLE = `${LS_PREFIX}role`;
const LS_MUTED = `${LS_PREFIX}muted`;
const LS_SIDEBAR = `${LS_PREFIX}sidebar_collapsed`;

export interface AppState {
  orgs: Organization[];
  byOrg: Record<string, OrgState>;
  activeOrgId: string;
  role: RolePreview;
  muted: boolean;
  realtimeRunning: boolean;
  hydrated: boolean;
  /** bumped whenever any org slice changes (cheap change detection) */
  version: number;
}

/* ── App events (toast + ping hook consumed by the Toast provider) ───────── */

export interface AppEvent {
  kind: 'alert' | 'info';
  alert?: Alert;
  message?: string;
  severity?: Severity;
}
type EventListener = (e: AppEvent) => void;
const eventListeners = new Set<EventListener>();
export function onAppEvent(fn: EventListener): () => void {
  eventListeners.add(fn);
  return () => eventListeners.delete(fn);
}
export function emitAppEvent(e: AppEvent): void {
  eventListeners.forEach((fn) => fn(e));
}

/* ── Store core ──────────────────────────────────────────────────────────── */

type Listener = () => void;

function loadPersisted(): { byOrg: Record<string, OrgState>; orgs: Organization[] } | null {
  try {
    const raw = localStorage.getItem(LS_STATE);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { orgs: Organization[]; byOrg: Record<string, OrgState> };
    if (!parsed.orgs?.length || !parsed.byOrg) return null;
    // basic integrity check — reseed if shape is stale
    const first = parsed.byOrg[parsed.orgs[0].id];
    if (!first || !Array.isArray(first.cameras) || !Array.isArray(first.alerts)) return null;
    return parsed;
  } catch {
    return null;
  }
}

class Store {
  private state: AppState;
  private listeners = new Set<Listener>();
  private persistTimer: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    const persisted = typeof window !== 'undefined' ? loadPersisted() : null;
    const seed: SeedResult = persisted ?? generateSeed();
    const savedActive = typeof window !== 'undefined' ? localStorage.getItem(LS_ACTIVE_ORG) : null;
    const activeOrgId = seed.orgs.some((o) => o.id === savedActive) ? (savedActive as string) : seed.orgs[0].id;
    const role = (typeof window !== 'undefined' ? localStorage.getItem(LS_ROLE) : null) as RolePreview | null;
    this.state = {
      orgs: seed.orgs,
      byOrg: seed.byOrg,
      activeOrgId,
      role: role === 'operator' || role === 'guard' ? role : 'manager',
      muted: typeof window !== 'undefined' ? localStorage.getItem(LS_MUTED) === '1' : false,
      realtimeRunning: true,
      hydrated: true,
      version: 0,
    };
  }

  getState = (): AppState => this.state;

  subscribe = (fn: Listener): (() => void) => {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  };

  private emit() {
    this.listeners.forEach((fn) => fn());
    this.schedulePersist();
  }

  private schedulePersist() {
    if (this.persistTimer) return;
    this.persistTimer = setTimeout(() => {
      this.persistTimer = null;
      this.persist();
    }, 800);
  }

  persist() {
    try {
      const { orgs, byOrg } = this.state;
      // cap the heaviest slices so localStorage stays well under quota
      const capped: Record<string, OrgState> = {};
      for (const [k, o] of Object.entries(byOrg)) {
        capped[k] = {
          ...o,
          plateReads: o.plateReads.slice(0, 2600),
          alerts: o.alerts.slice(0, 320),
          auditLog: o.auditLog.slice(0, 200),
          evidence: o.evidence.slice(0, 700),
          drones: o.drones.map((d) => ({ ...d, trail: d.trail.slice(-24) })),
        };
      }
      localStorage.setItem(LS_STATE, JSON.stringify({ orgs, byOrg: capped }));
    } catch {
      /* quota exceeded — drop persistence silently */
    }
  }

  /* ── Slice-level mutations (only replaced slices change reference) ── */

  setOrgSlices(orgId: string, partial: Partial<OrgState>): void {
    const cur = this.state.byOrg[orgId];
    if (!cur) return;
    this.state = {
      ...this.state,
      version: this.state.version + 1,
      byOrg: { ...this.state.byOrg, [orgId]: { ...cur, ...partial } },
    };
    this.emit();
  }

  getOrgState(orgId: string): OrgState {
    return this.state.byOrg[orgId];
  }

  patchOrgMeta(orgId: string, patch: Partial<Organization>): void {
    this.state = {
      ...this.state,
      version: this.state.version + 1,
      orgs: this.state.orgs.map((o) => (o.id === orgId ? { ...o, ...patch } : o)),
    };
    this.emit();
  }

  setActiveOrg(orgId: string): void {
    if (!this.state.byOrg[orgId] || orgId === this.state.activeOrgId) return;
    this.state = { ...this.state, activeOrgId: orgId, version: this.state.version + 1 };
    try {
      localStorage.setItem(LS_ACTIVE_ORG, orgId);
    } catch { /* noop */ }
    this.emit();
  }

  setRole(role: RolePreview): void {
    this.state = { ...this.state, role, version: this.state.version + 1 };
    try {
      localStorage.setItem(LS_ROLE, role);
    } catch { /* noop */ }
    this.emit();
  }

  setMuted(muted: boolean): void {
    this.state = { ...this.state, muted, version: this.state.version + 1 };
    try {
      localStorage.setItem(LS_MUTED, muted ? '1' : '0');
    } catch { /* noop */ }
    this.emit();
  }

  setRealtimeRunning(running: boolean): void {
    if (running === this.state.realtimeRunning) return;
    this.state = { ...this.state, realtimeRunning: running, version: this.state.version + 1 };
    this.emit();
  }

  resetDemoData(): void {
    const seed = generateSeed();
    try {
      localStorage.removeItem(LS_STATE);
    } catch { /* noop */ }
    this.state = { ...this.state, orgs: seed.orgs, byOrg: seed.byOrg, version: this.state.version + 1 };
    this.emit();
    this.persist();
  }
}

export const store = new Store();

/* ── Selector hook (fine-grained subscriptions) ──────────────────────────── */

/**
 * Subscribe to a stable slice of app state. The selector MUST return a
 * reference-stable value (a stored slice, or a primitive). For derived
 * arrays/objects, memoize in the calling component.
 */
export function useStoreSelector<T>(selector: (s: AppState) => T): T {
  return useSyncExternalStore(
    store.subscribe,
    () => selector(store.getState()),
    () => selector(store.getState()),
  );
}

/* ── Audit helper (every mutation writes here — CJIS-style) ──────────────── */

let auditCounter = 0;
export function writeAudit(
  orgId: string,
  entry: Omit<AuditEntry, 'id' | 'org_id' | 'created_at'>,
): void {
  const cur = store.getOrgState(orgId);
  auditCounter += 1;
  const audit: AuditEntry = {
    id: `aud-live-${Date.now().toString(36)}-${auditCounter}`,
    org_id: orgId,
    created_at: new Date().toISOString(),
    ...entry,
  };
  store.setOrgSlices(orgId, { auditLog: [audit, ...cur.auditLog].slice(0, 400) });
}

/* ── Shared derivations ──────────────────────────────────────────────────── */

export const OPEN_STATUSES = new Set(['new', 'acknowledged', 'responding']);

export function deriveThreat(alerts: Alert[]): ThreatLevel {
  const open = alerts.filter((a) => OPEN_STATUSES.has(a.status));
  const crit = open.filter((a) => a.severity === 'critical').length;
  const high = open.filter((a) => a.severity === 'high').length;
  if (crit >= 2 || (crit >= 1 && high >= 2)) return 'HIGH';
  if (crit >= 1 || high >= 3) return 'ELEVATED';
  if (high >= 1) return 'GUARDED';
  return 'LOW';
}

export function severityRank(s: Severity): number {
  return s === 'critical' ? 3 : s === 'high' ? 2 : s === 'medium' ? 1 : 0;
}

export function getSidebarCollapsed(): boolean {
  try {
    return localStorage.getItem(LS_SIDEBAR) === '1';
  } catch {
    return false;
  }
}
export function setSidebarCollapsed(v: boolean): void {
  try {
    localStorage.setItem(LS_SIDEBAR, v ? '1' : '0');
  } catch { /* noop */ }
  window.dispatchEvent(new CustomEvent('swealth:sidebar'));
}
