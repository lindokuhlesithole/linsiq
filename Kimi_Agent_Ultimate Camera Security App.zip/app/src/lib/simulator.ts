/**
 * SWEALTH OS — simulated real-time engine (info.md §4).
 * Singleton 1s tick loop, started by a React provider. Simulates the ACTIVE
 * org only. Mutates via store slice updates so only affected subscribers
 * re-render. Fires the toast+ping hook (emitAppEvent) for high/critical alerts.
 */
import type {
  Alert,
  AlertEvidence,
  AlertType,
  AudioEvent,
  Camera,
  Drone,
  PlateRead,
  Severity,
} from './types';
import { emitAppEvent, OPEN_STATUSES, store, writeAudit } from './store';
import { hashString, hourWeight, mulberry32, type OrgState } from './seed';

/* ── Live RNG (non-deterministic stream, seeded per session) ─────────────── */
const live = mulberry32((Date.now() ^ 0x9e3779b9) >>> 0);
const rf = () => live();
const rint = (min: number, max: number) => Math.floor(rf() * (max - min + 1)) + min;
const rpick = <T,>(arr: readonly T[]): T => arr[Math.floor(rf() * arr.length)];
const chance = (p: number) => rf() < p;

let idCounter = 0;
const uid = (prefix: string) => `${prefix}-live-${Date.now().toString(36)}-${++idCounter}`;

/** Hotlist entries added via the UI must produce a hit within 30s (info.md §5 /alpr). */
const forcedHitDone = new Set<string>();

/* ── Geo helpers ─────────────────────────────────────────────────────────── */
const M_PER_DEG_LAT = 111_320;
function moveToward(lat: number, lng: number, tLat: number, tLng: number, meters: number): { lat: number; lng: number; arrived: boolean } {
  const dLatM = (tLat - lat) * M_PER_DEG_LAT;
  const dLngM = (tLng - lng) * M_PER_DEG_LAT * Math.cos((lat * Math.PI) / 180);
  const dist = Math.hypot(dLatM, dLngM);
  if (dist <= meters) return { lat: tLat, lng: tLng, arrived: true };
  const f = meters / dist;
  return { lat: lat + (dLatM * f) / M_PER_DEG_LAT, lng: lng + (dLngM * f) / (M_PER_DEG_LAT * Math.cos((lat * Math.PI) / 180)), arrived: false };
}

/* ── Realtime status mini-store (running + lastTickAt) ───────────────────── */
let lastTickAt = Date.now();
const rtListeners = new Set<() => void>();
export function subscribeRealtime(fn: () => void): () => void {
  rtListeners.add(fn);
  return () => rtListeners.delete(fn);
}
export function getRealtimeSnapshot(): { running: boolean; lastTickAt: number } {
  return { running: store.getState().realtimeRunning, lastTickAt };
}
function emitRt() {
  rtListeners.forEach((fn) => fn());
}
export function setRealtimeRunning(running: boolean): void {
  store.setRealtimeRunning(running);
  writeAudit(store.getState().activeOrgId, {
    actor: 'Estate Manager', action: running ? 'simulator.resume' : 'simulator.pause',
    entity_kind: 'system', entity_id: 'simulator',
    detail: running ? 'Live feed resumed' : 'Live feed paused by operator',
  });
  emitRt();
}

/* ── Live entity factories ───────────────────────────────────────────────── */

const VEHICLE_LIVE: readonly (readonly [string, string, string])[] = [
  ['Toyota Hilux', 'bakkie', 'White'], ['VW Polo', 'hatch', 'Silver'], ['Ford Ranger', 'bakkie', 'White'],
  ['Isuzu D-Max', 'bakkie', 'Grey'], ['Toyota Quantum', 'taxi', 'White'], ['Toyota Corolla', 'sedan', 'Silver'],
  ['Hyundai i20', 'hatch', 'Red'], ['Nissan NP200', 'bakkie', 'White'], ['Haval Jolion', 'suv', 'Blue'],
  ['Toyota Fortuner', 'suv', 'Black'], ['Suzuki Swift', 'hatch', 'White'], ['BMW 3 Series', 'sedan', 'Black'],
];
const PROVINCES_BY_ORG: Record<string, readonly string[]> = {
  'org-silver-lakes': ['GP', 'GP', 'GP', 'GP', 'GP', 'GP', 'GP', 'GP', 'NW', 'MP', 'LP', 'KZN'],
  'org-waterfall-heights': ['GP', 'GP', 'GP', 'GP', 'GP', 'GP', 'GP', 'GP', 'GP', 'NW', 'LP', 'MP'],
  'org-camps-bay-marina': ['CA', 'CA', 'CA', 'CA', 'CA', 'WC', 'WC', 'GP', 'GP', 'EC', 'KZN', 'NW'],
};

function livePlate(orgId: string): { plate: string; province: string } {
  const pool = PROVINCES_BY_ORG[orgId] ?? ['GP'];
  const province = rpick(pool);
  return { plate: `${province} ${rint(100, 999)}-${rint(100, 999)}`, province };
}

function pickHotlistPlate(org: OrgState): { plate: string; hotlistId: string } | undefined {
  const lists = org.hotlists.filter((h) => h.enabled && h.entries.length > 0);
  if (!lists.length) return undefined;
  const list = rpick(lists);
  const entry = rpick(list.entries);
  return { plate: entry.plate, hotlistId: list.id };
}

function makeLiveRead(org: OrgState, orgId: string, camera: Camera, forcedPlate?: { plate: string; hotlistId: string }): PlateRead {
  const hit = forcedPlate ?? (chance(1 / 400) ? pickHotlistPlate(org) : undefined);
  const p = hit ? { plate: hit.plate, province: hit.plate.slice(0, 2) } : livePlate(orgId);
  const v = rpick(VEHICLE_LIVE);
  return {
    id: uid('pr'),
    org_id: orgId,
    camera_id: camera.id,
    plate: p.plate,
    province: p.province as PlateRead['province'],
    vehicle_color: v[2],
    vehicle_make: v[0],
    vehicle_type: v[1] as PlateRead['vehicle_type'],
    direction: chance(0.5) ? 'inbound' : 'outbound',
    confidence: Math.round((0.82 + rf() * 0.17) * 100) / 100,
    snapshot_id: `snap-${Date.now().toString(36)}-${idCounter}`,
    hotlist_hit: !!hit,
    hotlist_id: hit?.hotlistId,
    captured_at: new Date().toISOString(),
  };
}

function pushAlert(
  orgId: string,
  org: OrgState,
  partial: Pick<Alert, 'type' | 'severity' | 'source_kind' | 'source_id' | 'source_name' | 'title' | 'ai_summary' | 'lat' | 'lng'> & { plate_read_id?: string | null },
  evidence: { kind: AlertEvidence['kind']; seed: string }[],
): Alert {
  const now = new Date().toISOString();
  const alert: Alert = {
    id: uid('al'),
    org_id: orgId,
    ai_confidence: Math.round((0.8 + rf() * 0.18) * 100) / 100,
    status: 'new',
    assigned_guard_id: null,
    acknowledged_by: null,
    acknowledged_at: null,
    resolved_at: null,
    plate_read_id: partial.plate_read_id ?? null,
    created_at: now,
    updated_at: now,
    escalated: false,
    escalated_at: null,
    ...partial,
  };
  const newEvidence: AlertEvidence[] = evidence.map((e) => ({
    id: uid('ev'),
    org_id: orgId,
    alert_id: alert.id,
    kind: e.kind,
    storage_path: `proc://${e.kind}/${e.seed}`,
    captured_at: now,
  }));
  store.setOrgSlices(orgId, {
    alerts: [alert, ...org.alerts].slice(0, 300),
    evidence: [...newEvidence, ...org.evidence].slice(0, 800),
  });
  writeAudit(orgId, {
    actor: 'SYSTEM', action: 'alert.create', entity_kind: 'alert', entity_id: alert.id,
    detail: `New ${alert.severity} alert — ${alert.title}`,
  });
  if (alert.severity === 'high' || alert.severity === 'critical') {
    emitAppEvent({ kind: 'alert', alert });
  }
  return alert;
}

function fireHotlistAlert(orgId: string, org: OrgState, read: PlateRead, camera: Camera): void {
  const list = org.hotlists.find((h) => h.id === read.hotlist_id);
  const entry = list?.entries.find((e) => e.plate === read.plate);
  const severity: Severity = entry?.priority === 'critical' ? 'critical' : entry?.priority === 'medium' ? 'medium' : 'high';
  pushAlert(
    orgId,
    org,
    {
      type: 'hotlist_hit',
      severity,
      source_kind: 'alpr',
      source_id: camera.id,
      source_name: camera.name,
      title: `Hotlist vehicle detected — ${read.plate}`,
      ai_summary: `ALPR matched ${read.plate} on "${list?.name ?? 'hotlist'}" at ${camera.name} (${read.direction}). ${entry?.reason ?? 'Flagged plate'} — ${read.vehicle_color} ${read.vehicle_make}. Gate footage and plate crop attached.`,
      lat: camera.lat,
      lng: camera.lng,
      plate_read_id: read.id,
    },
    [
      { kind: 'snapshot', seed: read.id },
      { kind: 'plate_crop', seed: read.plate },
    ],
  );
}

/* ── Per-slice tickers ───────────────────────────────────────────────────── */

function tickDrones(orgId: string, org: OrgState): void {
  let changed = false;
  const nowIso = new Date().toISOString();
  const next = org.drones.map((d) => {
    const drone: Drone = { ...d };
    if (drone.status === 'charging') {
      drone.battery_pct = Math.min(100, drone.battery_pct + 1.2);
      drone.altitude_m = 0;
      drone.speed_mps = 0;
      if (drone.battery_pct >= 99) {
        drone.status = 'patrolling';
        drone.altitude_m = rint(45, 80);
      }
      drone.last_heartbeat = nowIso;
      changed = true;
      return drone;
    }
    if (drone.status === 'idle') {
      if (chance(1 / 600) && drone.battery_pct > 60) {
        drone.status = 'patrolling';
        drone.last_heartbeat = nowIso;
        changed = true;
        return drone;
      }
      return d;
    }
    // patrolling / responding / returning
    const target =
      drone.status === 'responding' && drone.respond_target
        ? drone.respond_target
        : drone.status === 'returning'
          ? { lat: drone.base_lat, lng: drone.base_lng }
          : drone.waypoints[drone.current_waypoint] ?? { lat: drone.base_lat, lng: drone.base_lng };
    const speed = drone.status === 'responding' ? 16 : drone.status === 'returning' ? 13 : 8 + rf() * 3;
    const step = moveToward(drone.lat, drone.lng, target.lat, target.lng, speed);
    drone.lat = step.lat;
    drone.lng = step.lng;
    drone.speed_mps = speed + (rf() - 0.5);
    drone.altitude_m = Math.max(35, Math.min(120, (drone.altitude_m || rint(50, 70)) + (rf() - 0.5) * 2));
    drone.battery_pct = Math.max(0, drone.battery_pct - (drone.status === 'responding' ? 0.05 : 0.025));
    drone.signal_pct = Math.max(60, Math.min(99, drone.signal_pct + (rf() - 0.5) * 4));
    drone.trail = [...drone.trail, { lat: drone.lat, lng: drone.lng, at: nowIso }].slice(-24);
    if (step.arrived) {
      if (drone.status === 'patrolling') {
        drone.current_waypoint = (drone.current_waypoint + 1) % Math.max(1, drone.waypoints.length);
      } else if (drone.status === 'returning') {
        drone.status = 'charging';
        drone.altitude_m = 0;
        drone.speed_mps = 0;
      } else if (drone.status === 'responding' && drone.respond_target) {
        // Arrival at triangulation point → follow-up evidence event
        const alertId = drone.respond_target.alert_id;
        drone.respond_target = null;
        drone.status = 'returning';
        const ev: AlertEvidence = {
          id: uid('ev'), org_id: orgId, alert_id: alertId, kind: 'thermal',
          storage_path: `proc://thermal/${alertId}-aerial`, captured_at: nowIso,
        };
        const cur = store.getOrgState(orgId);
        store.setOrgSlices(orgId, {
          alerts: cur.alerts.map((a) =>
            a.id === alertId
              ? { ...a, updated_at: nowIso, ai_summary: `${a.ai_summary} Aerial unit ${drone.callsign} on station — thermal sweep attached.` }
              : a,
          ),
          evidence: [ev, ...cur.evidence].slice(0, 800),
        });
        writeAudit(orgId, {
          actor: 'SYSTEM', action: 'drone.on_station', entity_kind: 'drone', entity_id: drone.id,
          detail: `${drone.callsign} arrived at triangulation point; aerial evidence captured`,
        });
      }
    }
    if (drone.battery_pct < 22 && drone.status === 'patrolling') drone.status = 'returning';
    drone.last_heartbeat = nowIso;
    changed = true;
    return drone;
  });
  if (changed) store.setOrgSlices(orgId, { drones: next });
}

function tickGuards(orgId: string, org: OrgState): void {
  let changed = false;
  const next = org.guards.map((g) => {
    if (g.status === 'responding' && g.dispatch_target) {
      changed = true;
      const step = moveToward(g.lat, g.lng, g.dispatch_target.lat, g.dispatch_target.lng, 22 + rf() * 8);
      if (step.arrived) {
        return { ...g, lat: step.lat, lng: step.lng, status: 'on_duty' as const, dispatch_target: null };
      }
      return { ...g, lat: step.lat, lng: step.lng };
    }
    if ((g.status === 'on_duty' || g.status === 'on_break') && chance(0.3)) {
      changed = true;
      const drift = 0.00012;
      const nl = g.lat + (rf() - 0.5) * drift;
      const ng = g.lng + (rf() - 0.5) * drift;
      return { ...g, lat: nl + (g.base_lat - nl) * 0.02, lng: ng + (g.base_lng - ng) * 0.02 };
    }
    return g;
  });
  if (changed) store.setOrgSlices(orgId, { guards: next });
}

let camTickPhase = 0;
function tickCameras(orgId: string, org: OrgState): void {
  camTickPhase += 1;
  const heartbeatDue = camTickPhase % 5 === 0;
  let changed = heartbeatDue;
  const nowIso = new Date().toISOString();
  const extraAlerts: Camera[] = [];
  const next = org.cameras.map((c) => {
    let cam = heartbeatDue
      ? { ...c, last_heartbeat: nowIso, storage_used_pct: Math.min(96, c.storage_used_pct + 0.004) }
      : c;
    if (cam.status === 'offline') {
      if (chance(1 / 90)) {
        cam = { ...cam, status: 'degraded' as const, last_heartbeat: nowIso };
        changed = true;
      }
    } else if (cam.status === 'degraded') {
      if (chance(1 / 150)) {
        cam = { ...cam, status: 'online' as const };
        changed = true;
      } else if (chance(1 / 900)) {
        cam = { ...cam, status: 'offline' as const };
        changed = true;
        extraAlerts.push(cam);
      }
    } else if (chance(1 / 3600)) {
      cam = { ...cam, status: 'degraded' as const };
      changed = true;
    }
    return cam;
  });
  if (changed) store.setOrgSlices(orgId, { cameras: next });
  for (const cam of extraAlerts) offlineAlert(orgId, cam);
}

function offlineAlert(orgId: string, cam: Camera): void {
  const org = store.getOrgState(orgId);
  if (org.alerts.some((a) => a.type === 'offline_device' && a.source_id === cam.id && OPEN_STATUSES.has(a.status))) return;
  pushAlert(
    orgId, org,
    {
      type: 'offline_device', severity: 'medium', source_kind: 'camera',
      source_id: cam.id, source_name: cam.name,
      title: `Device offline — ${cam.name}`,
      ai_summary: `${cam.name} missed 3 consecutive heartbeats. Last known state captured; field reset recommended if not recovered within 10 minutes.`,
      lat: cam.lat, lng: cam.lng,
    },
    [{ kind: 'snapshot', seed: cam.id }],
  );
}

function tickPlateReads(orgId: string, org: OrgState): void {
  const hour = new Date().getHours() + new Date().getMinutes() / 60;
  const w = hourWeight(hour);
  const newReads: PlateRead[] = [];
  const gates = org.cameras.filter((c) => c.kind === 'fixed_alpr' && c.status !== 'offline');
  for (const cam of gates) {
    // ~55 reads/hour baseline per gate, scaled by time-of-day weight
    if (chance((55 / 3600) * w * 1.15)) {
      newReads.push(makeLiveRead(org, orgId, cam));
    }
  }
  // occasional reads on other cameras
  for (const cam of org.cameras) {
    if (cam.kind === 'fixed_alpr' || cam.kind === 'doorbell' || cam.status === 'offline') continue;
    if (chance(0.0025)) newReads.push(makeLiveRead(org, orgId, cam));
  }
  // freshly added hotlist entries must hit within 30s
  for (const list of org.hotlists) {
    if (!list.enabled) continue;
    for (const entry of list.entries) {
      if (forcedHitDone.has(entry.id)) continue;
      const ageMs = Date.now() - new Date(entry.added_at).getTime();
      if (ageMs > 30_000) {
        forcedHitDone.add(entry.id);
        continue;
      }
      // schedule the forced hit: probability scaled to land inside the remaining window
      const remaining = Math.max(1, 30_000 - ageMs);
      if (gates.length && chance(Math.min(1, 2000 / remaining))) {
        const cam = rpick(gates);
        const read = makeLiveRead(org, orgId, cam, { plate: entry.plate, hotlistId: list.id });
        forcedHitDone.add(entry.id);
        newReads.push(read);
      }
    }
  }
  if (!newReads.length) return;
  newReads.sort((a, b) => b.captured_at.localeCompare(a.captured_at));
  store.setOrgSlices(orgId, { plateReads: [...newReads, ...org.plateReads].slice(0, 3200) });
  // fire hotlist alerts after the reads are committed
  const fresh = store.getOrgState(orgId);
  for (const read of newReads) {
    if (read.hotlist_hit) {
      const cam = org.cameras.find((c) => c.id === read.camera_id);
      if (cam) fireHotlistAlert(orgId, fresh, read, cam);
    }
  }
}

function tickGunshot(orgId: string, org: OrgState): void {
  if (!chance(1 / 5400)) return; // roughly every ~90 min of live runtime
  const online = org.audioSensors.filter((s) => s.status === 'online');
  if (!online.length) return;
  const sensor = rpick(online);
  const nowIso = new Date().toISOString();
  const event: AudioEvent = {
    id: uid('ae'),
    org_id: orgId,
    sensor_id: sensor.id,
    kind: 'gunshot',
    confidence: Math.round((0.78 + rf() * 0.18) * 100) / 100,
    lat: sensor.lat + (rf() - 0.5) * 0.002,
    lng: sensor.lng + (rf() - 0.5) * 0.002,
    triangulation_radius_m: sensor.triangulation_radius_m,
    sensors_confirmed: rint(2, Math.max(2, org.audioSensors.length)),
    status: 'new',
    captured_at: nowIso,
  };
  store.setOrgSlices(orgId, { audioEvents: [event, ...org.audioEvents].slice(0, 120) });
  const alert = pushAlert(
    orgId, store.getOrgState(orgId),
    {
      type: 'gunshot', severity: 'critical', source_kind: 'audio',
      source_id: sensor.id, source_name: sensor.name,
      title: `Gunshot detected — triangulated near ${sensor.zone}`,
      ai_summary: `Acoustic sensors confirmed a gunshot signature (${event.sensors_confirmed} nodes, ${Math.round(event.confidence * 100)}% confidence). Triangulation radius ${event.triangulation_radius_m}m. Nearest drone auto-dispatched for aerial confirmation.`,
      lat: event.lat, lng: event.lng,
    },
    [
      { kind: 'audio_clip', seed: event.id },
      { kind: 'snapshot', seed: event.id },
    ],
  );
  // auto-dispatch nearest available drone
  const fresh = store.getOrgState(orgId);
  const candidates = fresh.drones.filter((d) => d.status === 'patrolling' || d.status === 'idle');
  if (candidates.length) {
    let best = candidates[0];
    let bestD = Infinity;
    for (const d of candidates) {
      const dist = Math.hypot(d.lat - event.lat, d.lng - event.lng);
      if (dist < bestD) {
        bestD = dist;
        best = d;
      }
    }
    store.setOrgSlices(orgId, {
      drones: fresh.drones.map((d) =>
        d.id === best.id
          ? { ...d, status: 'responding' as const, respond_target: { lat: event.lat, lng: event.lng, alert_id: alert.id }, altitude_m: Math.max(d.altitude_m, 60) }
          : d,
      ),
    });
    writeAudit(orgId, {
      actor: 'SYSTEM', action: 'drone.auto_dispatch', entity_kind: 'drone', entity_id: best.id,
      detail: `${best.callsign} auto-dispatched to gunshot triangulation (alert ${alert.id})`,
    });
  }
}

const RANDOM_ALERT_POOL: readonly (readonly [AlertType, Severity, number])[] = [
  ['perimeter_breach', 'high', 1 / 4200],
  ['unidentified_person', 'medium', 1 / 3000],
  ['loitering', 'low', 1 / 2600],
  ['tailgating', 'medium', 1 / 5400],
  ['drone_anomaly', 'medium', 1 / 7200],
  ['fire_smoke', 'high', 1 / 10800],
];
const RANDOM_TITLES: Record<string, (src: string) => { title: string; summary: string }> = {
  perimeter_breach: (s) => ({ title: `Perimeter breach — ${s}`, summary: `Thermal+motion fusion detected human crossing at the perimeter line near ${s}. No matching resident access event in window.` }),
  unidentified_person: (s) => ({ title: `Unidentified person — ${s}`, summary: `Person detected outside resident access hours at ${s}. No biometric or access-tag match on record.` }),
  loitering: (s) => ({ title: `Loitering vehicle — ${s}`, summary: `Vehicle stationary in no-stopping zone near ${s} for over 6 minutes. Plate captured; no resident association.` }),
  tailgating: (s) => ({ title: `Tailgating event — ${s}`, summary: `Second vehicle followed a resident through the boom at ${s}. Plate captured on exit camera; cross-checking hotlists.` }),
  drone_anomaly: (s) => ({ title: `Drone telemetry anomaly — ${s}`, summary: `${s} reported signal drift outside patrol envelope. Auto-failsafe armed; monitoring recovery.` }),
  fire_smoke: (s) => ({ title: `Possible smoke signature — ${s}`, summary: `Vision model flagged a smoke-like plume in frame at ${s}. Thermal channel inconclusive.` }),
};

function tickRandomAlerts(orgId: string, org: OrgState): void {
  const night = new Date().getHours() >= 20 || new Date().getHours() < 6;
  for (const [type, severity, baseP] of RANDOM_ALERT_POOL) {
    const p = type === 'perimeter_breach' && night ? baseP * 3 : baseP;
    if (!chance(p)) continue;
    if (type === 'drone_anomaly') {
      const d = rpick(org.drones);
      const t = RANDOM_TITLES[type](d.callsign);
      pushAlert(orgId, store.getOrgState(orgId), {
        type, severity, source_kind: 'drone', source_id: d.id, source_name: d.callsign,
        title: t.title, ai_summary: t.summary, lat: d.lat, lng: d.lng,
      }, [{ kind: 'snapshot', seed: d.id }]);
    } else {
      const cams = org.cameras.filter((c) => c.status !== 'offline');
      if (!cams.length) continue;
      const cam = rpick(cams);
      const t = RANDOM_TITLES[type](cam.name);
      pushAlert(orgId, store.getOrgState(orgId), {
        type, severity, source_kind: 'camera', source_id: cam.id, source_name: cam.name,
        title: t.title, ai_summary: t.summary, lat: cam.lat, lng: cam.lng,
      }, [{ kind: 'snapshot', seed: `${cam.id}-${Date.now().toString(36)}` }]);
    }
  }
}

function tickEscalation(orgId: string, org: OrgState): void {
  const now = Date.now();
  let changed = false;
  const escalations: Alert[] = [];
  const next = org.alerts.map((a) => {
    if (a.status !== 'new' || a.escalated) return a;
    const rule = org.routingRules.find((r) => r.severity === a.severity && r.enabled);
    if (!rule) return a;
    const ageSec = (now - new Date(a.created_at).getTime()) / 1000;
    if (ageSec < rule.escalate_after_sec) return a;
    changed = true;
    const bumped: Severity = a.severity === 'low' ? 'medium' : a.severity === 'medium' ? 'high' : 'critical';
    const updated: Alert = {
      ...a,
      severity: bumped,
      escalated: true,
      escalated_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    escalations.push(updated);
    return updated;
  });
  if (!changed) return;
  store.setOrgSlices(orgId, { alerts: next });
  for (const updated of escalations) {
    writeAudit(orgId, {
      actor: 'SYSTEM', action: 'alert.escalate', entity_kind: 'alert', entity_id: updated.id,
      detail: `Unacknowledged past escalation window — severity escalated to ${updated.severity.toUpperCase()}; second routing fired`,
    });
    emitAppEvent({ kind: 'alert', alert: updated });
  }
}

/* ── Engine lifecycle ────────────────────────────────────────────────────── */

let timer: ReturnType<typeof setInterval> | null = null;

function tick(): void {
  const state = store.getState();
  if (!state.realtimeRunning) return;
  const orgId = state.activeOrgId;
  const org = store.getOrgState(orgId);
  if (!org) return;
  lastTickAt = Date.now();
  try {
    tickDrones(orgId, org);
    tickGuards(orgId, store.getOrgState(orgId));
    tickCameras(orgId, store.getOrgState(orgId));
    tickPlateReads(orgId, store.getOrgState(orgId));
    tickGunshot(orgId, store.getOrgState(orgId));
    tickRandomAlerts(orgId, store.getOrgState(orgId));
    tickEscalation(orgId, store.getOrgState(orgId));
  } catch (err) {
    // never let a tick kill the loop
    console.error('[simulator] tick error', err);
  }
  emitRt();
}

export function startSimulator(): void {
  if (timer) return;
  timer = setInterval(tick, 1000);
}

export function stopSimulator(): void {
  if (timer) {
    clearInterval(timer);
    timer = null;
  }
}

/** Used by resetDemoData consumers to re-arm forced-hit tracking. */
export function resetSimulatorSession(): void {
  forcedHitDone.clear();
  idCounter = hashString(String(Date.now())) % 10000;
}
