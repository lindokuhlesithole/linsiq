/**
 * SWEALTH OS — procedural visuals (design.md §12).
 * All imagery is code-generated and seeded by entity id so every camera feed,
 * evidence thumbnail, plate crop and map is distinct but stable across renders.
 * (Plain .ts with createElement — no JSX — per scaffold contract.)
 */
import { createElement as h, memo } from 'react';
import type { ReactNode, SVGProps } from 'react';
import { hashString, mulberry32 } from './seed';
import type { CameraKind } from './types';

function seededRng(seed: string): () => number {
  return mulberry32(hashString(seed));
}

/* ── Palette (mirrors tailwind tokens; used inside SVG attribute space) ──── */
const C = {
  sky0: '#0d1b2e',
  sky1: '#060D1A',
  ground: '#081226',
  silhouette: '#12233f',
  silhouette2: '#16294A',
  street: '#1B2F52',
  dash: 'rgba(168,178,209,0.35)',
  accent: '#00D4AA',
  danger: '#E71D36',
  warning: '#FF9F1C',
  info: '#4CC9F0',
  muted: '#5C6B8A',
  primary: '#E6F1FF',
  headlight: 'rgba(230,241,255,0.9)',
  taillight: 'rgba(231,29,54,0.8)',
};

/* ══════════════════════════════════════════════════════════════════════════
 * CameraScene — procedural night feed seeded by camera id (design.md §6.4)
 * ══════════════════════════════════════════════════════════════════════════ */

export interface CameraSceneProps extends SVGProps<SVGSVGElement> {
  seed: string;
  kind?: CameraKind;
  /** heavier static noise (degraded cameras) */
  noisy?: boolean;
}

function vehicleDot(rng: () => number, i: number, y: number, dir: 1 | -1): ReactNode {
  const dur = 4 + rng() * 5;
  const begin = -(rng() * dur);
  const glow = dir === 1 ? C.headlight : C.taillight;
  return h('g', { key: `veh-${i}` }, [
    h('circle', { key: 'glow', r: 5, fill: glow, opacity: 0.25 }, [
      h('animate', { key: 'a1', attributeName: 'cx', from: dir === 1 ? -30 : 350, to: dir === 1 ? 350 : -30, dur: `${dur}s`, begin: `${begin}s`, repeatCount: 'indefinite' }),
      h('animate', { key: 'a2', attributeName: 'cy', values: `${y};${y - 2};${y}`, dur: `${dur}s`, begin: `${begin}s`, repeatCount: 'indefinite' }),
    ]),
    h('circle', { key: 'dot', r: 2, fill: glow, opacity: 0.95 }, [
      h('animate', { key: 'a1', attributeName: 'cx', from: dir === 1 ? -30 : 350, to: dir === 1 ? 350 : -30, dur: `${dur}s`, begin: `${begin}s`, repeatCount: 'indefinite' }),
      h('animate', { key: 'a2', attributeName: 'cy', values: `${y};${y - 2};${y}`, dur: `${dur}s`, begin: `${begin}s`, repeatCount: 'indefinite' }),
    ]),
  ]);
}

function treeRow(rng: () => number, y: number, count: number): ReactNode {
  const trees: ReactNode[] = [];
  for (let i = 0; i < count; i++) {
    const x = 12 + (i / count) * 296 + rng() * 18;
    const s = 6 + rng() * 8;
    trees.push(
      h('path', {
        key: `tree-${i}`,
        d: `M ${x} ${y} l ${s * 0.5} -${s} l ${s * 0.5} ${s} z M ${x + s * 0.5} ${y} v 3`,
        fill: C.silhouette,
        opacity: 0.85,
      }),
    );
  }
  return h('g', { key: 'trees' }, trees);
}

export const CameraScene = memo(function CameraScene({ seed, kind = 'bullet', noisy = false, ...rest }: CameraSceneProps) {
  const rng = seededRng(seed);
  const isGate = kind === 'fixed_alpr';
  const uid = hashString(seed).toString(36);
  const skyId = `sky-${uid}`;
  const vigId = `vig-${uid}`;
  const noiseId = `nz-${uid}`;

  const horizon = isGate ? 118 : 108 + Math.floor(rng() * 14);
  const children: ReactNode[] = [];

  // sky + ground
  children.push(h('rect', { key: 'sky', x: 0, y: 0, width: 320, height: horizon, fill: `url(#${skyId})` }));
  children.push(h('rect', { key: 'ground', x: 0, y: horizon, width: 320, height: 180 - horizon, fill: C.ground }));

  if (isGate) {
    // road with lane dashes
    children.push(h('rect', { key: 'road', x: 0, y: horizon + 14, width: 320, height: 34, fill: C.street, opacity: 0.9 }));
    const dashes: ReactNode[] = [];
    for (let x = 0; x < 320; x += 26) {
      dashes.push(h('rect', { key: `d-${x}`, x, y: horizon + 30, width: 12, height: 1.6, fill: C.dash }));
    }
    children.push(h('g', { key: 'dashes' }, dashes));
    // perimeter wall
    children.push(h('rect', { key: 'wall', x: 0, y: horizon - 6, width: 320, height: 8, fill: C.silhouette, opacity: 0.9 }));
    // gate boom (diagonal) + post
    const bx = 200 + rng() * 60;
    children.push(h('rect', { key: 'post', x: bx, y: horizon - 16, width: 5, height: 26, fill: C.silhouette2 }));
    children.push(
      h('rect', {
        key: 'boom',
        x: bx + 2, y: horizon - 18, width: 70, height: 3.4, rx: 1,
        fill: C.silhouette2,
        transform: `rotate(${-18 - rng() * 10} ${bx + 2} ${horizon - 16})`,
      }),
    );
    // boom stripes
    children.push(h('rect', { key: 'stripe', x: bx + 8, y: horizon - 18, width: 10, height: 3.4, fill: C.danger, opacity: 0.55, transform: `rotate(-22 ${bx + 2} ${horizon - 16})` }));
    // vehicle dots with headlight/taillight glow crossing the gate
    const count = 2 + Math.floor(rng() * 2);
    const dots: ReactNode[] = [];
    for (let i = 0; i < count; i++) {
      dots.push(vehicleDot(rng, i, horizon + 22 + (i % 2) * 12, i % 2 === 0 ? 1 : -1));
    }
    children.push(h('g', { key: 'vehicles' }, dots));
  } else {
    // generic estate scene: wall line + tree silhouettes + occasional distant dot
    children.push(h('rect', { key: 'wall', x: 0, y: horizon - 4, width: 320, height: 6, fill: C.silhouette, opacity: 0.8 }));
    children.push(treeRow(rng, horizon - 4, 4 + Math.floor(rng() * 4)));
    if (rng() > 0.4) children.push(vehicleDot(rng, 0, horizon + 18, rng() > 0.5 ? 1 : -1));
    // lamp posts
    const lamps: ReactNode[] = [];
    const lampCount = 1 + Math.floor(rng() * 2);
    for (let i = 0; i < lampCount; i++) {
      const lx = 40 + rng() * 240;
      lamps.push(h('line', { key: `lp-${i}`, x1: lx, y1: horizon, x2: lx, y2: horizon - 26, stroke: C.silhouette2, strokeWidth: 2 }));
      lamps.push(h('circle', { key: `lpg-${i}`, cx: lx, cy: horizon - 26, r: 6, fill: C.accent, opacity: 0.12 }));
      lamps.push(h('circle', { key: `lpd-${i}`, cx: lx, cy: horizon - 26, r: 1.6, fill: C.accent, opacity: 0.6 }));
    }
    children.push(h('g', { key: 'lamps' }, lamps));
  }

  // static noise
  children.push(
    h('rect', { key: 'noise', x: 0, y: 0, width: 320, height: 180, filter: `url(#${noiseId})`, opacity: noisy ? 0.35 : 0.14 }),
  );
  // IR vignette
  children.push(h('rect', { key: 'vig', x: 0, y: 0, width: 320, height: 180, fill: `url(#${vigId})` }));

  return h(
    'svg',
    { viewBox: '0 0 320 180', preserveAspectRatio: 'xMidYMid slice', 'aria-hidden': true, ...rest },
    [
      h('defs', { key: 'defs' }, [
        h('linearGradient', { key: 'sky', id: skyId, x1: 0, y1: 0, x2: 0, y2: 1 }, [
          h('stop', { key: 's0', offset: '0%', stopColor: C.sky0 }),
          h('stop', { key: 's1', offset: '100%', stopColor: C.sky1 }),
        ]),
        h('radialGradient', { key: 'vig', id: vigId, cx: 0.5, cy: 0.5, r: 0.75 }, [
          h('stop', { key: 'v0', offset: '55%', stopColor: 'rgba(2,6,17,0)' }),
          h('stop', { key: 'v1', offset: '100%', stopColor: 'rgba(2,6,17,0.55)' }),
        ]),
        h('filter', { key: 'nz', id: noiseId }, [
          h('feTurbulence', { key: 't', type: 'fractalNoise', baseFrequency: 0.9, numOctaves: 2, seed: hashString(seed) % 97 }),
          h('feColorMatrix', { key: 'm', type: 'matrix', values: '0 0 0 0 0.9  0 0 0 0 0.95  0 0 0 0 1  0 0 0 0.5 0' }),
        ]),
      ]),
      ...children,
    ],
  );
});

/* ══════════════════════════════════════════════════════════════════════════
 * Plate crop — enlarged mono plate on a dark plinth (design.md §6.11)
 * ══════════════════════════════════════════════════════════════════════════ */

export function plateCropSvg(plate: string, w = 200, hgt = 64): ReactNode {
  const province = plate.slice(0, 2);
  return h('svg', { viewBox: '0 0 200 64', width: w, height: hgt, 'aria-hidden': true }, [
    h('rect', { key: 'bg', x: 0, y: 0, width: 200, height: 64, fill: '#081226' }),
    h('rect', { key: 'plinth', x: 10, y: 10, width: 180, height: 44, rx: 2, fill: '#16294A', stroke: 'rgba(100,255,218,0.25)' }),
    h('rect', { key: 'band', x: 10, y: 10, width: 26, height: 44, rx: 2, fill: 'rgba(76,201,240,0.15)' }),
    h('text', { key: 'prov', x: 23, y: 38, textAnchor: 'middle', fontFamily: '"JetBrains Mono", monospace', fontSize: 13, fontWeight: 600, fill: C.info }, province),
    h('text', { key: 'plate', x: 116, y: 40, textAnchor: 'middle', fontFamily: '"JetBrains Mono", monospace', fontSize: 21, fontWeight: 600, letterSpacing: 1.5, fill: C.primary }, plate.slice(2).trim() || plate),
  ]);
}

/* ══════════════════════════════════════════════════════════════════════════
 * Audio waveform (design.md §6.11)
 * ══════════════════════════════════════════════════════════════════════════ */

export function audioWaveformSvg(seed: string, w = 200, hgt = 64, accent = false): ReactNode {
  const rng = seededRng(seed);
  const bars: ReactNode[] = [];
  const n = 42;
  for (let i = 0; i < n; i++) {
    const env = Math.sin((i / n) * Math.PI) * (0.4 + rng() * 0.6);
    const bh = Math.max(2, env * (hgt - 12));
    bars.push(
      h('rect', {
        key: i,
        x: 4 + i * ((w - 8) / n),
        y: (hgt - bh) / 2,
        width: Math.max(1.6, (w - 8) / n - 1.6),
        height: bh,
        fill: accent ? C.danger : C.accent,
        opacity: 0.35 + env * 0.6,
      }),
    );
  }
  return h('svg', { viewBox: `0 0 ${w} ${hgt}`, width: w, height: hgt, 'aria-hidden': true }, [
    h('rect', { key: 'bg', x: 0, y: 0, width: w, height: hgt, fill: '#081226' }),
    ...bars,
  ]);
}

/* ══════════════════════════════════════════════════════════════════════════
 * Evidence thumbnails — snapshot / plate_crop / audio_clip / video_clip / thermal
 * ══════════════════════════════════════════════════════════════════════════ */

export function evidenceThumbSvg(kind: string, seed: string, w = 160, hgt = 90): ReactNode {
  if (kind === 'plate_crop') {
    return plateCropSvg(seed.length > 3 ? seed.toUpperCase() : 'GP 482-913', w, hgt);
  }
  if (kind === 'audio_clip') {
    return audioWaveformSvg(seed, w, hgt, true);
  }
  if (kind === 'thermal') {
    const rng = seededRng(seed);
    const blocks: ReactNode[] = [];
    const cols = 16;
    const rows = 9;
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        const v = rng();
        // false-color: mostly cold navy, sparse hot amber/red blobs
        const hot = Math.sin(x * 0.55 + hashString(seed) % 7) + Math.cos(y * 0.7) > 1.1 && v > 0.35;
        const fill = hot ? (v > 0.75 ? C.danger : C.warning) : v > 0.85 ? '#1B2F52' : '#081226';
        blocks.push(h('rect', { key: `${x}-${y}`, x: x * 10, y: y * 10, width: 10, height: 10, fill, opacity: hot ? 0.75 : 1 }));
      }
    }
    return h('svg', { viewBox: '0 0 160 90', width: w, height: hgt, 'aria-hidden': true }, blocks);
  }
  // snapshot / video_clip → mini camera scene
  return h(CameraScene, { seed, kind: hashString(seed) % 3 === 0 ? 'fixed_alpr' : 'bullet', width: w, height: hgt });
}

/* ══════════════════════════════════════════════════════════════════════════
 * Tenant street geometry — hand-authored SVG path data per tenant (§6.5)
 * ══════════════════════════════════════════════════════════════════════════ */

export interface ZoneLabel {
  label: string;
  x: number;
  y: number;
}

export interface TenantGeometry {
  viewBox: string;
  width: number;
  height: number;
  streets: string[];
  boundary: string;
  water?: string; // lake / harbour fill path
  waterLabel?: ZoneLabel;
  zones: ZoneLabel[];
  bbox: { minLat: number; maxLat: number; minLng: number; maxLng: number };
  /** lat/lng → svg coordinates (linear projection within bbox) */
  project: (lat: number, lng: number) => { x: number; y: number };
  /** svg coordinates → lat/lng (cursor readout) */
  unproject: (x: number, y: number) => { lat: number; lng: number };
}

function makeGeometry(
  center: { lat: number; lng: number },
  spread: number,
  width: number,
  height: number,
  streets: string[],
  boundary: string,
  zones: ZoneLabel[],
  water?: string,
  waterLabel?: ZoneLabel,
): TenantGeometry {
  const bbox = {
    minLat: center.lat - spread * 1.28,
    maxLat: center.lat + spread * 1.28,
    minLng: center.lng - spread * 1.28,
    maxLng: center.lng + spread * 1.28,
  };
  return {
    viewBox: `0 0 ${width} ${height}`,
    width,
    height,
    streets,
    boundary,
    zones,
    water,
    waterLabel,
    bbox,
    project: (lat, lng) => ({
      x: ((lng - bbox.minLng) / (bbox.maxLng - bbox.minLng)) * width,
      y: (1 - (lat - bbox.minLat) / (bbox.maxLat - bbox.minLat)) * height,
    }),
    unproject: (x, y) => ({
      lat: bbox.minLat + (1 - y / height) * (bbox.maxLat - bbox.minLat),
      lng: bbox.minLng + (x / width) * (bbox.maxLng - bbox.minLng),
    }),
  };
}

const GEOMETRY_CACHE = new Map<string, TenantGeometry>();

export function getTenantGeometry(orgId: string): TenantGeometry {
  const cached = GEOMETRY_CACHE.get(orgId);
  if (cached) return cached;
  let geo: TenantGeometry;
  if (orgId === 'org-waterfall-heights') {
    geo = makeGeometry(

      { lat: -25.9987, lng: 28.0913 },
      0.0062,
      1000,
      620,
      [
        'M 60 480 C 220 430 380 460 520 400 C 660 340 800 360 950 300',
        'M 120 560 C 200 420 180 260 260 120',
        'M 260 120 C 420 160 560 120 700 170 C 800 205 880 190 950 300',
        'M 520 400 C 540 300 520 230 560 130',
        'M 700 170 C 720 260 760 320 950 300',
        'M 60 480 C 90 380 60 240 140 150',
        'M 330 505 C 420 480 500 500 590 470',
        'M 140 150 C 190 135 230 130 260 120',
      ],
      'M 60 480 C 40 380 55 230 140 150 C 180 110 220 100 260 95 C 420 130 560 95 705 145 C 810 180 905 175 965 285 C 975 300 970 315 950 330 C 830 385 700 370 590 425 C 480 480 320 515 200 520 C 130 525 75 515 60 480 Z',
      [
        { label: 'WEST GATE', x: 88, y: 492 },
        { label: 'EAST GATE', x: 900, y: 288 },
        { label: 'RIDGE VIEW', x: 620, y: 120 },
        { label: 'CLUBHOUSE', x: 480, y: 330 },
        { label: 'PERIMETER N', x: 380, y: 80 },
        { label: 'PERIMETER S', x: 420, y: 560 },
      ],
    );
  } else if (orgId === 'org-camps-bay-marina') {
    geo = makeGeometry(

      { lat: -33.9521, lng: 18.3798 },
      0.0058,
      1000,
      620,
      [
        'M 40 140 C 240 190 460 170 660 220 C 800 255 900 250 970 240',
        'M 90 520 C 220 430 300 300 330 180',
        'M 330 180 C 470 150 620 160 770 130',
        'M 90 520 C 300 540 520 520 720 470 C 850 440 930 380 970 240',
        'M 520 515 C 540 420 520 330 560 210',
        'M 720 470 C 740 380 720 250 770 130',
        'M 200 300 C 300 320 420 310 520 340',
      ],
      'M 40 140 C 30 90 80 60 150 70 C 300 30 560 40 770 100 C 880 130 950 170 985 235 C 995 260 985 300 965 330 C 940 420 860 480 720 520 C 520 570 260 575 95 545 C 45 535 30 480 40 420 C 55 330 30 230 40 140 Z',
      [
        { label: 'MARINA GATE', x: 110, y: 120 },
        { label: 'HARBOUR WALK', x: 720, y: 560 },
        { label: 'PROMENADE', x: 850, y: 200 },
        { label: 'DOCK B', x: 130, y: 480 },
        { label: 'CLUBHOUSE', x: 470, y: 320 },
        { label: 'PERIMETER', x: 420, y: 60 },
      ],
      'M 0 560 C 200 600 420 590 620 610 L 1000 620 L 1000 620 L 0 620 Z M 850 620 C 900 560 960 480 1000 420 L 1000 620 Z',
      { label: 'HARBOUR', x: 250, y: 600 },
    );
  } else {
    // Silver Lakes Estate, Pretoria (default) — with the glinting lake
    geo = makeGeometry(

      { lat: -25.7835, lng: 28.3612 },
      0.0075,
      1000,
      620,
      [
        // ring road
        'M 150 320 C 150 200 300 120 500 120 C 700 120 850 200 850 320 C 850 440 700 520 500 520 C 300 520 150 440 150 320 Z',
        // feeders
        'M 500 120 C 505 80 495 50 500 18',
        'M 150 320 C 100 325 60 318 18 322',
        'M 500 520 C 498 555 502 580 500 604',
        'M 850 320 C 890 318 930 325 982 320',
        // inner streets
        'M 320 210 C 420 260 580 260 680 210',
        'M 320 430 C 420 385 580 385 680 430',
        'M 350 160 C 330 260 330 380 350 480',
        'M 650 160 C 670 260 670 380 650 480',
        'M 500 120 C 495 220 505 300 500 400 C 497 450 502 490 500 520',
        'M 220 260 C 300 300 380 320 460 325',
        'M 780 260 C 700 300 620 320 540 325',
      ],
      'M 500 18 C 640 22 800 60 905 160 C 970 220 995 270 982 320 C 975 420 900 500 760 555 C 650 595 560 610 500 604 C 380 600 200 570 90 480 C 30 430 8 370 18 322 C 25 230 90 130 210 70 C 320 25 420 15 500 18 Z',
      [
        { label: 'NORTH GATE', x: 480, y: 46 },
        { label: 'MAIN GATE', x: 60, y: 306 },
        { label: 'SOUTH GATE', x: 470, y: 590 },
        { label: 'LAKESIDE', x: 800, y: 480 },
        { label: 'CLUBHOUSE', x: 465, y: 300 },
        { label: 'PERIMETER W', x: 110, y: 160 },
        { label: 'PERIMETER E', x: 830, y: 180 },
        { label: 'GOLF VIEW', x: 300, y: 380 },
      ],
      // the lake (SE)
      'M 700 430 C 760 400 860 410 890 460 C 915 505 860 555 780 560 C 710 564 670 520 680 480 C 685 458 690 442 700 430 Z',
      { label: 'SILVER LAKES', x: 720, y: 500 },
    );
  }
  GEOMETRY_CACHE.set(orgId, geo);
  return geo;
}

/* ── Brand mark: hexagonal camera-aperture glyph (design.md §5.1) ────────── */

export function ApertureMark({ size = 26 }: { size?: number }): ReactNode {
  const blades: ReactNode[] = [];
  for (let i = 0; i < 6; i++) {
    const a = (i * 60 * Math.PI) / 180;
    const a2 = ((i * 60 + 60) * Math.PI) / 180;
    const x1 = 16 + Math.cos(a) * 9.5;
    const y1 = 16 + Math.sin(a) * 9.5;
    const x2 = 16 + Math.cos(a2) * 9.5;
    const y2 = 16 + Math.sin(a2) * 9.5;
    const cx = 16 + Math.cos(a + 0.52) * 4.6;
    const cy = 16 + Math.sin(a + 0.52) * 4.6;
    blades.push(h('path', { key: i, d: `M ${x1} ${y1} L ${x2} ${y2} L ${cx} ${cy} Z`, fill: 'none', stroke: C.accent, strokeWidth: 1.3, strokeLinejoin: 'round' }));
  }
  return h('svg', { width: size, height: size, viewBox: '0 0 32 32', 'aria-hidden': true }, [
    h('polygon', {
      key: 'hex',
      points: '16,2 28.1,9 28.1,23 16,30 3.9,23 3.9,9',
      fill: 'none', stroke: C.accent, strokeWidth: 1.6, strokeLinejoin: 'round',
    }),
    ...blades,
    h('circle', { key: 'lens', cx: 16, cy: 16, r: 2.1, fill: C.accent }),
  ]);
}
