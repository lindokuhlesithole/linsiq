/**
 * SWEALTH OS — core entity types (info.md §3).
 * All entities are tenant-scoped via `org_id`. Timestamps are ISO 8601 strings.
 */

/* ── Enum unions ─────────────────────────────────────────────────────────── */

export type ThreatLevel = 'LOW' | 'GUARDED' | 'ELEVATED' | 'HIGH';

export type CameraKind = 'fixed_alpr' | 'ptz' | 'bullet' | 'doorbell' | 'drone_mount';
export type CameraStatus = 'online' | 'offline' | 'recording' | 'motion' | 'degraded';

export type Province = 'GP' | 'CA' | 'NW' | 'ZN' | 'WC' | 'KZN' | 'EC' | 'FS' | 'LP' | 'MP';
export type VehicleType = 'sedan' | 'hatch' | 'suv' | 'bakkie' | 'truck' | 'motorcycle' | 'taxi';
export type Direction = 'inbound' | 'outbound';

export type HotlistKind = 'stolen_vehicle' | 'wanted_person_vehicle' | 'custom' | 'national_sync';
export type HotlistPriority = 'critical' | 'high' | 'medium';

export type AudioEventKind = 'gunshot' | 'glass_break' | 'scream' | 'explosion';
export type AudioEventStatus = 'new' | 'confirmed' | 'dismissed';

export type DroneStatus = 'idle' | 'patrolling' | 'returning' | 'charging' | 'responding';

export type GuardShift = 'day' | 'night' | 'swing';
export type GuardStatus = 'on_duty' | 'off_duty' | 'responding' | 'on_break';

export type AlertType =
  | 'hotlist_hit'
  | 'perimeter_breach'
  | 'unidentified_person'
  | 'gunshot'
  | 'drone_anomaly'
  | 'offline_device'
  | 'fire_smoke'
  | 'loitering'
  | 'tailgating';
export type Severity = 'critical' | 'high' | 'medium' | 'low';
export type AlertSourceKind = 'camera' | 'alpr' | 'audio' | 'drone' | 'guard' | 'system';
export type AlertStatus = 'new' | 'acknowledged' | 'responding' | 'resolved' | 'false_alarm';

export type EvidenceKind = 'snapshot' | 'plate_crop' | 'video_clip' | 'audio_clip' | 'thermal';

export type IncidentStatus = 'open' | 'investigating' | 'closed' | 'escalated_saps';
export type IncidentPriority = 'critical' | 'high' | 'medium' | 'low';

export type RoutingRole = 'supervisor' | 'operator' | 'manager' | 'guard';
export type RoutingChannel = 'push' | 'sms' | 'email' | 'radio';

export type PtzAction =
  | 'pan_left'
  | 'pan_right'
  | 'tilt_up'
  | 'tilt_down'
  | 'zoom_in'
  | 'zoom_out'
  | 'preset_recall'
  | 'preset_save';
export type PtzStatus = 'dispatched' | 'acknowledged' | 'completed' | 'failed';

export type Role = 'admin' | 'supervisor' | 'manager' | 'operator' | 'guard';
export type RolePreview = 'manager' | 'operator' | 'guard';

/* ── Entities ────────────────────────────────────────────────────────────── */

export interface Organization {
  id: string;
  name: string;
  slug: string;
  location: string;
  center_lat: number;
  center_lng: number;
  threat_level: ThreatLevel; // derived, recomputed from open alerts
  created_at: string;
}

export interface Camera {
  id: string;
  org_id: string;
  name: string;
  zone: string;
  kind: CameraKind;
  rtsp_url: string;
  resolution: string;
  fps: number;
  status: CameraStatus;
  ptz_enabled: boolean;
  storage_used_pct: number;
  lat: number;
  lng: number;
  heading_deg: number; // field-of-view direction (0 = north, clockwise)
  last_heartbeat: string;
  firmware: string;
  install_date: string;
}

export interface PlateRead {
  id: string;
  org_id: string;
  camera_id: string;
  plate: string; // SA format, e.g. "GP 482-913"
  province: Province;
  vehicle_color: string;
  vehicle_make: string;
  vehicle_type: VehicleType;
  direction: Direction;
  confidence: number; // 0..1
  snapshot_id: string;
  hotlist_hit: boolean;
  hotlist_id?: string;
  captured_at: string;
}

export interface HotlistEntry {
  id: string;
  plate: string;
  reason: string;
  priority: HotlistPriority;
  added_by: string;
  added_at: string;
  notes?: string;
}

export interface Hotlist {
  id: string;
  org_id: string;
  name: string;
  kind: HotlistKind;
  source: string;
  enabled: boolean;
  entries: HotlistEntry[];
}

export interface AudioSensor {
  id: string;
  org_id: string;
  name: string;
  zone: string;
  lat: number;
  lng: number;
  triangulation_radius_m: number;
  status: 'online' | 'offline';
}

export interface AudioEvent {
  id: string;
  org_id: string;
  sensor_id: string;
  kind: AudioEventKind;
  confidence: number;
  lat: number;
  lng: number;
  triangulation_radius_m: number;
  sensors_confirmed: number;
  status: AudioEventStatus;
  captured_at: string;
}

export interface Waypoint {
  lat: number;
  lng: number;
  label?: string;
}

export interface Drone {
  id: string;
  org_id: string;
  callsign: string;
  model: string;
  status: DroneStatus;
  battery_pct: number;
  altitude_m: number;
  speed_mps: number;
  signal_pct: number;
  lat: number;
  lng: number;
  base_lat: number;
  base_lng: number;
  waypoints: Waypoint[];
  current_waypoint: number;
  last_heartbeat: string;
  /** Simulator runtime fields */
  respond_target?: { lat: number; lng: number; alert_id: string } | null;
  trail: { lat: number; lng: number; at: string }[];
}

export interface Guard {
  id: string;
  org_id: string;
  full_name: string;
  badge_no: string;
  shift: GuardShift;
  status: GuardStatus;
  lat: number;
  lng: number;
  base_lat: number;
  base_lng: number;
  alerts_resolved: number;
  avg_response_sec: number;
  phone: string;
  /** Dispatch runtime: where this guard is heading */
  dispatch_target?: { lat: number; lng: number; alert_id: string } | null;
}

export interface Alert {
  id: string;
  org_id: string;
  type: AlertType;
  severity: Severity;
  source_kind: AlertSourceKind;
  source_id: string;
  source_name: string;
  title: string;
  ai_summary: string;
  ai_confidence: number; // 0..1
  status: AlertStatus;
  assigned_guard_id?: string | null;
  lat: number;
  lng: number;
  plate_read_id?: string | null;
  created_at: string;
  updated_at: string;
  acknowledged_by?: string | null;
  acknowledged_at?: string | null;
  resolved_at?: string | null;
  /** Escalation runtime: rule timer overran and severity was bumped */
  escalated?: boolean;
  escalated_at?: string | null;
}

export interface AlertEvidence {
  id: string;
  org_id: string;
  alert_id: string;
  kind: EvidenceKind;
  storage_path: string; // Phase 1: procedural reference, e.g. "proc://snapshot/<seed>"
  captured_at: string;
}

export interface Incident {
  id: string;
  org_id: string;
  case_no: string; // e.g. "SL-2026-0042"
  title: string;
  status: IncidentStatus;
  priority: IncidentPriority;
  linked_alert_ids: string[];
  linked_plate_reads: string[];
  assigned_investigator: string;
  summary: string;
  created_at: string;
  closed_at?: string | null;
  disposition?: string | null;
  notes: { id: string; author: string; text: string; created_at: string }[];
}

export interface AlertRoutingRule {
  id: string;
  org_id: string;
  severity: Severity;
  role: RoutingRole;
  channel: RoutingChannel;
  escalate_after_sec: number;
  enabled: boolean;
}

export interface PtzCommand {
  id: string;
  org_id: string;
  camera_id: string;
  action: PtzAction;
  payload: Record<string, string | number>;
  status: PtzStatus;
  dispatched_at: string;
  acknowledged_at?: string | null;
  completed_at?: string | null;
  error?: string | null;
  created_by: string;
}

export interface AuditEntry {
  id: string;
  org_id: string;
  actor: string;
  action: string;
  entity_kind: string;
  entity_id: string;
  detail: string;
  created_at: string;
}

/* ── Filter shapes used by hooks ─────────────────────────────────────────── */

export interface PlateReadFilters {
  cameraId?: string;
  direction?: Direction;
  hotlistOnly?: boolean;
  sinceMs?: number; // only reads newer than now - sinceMs
  limit?: number;
  plateQuery?: string;
}

export interface AlertFilter {
  severities?: Severity[];
  statuses?: AlertStatus[];
  types?: AlertType[];
  openOnly?: boolean;
  sinceMs?: number;
  limit?: number;
  query?: string;
}
