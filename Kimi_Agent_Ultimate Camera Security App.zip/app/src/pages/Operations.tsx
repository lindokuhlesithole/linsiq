/**
 * `/operations` — Live Operations (design/operations.md).
 * Three-column control surface: PTZ camera control · operations map with
 * MONITOR / EDIT WAYPOINTS modes · units rail (drones + guards).
 */
import { useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { Map as MapIcon, Route as RouteIcon } from 'lucide-react';
import type { Drone, Waypoint } from '@/lib/types';
import {
  dispatchGuard,
  useAlerts,
  useCameras,
  useCanOperate,
  useGuards,
  useActiveOrgId,
} from '@/hooks/useData';
import {
  Panel,
  PanelHeader,
  RouteErrorBoundary,
  SkeletonRow,
  TacticalMap,
  showToast,
} from '@/components/soc';
import { useDroneFleet } from '@/components/operations/droneOverrides';
import { PtzColumn } from '@/components/operations/PtzColumn';
import { WaypointEditor } from '@/components/operations/WaypointEditor';
import { UnitsRail } from '@/components/operations/UnitsRail';
import type { UnitsTab } from '@/components/operations/UnitsRail';
import { usePageTitle } from './Stub';
import { cn } from '@/lib/utils';

type MapMode = 'monitor' | 'waypoints';

export default function Operations() {
  usePageTitle('SWEALTH OS — Live Operations', 'PTZ control, drone patrols and guard dispatch in real time.');
  const orgId = useActiveOrgId();
  const cameras = useCameras();
  const guards = useGuards();
  const openAlerts = useAlerts({ openOnly: true });
  const canOperate = useCanOperate();
  const fleet = useDroneFleet();

  const [ready, setReady] = useState(false);
  const [selectedCamId, setSelectedCamId] = useState<string | null>(null);
  const [mapMode, setMapMode] = useState<MapMode>('monitor');
  const [unitsTab, setUnitsTab] = useState<UnitsTab>('drones');
  const [selectedDroneId, setSelectedDroneId] = useState<string | null>(null);
  const [editDroneId, setEditDroneId] = useState<string | null>(null);
  const [draftWpts, setDraftWpts] = useState<Waypoint[]>([]);

  /* mount skeleton (mirrors FleetCommand) + tenant-switch reset */
  useEffect(() => {
    setReady(false);
    setSelectedCamId(null);
    setMapMode('monitor');
    setEditDroneId(null);
    setSelectedDroneId(null);
    const t = setTimeout(() => setReady(true), 550);
    return () => clearTimeout(t);
  }, [orgId]);

  /* default controlled camera: first online PTZ, else first online camera */
  useEffect(() => {
    if (selectedCamId && cameras.some((c) => c.id === selectedCamId)) return;
    const ptz = cameras.find((c) => c.ptz_enabled && c.status !== 'offline');
    const anyOnline = cameras.find((c) => c.status !== 'offline');
    setSelectedCamId((ptz ?? anyOnline ?? cameras[0] ?? null)?.id ?? null);
  }, [cameras, selectedCamId]);

  /* default selected drone */
  useEffect(() => {
    if (!selectedDroneId && fleet.drones.length > 0) setSelectedDroneId(fleet.drones[0].id);
  }, [fleet.drones, selectedDroneId]);

  const editDrone = useMemo(
    () => fleet.drones.find((d) => d.id === editDroneId) ?? null,
    [fleet.drones, editDroneId],
  );

  const enterEdit = (d: Drone) => {
    if (!canOperate) return;
    setEditDroneId(d.id);
    setDraftWpts(d.waypoints.map((w) => ({ ...w })));
    setMapMode('waypoints');
    setUnitsTab('drones');
  };

  const saveRoute = () => {
    if (!editDroneId || draftWpts.length < 2) return;
    fleet.saveWaypoints(editDroneId, draftWpts);
    const cs = fleet.drones.find((d) => d.id === editDroneId)?.callsign ?? 'Drone';
    showToast({ severity: 'low', title: `${cs} — route saved`, body: `${draftWpts.length} waypoints · audit logged (local control layer)` });
    setMapMode('monitor');
    setEditDroneId(null);
  };

  const discardEdit = () => {
    setMapMode('monitor');
    setEditDroneId(null);
  };

  const onDispatch = (guardId: string, alertId: string) => {
    dispatchGuard(guardId, alertId);
    const g = guards.find((x) => x.id === guardId);
    const a = openAlerts.find((x) => x.id === alertId);
    showToast({
      severity: 'medium',
      title: `${g?.badge_no ?? 'Guard'} dispatched`,
      body: a ? `→ ${a.title}` : 'Unit responding.',
    });
  };

  const mapModeBtn = (mode: MapMode, label: string, icon: ReactNode, disabled: boolean, tip?: string) => (
    <button
      key={mode}
      disabled={disabled}
      title={tip}
      onClick={() => {
        if (mode === 'waypoints') {
          if (editDrone) setMapMode('waypoints');
          else enterEditFromSelection();
        } else {
          discardEdit();
        }
      }}
      className={cn(
        'flex h-6 items-center gap-1 rounded-sm px-2 font-sans text-[10px] font-semibold uppercase tracking-[0.08em] transition-colors duration-150',
        mapMode === mode ? 'bg-accent-dim text-accent' : 'text-muted hover:text-secondary',
        'disabled:cursor-not-allowed disabled:opacity-40',
      )}
    >
      {icon}
      {label}
    </button>
  );

  const enterEditFromSelection = () => {
    const d = fleet.drones.find((x) => x.id === selectedDroneId) ?? fleet.drones[0];
    if (d) enterEdit(d);
  };

  return (
    <RouteErrorBoundary>
      <div className="grid h-full min-h-0 grid-cols-12 gap-3 p-3">
        {/* left — camera + PTZ */}
        <div className="col-span-4 h-full min-h-0">
          {ready ? (
            <PtzColumn cameras={cameras} selectedId={selectedCamId} onSelect={setSelectedCamId} />
          ) : (
            <Panel className="flex h-full flex-col">
              <PanelHeader label="Active control" />
              <div className="space-y-3 p-3">
                <SkeletonRow variant="feed" />
                <SkeletonRow />
                <SkeletonRow />
              </div>
            </Panel>
          )}
        </div>

        {/* center — operations map */}
        <div className="col-span-5 h-full min-h-0">
          <Panel className="flex h-full min-h-0 flex-col">
            <PanelHeader
              label={mapMode === 'waypoints' ? `Waypoint editor — ${editDrone?.callsign ?? ''}` : 'Operations map'}
              right={
                <div className="flex items-center gap-0.5 rounded-sm border border-line bg-inset p-0.5">
                  {mapModeBtn('monitor', 'Monitor', <MapIcon size={11} />, false)}
                  {mapModeBtn(
                    'waypoints',
                    'Edit waypoints',
                    <RouteIcon size={11} />,
                    !canOperate || fleet.drones.length === 0,
                    !canOperate ? 'Requires OPERATOR role' : fleet.drones.length === 0 ? 'No drones in fleet' : 'Edit selected drone route',
                  )}
                </div>
              }
            />
            <div className="min-h-0 flex-1">
              {mapMode === 'monitor' || !editDrone ? (
                <TacticalMap drones={fleet.drones} className="h-full" />
              ) : (
                <WaypointEditor
                  drone={editDrone}
                  fleet={fleet.drones}
                  guards={guards}
                  alerts={openAlerts}
                  draft={draftWpts}
                  onDraftChange={setDraftWpts}
                  onSave={saveRoute}
                  onDiscard={discardEdit}
                />
              )}
            </div>
          </Panel>
        </div>

        {/* right — units rail */}
        <div className="col-span-3 h-full min-h-0">
          <Panel className="h-full min-h-0 p-3">
            {ready ? (
              <UnitsRail
                tab={unitsTab}
                onTab={setUnitsTab}
                fleet={fleet}
                guards={guards}
                openAlerts={openAlerts}
                canOperate={canOperate}
                editDroneId={mapMode === 'waypoints' ? editDroneId : null}
                draftWpts={draftWpts}
                onEditRoute={enterEdit}
                onDraftChange={setDraftWpts}
                onDispatch={onDispatch}
                onSelectDrone={setSelectedDroneId}
              />
            ) : (
              <div className="space-y-2">
                <SkeletonRow />
                <SkeletonRow />
                <SkeletonRow />
                <SkeletonRow />
              </div>
            )}
          </Panel>
        </div>
      </div>
    </RouteErrorBoundary>
  );
}
