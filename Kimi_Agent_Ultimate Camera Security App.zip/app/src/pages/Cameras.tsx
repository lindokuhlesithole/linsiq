/**
 * `/cameras` — Camera Network (design/cameras.md).
 * Inventory table + filter bar + Add Camera wizard + per-camera detail drawer.
 */
import { memo, useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Rows3, Search, X } from 'lucide-react';
import type { Camera, CameraKind, CameraStatus } from '@/lib/types';
import { useAlerts, useCameras, useCanOperate, useClock, useOrg, usePlateReads } from '@/hooks/useData';
import { Panel, SocButton, SocInput, FilterChip, GhostButton, IconButton } from '@/components/soc/primitives';
import { StatusPill } from '@/components/soc';
import { AddCameraWizard } from '@/components/cameras/AddCameraWizard';
import { CameraDetailDrawer } from '@/components/cameras/CameraDetailDrawer';
import { CameraInventoryTable } from '@/components/cameras/CameraInventoryTable';
import type { CamLastEvent, Density } from '@/components/cameras/CameraInventoryTable';
import { KIND_META, camCode } from '@/components/cameras/utils';
import { usePageTitle } from './Stub';
import { cn } from '@/lib/utils';

const KIND_ORDER: CameraKind[] = ['fixed_alpr', 'ptz', 'bullet', 'doorbell'];
const STATUS_ORDER: CameraStatus[] = ['online', 'recording', 'motion', 'degraded', 'offline'];

/* ticking LAST SYNC indicator, isolated so the 1s clock re-renders only this */
const LastSync = memo(function LastSync({ cameras }: { cameras: Camera[] }) {
  const now = useClock(1000);
  const latest = useMemo(
    () => cameras.reduce((m, c) => Math.max(m, new Date(c.last_heartbeat).getTime()), 0),
    [cameras],
  );
  const age = latest ? Math.max(0, Math.floor((now.getTime() - latest) / 1000)) : 0;
  return <span className={age > 30 ? 'text-danger' : 'text-muted'}>LAST SYNC ♥ {age}s</span>;
});

export default function Cameras() {
  usePageTitle('SWEALTH OS — Camera Network', 'Inventory, health and onboarding for every camera on the estate network.');
  const org = useOrg();
  const cameras = useCameras();
  const canOperate = useCanOperate();
  const reads = usePlateReads({ sinceMs: 24 * 3600_000 });
  const alerts = useAlerts({ sinceMs: 24 * 3600_000 });

  // brief skeleton while hooks settle (design.md §6.13)
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 450);
    return () => clearTimeout(t);
  }, []);

  /* ── filters ─────────────────────────────────────────────────────────── */
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim().toLowerCase()), 150);
    return () => clearTimeout(t);
  }, [searchInput]);
  const [kind, setKind] = useState<CameraKind | null>(null);
  const [status, setStatus] = useState<CameraStatus | null>(null);
  const [zone, setZone] = useState<string>('all');
  const [density, setDensity] = useState<Density>('comfortable');

  const zones = useMemo(() => Array.from(new Set(cameras.map((c) => c.zone))).sort(), [cameras]);
  const filtersActive = !!search || !!kind || !!status || zone !== 'all';
  const clearFilters = useCallback(() => {
    setSearchInput('');
    setSearch('');
    setKind(null);
    setStatus(null);
    setZone('all');
  }, []);

  const filtered = useMemo(() => {
    let out = cameras;
    if (kind) out = out.filter((c) => c.kind === kind);
    if (status) out = out.filter((c) => c.status === status);
    if (zone !== 'all') out = out.filter((c) => c.zone === zone);
    if (search) {
      out = out.filter(
        (c) =>
          c.name.toLowerCase().includes(search) ||
          c.zone.toLowerCase().includes(search) ||
          c.rtsp_url.toLowerCase().includes(search),
      );
    }
    return out;
  }, [cameras, kind, status, zone, search]);

  const statusCounts = useMemo(() => {
    const m = new Map<CameraStatus, number>();
    for (const c of cameras) m.set(c.status, (m.get(c.status) ?? 0) + 1);
    return m;
  }, [cameras]);

  /* ── last event per camera (plate read or AI alert) ──────────────────── */
  const lastEvents = useMemo(() => {
    const m = new Map<string, CamLastEvent>();
    for (const r of reads) {
      const cur = m.get(r.camera_id);
      if (!cur || r.captured_at > cur.at) m.set(r.camera_id, { kind: 'plate', label: 'plate read', at: r.captured_at });
    }
    for (const a of alerts) {
      const cur = m.get(a.source_id);
      if (!cur || a.created_at > cur.at) m.set(a.source_id, { kind: 'alert', label: a.type.replace(/_/g, ' '), at: a.created_at });
    }
    return m;
  }, [reads, alerts]);

  /* ── wizard + drawer ─────────────────────────────────────────────────── */
  const [wizardOpen, setWizardOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [newSince, setNewSince] = useState<Record<string, number>>({});
  const selected = useMemo(() => cameras.find((c) => c.id === selectedId) ?? null, [cameras, selectedId]);
  const selectedCode = useMemo(() => {
    const idx = cameras.findIndex((c) => c.id === selectedId);
    return idx >= 0 ? camCode(org, idx) : '';
  }, [cameras, org, selectedId]);

  const onCreated = useCallback((cam: Camera) => {
    setNewSince((s) => ({ ...s, [cam.id]: Date.now() }));
    setSelectedId(cam.id);
  }, []);

  const alprCount = cameras.filter((c) => c.kind === 'fixed_alpr').length;
  const ptzCount = cameras.filter((c) => c.ptz_enabled).length;

  return (
    <div className="flex h-full flex-col overflow-hidden">
      {/* ── Section 1: header bar ───────────────────────────────────────── */}
      <div className="flex shrink-0 items-start justify-between gap-4 px-4 pt-4">
        <div>
          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15 }}
            className="font-sans text-[18px] font-semibold leading-6 tracking-[-0.01em] text-primary"
          >
            Camera Network
          </motion.h1>
          <div className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
            {org.name} / Camera Network
          </div>
          <div className="mt-1.5 flex items-center gap-2 font-mono text-[10px] text-muted">
            <span>{cameras.length} DEVICES</span>
            <span>·</span>
            <span>{alprCount} ALPR GATES</span>
            <span>·</span>
            <span>{ptzCount} PTZ</span>
            <span>·</span>
            <LastSync cameras={cameras} />
          </div>
        </div>
        <div className="flex items-center gap-2">
          {(['online', 'degraded', 'offline'] as CameraStatus[]).map((s, i) => {
            const n = statusCounts.get(s) ?? 0;
            if (n === 0) return null;
            return (
              <motion.button
                key={s}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 + i * 0.04, duration: 0.18 }}
                onClick={() => setStatus(status === s ? null : s)}
                className={cn('rounded-full transition-shadow', status === s && 'ring-2 ring-accent-dim')}
                title={`Filter: ${s}`}
              >
                <StatusPill status={s} label={`${n} ${s}`} />
              </motion.button>
            );
          })}
          <SocButton
            onClick={() => setWizardOpen(true)}
            disabled={!canOperate}
            tooltip={canOperate ? 'Onboard a new camera' : 'Requires OPERATOR role'}
          >
            <span className="inline-flex items-center gap-1.5">
              <Plus size={13} /> Add camera
            </span>
          </SocButton>
        </div>
      </div>

      {/* ── Section 2: filter bar (sticky) ──────────────────────────────── */}
      <div className="sticky top-0 z-20 mt-3 shrink-0 border-b border-line bg-base/95 px-4 pb-2.5 pt-2 backdrop-blur-sm">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-64">
            <Search size={13} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted" />
            <SocInput
              mono
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search name, zone, RTSP host…"
              className="pl-8"
            />
            {searchInput && (
              <button onClick={() => setSearchInput('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted hover:text-primary" title="Clear search">
                <X size={12} />
              </button>
            )}
          </div>

          <span className="mx-1 h-4 w-px bg-line-strong" />
          <FilterChip active={!kind} onClick={() => setKind(null)}>
            All
          </FilterChip>
          {KIND_ORDER.map((k) => {
            const Icon = KIND_META[k].icon;
            return (
              <FilterChip key={k} active={kind === k} onClick={() => setKind(kind === k ? null : k)}>
                <span className="inline-flex items-center gap-1">
                  <Icon size={11} /> {KIND_META[k].label}
                </span>
              </FilterChip>
            );
          })}

          <span className="mx-1 h-4 w-px bg-line-strong" />
          {STATUS_ORDER.map((s) => {
            const n = statusCounts.get(s) ?? 0;
            if (n === 0) return null;
            return (
              <FilterChip key={s} active={status === s} onClick={() => setStatus(status === s ? null : s)}>
                {s} <span className="ml-1 font-mono text-[9px] text-muted">{n}</span>
              </FilterChip>
            );
          })}

          <span className="mx-1 h-4 w-px bg-line-strong" />
          <select
            value={zone}
            onChange={(e) => setZone(e.target.value)}
            className="h-6 rounded-full border border-line bg-raised px-2 font-sans text-[10px] font-semibold uppercase tracking-[0.1em] text-secondary focus:border-accent focus:outline-none"
            title="Filter by zone"
          >
            <option value="all">All zones</option>
            {zones.map((z) => (
              <option key={z} value={z}>
                {z}
              </option>
            ))}
          </select>

          <div className="ml-auto flex items-center gap-2">
            {filtersActive && (
              <GhostButton className="h-6 px-2 text-[10px]" onClick={clearFilters}>
                Reset
              </GhostButton>
            )}
            <IconButton
              tooltip={density === 'comfortable' ? 'Switch to compact rows' : 'Switch to comfortable rows'}
              onClick={() => setDensity((d) => (d === 'comfortable' ? 'compact' : 'comfortable'))}
            >
              <Rows3 size={14} className={density === 'compact' ? 'text-accent' : undefined} />
            </IconButton>
          </div>
        </div>
      </div>

      {/* ── Section 3: inventory table ──────────────────────────────────── */}
      <div className="min-h-0 flex-1 overflow-y-auto p-4 pt-3">
        <Panel>
          <CameraInventoryTable
            cameras={filtered}
            allCameras={cameras}
            org={org}
            density={density}
            newSince={newSince}
            lastEvents={lastEvents}
            loading={loading}
            filtersActive={filtersActive}
            onClearFilters={clearFilters}
            onOpen={(c) => setSelectedId(c.id)}
          />
        </Panel>
        <div className="mt-2 flex justify-between px-1 font-mono text-[9px] uppercase tracking-[0.1em] text-muted">
          <span>
            {filtered.length} of {cameras.length} devices
          </span>
          <span>Row click opens detail drawer · Esc closes</span>
        </div>
      </div>

      <AddCameraWizard open={wizardOpen} onClose={() => setWizardOpen(false)} onCreated={onCreated} />
      <CameraDetailDrawer camera={selected} code={selectedCode} open={!!selected} onClose={() => setSelectedId(null)} />
    </div>
  );
}
