/**
 * `/` — Fleet Command (design/fleet-command.md).
 * KPI strip · live camera wall · tactical map · dual live tickers.
 * Fixed-height regions; only the tickers scroll internally.
 */
import { memo, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BellOff, LayoutGrid, Maximize2, Rows3, Volume2, VolumeX } from 'lucide-react';
import type { Alert, Camera, PlateRead } from '@/lib/types';
import {
  toggleMute, useActiveOrgId, useAlerts, useCameras, useGuards, useMuted,
  useOrg, usePlateReads, useThreatLevel,
} from '@/hooks/useData';
import { OPEN_STATUSES } from '@/lib/store';
import { fmtNum } from '@/lib/format';
import { CameraDetailPanel } from '@/components/soc/CameraDetailPanel';
import { CameraTile } from '@/components/soc/CameraTile';
import { KpiTile } from '@/components/soc/KpiTile';
import { Panel, PanelHeader, GhostButton, IconButton } from '@/components/soc/primitives';
import { SkeletonRow } from '@/components/soc/feedback';
import { TacticalMap } from '@/components/soc/TacticalMap';
import { AlertTicker, PlateTicker } from '@/components/soc/Tickers';
import { ThreatLevelGauge } from '@/components/soc/StatusPill';
import { usePageTitle } from './Stub';
import { cn } from '@/lib/utils';

const DAY_MS = 24 * 3600_000;

/* hourly buckets for sparklines */
function hourlyBuckets(reads: PlateRead[], hours: number): number[] {
  const now = Date.now();
  const buckets = new Array(hours).fill(0) as number[];
  for (const r of reads) {
    const ageH = Math.floor((now - new Date(r.captured_at).getTime()) / 3600_000);
    if (ageH >= 0 && ageH < hours) buckets[hours - 1 - ageH] += 1;
  }
  return buckets;
}

/* ── Camera wall slot persistence ────────────────────────────────────────── */
function wallSlotsKey(orgId: string): string {
  return `swealth.wall_slots.${orgId}`;
}
function loadWallSlots(orgId: string): (string | null)[] {
  try {
    const raw = localStorage.getItem(wallSlotsKey(orgId));
    const parsed = raw ? (JSON.parse(raw) as (string | null)[]) : [];
    return Array.isArray(parsed) ? parsed.slice(0, 6) : [];
  } catch {
    return [];
  }
}

export default function FleetCommand() {
  usePageTitle('SWEALTH OS — Fleet Command', 'Live tactical overview of cameras, plate reads, alerts, drones and guards across the estate.');
  const navigate = useNavigate();
  const org = useOrg();
  const orgId = useActiveOrgId();
  const cameras = useCameras();
  const guards = useGuards();
  const allAlerts = useAlerts();
  const reads24h = usePlateReads({ sinceMs: DAY_MS });
  const reads48h = usePlateReads({ sinceMs: 2 * DAY_MS });
  const readsHour = usePlateReads({ sinceMs: 3600_000, limit: 500 });
  const threat = useThreatLevel();
  const muted = useMuted();

  const [ready, setReady] = useState(false);
  const [wallLayout, setWallLayout] = useState<'2x3' | '3x2'>('2x3');
  const [detailCam, setDetailCam] = useState<Camera | null>(null);
  const [slots, setSlots] = useState<(string | null)[]>(() => loadWallSlots(orgId));

  useEffect(() => {
    setReady(false);
    setSlots(loadWallSlots(orgId));
    const t = setTimeout(() => setReady(true), 550);
    return () => clearTimeout(t);
  }, [orgId]);

  /* ── KPI derivations ─────────────────────────────────────────────────── */
  const openAlerts = useMemo(() => allAlerts.filter((a) => OPEN_STATUSES.has(a.status)), [allAlerts]);
  const onlineCams = cameras.filter((c) => c.status !== 'offline').length;
  const degradedCams = cameras.filter((c) => c.status === 'degraded').length;
  const hits24h = useMemo(() => reads24h.filter((r) => r.hotlist_hit), [reads24h]);
  const openHitAlerts = openAlerts.filter((a) => a.type === 'hotlist_hit').length;
  const prevDayReads = reads48h.length - reads24h.length;
  const readsDelta = prevDayReads > 0 ? Math.round(((reads24h.length - prevDayReads) / prevDayReads) * 100) : 0;
  const avgResponse = useMemo(() => {
    const acked = allAlerts.filter((a) => a.acknowledged_at);
    if (!acked.length) return Math.round(guards.reduce((s, g) => s + g.avg_response_sec, 0) / Math.max(1, guards.length));
    const sum = acked.reduce((s, a) => s + (new Date(a.acknowledged_at!).getTime() - new Date(a.created_at).getTime()) / 1000, 0);
    return Math.round(sum / acked.length);
  }, [allAlerts, guards]);
  const openHighPlus = openAlerts.filter((a) => a.severity === 'critical' || a.severity === 'high').length;
  const critN = openAlerts.filter((a) => a.severity === 'critical').length;
  const highN = openAlerts.filter((a) => a.severity === 'high').length;
  const medN = openAlerts.filter((a) => a.severity === 'medium').length;
  const readSpark = useMemo(() => hourlyBuckets(reads24h, 24), [reads24h]);
  const camSpark = useMemo(() => readSpark.map((_, i) => Math.max(0, onlineCams - (i % 5 === 0 ? 1 : 0))), [readSpark, onlineCams]);
  const respSpark = useMemo(() => {
    const base = avgResponse;
    return [1.12, 1.08, 1.15, 1.02, 0.97, 1.0, 0.94].map((f) => Math.round(base * f));
  }, [avgResponse]);

  /* ── Camera wall selection ───────────────────────────────────────────── */
  const alertSourceCamIds = useMemo(() => {
    const set = new Set<string>();
    for (const a of openAlerts) {
      if (a.severity === 'critical' && (a.source_kind === 'camera' || a.source_kind === 'alpr')) set.add(a.source_id);
    }
    return set;
  }, [openAlerts]);
  const hotCamIds = useMemo(() => {
    const set = new Set<string>();
    for (const a of openAlerts) if (a.type === 'hotlist_hit') set.add(a.source_id);
    return set;
  }, [openAlerts]);

  const activityByCam = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of reads24h.slice(0, 800)) m.set(r.camera_id, (m.get(r.camera_id) ?? 0) + 1);
    return m;
  }, [reads24h]);

  const wallCameras = useMemo(() => {
    const picked: Camera[] = [];
    const seen = new Set<string>();
    const push = (c: Camera | undefined) => {
      if (c && !seen.has(c.id) && picked.length < 6) {
        seen.add(c.id);
        picked.push(c);
      }
    };
    // 1) force-pin cameras tied to active critical alerts
    for (const id of alertSourceCamIds) push(cameras.find((c) => c.id === id));
    // 2) operator-pinned slots
    for (const id of slots) push(cameras.find((c) => c.id === id));
    // 3) ALPR gate cameras
    for (const c of cameras.filter((c) => c.kind === 'fixed_alpr')) push(c);
    // 4) highest-activity cameras
    const byActivity = [...cameras].sort((a, b) => (activityByCam.get(b.id) ?? 0) - (activityByCam.get(a.id) ?? 0));
    for (const c of byActivity) push(c);
    return picked;
  }, [cameras, alertSourceCamIds, slots, activityByCam]);

  const swapSlot = (slotIdx: number, camId: string) => {
    setSlots((prev) => {
      const next = [...prev];
      while (next.length < 6) next.push(null);
      next[slotIdx] = camId;
      try {
        localStorage.setItem(wallSlotsKey(orgId), JSON.stringify(next));
      } catch { /* noop */ }
      return next;
    });
  };

  const onTickerAlert = (a: Alert) => window.dispatchEvent(new CustomEvent('swealth:open-alert', { detail: { alertId: a.id } }));
  const onTickerRead = (r: PlateRead) => navigate(`/alpr?plate=${encodeURIComponent(r.plate)}`);

  const latestAlerts = useMemo(() => allAlerts.slice(0, 12), [allAlerts]);

  /* ── Render ──────────────────────────────────────────────────────────── */
  return (
    <div className="scan-grid flex h-full flex-col gap-3 bg-canvas p-3">
      {/* KPI STRIP */}
      <div className="grid shrink-0 grid-cols-6 gap-3">
        {!ready ? (
          Array.from({ length: 6 }, (_, i) => <SkeletonRow key={i} variant="kpi" />)
        ) : (
          <>
            <KpiTile
              label="Cameras Online"
              value={`${onlineCams}/${cameras.length}`}
              sub={degradedCams > 0 ? `${degradedCams} DEGRADED · ♥ LIVE` : 'ALL NOMINAL · ♥ LIVE'}
              spark={camSpark}
              onClick={() => navigate('/cameras')}
            />
            <KpiTile
              label="Plate Reads 24H"
              value={fmtNum(reads24h.length)}
              delta={{ dir: readsDelta >= 0 ? 'up' : 'down', text: `${Math.abs(readsDelta)}% vs yesterday`, good: readsDelta >= 0 }}
              spark={readSpark}
              onClick={() => navigate('/alpr')}
            />
            <KpiTile
              label="Hotlist Hits 24H"
              value={String(hits24h.length)}
              topBorder="danger"
              sub={`${hits24h.length - openHitAlerts >= 0 ? hits24h.length - openHitAlerts : 0} RESOLVED · ${openHitAlerts} OPEN`}
              sparkStroke="#E71D36"
              spark={hourlyBuckets(reads24h.filter((r) => r.hotlist_hit), 24).map((v) => v + 0.2)}
              onClick={() => navigate('/alpr?hotlist=1')}
            />
            <KpiTile
              label="Open Alerts"
              value={String(openAlerts.length)}
              topBorder="warning"
              sub={`${critN} CRIT · ${highN} HIGH · ${medN} MED`}
              sparkStroke="#FF9F1C"
              spark={[3, 4, 2, 5, 4, 6, openAlerts.length]}
              onClick={() => navigate('/alerts')}
            />
            <KpiTile
              label="Avg Response"
              value={`${Math.floor(avgResponse / 60)}m ${String(avgResponse % 60).padStart(2, '0')}s`}
              delta={{ dir: 'down', text: '38s', good: true }}
              spark={respSpark}
              onClick={() => navigate('/analytics#response')}
            />
            <KpiTile
              label="Threat Level"
              value={<ThreatLevelGauge level={threat} compact />}
              sub={`${openHighPlus} open high+ alerts`}
              onClick={() => navigate('/map')}
            />
          </>
        )}
      </div>

      {/* MAIN GRID */}
      <div className="grid min-h-0 flex-1 grid-cols-12 gap-3">
        {/* LEFT: camera wall + map */}
        <div className="col-span-12 flex min-h-0 flex-col gap-3 xl:col-span-7">
          {/* camera wall */}
          <Panel className="flex min-h-0 flex-[48] flex-col">
            <PanelHeader
              label="Live camera wall"
              right={
                <>
                  <span className="font-mono text-[10px] text-muted">{wallCameras.length} STREAMS</span>
                  <IconButton tooltip="2×3 layout" onClick={() => setWallLayout('2x3')} className={cn(wallLayout === '2x3' && 'text-accent')}>
                    <LayoutGrid size={13} />
                  </IconButton>
                  <IconButton tooltip="3×2 layout" onClick={() => setWallLayout('3x2')} className={cn(wallLayout === '3x2' && 'text-accent')}>
                    <Rows3 size={13} />
                  </IconButton>
                  <GhostButton className="h-6 px-2 text-[10px]" onClick={() => navigate('/cameras')}>
                    All cameras →
                  </GhostButton>
                </>
              }
            />
            <div className={cn('grid min-h-0 flex-1 gap-2 p-2', wallLayout === '2x3' ? 'grid-cols-3 grid-rows-2' : 'grid-cols-2 grid-rows-3')}>
              {!ready
                ? Array.from({ length: 6 }, (_, i) => <SkeletonRow key={i} variant="feed" />)
                : wallCameras.map((cam, i) => (
                    <motion.div
                      key={cam.id}
                      initial={{ opacity: 0, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.3, delay: i * 0.05 }}
                      className="group/slot relative min-h-0"
                    >
                      <CameraTile
                        camera={cam}
                        alertActive={alertSourceCamIds.has(cam.id)}
                        onClick={setDetailCam}
                        className="h-full [&>div:first-child]:h-[calc(100%-28px)] [&>div:first-child]:aspect-auto"
                      />
                      <SlotSwapper slotIdx={i} cameras={cameras} current={cam.id} onSwap={swapSlot} />
                    </motion.div>
                  ))}
            </div>
          </Panel>

          {/* tactical map */}
          <Panel className="flex min-h-0 flex-[52] flex-col">
            <PanelHeader
              label={`Tactical map — ${org.name}`}
              right={
                <IconButton tooltip="Expand tactical map" onClick={() => navigate('/map')}>
                  <Maximize2 size={13} />
                </IconButton>
              }
            />
            <div className="min-h-0 flex-1 p-1.5">
              <TacticalMap hotCameraIds={hotCamIds} className="rounded-sm border border-line" />
            </div>
          </Panel>
        </div>

        {/* RIGHT RAIL */}
        <div className="col-span-12 flex min-h-0 flex-col gap-3 xl:col-span-5">
          {/* alert ticker */}
          <Panel className="flex min-h-0 flex-[48] flex-col">
            <PanelHeader
              label={openHighPlus === 0 ? 'Live alerts — all clear' : 'Live alerts'}
              right={
                <>
                  <span className={cn('rounded-full px-1.5 py-px font-mono text-[10px] font-semibold', critN > 0 ? 'bg-danger-dim text-danger' : 'bg-raised text-muted')}>
                    {openAlerts.length}
                  </span>
                  <IconButton tooltip={muted ? 'Unmute alert ping' : 'Mute alert ping'} onClick={toggleMute}>
                    {muted ? <VolumeX size={13} /> : <Volume2 size={13} />}
                  </IconButton>
                  <GhostButton className="h-6 px-2 text-[10px]" onClick={() => navigate('/alerts')}>
                    All →
                  </GhostButton>
                </>
              }
            />
            {!ready ? (
              <div className="flex-1">{Array.from({ length: 5 }, (_, i) => <SkeletonRow key={i} />)}</div>
            ) : (
              <AlertTicker alerts={latestAlerts} onAlertClick={onTickerAlert} />
            )}
          </Panel>

          {/* plate ticker */}
          <Panel className="flex min-h-0 flex-[52] flex-col">
            <PanelHeader
              label="Live plate reads"
              right={
                <>
                  <span className="font-mono text-[10px] text-accent">{readsHour.length}/HR</span>
                  <GhostButton className="h-6 px-2 text-[10px]" onClick={() => navigate('/alpr')}>
                    All →
                  </GhostButton>
                </>
              }
            />
            {!ready ? (
              <div className="flex-1">{Array.from({ length: 5 }, (_, i) => <SkeletonRow key={i} variant="plate" />)}</div>
            ) : (
              <PlateTicker reads={reads24h} cameras={cameras} onReadClick={onTickerRead} />
            )}
          </Panel>
        </div>
      </div>

      <CameraDetailPanel camera={detailCam} open={!!detailCam} onClose={() => setDetailCam(null)} />
    </div>
  );
}

/* Hover SWAP affordance: pin a different camera into this wall slot */
const SlotSwapper = memo(function SlotSwapper({
  slotIdx,
  cameras,
  current,
  onSwap,
}: {
  slotIdx: number;
  cameras: Camera[];
  current: string;
  onSwap: (slot: number, camId: string) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="absolute right-1.5 top-8 z-20 opacity-0 transition-opacity duration-100 group-hover/slot:opacity-100">
      <button
        onClick={(e) => {
          e.stopPropagation();
          setOpen((o) => !o);
        }}
        className="rounded-sm border border-line-strong bg-surface-solid/90 px-1.5 py-0.5 font-mono text-[8px] font-semibold uppercase tracking-[0.08em] text-secondary hover:text-accent"
      >
        Swap
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1 max-h-40 w-44 overflow-y-auto rounded-sm border border-line-strong bg-surface-solid shadow-drawer">
          {cameras.filter((c) => c.status !== 'offline').map((c) => (
            <button
              key={c.id}
              onClick={(e) => {
                e.stopPropagation();
                onSwap(slotIdx, c.id);
                setOpen(false);
              }}
              className={cn(
                'flex w-full items-center gap-1.5 px-2 py-1 text-left font-sans text-[10px] transition-colors hover:bg-raised',
                c.id === current ? 'text-accent' : 'text-secondary',
              )}
            >
              {c.id === current ? <BellOff size={10} /> : null}
              <span className="truncate">{c.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
});
