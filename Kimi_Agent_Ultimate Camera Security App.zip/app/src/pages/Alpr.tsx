/**
 * `/alpr` — Plate Intelligence (design/alpr.md).
 * Tabs: LIVE FEED · VEHICLE SEARCH · HOTLISTS (persisted in ?tab=).
 * Header stat chips (reads today ticking, hits 24h, avg confidence),
 * VehicleProfileDrawer opened from rows/cards/tickers (?plate= deep-link,
 * ?hotlist=1 → hotlist-only feed).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import type { PlateRead } from '@/lib/types';
import { useActiveOrgId, useCameras, useHotlists, usePlateReads } from '@/hooks/useData';
import { fmtNum } from '@/lib/format';
import { SocTabs } from '@/components/soc/primitives';
import { VehicleProfileDrawer } from '@/components/soc/VehicleProfileDrawer';
import { LiveFeedTab } from '@/components/alpr/LiveFeedTab';
import { VehicleSearchTab } from '@/components/alpr/VehicleSearchTab';
import { HotlistManagerTab } from '@/components/alpr/HotlistManagerTab';
import { usePageTitle } from './Stub';
import { cn } from '@/lib/utils';

type TabId = 'feed' | 'search' | 'hotlists';
const DAY_MS = 24 * 3600_000;

/* Stat chip with accent flash on value change (design §7 numeric updates) */
function StatChip({ label, value, danger = false }: { label: string; value: string; danger?: boolean }) {
  const [flash, setFlash] = useState(false);
  const prev = useRef(value);
  useEffect(() => {
    if (prev.current !== value) {
      prev.current = value;
      setFlash(true);
      const t = setTimeout(() => setFlash(false), 300);
      return () => clearTimeout(t);
    }
  }, [value]);
  return (
    <div
      className={cn(
        'flex h-9 items-center gap-2 rounded-sm border px-2.5 transition-colors duration-150',
        danger ? 'border-danger-line bg-danger-dim' : 'border-line bg-surface',
        flash && 'bg-accent-dim',
      )}
    >
      <span className="font-sans text-[9px] font-semibold uppercase tracking-[0.12em] text-muted">{label}</span>
      <span className={cn('font-mono text-[13px] font-semibold', danger ? 'text-danger' : 'text-primary')}>{value}</span>
    </div>
  );
}

export default function Alpr() {
  usePageTitle('SWEALTH OS — Plate Intelligence', 'Live license-plate recognition feed, vehicle fingerprint search and hotlist management.');
  const [params, setParams] = useSearchParams();
  const orgId = useActiveOrgId();
  const cameras = useCameras();
  const hotlists = useHotlists();
  const reads24h = usePlateReads({ sinceMs: DAY_MS });

  const tabParam = params.get('tab');
  const tab: TabId = tabParam === 'search' || tabParam === 'hotlists' ? tabParam : 'feed';
  const hotlistDeepLink = params.get('hotlist') === '1';
  const plateParam = params.get('plate');

  const [drawerPlate, setDrawerPlate] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  // skeleton window per tenant switch (matches FleetCommand cadence)
  useEffect(() => {
    setReady(false);
    const t = setTimeout(() => setReady(true), 550);
    return () => clearTimeout(t);
  }, [orgId]);

  // ?plate= deep-link (tickers, alert drawer)
  useEffect(() => {
    if (plateParam) setDrawerPlate(plateParam);
  }, [plateParam]);

  const setTab = useCallback(
    (t: TabId) => {
      setParams(
        (prev) => {
          const next = new URLSearchParams(prev);
          next.set('tab', t);
          next.delete('hotlist');
          return next;
        },
        { replace: true },
      );
    },
    [setParams],
  );

  const closeDrawer = useCallback(() => {
    setDrawerPlate(null);
    setParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        next.delete('plate');
        return next;
      },
      { replace: true },
    );
  }, [setParams]);

  const onViewVehicle = useCallback((read: PlateRead) => setDrawerPlate(read.plate), []);

  /* header derivations */
  const alprGates = useMemo(() => cameras.filter((c) => c.kind === 'fixed_alpr').length, [cameras]);
  const activeLists = useMemo(() => hotlists.filter((h) => h.enabled).length, [hotlists]);
  const hits24h = useMemo(() => reads24h.filter((r) => r.hotlist_hit).length, [reads24h]);
  const avgConf = useMemo(() => {
    if (!reads24h.length) return '—';
    const sum = reads24h.reduce((s, r) => s + r.confidence, 0);
    return `${((sum / reads24h.length) * 100).toFixed(1)}%`;
  }, [reads24h]);

  return (
    <div className="scan-grid flex h-full flex-col gap-3 bg-canvas p-4">
      {/* header */}
      <div className="flex shrink-0 flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-sans text-[18px] font-semibold leading-6 tracking-[-0.01em] text-primary">Plate Intelligence</h1>
          <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.10em] text-muted">
            {fmtNum(reads24h.length)} reads / 24h · {alprGates} ALPR gates · {activeLists} hotlists active
          </p>
        </div>
        <div className="flex items-center gap-2">
          <StatChip label="Reads today" value={fmtNum(reads24h.length)} />
          <StatChip label="Hits 24H" value={String(hits24h)} danger />
          <StatChip label="Avg confidence" value={avgConf} />
        </div>
      </div>

      {/* tab bar */}
      <SocTabs
        idScope="alpr"
        active={tab}
        onChange={(t) => setTab(t as TabId)}
        tabs={[
          { id: 'feed' as TabId, label: 'Live feed' },
          { id: 'search' as TabId, label: 'Vehicle search' },
          { id: 'hotlists' as TabId, label: 'Hotlists', count: hotlists.length },
        ]}
      />

      {/* tab panels */}
      <div className="min-h-0 flex-1 rounded-sm border border-line bg-surface backdrop-blur-sm">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: [0.2, 0.8, 0.2, 1] }}
            className="h-full"
          >
            {tab === 'feed' && <LiveFeedTab ready={ready} hotlistOnlyInitial={hotlistDeepLink} onViewVehicle={onViewVehicle} />}
            {tab === 'search' && <VehicleSearchTab ready={ready} onViewVehicle={onViewVehicle} />}
            {tab === 'hotlists' && <HotlistManagerTab ready={ready} />}
          </motion.div>
        </AnimatePresence>
      </div>

      <VehicleProfileDrawer plate={drawerPlate} open={!!drawerPlate} onClose={closeDrawer} />
    </div>
  );
}
