/**
 * `/settings` — Settings & Administration (settings.md).
 * Two-column card grid: tenant, access/roles, routing rules, hotlist sync,
 * full-width audit viewer, demo data, QA diagnostics.
 */
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useRole } from '@/hooks/useData';
import { showToast } from '@/components/soc';
import { usePageTitle } from './Stub';
import { TenantSection } from '@/components/settings/TenantSection';
import { RoleSection } from '@/components/settings/RoleSection';
import { RoutingRulesSection } from '@/components/settings/RoutingRulesSection';
import { HotlistSyncSection } from '@/components/settings/HotlistSyncSection';
import { AuditLogSection } from '@/components/settings/AuditLogSection';
import { DemoDataSection } from '@/components/settings/DemoDataSection';
import { QaSection } from '@/components/settings/QaSection';

export default function Settings() {
  usePageTitle('SWEALTH OS — Settings', 'Tenant, role, routing, hotlist sync, audit and demo-data administration.');
  const navigate = useNavigate();
  const role = useRole();

  /* guard role: entire route hidden (settings.md States) */
  useEffect(() => {
    if (role === 'guard') {
      showToast({ severity: 'high', title: 'Insufficient role', body: 'Settings requires OPERATOR role — redirecting to Fleet Command.' });
      navigate('/', { replace: true });
    }
  }, [role, navigate]);

  if (role === 'guard') return null;

  return (
    <div className="h-full overflow-y-auto p-4">
      <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
        <TenantSection />
        <RoleSection />
        <RoutingRulesSection />
        <HotlistSyncSection />
        <AuditLogSection className="xl:col-span-2" />
        <DemoDataSection />
        <QaSection />
      </div>
    </div>
  );
}
