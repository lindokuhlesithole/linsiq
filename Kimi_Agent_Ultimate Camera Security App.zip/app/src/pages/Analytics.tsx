/**
 * `/analytics` — Intelligence (analytics.md).
 * Six Recharts panels, every series derived live from the data layer.
 */
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  useActiveOrgId, useAlerts, useCameras, useGuards, usePlateReads, useRole,
} from '@/hooks/useData';
import { showToast } from '@/components/soc';
import { FilterChip } from '@/components/soc';
import { fmtNum } from '@/lib/format';
import { usePageTitle } from './Stub';
import { AlertsOverTime } from '@/components/analytics/AlertsOverTime';
import { PlateHeatCurve } from '@/components/analytics/PlateHeatCurve';
import { ResponseDistribution } from '@/components/analytics/ResponseDistribution';
import { HotlistOutcomes } from '@/components/analytics/HotlistOutcomes';
import { DeviceUptime, uptimePct } from '@/components/analytics/DeviceUptime';
import { GuardLeaderboard } from '@/components/analytics/GuardLeaderboard';
import { InsightLine } from '@/components/analytics/InsightLine';
import { RANGES, rangeMs } from '@/components/analytics/ranges';
import type { RangeKey } from '@/components/analytics/ranges';

const DAY_MS = 24 * 3600_000;
const pad = (n: number) => String(n).padStart(2, '0');

export default function Analytics() {
  usePageTitle('SWEALTH OS — Intelligence Analytics', 'Alert trends, plate-read volume, response performance, device uptime and hotlist outcomes.');
  const navigate = useNavigate();
  const role = useRole();
  const orgId = useActiveOrgId();
  const cameras = useCameras();
  const guards = useGuards();
  const alerts = useAlerts();

  const [range, setRange] = useState<RangeKey>('24H');
  const reads = usePlateReads({ sinceMs: rangeMs(range) });

  /* per-panel skeleton window (org switch / mount) */
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => setLoading(false), 550);
    return () => clearTimeout(t);
  }, [orgId]);

  /* guard role: page hidden per role preview rules */
  useEffect(() => {
    if (role === 'guard') {
      showToast({ severity: 'high', title: 'Insufficient role', body: 'Intelligence requires OPERATOR role — redirecting to Fleet Command.' });
      navigate('/', { replace: true });
    }
  }, [role, navigate]);

  const eventsInRange = useMemo(() => {
    const cutoff = Date.now() - rangeMs(range);
    const a = alerts.filter((x) => new Date(x.created_at).getTime() >= cutoff).length;
    return a + reads.length;
  }, [alerts, reads, range]);

  /* auto-insights, all computed from live slices */
  const insights = useMemo<string[]>(() => {
    const out: string[] = [];
    const now = Date.now();
    const hits = alerts.filter((a) => a.type === 'hotlist_hit');
    const cur = hits.filter((a) => now - new Date(a.created_at).getTime() < DAY_MS);
    const prev = hits.filter((a) => {
      const age = now - new Date(a.created_at).getTime();
      return age >= DAY_MS && age < 2 * DAY_MS;
    });
    if (cur.length > 0) {
      const delta = prev.length ? Math.round(((cur.length - prev.length) / prev.length) * 100) : 100;
      const gateCounts = new Map<string, number>();
      for (const a of cur) gateCounts.set(a.source_name, (gateCounts.get(a.source_name) ?? 0) + 1);
      const topGate = [...gateCounts.entries()].sort((x, y) => y[1] - x[1])[0]?.[0];
      out.push(
        `${delta >= 0 ? '▲' : '▼'} Hotlist hits ${delta >= 0 ? 'up' : 'down'} ${Math.abs(delta)}% vs prior 24h${topGate ? ` — concentrated at ${topGate}` : ''}`,
      );
    }
    if (reads.length) {
      const byHour = new Array(24).fill(0) as number[];
      for (const r of reads) byHour[new Date(r.captured_at).getHours()] += 1;
      const peakH = byHour.indexOf(Math.max(...byHour));
      out.push(`▲ Gate volume peaks ${pad(peakH)}:00 — ${fmtNum(byHour[peakH])} reads in that hour`);
    }
    if (cameras.length) {
      const worst = [...cameras].sort((a, b) => uptimePct(a) - uptimePct(b))[0];
      const u = uptimePct(worst);
      if (u < 99) out.push(`▼ ${worst.name} lowest fleet uptime at ${u.toFixed(1)}% — maintenance window advised`);
    }
    return out.slice(0, 3);
  }, [alerts, reads, cameras]);

  if (role === 'guard') return null;

  return (
    <div className="h-full overflow-y-auto p-4">
      {/* header */}
      <header className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-sans text-[18px] font-semibold leading-6 tracking-[-0.01em] text-primary">Intelligence</h1>
          <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.10em] text-muted">
            Derived live from operational data · {fmtNum(eventsInRange)} events in range
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-4">
          <InsightLine insights={insights} />
          <div className="flex items-center gap-1">
            {RANGES.map((r) => (
              <FilterChip key={r.id} active={range === r.id} onClick={() => setRange(r.id)}>
                {r.label}
              </FilterChip>
            ))}
          </div>
        </div>
      </header>

      {/* chart grid — two columns, first row tall */}
      <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
        <AlertsOverTime alerts={alerts} range={range} loading={loading} />
        <PlateHeatCurve reads={reads} cameras={cameras} loading={loading} />
        <ResponseDistribution alerts={alerts} loading={loading} />
        <HotlistOutcomes alerts={alerts} loading={loading} />
        <DeviceUptime cameras={cameras} loading={loading} />
        <GuardLeaderboard guards={guards} loading={loading} />
      </div>
    </div>
  );
}
