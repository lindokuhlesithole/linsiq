/**
 * `/map` — Full-Screen Tactical Map (design/map.md).
 * Full-viewport map, layer chips, legend, LIVE/REPLAY modes, 2h time scrubber,
 * ?focus=<entityId> deep-linking.
 */
import { memo, useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Activity, Cctv, ChevronDown, Flame, Navigation, ScanLine, ShieldCheck, Siren, Tag } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useActiveOrgId, useAlerts, useAudioSensors, useCameras, useDrones, useGuards } from '@/hooks/useData';
import { OPEN_STATUSES } from '@/lib/store';
import { getTenantGeometry } from '@/lib/procedural';
import { FullTacticalMap, DEFAULT_MAP_LAYERS } from '@/components/map/FullTacticalMap';
import type { MapMode, MapPageLayers } from '@/components/map/FullTacticalMap';
import { TimeScrubber } from '@/components/map/TimeScrubber';
import { usePageTitle } from './Stub';
import { cn } from '@/lib/utils';

/* ── layer chip ──────────────────────────────────────────────────────────── */

const LayerChip = memo(function LayerChip({
  icon: Icon,
  label,
  dot,
  count,
  active,
  onClick,
}: {
  icon: LucideIcon;
  label: string;
  dot: string;
  count?: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex h-7 w-[168px] items-center gap-2 rounded-sm border px-2 text-left transition-colors duration-150 backdrop-blur-sm',
        active ? 'border-line-strong bg-surface-solid/90' : 'border-line bg-surface-solid/60 opacity-60 hover:opacity-90',
      )}
    >
      <Icon size={14} className={active ? 'text-secondary' : 'text-muted'} />
      <span className={cn('font-sans text-[10px] font-semibold uppercase tracking-[0.10em]', active ? 'text-primary' : 'text-muted')}>
        {label}
      </span>
      <span className="ml-auto flex items-center gap-1.5">
        {typeof count === 'number' && <span className="font-mono text-[9px] text-muted">{count}</span>}
        <span className="h-1.5 w-1.5 rounded-full" style={{ background: active ? dot : '#5C6B8A' }} />
      </span>
    </button>
  );
});

/* ── legend ──────────────────────────────────────────────────────────────── */

const LEGEND_ROWS: { glyph: React.ReactNode; label: string }[] = [
  { glyph: <span className="h-2 w-2 rotate-45 bg-accent" />, label: 'Camera online' },
  { glyph: <span className="h-2 w-2 rotate-45 bg-info" />, label: 'Motion detected' },
  { glyph: <span className="h-2 w-2 rotate-45 bg-warning" />, label: 'Degraded' },
  { glyph: <span className="h-2 w-2 rotate-45 bg-danger" />, label: 'Offline' },
  { glyph: <span className="flex h-2.5 w-2.5 items-center justify-center bg-accent"><span className="h-px w-1.5 bg-on-accent" /></span>, label: 'ALPR gate' },
  { glyph: <span className="h-0 w-2.5 border-t-2 border-info" style={{ clipPath: 'polygon(50% 0, 100% 100%, 0 100%)' }} />, label: 'Drone' },
  { glyph: <span className="h-2 w-2 rounded-full border border-accent" />, label: 'Guard' },
  { glyph: <span className="h-2.5 w-2.5 rounded-full border border-danger" />, label: 'Alert · critical' },
  { glyph: <span className="h-2.5 w-2.5 rounded-full border border-warning" />, label: 'Alert · high' },
  { glyph: <span className="h-2.5 w-2.5 rounded-full border border-dashed border-info" />, label: 'Audio radius' },
];

const MapLegend = memo(function MapLegend() {
  const [open, setOpen] = useState(true);
  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="rounded-sm border border-line bg-surface/85 px-2 py-1 font-mono text-[9px] font-semibold uppercase tracking-[0.12em] text-muted backdrop-blur-sm transition-colors hover:text-primary"
      >
        Legend
      </button>
    );
  }
  return (
    <motion.div
      initial={{ opacity: 0, x: 16 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.25, delay: 0.1 }}
      className="w-[180px] rounded-sm border border-line bg-surface/85 p-2.5 backdrop-blur-sm"
    >
      <button onClick={() => setOpen(false)} className="mb-1.5 flex w-full items-center justify-between font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted hover:text-primary">
        Legend
        <ChevronDown size={12} />
      </button>
      <div className="space-y-1">
        {LEGEND_ROWS.map((r) => (
          <div key={r.label} className="flex items-center gap-2">
            <span className="flex h-3 w-3 items-center justify-center">{r.glyph}</span>
            <span className="font-sans text-[10px] text-secondary">{r.label}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
});

/* ── page ────────────────────────────────────────────────────────────────── */

export default function TacticalMapPage() {
  usePageTitle('SWEALTH OS — Tactical Map', 'Full-screen tactical map of cameras, drones, guards, sensors and alert activity.');
  const orgId = useActiveOrgId();
  const cameras = useCameras();
  const drones = useDrones();
  const guards = useGuards();
  const sensors = useAudioSensors();
  const alerts = useAlerts();
  const geo = useMemo(() => getTenantGeometry(orgId), [orgId]);

  const [layers, setLayers] = useState<MapPageLayers>(DEFAULT_MAP_LAYERS);
  const [mode, setMode] = useState<MapMode>('live');
  const [offsetSec, setOffsetSec] = useState(0);
  const [searchParams, setSearchParams] = useSearchParams();
  const focusId = searchParams.get('focus');

  // brief skeleton markers while hooks settle (map.md States)
  const [settling, setSettling] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setSettling(false), 400);
    return () => clearTimeout(t);
  }, []);

  const onFocusDone = useCallback(() => {
    if (!focusId) return;
    const next = new URLSearchParams(searchParams);
    next.delete('focus');
    setSearchParams(next, { replace: true });
  }, [focusId, searchParams, setSearchParams]);

  const openAlerts = useMemo(() => alerts.filter((a) => OPEN_STATUSES.has(a.status)), [alerts]);
  const heatCount = useMemo(
    () => alerts.filter((a) => Date.now() - new Date(a.created_at).getTime() < 2 * 3600_000 && a.severity !== 'low').length,
    [alerts],
  );

  const replayAt = mode === 'replay' ? Date.now() + offsetSec * 1000 : null;

  const toggle = (k: keyof MapPageLayers) => setLayers((l) => ({ ...l, [k]: !l[k] }));

  return (
    <div className="flex h-full flex-col overflow-hidden bg-canvas">
      {/* map region */}
      <motion.div
        initial={{ opacity: 0, scale: 1.02 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.35 }}
        className="relative min-h-0 flex-1"
      >
        <FullTacticalMap layers={layers} mode={mode} replayAt={replayAt} focusId={focusId} onFocusDone={onFocusDone} />

        {/* skeleton markers while hooks settle */}
        {settling && (
          <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center gap-8">
            {Array.from({ length: 6 }, (_, i) => (
              <span key={i} className="relative h-2 w-2 overflow-hidden rounded-full bg-raised">
                <span className="absolute inset-0 -translate-x-full animate-shimmer bg-[linear-gradient(90deg,transparent,rgba(0,212,170,0.15),transparent)]" />
              </span>
            ))}
          </div>
        )}

        {/* layer chips — top-left stack */}
        <div className="absolute left-3 top-3 z-10 flex flex-col gap-1">
          <LayerChip icon={Cctv} label="Cameras + FOV" dot="#00D4AA" count={cameras.filter((c) => c.kind !== 'fixed_alpr').length} active={layers.cameras} onClick={() => toggle('cameras')} />
          <LayerChip icon={ScanLine} label="ALPR gates" dot="#00D4AA" count={cameras.filter((c) => c.kind === 'fixed_alpr').length} active={layers.alprGates} onClick={() => toggle('alprGates')} />
          <LayerChip icon={Navigation} label="Drones" dot="#4CC9F0" count={drones.length} active={layers.drones} onClick={() => toggle('drones')} />
          <LayerChip icon={ShieldCheck} label="Guards" dot="#00D4AA" count={guards.filter((g) => g.status !== 'off_duty').length} active={layers.guards} onClick={() => toggle('guards')} />
          <LayerChip icon={Activity} label="Audio sensors" dot="#5C6B8A" count={sensors.length} active={layers.audio} onClick={() => toggle('audio')} />
          <LayerChip icon={Flame} label="Alert heat" dot="#E71D36" count={heatCount} active={layers.heat} onClick={() => toggle('heat')} />
          <LayerChip icon={Tag} label="Zones" dot="#5C6B8A" count={geo.zones.length} active={layers.zones} onClick={() => toggle('zones')} />
          <LayerChip icon={Siren} label="Alert markers" dot="#FF9F1C" count={openAlerts.length} active={layers.alerts} onClick={() => toggle('alerts')} />
        </div>

        {/* mode chips — top-right, beside legend */}
        <div className="absolute right-16 top-3 z-10 flex rounded-sm border border-line bg-surface-solid/90 p-0.5 backdrop-blur-sm">
          {(['live', 'replay'] as MapMode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={cn(
                'h-6 rounded-sm px-3 font-sans text-[10px] font-semibold uppercase tracking-[0.12em] transition-colors duration-150',
                mode === m ? (m === 'replay' ? 'bg-warning-dim text-warning' : 'bg-accent-dim text-accent') : 'text-muted hover:text-secondary',
              )}
            >
              {m}
            </button>
          ))}
        </div>

        {/* legend — top-right under compass */}
        <div className="absolute right-3 top-16 z-10">
          <MapLegend />
        </div>
      </motion.div>

      {/* time scrubber */}
      <motion.div initial={{ y: 64 }} animate={{ y: 0 }} transition={{ duration: 0.3, delay: 0.2 }}>
        <TimeScrubber
          active={mode === 'replay'}
          offsetSec={offsetSec}
          onOffsetChange={setOffsetSec}
          alerts={alerts}
        />
      </motion.div>
    </div>
  );
}
