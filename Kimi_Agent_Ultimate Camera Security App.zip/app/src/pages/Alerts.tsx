/**
 * `/alerts` — AI Alert Center (design/alerts.md).
 * Severity KPI tiles (click-to-filter) · sticky filter bar (search, severity /
 * status chips, type select, grouping + sort + mute) · grouped live feed with
 * hover triage, escalation countdowns and fresh-arrival flash.
 * Row click opens the shared AlertDetailDrawer via the `swealth:open-alert`
 * app event (hosted globally by Layout — same drawer as bell/toast clicks).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ShieldCheck, TriangleAlert, Volume2, VolumeX } from 'lucide-react';
import type { Alert, AlertStatus, AlertType, Severity } from '@/lib/types';
import {
  acknowledgeAlert, dispatchGuard, resolveAlert, toggleMute,
  useActiveOrgId, useAlerts, useCanOperate, useGuards, useMuted, useRoutingRules,
} from '@/hooks/useData';
import { OPEN_STATUSES, severityRank } from '@/lib/store';
import { fmtNum } from '@/lib/format';
import { groupAlerts } from '@/components/soc/AlertRow';
import { FilterChip, GhostButton, IconButton, SocInput, ToggleSwitch } from '@/components/soc/primitives';
import { EmptyState, SkeletonRow } from '@/components/soc/feedback';
import { showToast } from '@/components/soc/Toast';
import { SeverityKpis } from '@/components/alerts/SeverityKpis';
import type { SeverityTileSpec } from '@/components/alerts/SeverityKpis';
import { AlertFeedGroup, AlertFeedRow } from '@/components/alerts/AlertFeedRow';
import type { AlertGroup, FeedRowActions } from '@/components/alerts/AlertFeedRow';
import { haversineKm, useDebounced } from '@/components/alpr/pageUtils';
import { usePageTitle } from './Stub';
import { cn } from '@/lib/utils';

const DAY_MS = 24 * 3600_000;
const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low'];
const STATUSES: { id: AlertStatus; label: string }[] = [
  { id: 'new', label: 'NEW' },
  { id: 'acknowledged', label: 'ACK' },
  { id: 'responding', label: 'RESPONDING' },
  { id: 'resolved', label: 'RESOLVED' },
  { id: 'false_alarm', label: 'FALSE ALARM' },
];
const DEFAULT_STATUSES = new Set<AlertStatus>(['new', 'acknowledged', 'responding']);
const ALERT_TYPES: { id: AlertType; label: string }[] = [
  { id: 'hotlist_hit', label: 'Hotlist hit' },
  { id: 'perimeter_breach', label: 'Perimeter breach' },
  { id: 'unidentified_person', label: 'Unidentified person' },
  { id: 'gunshot', label: 'Gunshot' },
  { id: 'drone_anomaly', label: 'Drone anomaly' },
  { id: 'offline_device', label: 'Offline device' },
  { id: 'fire_smoke', label: 'Fire / smoke' },
  { id: 'loitering', label: 'Loitering' },
  { id: 'tailgating', label: 'Tailgating' },
];
const SEV_ACCENT: Record<Severity, string> = {
  critical: '#E71D36',
  high: '#FF9F1C',
  medium: '#4CC9F0',
  low: '#5C6B8A',
};

function hourlyBuckets(alerts: Alert[], hours: number, pred: (a: Alert) => boolean): number[] {
  const now = Date.now();
  const buckets = new Array(hours).fill(0) as number[];
  for (const a of alerts) {
    if (!pred(a)) continue;
    const ageH = Math.floor((now - new Date(a.created_at).getTime()) / 3600_000);
    if (ageH >= 0 && ageH < hours) buckets[hours - 1 - ageH] += 1;
  }
  return buckets;
}

export default function Alerts() {
  usePageTitle('SWEALTH OS — AI Alert Center', 'Real-time AI-triaged security alerts with evidence, routing and response workflow.');
  const orgId = useActiveOrgId();
  const allAlerts = useAlerts();
  const rules = useRoutingRules();
  const guards = useGuards();
  const canOperate = useCanOperate();
  const muted = useMuted();

  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebounced(query, 150);
  const [severities, setSeverities] = useState<Set<Severity>>(new Set());
  const [statuses, setStatuses] = useState<Set<AlertStatus>>(new Set(DEFAULT_STATUSES));
  const [typeFilter, setTypeFilter] = useState<AlertType | ''>('');
  const [groupBySource, setGroupBySource] = useState(true);
  const [sortMode, setSortMode] = useState<'newest' | 'severity'>('newest');
  const [escalatingOnly, setEscalatingOnly] = useState(false);

  useEffect(() => {
    setReady(false);
    const t = setTimeout(() => setReady(true), 550);
    return () => clearTimeout(t);
  }, [orgId]);

  /* ── derivations ───────────────────────────────────────────────────────── */
  const openAlerts = useMemo(() => allAlerts.filter((a) => OPEN_STATUSES.has(a.status)), [allAlerts]);
  const sevCounts = useMemo(() => {
    const m: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0 };
    for (const a of openAlerts) m[a.severity]++;
    return m;
  }, [openAlerts]);
  const resolved24h = useMemo(
    () => allAlerts.filter((a) => (a.status === 'resolved' || a.status === 'false_alarm') && Date.now() - new Date(a.resolved_at ?? a.updated_at).getTime() < DAY_MS),
    [allAlerts],
  );
  const unackedCritical = useMemo(() => openAlerts.some((a) => a.severity === 'critical' && a.status === 'new'), [openAlerts]);

  const overrunning = useMemo(() => {
    const now = Date.now();
    return openAlerts.filter((a) => {
      if (a.status !== 'new') return false;
      if (a.escalated) return true;
      const rule = rules.find((r) => r.enabled && r.severity === a.severity);
      return !!rule && (now - new Date(a.created_at).getTime()) / 1000 > rule.escalate_after_sec;
    });
  }, [openAlerts, rules]);

  const filtered = useAlerts({
    query: debouncedQuery || undefined,
    severities: [...severities],
    statuses: [...statuses],
    types: typeFilter ? [typeFilter] : undefined,
  });
  const visible = useMemo(() => {
    // hook treats an empty status array as "no filter" — but a fully
    // deselected status chip row must yield an empty queue instead
    if (statuses.size === 0) return [];
    if (!escalatingOnly) return filtered;
    const ids = new Set(overrunning.map((a) => a.id));
    return filtered.filter((a) => ids.has(a.id));
  }, [filtered, escalatingOnly, overrunning, statuses]);

  const groups = useMemo<AlertGroup[]>(() => {
    if (!groupBySource) return [];
    const g = groupAlerts(visible);
    if (sortMode === 'severity') {
      const maxSev = (grp: AlertGroup) => Math.max(...grp.children.map((c) => severityRank(c.severity)));
      g.sort((x, y) => maxSev(y) - maxSev(x) || y.head.created_at.localeCompare(x.head.created_at));
    }
    return g;
  }, [visible, groupBySource, sortMode]);

  const flatSorted = useMemo(() => {
    if (groupBySource) return [];
    const arr = [...visible];
    if (sortMode === 'severity') arr.sort((a, b) => severityRank(b.severity) - severityRank(a.severity) || b.created_at.localeCompare(a.created_at));
    return arr;
  }, [visible, groupBySource, sortMode]);

  /* ── fresh-arrival tracking (flash + entrance, 1.5s) ───────────────────── */
  const knownIds = useRef<Set<string>>(new Set());
  const [freshIds, setFreshIds] = useState<Set<string>>(new Set());
  useEffect(() => {
    if (!ready) return;
    const now = Date.now();
    const firstRun = knownIds.current.size === 0;
    const arrivals: string[] = [];
    for (const a of allAlerts) {
      if (!knownIds.current.has(a.id)) {
        knownIds.current.add(a.id);
        if (!firstRun && now - new Date(a.created_at).getTime() < 20_000) arrivals.push(a.id);
      }
    }
    if (firstRun || !arrivals.length) return;
    setFreshIds((prev) => new Set([...prev, ...arrivals]));
    const t = setTimeout(() => {
      setFreshIds((prev) => {
        const next = new Set(prev);
        for (const id of arrivals) next.delete(id);
        return next;
      });
    }, 1600);
    return () => clearTimeout(t);
  }, [allAlerts, ready]);

  /* ── actions ───────────────────────────────────────────────────────────── */
  const openDrawer = useCallback((a: Alert) => {
    window.dispatchEvent(new CustomEvent('swealth:open-alert', { detail: { alertId: a.id } }));
  }, []);
  const onAck = useCallback((a: Alert) => {
    acknowledgeAlert(a.id);
    showToast({ severity: 'low', title: `Acknowledged — ${a.title}`, body: 'Recorded operator + timestamp' });
  }, []);
  const onResolve = useCallback((a: Alert) => {
    resolveAlert(a.id, 'resolved', 'Resolved from alert feed quick action');
    showToast({ severity: 'medium', title: `Resolved — ${a.title}` });
  }, []);
  const onDispatch = useCallback(
    (a: Alert) => {
      const candidates = guards.filter((g) => g.status === 'on_duty');
      if (!candidates.length) {
        showToast({ severity: 'high', title: 'No on-duty guard available', body: 'Dispatch queue empty — escalate to supervisor' });
        return;
      }
      let best = candidates[0];
      let bestD = Infinity;
      for (const g of candidates) {
        const d = haversineKm(g.lat, g.lng, a.lat, a.lng);
        if (d < bestD) {
          bestD = d;
          best = g;
        }
      }
      dispatchGuard(best.id, a.id);
      showToast({ severity: 'high', title: `${best.full_name} dispatched`, body: `${bestD.toFixed(1)}km to ${a.source_name} · status → responding` });
    },
    [guards],
  );
  const actions: FeedRowActions = useMemo(
    () => ({ onOpen: openDrawer, onAck, onResolve, onDispatch }),
    [openDrawer, onAck, onResolve, onDispatch],
  );

  /* ── KPI tiles ─────────────────────────────────────────────────────────── */
  const resolvedActive = statuses.has('resolved') && statuses.has('false_alarm') && !statuses.has('new');
  const tiles: SeverityTileSpec[] = useMemo(
    () => [
      ...SEVERITIES.map((sev) => ({
        id: sev,
        label: sev,
        count: sevCounts[sev],
        spark: hourlyBuckets(allAlerts, 24, (a) => a.severity === sev).map((v) => v + 0.15),
        accent: SEV_ACCENT[sev],
        active: severities.has(sev),
        pulse: sev === 'critical' && unackedCritical,
        onToggle: () =>
          setSeverities((prev) => {
            const next = new Set(prev);
            if (next.has(sev)) next.delete(sev);
            else next.add(sev);
            return next;
          }),
      })),
      {
        id: 'resolved',
        label: 'Resolved 24H',
        count: resolved24h.length,
        spark: hourlyBuckets(allAlerts, 24, (a) => a.status === 'resolved' || a.status === 'false_alarm').map((v) => v + 0.15),
        accent: '#00D4AA',
        active: resolvedActive,
        onToggle: () =>
          setStatuses((prev) => {
            const onlyResolved = prev.has('resolved') && prev.has('false_alarm') && !prev.has('new');
            return onlyResolved ? new Set(DEFAULT_STATUSES) : new Set<AlertStatus>(['resolved', 'false_alarm']);
          }),
      },
    ],
    [sevCounts, allAlerts, severities, unackedCritical, resolved24h.length, resolvedActive],
  );

  /* ── filter helpers ────────────────────────────────────────────────────── */
  const isFiltered =
    !!debouncedQuery || severities.size > 0 || typeFilter !== '' || escalatingOnly ||
    !(statuses.size === DEFAULT_STATUSES.size && [...DEFAULT_STATUSES].every((s) => statuses.has(s)));
  const resetFilters = useCallback(() => {
    setQuery('');
    setSeverities(new Set());
    setStatuses(new Set(DEFAULT_STATUSES));
    setTypeFilter('');
    setEscalatingOnly(false);
  }, []);
  const toggleStatus = (s: AlertStatus) =>
    setStatuses((prev) => {
      const next = new Set(prev);
      if (next.has(s)) next.delete(s);
      else next.add(s);
      return next;
    });

  const allClear = !isFiltered && openAlerts.length === 0;

  return (
    <div className="scan-grid flex h-full flex-col gap-3 bg-canvas p-4">
      {/* severity KPI tiles */}
      {!ready ? (
        <div className="grid shrink-0 grid-cols-5 gap-3">
          {Array.from({ length: 5 }, (_, i) => (
            <SkeletonRow key={i} variant="kpi" className="h-[72px]" />
          ))}
        </div>
      ) : (
        <SeverityKpis tiles={tiles} />
      )}

      {/* filter bar */}
      <div className="flex shrink-0 flex-wrap items-center gap-2 rounded-sm border border-line bg-surface px-3 py-2 backdrop-blur-sm">
        <div className="w-64">
          <SocInput value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search titles + AI summaries…" aria-label="Search alerts" />
        </div>
        <span className="h-4 w-px bg-line-strong" />
        {SEVERITIES.map((sev) => (
          <FilterChip key={sev} active={severities.has(sev)} onClick={() => setSeverities((prev) => {
            const next = new Set(prev);
            if (next.has(sev)) next.delete(sev);
            else next.add(sev);
            return next;
          })}>
            {sev} <span className="ml-1 font-mono text-[9px] opacity-80">{sevCounts[sev]}</span>
          </FilterChip>
        ))}
        <span className="h-4 w-px bg-line-strong" />
        {STATUSES.map((s) => (
          <FilterChip key={s.id} active={statuses.has(s.id)} onClick={() => toggleStatus(s.id)}>
            {s.label}
          </FilterChip>
        ))}
        <FilterChip active={statuses.size === STATUSES.length} onClick={() => setStatuses(new Set(STATUSES.map((s) => s.id)))}>
          ALL
        </FilterChip>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value as AlertType | '')}
          className="h-8 rounded-sm border border-line bg-inset px-2 font-sans text-[11px] text-primary focus:border-accent focus:outline-none"
          aria-label="Filter by alert type"
        >
          <option value="">ALL TYPES</option>
          {ALERT_TYPES.map((t) => (
            <option key={t.id} value={t.id}>{t.label}</option>
          ))}
        </select>
        <AnimatePresence>
          {overrunning.length >= 2 && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              onClick={() => setEscalatingOnly((v) => !v)}
              className={cn(
                'flex h-6 items-center gap-1.5 rounded-full border px-2.5 font-sans text-[10px] font-semibold uppercase tracking-[0.10em] transition-colors',
                escalatingOnly ? 'border-warning/50 bg-warning-dim text-warning' : 'border-warning/30 bg-warning-dim/50 text-warning hover:bg-warning-dim',
              )}
            >
              <TriangleAlert size={11} /> Escalating {overrunning.length}
            </motion.button>
          )}
        </AnimatePresence>
        <span className="ml-auto flex items-center gap-2">
          <span className="flex items-center gap-1.5">
            <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.10em] text-secondary">Group by source</span>
            <ToggleSwitch on={groupBySource} onChange={setGroupBySource} tooltip="Collapse repeats from the same source + type" />
          </span>
          <GhostButton className="h-7 px-2 text-[10px]" onClick={() => setSortMode((m) => (m === 'newest' ? 'severity' : 'newest'))} tooltip="Toggle feed sort order">
            {sortMode === 'newest' ? 'NEWEST' : 'SEVERITY'}
          </GhostButton>
          <IconButton tooltip={muted ? 'Unmute alert ping' : 'Mute alert ping'} onClick={toggleMute}>
            {muted ? <VolumeX size={13} /> : <Volume2 size={13} />}
          </IconButton>
          {isFiltered && (
            <GhostButton className="h-7 px-2 text-[10px]" onClick={resetFilters}>
              Reset
            </GhostButton>
          )}
        </span>
      </div>

      {/* feed */}
      <div className="flex min-h-0 flex-1 flex-col rounded-sm border border-line bg-surface backdrop-blur-sm">
        <div className="flex h-8 shrink-0 items-center justify-between border-b border-line px-3">
          <span className="font-sans text-[10px] font-semibold uppercase tracking-[0.12em] text-muted">
            Alert feed {groupBySource && groups.length > 0 ? `· ${groups.length} groups` : `· ${visible.length} alerts`}
          </span>
          <span className="font-mono text-[10px] text-muted">
            {openAlerts.length} OPEN{overrunning.length > 0 ? ` · ${overrunning.length} OVERRUNNING` : ''}
          </span>
        </div>
        {!ready ? (
          <div className="flex-1 overflow-hidden">
            {Array.from({ length: 8 }, (_, i) => (
              <SkeletonRow key={i} />
            ))}
          </div>
        ) : visible.length === 0 ? (
          allClear ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-2 p-6 text-center">
              <ShieldCheck size={32} className="animate-live-pulse text-accent" strokeWidth={1.5} />
              <div className="font-sans text-[13px] font-medium text-primary">All clear — no active alerts</div>
              <p className="font-sans text-[12px] text-muted">{fmtNum(resolved24h.length)} alerts resolved in the last 24h</p>
              <GhostButton className="mt-1" onClick={() => setStatuses(new Set(STATUSES.map((s) => s.id)))}>
                View resolved
              </GhostButton>
            </div>
          ) : (
            <EmptyState
              icon={ShieldCheck}
              heading="Queue clear — no active alerts match these filters"
              copy={`${fmtNum(resolved24h.length)} alerts resolved in the last 24h`}
              actionLabel="View resolved"
              onAction={() => setStatuses(new Set(['resolved', 'false_alarm']))}
              className="flex-1"
            />
          )
        ) : (
          <div className="min-h-0 flex-1 overflow-y-auto">
            {groupBySource
              ? groups.map((g) => (
                  <AlertFeedGroup key={g.key} group={g} rules={rules} query={debouncedQuery} canOperate={canOperate} freshIds={freshIds} actions={actions} />
                ))
              : flatSorted.map((a) => (
                  <AlertFeedRow
                    key={a.id}
                    alert={a}
                    rule={rules.find((r) => r.enabled && r.severity === a.severity)}
                    query={debouncedQuery}
                    canOperate={canOperate}
                    fresh={freshIds.has(a.id)}
                    {...actions}
                  />
                ))}
          </div>
        )}
      </div>
    </div>
  );
}
