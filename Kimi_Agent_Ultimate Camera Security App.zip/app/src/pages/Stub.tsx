/** Placeholder page — page agents replace stubs with real implementations. */
import { useEffect } from 'react';
import { Construction } from 'lucide-react';

export function usePageTitle(title: string, description?: string) {
  useEffect(() => {
    document.title = title;
    if (description) {
      let meta = document.querySelector<HTMLMetaElement>('meta[name="description"]');
      if (!meta) {
        meta = document.createElement('meta');
        meta.name = 'description';
        document.head.appendChild(meta);
      }
      meta.content = description;
    }
  }, [title, description]);
}

export default function Stub({ name, route, bare = false }: { name: string; route: string; bare?: boolean }) {
  usePageTitle(`SWEALTH OS — ${name}`);
  return (
    <div className={bare ? 'flex h-screen items-center justify-center bg-canvas scan-grid' : 'flex h-full items-center justify-center scan-grid'}>
      <div className="rounded-sm border border-line bg-surface p-8 text-center backdrop-blur-sm">
        <Construction size={28} className="mx-auto text-muted" strokeWidth={1.5} />
        <h2 className="mt-3 font-sans text-[16px] font-semibold text-primary">{name}</h2>
        <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.12em] text-muted">
          {route} · module under construction — page agent inbound
        </p>
      </div>
    </div>
  );
}
