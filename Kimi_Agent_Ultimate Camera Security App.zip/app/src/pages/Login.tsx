/**
 * `/login` — Secure Terminal (login.md). The only page outside the app shell.
 * Dark aerial backdrop + GSAP boot sequence + guest/operator entry paths.
 * Session restore: valid localStorage session redirects to `/` automatically.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import gsap from 'gsap';
import { useCameras, useClock, useOrg, useThreatLevel } from '@/hooks/useData';
import { fmtTime } from '@/lib/format';
import { usePageTitle } from './Stub';
import { ApertureMark } from '@/components/login/ApertureMark';
import { BootLog } from '@/components/login/BootLog';
import type { BootLine, BootLogHandle } from '@/components/login/BootLog';
import { AuthForm } from '@/components/login/AuthForm';
import { SEEN_BOOT_KEY, clearSession, getSession } from '@/components/login/session';
import { lsGet, lsSet } from '@/components/settings/shared';
import { cn } from '@/lib/utils';

const THREAT_TONE: Record<string, 'accent' | 'info' | 'warning' | 'danger'> = {
  LOW: 'accent', GUARDED: 'info', ELEVATED: 'warning', HIGH: 'danger',
};

export default function Login() {
  usePageTitle('SWEALTH OS — Secure Sign In', 'Authenticate into the SWEALTH OS community safety platform.');
  const navigate = useNavigate();
  const org = useOrg();
  const cameras = useCameras();
  const threat = useThreatLevel();
  const now = useClock(1000);

  const cardRef = useRef<HTMLDivElement>(null);
  const backdropRef = useRef<HTMLImageElement>(null);
  const bootRef = useRef<BootLogHandle>(null);

  const existing = useMemo(() => getSession(), []);
  const [restoreCancelled, setRestoreCancelled] = useState(false);
  const restoring = !!existing && !restoreCancelled;

  const skipMotion = useMemo(
    () =>
      lsGet(SEEN_BOOT_KEY, false) ||
      (typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches),
    [],
  );
  const [formReady, setFormReady] = useState(skipMotion);

  const lines = useMemo<BootLine[]>(() => {
    const base: BootLine[] = [
      { text: 'establishing secure channel …', status: 'OK', tone: 'accent' },
      { text: `loading tenant profile: ${org.name.toUpperCase()} …`, status: 'OK', tone: 'accent' },
      { text: 'realtime engine …', status: 'CONNECTED', tone: 'accent' },
      { text: `${cameras.length} camera streams …`, status: 'READY', tone: 'accent' },
      { text: 'threat level:', status: threat, tone: THREAT_TONE[threat] ?? 'info' },
    ];
    if (restoring) base.push({ text: 'session restored — redirecting …', tone: 'info' });
    return base;
  }, [org.name, cameras.length, threat, restoring]);

  /* intro GSAP timeline: backdrop fade, card rise, aperture draw, zoom loop */
  useEffect(() => {
    if (skipMotion) return;
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ onComplete: () => lsSet(SEEN_BOOT_KEY, true) });
      tl.fromTo(backdropRef.current, { opacity: 0 }, { opacity: 0.25, duration: 0.8, ease: 'power1.out' }, 0);
      tl.fromTo(cardRef.current, { y: 24, opacity: 0 }, { y: 0, opacity: 1, duration: 0.4, ease: 'power2.out' }, 0.25);

      // aperture mark: blades draw in + ring rotates into place
      const ring = cardRef.current?.querySelector('.ap-ring');
      const blades = cardRef.current?.querySelectorAll('.ap-blade');
      const iris = cardRef.current?.querySelector('.ap-iris');
      const prep = (el: Element) => {
        const len = (el as SVGGeometryElement).getTotalLength?.() ?? 80;
        gsap.set(el, { strokeDasharray: len, strokeDashoffset: len });
        return len;
      };
      if (ring) {
        prep(ring);
        tl.fromTo(ring, { rotation: -90, transformOrigin: '50% 50%' }, { rotation: 0, duration: 0.5, ease: 'power2.out' }, 0.4);
        tl.to(ring, { strokeDashoffset: 0, duration: 0.5, ease: 'power1.inOut' }, 0.4);
      }
      blades?.forEach((b, i) => {
        prep(b);
        tl.to(b, { strokeDashoffset: 0, duration: 0.3, ease: 'power1.out' }, 0.55 + i * 0.06);
      });
      if (iris) {
        prep(iris);
        tl.to(iris, { strokeDashoffset: 0, duration: 0.25 }, 0.95);
      }

      // barely-perceptible slow zoom, GPU transform only
      tl.to(backdropRef.current, { scale: 1.06, duration: 40, yoyo: true, repeat: -1, ease: 'sine.inOut' }, 0.8);
    });
    return () => ctx.revert();
  }, [skipMotion]);

  /* session restore: brief boot, then auto-redirect */
  useEffect(() => {
    if (!restoring) return;
    const t = setTimeout(() => navigate('/', { replace: true }), skipMotion ? 400 : 2400);
    return () => clearTimeout(t);
  }, [restoring, skipMotion, navigate]);

  const handleSuccess = () => {
    lsSet(SEEN_BOOT_KEY, true);
    if (skipMotion) {
      navigate('/', { replace: true });
      return;
    }
    gsap.to(cardRef.current, {
      scale: 0.98,
      opacity: 0,
      duration: 0.3,
      ease: 'power2.in',
      onComplete: () => navigate('/', { replace: true }),
    });
  };

  return (
    <div className="relative flex min-h-[100dvh] w-screen items-center justify-center overflow-hidden bg-canvas">
      {/* backdrop: aerial estate at 25% under navy overlay + scan-grid + vignette */}
      <img
        ref={backdropRef}
        src="/login-backdrop.jpg"
        alt=""
        draggable={false}
        onError={(e) => ((e.target as HTMLImageElement).style.display = 'none')}
        className="pointer-events-none absolute inset-0 h-full w-full object-cover"
        style={{ opacity: 0.25 }}
      />
      <div className="pointer-events-none absolute inset-0 bg-canvas/70" />
      <div className="scan-grid pointer-events-none absolute inset-0" />
      <div
        className="pointer-events-none absolute inset-0"
        style={{ boxShadow: 'inset 0 0 180px 60px #060D1A' }}
      />

      {/* terminal card */}
      <div
        ref={cardRef}
        className="relative z-10 w-[400px] max-w-[calc(100vw-32px)] rounded-sm border border-line-strong bg-surface-solid p-6 shadow-drawer"
        style={skipMotion ? undefined : { opacity: 0 }}
      >
        {/* brand block */}
        <div className="mb-4 flex items-center gap-3">
          <ApertureMark size={40} />
          <div>
            <div className="font-sans text-[16px] font-semibold tracking-[0.08em] text-primary">
              SWEALTH <span className="font-mono text-accent">OS</span>
            </div>
            <div className="font-mono text-[9px] uppercase tracking-[0.12em] text-muted">
              Community safety platform · v1.4.2
            </div>
          </div>
        </div>

        {/* boot log */}
        <BootLog
          ref={bootRef}
          lines={lines}
          instant={skipMotion}
          startDelay={skipMotion ? 0 : 0.75}
          onComplete={() => setFormReady(true)}
          className="mb-4"
        />

        {/* auth form (revealed after boot) */}
        <div
          className={cn('transition-all duration-300', formReady ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-2 opacity-0')}
          aria-hidden={!formReady}
        >
          {restoring ? (
            <div className="text-center">
              <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.08em] text-info">
                Active session — {existing?.name}
              </p>
              <button
                onClick={() => {
                  clearSession();
                  setRestoreCancelled(true);
                }}
                className="font-sans text-[11px] font-semibold uppercase tracking-[0.06em] text-secondary underline underline-offset-2 transition-colors hover:text-accent"
              >
                Sign in as different user
              </button>
            </div>
          ) : (
            <AuthForm
              onBootLog={(text, tone) => bootRef.current?.append({ text, status: tone === 'danger' ? '✕' : '✓', tone })}
              onSuccess={handleSuccess}
            />
          )}
        </div>
      </div>

      {/* footer strip */}
      <div className="absolute inset-x-0 bottom-3 z-10 flex items-center justify-center gap-2 font-mono text-[9px] uppercase tracking-[0.10em] text-muted">
        <span>Tenant: {org.name}</span>
        <span className="text-line-strong">·</span>
        <span>SAST {fmtTime(now)}</span>
        <span className="text-line-strong">·</span>
        <span className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 animate-live-pulse rounded-full bg-accent" />
          Systems nominal
        </span>
      </div>
    </div>
  );
}
