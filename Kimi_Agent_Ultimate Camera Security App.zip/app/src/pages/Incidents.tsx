/**
 * `/incidents` — Case Management (design/incidents.md).
 * Header with live stat chips + NEW CASE · four-column status board with
 * drag-and-drop transitions · 560px case drawer · PDF evidence-pack export.
 */
import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { FolderOpen, Plus } from 'lucide-react';
import type { Incident, IncidentPriority, IncidentStatus } from '@/lib/types';
import {
  updateIncident,
  useActiveOrgId,
  useAlerts,
  useCanOperate,
  useEvidence,
  useIncidents,
  usePlateReads,
} from '@/hooks/useData';
import { EmptyState, FilterChip, RouteErrorBoundary, SkeletonRow, showToast } from '@/components/soc';
import { CaseBoard, BOARD_STATUSES } from '@/components/incidents/CaseBoard';
import { NewCaseModal } from '@/components/incidents/NewCaseModal';
import { IncidentDrawer } from '@/components/incidents/IncidentDrawer';
import { usePageTitle } from './Stub';
import { cn } from '@/lib/utils';

const PRIORITIES: IncidentPriority[] = ['critical', 'high', 'medium', 'low'];
const DAY_MS = 24 * 3600_000;

export default function Incidents() {
  usePageTitle('SWEALTH OS — Case Management', 'Incident case files, linked evidence, investigation workflow and PDF evidence export.');
  const orgId = useActiveOrgId();
  const incidents = useIncidents();
  const alerts = useAlerts();
  const plateReads = usePlateReads();
  const evidence = useEvidence();
  const canOperate = useCanOperate();

  const [ready, setReady] = useState(false);
  const [statusFilter, setStatusFilter] = useState<IncidentStatus | null>(null);
  const [priorityFilter, setPriorityFilter] = useState<IncidentPriority | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [newCaseOpen, setNewCaseOpen] = useState(false);

  useEffect(() => {
    setReady(false);
    setSelectedId(null);
    const t = setTimeout(() => setReady(true), 550);
    return () => clearTimeout(t);
  }, [orgId]);

  /* header stats */
  const counts = useMemo(() => {
    const m = new Map<IncidentStatus, number>();
    for (const s of BOARD_STATUSES) m.set(s.id, 0);
    for (const i of incidents) m.set(i.status, (m.get(i.status) ?? 0) + 1);
    return m;
  }, [incidents]);

  const avgCloseDays = useMemo(() => {
    const closed = incidents.filter((i) => i.closed_at);
    if (closed.length === 0) return null;
    const sum = closed.reduce(
      (s, i) => s + (new Date(i.closed_at!).getTime() - new Date(i.created_at).getTime()) / DAY_MS,
      0,
    );
    return sum / closed.length;
  }, [incidents]);

  /* filtered + live selected incident */
  const visible = useMemo(
    () =>
      incidents.filter(
        (i) =>
          (statusFilter === null || i.status === statusFilter) &&
          (priorityFilter === null || i.priority === priorityFilter),
      ),
    [incidents, statusFilter, priorityFilter],
  );
  const selected = useMemo(() => incidents.find((i) => i.id === selectedId) ?? null, [incidents, selectedId]);

  const openAlerts = useMemo(() => alerts.filter((a) => ['new', 'acknowledged', 'responding'].includes(a.status)), [alerts]);
  const hotlistReads = useMemo(() => plateReads.filter((r) => r.hotlist_hit).slice(0, 40), [plateReads]);

  /* status change (board DnD + drawer stepper), confirmValue = disposition | SAPS ref */
  const changeStatus = (id: string, target: IncidentStatus, confirmValue?: string) => {
    const inc = incidents.find((i) => i.id === id);
    if (!inc || inc.status === target) return;
    if (target === 'closed') {
      updateIncident(id, { status: 'closed', disposition: confirmValue ?? 'Case closed', addNote: `Case closed — ${confirmValue ?? 'disposition not recorded'}` });
      showToast({ severity: 'low', title: `${inc.case_no} closed`, body: confirmValue ?? '' });
    } else if (target === 'escalated_saps') {
      updateIncident(id, { status: 'escalated_saps', addNote: `Escalated to SAPS — reference ${confirmValue ?? 'PENDING'}` });
      showToast({ severity: 'high', title: `${inc.case_no} escalated to SAPS`, body: `Ref ${confirmValue ?? 'pending'}` });
    } else {
      updateIncident(id, { status: target });
      showToast({ severity: 'low', title: `${inc.case_no} → ${target.replace('_', ' ').toUpperCase()}`, body: inc.title });
    }
  };

  const chipColor: Record<IncidentStatus, string> = {
    open: 'text-warning',
    investigating: 'text-info',
    escalated_saps: 'text-danger',
    closed: 'text-accent',
  };

  return (
    <RouteErrorBoundary>
      <div className="flex h-full min-h-0 flex-col gap-3 p-3">
        {/* header */}
        <header className="flex shrink-0 flex-wrap items-center gap-3">
          <div className="min-w-0">
            <h1 className="font-sans text-[18px] font-semibold leading-6 tracking-[-0.01em] text-primary">
              Case Management
            </h1>
            <div className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.08em] text-muted">
              {incidents.length} CASES · {counts.get('open') ?? 0} OPEN · {counts.get('escalated_saps') ?? 0} ESCALATED TO
              SAPS · {avgCloseDays !== null ? `AVG TIME-TO-CLOSE ${avgCloseDays.toFixed(1)} DAYS` : 'NO CLOSED CASES YET'}
            </div>
          </div>

          {/* stat chips */}
          <div className="ml-auto flex flex-wrap items-center gap-1.5">
            {BOARD_STATUSES.map((s, i) => (
              <motion.button
                key={s.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04, duration: 0.18 }}
                onClick={() => setStatusFilter((f) => (f === s.id ? null : s.id))}
                title={`Filter board — ${s.label}`}
                className={cn(
                  'flex h-6 items-center gap-1.5 rounded-full border px-2.5 font-sans text-[10px] font-semibold uppercase tracking-[0.10em] transition-all duration-150',
                  statusFilter === s.id
                    ? 'border-accent/30 bg-accent-dim text-accent'
                    : 'border-transparent bg-raised text-secondary hover:text-primary',
                )}
              >
                <span className={cn('font-mono text-[11px]', chipColor[s.id])}>{counts.get(s.id) ?? 0}</span>
                {s.label}
              </motion.button>
            ))}
            <span className="mx-1 h-4 w-px bg-line-strong" />
            {PRIORITIES.map((p) => (
              <FilterChip key={p} active={priorityFilter === p} onClick={() => setPriorityFilter((f) => (f === p ? null : p))}>
                {p}
              </FilterChip>
            ))}
            <button
              disabled={!canOperate}
              onClick={() => setNewCaseOpen(true)}
              title={canOperate ? 'Open a new case' : 'Requires OPERATOR role'}
              className={cn(
                'ml-1 flex h-8 items-center gap-1.5 rounded-sm bg-accent px-3 font-sans text-[12px] font-semibold uppercase tracking-[0.02em] text-on-accent',
                'transition-all duration-100 hover:brightness-110 hover:-translate-y-px active:scale-[0.97]',
                'disabled:cursor-not-allowed disabled:bg-raised disabled:text-muted',
              )}
            >
              <Plus size={14} /> New case
            </button>
          </div>
        </header>

        {/* board */}
        {!ready ? (
          <div className="flex flex-1 gap-3 overflow-hidden">
            {BOARD_STATUSES.map((s) => (
              <div key={s.id} className="min-w-[280px] flex-1 space-y-2">
                <SkeletonRow />
                <SkeletonRow />
                <SkeletonRow />
              </div>
            ))}
          </div>
        ) : incidents.length === 0 ? (
          <div className="flex-1 rounded-sm border border-line bg-surface">
            <EmptyState
              icon={FolderOpen}
              heading="No cases on the board"
              copy="Open a case from scratch or link live alerts and hotlist sightings into an investigation."
              actionLabel={canOperate ? 'New case' : undefined}
              onAction={canOperate ? () => setNewCaseOpen(true) : undefined}
            />
          </div>
        ) : visible.length === 0 ? (
          <div className="flex-1 rounded-sm border border-line bg-surface">
            <EmptyState
              icon={FolderOpen}
              heading="No cases match these filters"
              copy="Clear the status/priority filters to see the full board."
              actionLabel="Clear filters"
              onAction={() => {
                setStatusFilter(null);
                setPriorityFilter(null);
              }}
            />
          </div>
        ) : (
          <CaseBoard
            incidents={visible}
            alerts={alerts}
            plateReads={plateReads}
            evidence={evidence}
            canOperate={canOperate}
            statusFilter={statusFilter}
            onOpen={setSelectedId}
            onStatusChange={changeStatus}
          />
        )}
      </div>

      <NewCaseModal
        open={newCaseOpen}
        onClose={() => setNewCaseOpen(false)}
        openAlerts={openAlerts}
        hotlistReads={hotlistReads}
        onCreated={(inc: Incident) => {
          setSelectedId(inc.id);
          setStatusFilter(null);
          setPriorityFilter(null);
        }}
      />

      <IncidentDrawer
        incident={selected}
        open={selectedId !== null}
        onClose={() => setSelectedId(null)}
        canOperate={canOperate}
        alerts={alerts}
        plateReads={plateReads}
        onStatusChange={changeStatus}
      />
    </RouteErrorBoundary>
  );
}
